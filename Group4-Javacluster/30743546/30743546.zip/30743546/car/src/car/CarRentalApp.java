package car;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class CarRentalApp {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/CarRentalDB";
    private static final String USER = "root";
    private static final String PASS = "Root@123"; 

    public static void main(String[] args) {
        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASS)) {
            CarManagement carManagement = new CarManagement(conn);
            CustomerManagement customerManagement = new CustomerManagement(conn);
            RentalManagement rentalManagement = new RentalManagement(conn);

            Scanner scanner = new Scanner(System.in);

            while (true) {
                System.out.println("\nCar Rental System");
                System.out.println("1. View Available Cars");
                System.out.println("2. Rent a Car");
                System.out.println("3. Return a Car");
                System.out.println("4. Add Customer");
                System.out.println("5. Exit");
                System.out.print("Choose an option: ");
                int option = scanner.nextInt();

                switch (option) {
                    case 1:
                        carManagement.viewAvailableCars();
                        break;
                    case 2:
                        System.out.print("Enter Car ID to rent: ");
                        int carId = scanner.nextInt();
                        System.out.print("Enter your name: ");
                        String customerName = scanner.next();

                        int customerId = customerManagement.getCustomerIdByName(customerName);
                        if (customerId == -1) {
                            System.out.println("Customer not found. Please add the customer first.");
                        } else {
                            rentalManagement.rentCar(carId, customerId);
                            carManagement.updateCarAvailability(carId, false);
                        }
                        break;
                    case 3:
                        System.out.print("Enter Rental ID to return: ");
                        int rentalId = scanner.nextInt();
                        if (!rentalManagement.returnCar(rentalId)) {
                            System.out.println("Invalid Rental ID.");
                        }
                        break;
                    case 4:
                        System.out.print("Enter customer name: ");
                        String name = scanner.next();
                        System.out.print("Enter phone number: ");
                        String phone = scanner.next();
                        customerManagement.addCustomer(name, phone);
                        break;
                    case 5:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
