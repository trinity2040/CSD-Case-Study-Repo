package car;

import java.sql.*;

public class RentalManagement {
    private Connection conn;

    public RentalManagement(Connection conn) {
        this.conn = conn;
    }

    public void rentCar(int carId, int customerId) throws SQLException {
        String query = "INSERT INTO rentals (car_id, customer_id, rental_date) VALUES (?, ?, CURDATE())";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, carId);
            pstmt.setInt(2, customerId);
            pstmt.executeUpdate();
            System.out.println("Car rented successfully!");
        }
    }

    public boolean returnCar(int rentalId) throws SQLException {
        String query = "SELECT car_id FROM rentals WHERE car_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, rentalId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                int carId = rs.getInt("car_id");

                String updateQuery = "UPDATE cars SET available = TRUE WHERE id = ?";
                try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {
                    updateStmt.setInt(1, carId);
                    updateStmt.executeUpdate();

                    String deleteQuery = "DELETE FROM rentals WHERE rental_id = ?";
                    try (PreparedStatement deleteStmt = conn.prepareStatement(deleteQuery)) {
                        deleteStmt.setInt(1, rentalId);
                        deleteStmt.executeUpdate();
                        System.out.println("Car returned successfully!");
                        return true;
                    }
                }
            }
        }
        return false; // Rental ID not found
    }
}
