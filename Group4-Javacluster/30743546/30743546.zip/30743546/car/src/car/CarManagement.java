package car;

import java.sql.*;

public class CarManagement {
    private Connection conn;

    public CarManagement(Connection conn) {
        this.conn = conn;
    }

    public void viewAvailableCars() throws SQLException {
        String query = "SELECT * FROM cars WHERE available = TRUE";
        try (Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            System.out.println("\nAvailable Cars:");
            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id") + ", Model: " + rs.getString("model") + ", Brand: " + rs.getString("brand"));
            }
        }
    }

    public boolean updateCarAvailability(int carId, boolean isAvailable) throws SQLException {
        String query = "UPDATE cars SET available = ? WHERE id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setBoolean(1, isAvailable);
            pstmt.setInt(2, carId);
            return pstmt.executeUpdate() > 0;
        }
    }
}

