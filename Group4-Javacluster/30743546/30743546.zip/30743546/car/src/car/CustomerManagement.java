package car;

import java.sql.*;

public class CustomerManagement {
    private Connection conn;

    public CustomerManagement(Connection conn) {
        this.conn = conn;
    }

    public int getCustomerIdByName(String name) throws SQLException {
        String query = "SELECT id FROM customers WHERE name = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, name);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        }
        return -1; // Customer not found
    }

    public void addCustomer(String name, String phone) throws SQLException {
        String query = "INSERT INTO customers (name, phone) VALUES (?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, name);
            pstmt.setString(2, phone);
            pstmt.executeUpdate();
            System.out.println("Customer added successfully!");
        }
    }
}

