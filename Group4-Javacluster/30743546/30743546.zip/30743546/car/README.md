# Car Rental Management System

This is a simple Java console application for managing a car rental business. The system is designed to manage cars, customers, and rentals using a MySQL database.

## Features

### 1. **Car Management**
   - **Add New Car**: Allows you to add new cars to the database by entering the car model and brand.
   - **List Cars**: Displays a list of all cars in the system along with their availability status.

### 2. **Customer Management**
   - **Add New Customer**: Add new customers by entering their name and phone number.
   - **List Customers**: Displays a list of all registered customers.

### 3. **Rental Management**
   - **Rent a Car**: Rent out a car to a customer by providing the car ID and customer ID.
   - **Return a Car**: Mark a car as returned by providing the rental ID.

## How to Run

### **1. Prerequisites**

Before running the application, ensure that you have the following installed:

- **Java JDK** (version 8 or higher): [Download here](https://www.oracle.com/java/technologies/javase-downloads.html).
- **MySQL Server**: [Download here](https://dev.mysql.com/downloads/installer/).
- **MySQL Connector/J** (JDBC driver): [Download here](https://dev.mysql.com/downloads/connector/j/).

### **2. Database Setup**

1. **Create the Database and Tables:**

   Use the following SQL script to set up your MySQL database:

    ```sql
    CREATE DATABASE CarRentalDB;

    USE CarRentalDB;

    CREATE TABLE Cars (
        car_id INT AUTO_INCREMENT PRIMARY KEY,
        model VARCHAR(50),
        brand VARCHAR(50),
        available BOOLEAN DEFAULT TRUE
    );

    CREATE TABLE Customers (
        customer_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(50),
        phone VARCHAR(20)
    );

    CREATE TABLE Rentals (
        rental_id INT AUTO_INCREMENT PRIMARY KEY,
        car_id INT,
        customer_id INT,
        rent_date DATE,
        return_date DATE,
        FOREIGN KEY (car_id) REFERENCES Cars(car_id),
        FOREIGN KEY (customer_id) REFERENCES Customers(customer_id)
    );
    ```

### **3. Running the Application**

#### **Option 1: Using an IDE (IntelliJ IDEA, Eclipse, or NetBeans)**

1. **Create a New Project:**
   - Import the project files into your preferred Java IDE.
   
2. **Add MySQL Connector/J:**
   - Add the MySQL JDBC driver (mysql-connector-java.jar) to your project's classpath.

3. **Run the Application:**
   - Locate the `CarRentalApp.java` file in the project explorer.
   - Right-click the file and select "Run" to start the application.

