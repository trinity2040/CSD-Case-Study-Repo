/**
 * 
 */
/**
 * 
 */
module SportsMangementsystem {
	requires java.sql;
}