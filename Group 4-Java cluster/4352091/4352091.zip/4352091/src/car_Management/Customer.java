package car_Management;

import java.sql.*;
import java.util.Scanner;

public class Customer {

    // Private fields to store customer details
    private String name;
    private String email;
    private String phone;
    private String address;

    private static final Scanner scanner = new Scanner(System.in);

    // Constructor to initialize customer details
    public Customer(String name, String email, String phone, String address) {
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.address = address;
    }

    // Getter and Setter methods for customer details
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    // Method to register a new customer
    public static void registerNewCustomer() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.print("Enter customer name: ");
        String name = scanner.nextLine();
        System.out.print("Enter customer email: ");
        String email = scanner.nextLine();
        System.out.print("Enter customer phone number (10 digits): ");
        String phone = scanner.nextLine();
        System.out.print("Enter customer address: ");
        String address = scanner.nextLine();

        Customer customer = new Customer(name, email, phone, address);

        try {
            String sql = "INSERT INTO customer (Name, EMail, phone_number, Address) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = Database.conn.prepareStatement(sql);
            statement.setString(1, customer.getName());
            statement.setString(2, customer.getEmail());
            statement.setString(3, customer.getPhone());
            statement.setString(4, customer.getAddress());
            statement.executeUpdate();
            System.out.println("Customer registered successfully.");
            System.out.println("---------------------------------------------------------------------------------");
            
        } catch (SQLException e) {
            System.out.println("Error registering customer: " + e.getMessage());
            registerNewCustomer();
        }
    }

    // Method to view customer details
    public static void viewCustomerDetails() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.print("Enter Customer ID to view details (or 0 to view all customers): ");
        int customerId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        try {
            String sql;
            PreparedStatement statement;
            if (customerId == 0) {
                sql = "SELECT * FROM Customer";
                statement = Database.conn.prepareStatement(sql);
            } else {
                sql = "SELECT * FROM Customer WHERE customer_id = ?";
                statement = Database.conn.prepareStatement(sql);
                statement.setInt(1, customerId);
            }

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                System.out.println("Customer ID: " + resultSet.getInt("customer_id"));
                System.out.println("Name: " + resultSet.getString("name"));
                System.out.println("Email: " + resultSet.getString("email"));
                System.out.println("Phone Number: " + resultSet.getString("phone_number"));
                System.out.println("Address: " + resultSet.getString("address"));
                System.out.println("-------------");
            }
        } catch (SQLException e) {
            System.out.println("Error fetching customer details: " + e.getMessage());
        }
    }

    // Method to update customer information
    public static void updateCustomerInformation() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("=== Choose your option to update ===");
        System.out.println("1. Name");
        System.out.println("2. Email");
        System.out.println("3. Phone Number");
        System.out.println("4. Address");
        System.out.print("Enter Your Choice: ");
        int choice = scanner.nextInt();
        System.out.print("Enter the Customer ID to update: ");
        int customerId = scanner.nextInt();

        switch (choice) {
            case 1:
                scanner.nextLine();
                System.out.print("Enter new Name: ");
                String name = scanner.nextLine();
                updateCustomerField("Name", name, customerId);
                break;
            case 2:
                scanner.nextLine();
                System.out.print("Enter new Email: ");
                String email = scanner.nextLine();
                updateCustomerField("EMail", email, customerId);
                break;
            case 3:
                scanner.nextLine();
                System.out.print("Enter new customer phone number (10 digits): ");
                String phone = scanner.nextLine();
                updateCustomerField("phone_number", phone, customerId);
                break;
            case 4:
                scanner.nextLine();
                System.out.print("Enter new Address: ");
                String address = scanner.nextLine();
                updateCustomerField("Address", address, customerId);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
                updateCustomerInformation();
                break;
        }
    }

    // Helper method to update a specific customer field
    private static void updateCustomerField(String field, String newValue, int customerId) {
        try {
            String sql = "UPDATE Customer SET " + field + " = ? WHERE customer_id = ?";
            PreparedStatement statement = Database.conn.prepareStatement(sql);
            statement.setString(1, newValue);
            statement.setInt(2, customerId);
            int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated > 0) {
                System.out.println("Customer information updated successfully.");
            } else {
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating customer information: " + e.getMessage());
        }
    }

    // Method to delete a customer
    public static void deleteCustomer() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.print("Enter the Customer ID to delete: ");
        int customerId = scanner.nextInt();

        try {
            String sql = "DELETE FROM Customer WHERE customer_id = ?";
            PreparedStatement statement = Database.conn.prepareStatement(sql);
            statement.setInt(1, customerId);
            int rowsDeleted = statement.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println("Customer deleted successfully.");
            } else {
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting customer: " + e.getMessage());
        }
    }
}
