package car_Management;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class Rental {

    // Private fields for rental details
    private int carId;
    private int customerId;
    private String rentalStartDate;
    private String rentalEndDate;
    private double totalCharges;

    private static final Scanner scanner = new Scanner(System.in);

    // Constructor to initialize rental details
    public Rental(int carId, int customerId, String rentalStartDate, String rentalEndDate, double totalCharges) {
        this.carId = carId;
        this.customerId = customerId;
        this.rentalStartDate = rentalStartDate;
        this.rentalEndDate = rentalEndDate;
        this.totalCharges = totalCharges;
    }

    // Getter and Setter methods for rental details
    public int getCarId() {
        return carId;
    }

    public void setCarId(int carId) {
        this.carId = carId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getRentalStartDate() {
        return rentalStartDate;
    }

    public void setRentalStartDate(String rentalStartDate) {
        this.rentalStartDate = rentalStartDate;
    }

    public String getRentalEndDate() {
        return rentalEndDate;
    }

    public void setRentalEndDate(String rentalEndDate) {
        this.rentalEndDate = rentalEndDate;
    }

    public double getTotalCharges() {
        return totalCharges;
    }

    public void setTotalCharges(double totalCharges) {
        this.totalCharges = totalCharges;
    }

    // Method to rent a car
    public static void rentCar() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.print("Enter the Customer ID: ");
        int customerId = scanner.nextInt();
        System.out.print("Enter the Car ID: ");
        int carId = scanner.nextInt();
        System.out.print("Enter the rental start date (YYYY-MM-DD): ");
        String startDate = scanner.next();
        System.out.print("Enter the rental end date (YYYY-MM-DD): ");
        String endDate = scanner.next();

        try {
            // Check if the car is already rented
            String checkAvailabilitySql = "SELECT * FROM Rental WHERE car_id = ? AND rental_end_date >= ?";
            PreparedStatement checkStmt = Database.conn.prepareStatement(checkAvailabilitySql);
            checkStmt.setInt(1, carId);
            checkStmt.setString(2, startDate);
            ResultSet resultSet = checkStmt.executeQuery();

            if (resultSet.next()) {
                System.out.println("Car is not available for the selected dates.");
                return;
            }

            // Calculate the total rental charge
            String getRateSql = "SELECT Daily_Rate FROM Car WHERE car_id = ?";
            PreparedStatement getRateStmt = Database.conn.prepareStatement(getRateSql);
            getRateStmt.setInt(1, carId);
            ResultSet rateResult = getRateStmt.executeQuery();
            double dailyRate = 0;

            if (rateResult.next()) {
                dailyRate = rateResult.getDouble("Daily_Rate");
            }

            LocalDate start = LocalDate.parse(startDate);
            LocalDate end = LocalDate.parse(endDate);
            long rentalDays = ChronoUnit.DAYS.between(start, end);
            double totalCharge = rentalDays * dailyRate;

            // Create a rental object with calculated details
            Rental rental = new Rental(carId, customerId, startDate, endDate, totalCharge);

            // Insert rental record
            String insertSql = "INSERT INTO Rental (car_id, customer_id, Rental_Start_Date, Rental_End_Date, total_charges) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement insertStmt = Database.conn.prepareStatement(insertSql);
            insertStmt.setInt(1, rental.getCarId());
            insertStmt.setInt(2, rental.getCustomerId());
            insertStmt.setString(3, rental.getRentalStartDate());
            insertStmt.setString(4, rental.getRentalEndDate());
            insertStmt.setDouble(5, rental.getTotalCharges());
            insertStmt.executeUpdate();

            System.out.println("Car rented successfully. Total charge: $" + rental.getTotalCharges());
        } catch (SQLException e) {
            System.out.println("Error renting car: " + e.getMessage());
        }
    }

    // Method to return a rented car
    public static void returnCar() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.print("Enter the Rental ID to return: ");
        int rentalId = scanner.nextInt();

        try {
            // Get rental details
            String getRentalSql = "SELECT car_id FROM Rental WHERE rental_id = ?";
            PreparedStatement getRentalStmt = Database.conn.prepareStatement(getRentalSql);
            getRentalStmt.setInt(1, rentalId);
            ResultSet rentalResult = getRentalStmt.executeQuery();

            if (rentalResult.next()) {
                // Delete the rental record
                String deleteSql = "DELETE FROM Rental WHERE rental_id = ?";
                PreparedStatement deleteStmt = Database.conn.prepareStatement(deleteSql);
                deleteStmt.setInt(1, rentalId);
                int rowsDeleted = deleteStmt.executeUpdate();

                if (rowsDeleted > 0) {
                    System.out.println("Car returned successfully.");
                } else {
                    System.out.println("Rental not found.");
                }
            } else {
                System.out.println("Rental ID not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error returning car: " + e.getMessage());
        }
    }

    // Method to view rental details
    public static void viewRentalDetails() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.print("Enter Rental ID to view details (or 0 to view all rentals): ");
        int rentalId = scanner.nextInt();

        try {
            String sql;
            PreparedStatement statement;
            if (rentalId == 0) {
                sql = "SELECT * FROM Rental";
                statement = Database.conn.prepareStatement(sql);
            } else {
                sql = "SELECT * FROM Rental WHERE rental_id = ?";
                statement = Database.conn.prepareStatement(sql);
                statement.setInt(1, rentalId);
            }

            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                System.out.println("Rental ID: " + resultSet.getInt("rental_id"));
                System.out.println("Car ID: " + resultSet.getInt("car_id"));
                System.out.println("Customer ID: " + resultSet.getInt("customer_id"));
                System.out.println("Start Date: " + resultSet.getString("rental_start_date"));
                System.out.println("End Date: " + resultSet.getString("rental_end_date"));
                System.out.println("Total Charge: $" + resultSet.getDouble("total_charges"));
                System.out.println("-----------------------------------------------------------------------------");
            }
        } catch (SQLException e) {
            System.out.println("Error fetching rental details: " + e.getMessage());
        }
    }
}
