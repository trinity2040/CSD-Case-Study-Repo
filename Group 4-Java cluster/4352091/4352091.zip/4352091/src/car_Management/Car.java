package car_Management;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Car {

    // Scanner for user input
    private static final Scanner scanner = new Scanner(System.in);

    // Method to add a new car to the database
    public static void addNewCar() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.print("Enter car Company: ");
        String Company = scanner.next(); // Get car company from user
        System.out.print("Enter car model: ");
        String model = scanner.next(); // Get car model from user
        System.out.print("Enter car year: ");
        int year = scanner.nextInt(); // Get car manufacturing year from user
        System.out.print("Enter daily rental rate: ");
        double dailyRate = scanner.nextDouble(); // Get daily rental rate from user

        try {
            // SQL query to insert car details into the database
            String sql = "INSERT INTO Car (Company, Model, Year, Daily_Rate) VALUES (?, ?, ?, ?)";
            
            PreparedStatement statement = Database.conn.prepareStatement(sql); // Prepare the SQL statement
            statement.setString(1, Company); // Set company name
            statement.setString(2, model); // Set car model
            statement.setInt(3, year); // Set car year
            statement.setDouble(4, dailyRate); // Set daily rental rate
            statement.executeUpdate(); // Execute the insert operation
            System.out.println("Car added successfully."); // Confirmation message
        } catch (SQLException e) {
            System.out.println("Error adding car: " + e.getMessage()); // Print error message if insertion fails
        }
    }

    // Method to view details of all cars in the database
    public static void viewCarDetails() {
        System.out.println("---------------------------------------------------------------------------------");
        try {
            // SQL query to select all car details
            String sql = "SELECT * FROM Car";
            
            PreparedStatement statement = Database.conn.prepareStatement(sql); // Prepare the SQL statement
            ResultSet resultSet = statement.executeQuery(); // Execute query and get result set

            // Iterate through the result set to display car details
            while (resultSet.next()) {
                System.out.println("---------------------------------------------------------------------------------");
                System.out.println("Car ID: " + resultSet.getInt("car_id"));
                System.out.println("Company: " + resultSet.getString("Company"));
                System.out.println("Model: " + resultSet.getString("model"));
                System.out.println("Year: " + resultSet.getInt("year"));
                System.out.println("Daily Rate: " + resultSet.getDouble("daily_rate"));
            }
        } catch (SQLException e) {
            System.out.println("Error fetching car details: " + e.getMessage()); // Print error message if fetching fails
        }
    }

    // Method to update information of an existing car
    public static void updateCarInformation() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.print("Enter the Car ID to update: ");
        int carId = scanner.nextInt(); // Get car ID to update
        System.out.print("Enter new daily rental rate: ");
        double dailyRate = scanner.nextDouble(); // Get new daily rental rate

        try {
            // SQL query to update daily rental rate based on car ID
            String sql = "UPDATE Car SET daily_rate = ? WHERE car_id = ?";
            
            PreparedStatement statement = Database.conn.prepareStatement(sql); // Prepare the SQL statement
            statement.setDouble(1, dailyRate); // Set new daily rental rate
            statement.setInt(2, carId); // Set car ID
            int rowsUpdated = statement.executeUpdate(); // Execute the update operation

            // Check if the update was successful
            if (rowsUpdated > 0) {
                System.out.println("Car information updated successfully."); // Confirmation message
            } else {
                System.out.println("Car not found."); // Message if car ID is not found
            }
        } catch (SQLException e) {
            System.out.println("Error updating car information: " + e.getMessage()); // Print error message if update fails
        }
    }

    // Method to delete an existing car from the database
    public static void deleteCar() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.print("Enter the Car ID to delete: ");
        int carId = scanner.nextInt(); // Get car ID to delete

        try {
            // SQL query to delete car based on car ID
            String sql = "DELETE FROM Car WHERE car_id = ?";
            
            PreparedStatement st = Database.conn.prepareStatement(sql); // Prepare the SQL statement
            st.setInt(1, carId); // Set car ID
            int rowsDeleted = st.executeUpdate(); // Execute the delete operation

            // Check if the deletion was successful
            if (rowsDeleted > 0) {
                System.out.println("Car deleted successfully."); // Confirmation message
            } else {
                System.out.println("Car not found."); // Message if car ID is not found
            }
        } catch (SQLException e) {
            System.out.println("Error deleting car: " + e.getMessage()); // Print error message if deletion fails
        }
    }
}
