package car_Management;
import java.util.Scanner;

public class Car_Rental_Menu {

    // Scanner for user input
    private static final Scanner scanner = new Scanner(System.in);

    // Display the main menu
    static void main_Menu() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("=== Car Rental Management System ===");
        System.out.println("1. Car Management");
        System.out.println("2. Customer Management");
        System.out.println("3. Rental Management");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt(); // Get user input for menu selection

        // Handle user menu choice
        switch (choice) {
            case 1:
                carManagementMenu(); // Car management menu
                System.out.println("---------------------------------------------------------------------------------");
                break;
            case 2:
                customerManagementMenu(); // Customer management menu
                System.out.println("---------------------------------------------------------------------------------");
                break;
            case 3:
                rentalManagementMenu(); // Rental management menu
                System.out.println("---------------------------------------------------------------------------------");
                break;
            case 4:
                System.out.println("Thank You For Visiting....");
                System.exit(0); // Exit the application
                break;
            default:
            	System.out.println("---------------------------------------------------------------------------------");
                System.out.println("Invalid choice. Please try again.");
                main_Menu(); // Show the main menu again on invalid input
                break;
        }
    }

    // Display the car management menu
    private static void carManagementMenu() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("=== Car Management ===");
        System.out.println("1. Add a New Car");
        System.out.println("2. View Car Details");
        System.out.println("3. Update Car Information");
        System.out.println("4. Delete a Car");
        System.out.println("5. Return to Main Menu");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt(); // Get user input for car management menu

        // Handle user menu choice
        switch (choice) {
            case 1:
                Car.addNewCar(); // Add new car
                System.out.println("---------------------------------------------------------------------------------");
                break;
            case 2:
                Car.viewCarDetails(); // View car details
                System.out.println("---------------------------------------------------------------------------------");
                break;
            case 3:
                Car.updateCarInformation(); // Update car information
                
                System.out.println("---------------------------------------------------------------------------------");
                break;
            case 4:
                Car.deleteCar(); // Delete car
                System.out.println("---------------------------------------------------------------------------------");
                break;
            case 5:
                main_Menu(); // Return to main menu
                break;
            default:
            	System.out.println("---------------------------------------------------------------------------------");
                System.out.println("Invalid choice. Please try again.");
                carManagementMenu(); // Show car management menu again on invalid input
                break;
        }
    }

    // Display the customer management menu
    static void customerManagementMenu() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("=== Customer Management ===");
        System.out.println("1. Register a New Customer");
        System.out.println("2. View Customer Details");
        System.out.println("3. Update Customer Information");
        System.out.println("4. Delete a Customer");
        System.out.println("5. Return to Main Menu");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt(); // Get user input for customer management menu

        // Handle user menu choice
        switch (choice) {
            case 1:
                Customer.registerNewCustomer(); // Register new customer
                break;
            case 2:
                Customer.viewCustomerDetails(); // View customer details
                break;
            case 3:
                Customer.updateCustomerInformation(); // Update customer information
                break;
            case 4:
                Customer.deleteCustomer(); // Delete customer
                break;
            case 5:
                main_Menu(); // Return to main menu
                break;
            default:
            	System.out.println("---------------------------------------------------------------------------------");
                System.out.println("Invalid choice. Please try again.");
                customerManagementMenu(); // Show customer management menu again on invalid input
                break;
        }
    }

    // Display the rental management menu
    private static void rentalManagementMenu() {
        System.out.println("---------------------------------------------------------------------------------");
        System.out.println("=== Rental Management ===");
        System.out.println("1. Rent a Car");
        System.out.println("2. Return a Car");
        System.out.println("3. View Rental Details");
        System.out.println("4. Return to Main Menu");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt(); // Get user input for rental management menu

        // Handle user menu choice
        switch (choice) {
            case 1:
                Rental.rentCar(); // Rent a car
                break;
            case 2:
                Rental.returnCar(); // Return a car
                break;
            case 3:
                Rental.viewRentalDetails(); // View rental details
                break;
            case 4:
                main_Menu(); // Return to main menu
                break;
            default:
            	System.out.println("---------------------------------------------------------------------------------");
                System.out.println("Invalid choice. Please try again.");
                rentalManagementMenu(); // Show rental management menu again on invalid input
                break;
        }
    }
}
