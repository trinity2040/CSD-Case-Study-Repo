package car_Management;

import java.sql.Connection;
import java.sql.DriverManager;

public class Database {
	// Database connection details
    private static final String DB_Url = "jdbc:mysql://localhost:3306/Car_Rental_Db";
    private static final String DB_Username = "Pandu";
    private static final String DB_Password = "Pandu@8790";
    public static Connection conn = null;

    public static void main(String[] args) {
    	System.out.println("---------------------------------------------------------------------------------");
        // Establish database connection
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Load JDBC driver
            conn = DriverManager.getConnection(DB_Url, DB_Username, DB_Password); // Connect to the database
            if (conn != null) {
                System.out.println("Connected to the database successfully.");
                Car_Rental_Menu.main_Menu(); // Display the main menu
            } else {
                System.out.println("Connection failed! Check the Connection and Try gain! ");
            }
        } catch (Exception e) {
            e.printStackTrace(); // Print error details
        }
    }

}
