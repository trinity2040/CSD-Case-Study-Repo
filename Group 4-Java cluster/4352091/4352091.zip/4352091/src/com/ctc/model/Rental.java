package com.ctc.model;

import java.util.Date;

/**
 * Represents a rental record in the car rental system.
 */
public class Rental {

    private int rentalId;
    private int carId;
    private int customerId;
    private Date rentalStartDate;
    private Date rentalEndDate;
    private double totalCharge;

    // Getters and Setters
    public int getRentalId() { return rentalId; }
    public void setRentalId(int rentalId) { this.rentalId = rentalId; }

    public int getCarId() { return carId; }
    public void setCarId(int carId) { this.carId = carId; }

    public int getCustomerId() { return customerId; }
    public void setCustomerId(int customerId) { this.customerId = customerId; }

    public Date getRentalStartDate() { return rentalStartDate; }
    public void setRentalStartDate(Date rentalStartDate) { this.rentalStartDate = rentalStartDate; }

    public Date getRentalEndDate() { return rentalEndDate; }
    public void setRentalEndDate(Date rentalEndDate) { this.rentalEndDate = rentalEndDate; }

    public double getTotalCharge() { return totalCharge; }
    public void setTotalCharge(double totalCharge) { this.totalCharge = totalCharge; }
}
