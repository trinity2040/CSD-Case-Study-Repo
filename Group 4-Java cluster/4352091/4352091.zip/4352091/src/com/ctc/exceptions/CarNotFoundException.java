package com.ctc.exceptions;

/**
 * Exception thrown when a car is not found in the database.
 */
@SuppressWarnings("serial")
public class CarNotFoundException extends Exception {


	public CarNotFoundException(String message) {
        super(message);
    }
}
