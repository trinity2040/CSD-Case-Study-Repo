package com.ctc.exceptions;

/**
 * Exception thrown when a rental record is not found in the database.
 */
public class RentalNotFoundException extends Exception {

    public RentalNotFoundException(String message) {
        super(message);
    }
}
