package com.ctc.exceptions;

/**
 * Exception thrown when a customer is not found in the database.
 */
public class CustomerNotFoundException extends Exception {

    public CustomerNotFoundException(String message) {
        super(message);
    }
}
