package com.ctc.client;

import com.ctc.model.Car;
import com.ctc.model.Customer;
import com.ctc.model.Rental;
import com.ctc.service.CarService;
import com.ctc.service.CustomerService;
import com.ctc.service.RentalService;
import com.ctc.exceptions.CarNotFoundException;
import com.ctc.exceptions.CustomerNotFoundException;
import com.ctc.exceptions.RentalNotFoundException;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

/**
 * Console application for Car Rental Management System.
 */
public class CarRentalManagementSystem {

    private static CarService carService;
    private static CustomerService customerService;
    private static RentalService rentalService;

    public static void main(String[] args) throws CarNotFoundException {
        try {
            carService = new CarService();
            customerService = new CustomerService();
            rentalService = new RentalService();
            Scanner scanner = new Scanner(System.in);
            int choice;

            do {
            	System.out.println("========================================");
                System.out.println("Car Rental Management System");
                System.out.println("1. Manage Cars");
                System.out.println("2. Manage Customers");
                System.out.println("3. Manage Rentals");
                System.out.println("4. Exit");
                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();
                scanner.nextLine();  // Consume newline

                switch (choice) {
                    case 1:
                        manageCars(scanner);
                        break;
                    case 2:
                        manageCustomers(scanner);
                        break;
                    case 3:
                        manageRentals(scanner);
                        break;
                    case 4:
                        System.out.println("ThankYou For Visiting....");
                        break;
                    default:
                        System.out.println("Invalid choice, please try again.");
                }
            } while (choice != 4);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void manageCars(Scanner scanner) {
        int choice;
        do {
            System.out.println("Manage Cars");
            System.out.println("1. Add Car");
            System.out.println("2. View Car");
            System.out.println("3. Update Car");
            System.out.println("4. Delete Car");
            System.out.println("5. List All Cars");
            System.out.println("6. Back");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    addCar(scanner);
                    break;
                case 2:
                    viewCar(scanner);
                    break;
                case 3:
                    updateCar(scanner);
                    break;
                case 4:
                    deleteCar(scanner);
                    break;
                case 5:
                    listAllCars();
                    break;
                case 6:
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        } while (choice != 6);
    }

    private static void manageCustomers(Scanner scanner) {
        int choice;
        do {
            System.out.println("Manage Customers");
            System.out.println("1. Register Customer");
            System.out.println("2. View Customer");
            System.out.println("3. Update Customer");
            System.out.println("4. Delete Customer");
            System.out.println("5. List All Customers");
            System.out.println("6. Back");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    registerCustomer(scanner);
                    break;
                case 2:
                    viewCustomer(scanner);
                    break;
                case 3:
                    updateCustomer(scanner);
                    break;
                case 4:
                    deleteCustomer(scanner);
                    break;
                case 5:
                    listAllCustomers();
                    break;
                case 6:
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        } while (choice != 6);
    }

    private static void manageRentals(Scanner scanner) throws CarNotFoundException {
        int choice;
        do {
            System.out.println("Manage Rentals");
            System.out.println("1. Rent Car");
            System.out.println("2. Return Car");
            System.out.println("3. View Rental");
            System.out.println("4. List All Rentals");
            System.out.println("5. Calculate Rental Charges");
            System.out.println("6. Back");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    rentCar(scanner);
                    break;
                case 2:
                    returnCar(scanner);
                    break;
                case 3:
                    viewRental(scanner);
                    break;
                case 4:
                    listAllRentals();
                    break;
                case 5:
                    calculateRentalCharges(scanner);
                    break;
                case 6:
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        } while (choice != 6);
    }

    private static void addCar(Scanner scanner) {
        System.out.print("Enter make: ");
        String make = scanner.nextLine();
        System.out.print("Enter model: ");
        String model = scanner.nextLine();
        System.out.print("Enter year: ");
        int year = scanner.nextInt();
        System.out.print("Enter daily rate: ");
        double dailyRate = scanner.nextDouble();

        try {
            Car car = new Car();
            car.setMake(make);
            car.setModel(model);
            car.setYear(year);
            car.setDailyRate(dailyRate);
            carService.addCar(car);
            System.out.println("Car added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewCar(Scanner scanner) {
        System.out.print("Enter car ID: ");
        int carId = scanner.nextInt();

        try {
            Car car = carService.getCar(carId);
            System.out.println("Car Details: ");
            System.out.println("ID: " + car.getCarId());
            System.out.println("Make: " + car.getMake());
            System.out.println("Model: " + car.getModel());
            System.out.println("Year: " + car.getYear());
            System.out.println("Daily Rate: " + car.getDailyRate());
        } catch (CarNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateCar(Scanner scanner) {
        System.out.print("Enter car ID: ");
        int carId = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.print("Enter new make: ");
        String make = scanner.nextLine();
        System.out.print("Enter new model: ");
        String model = scanner.nextLine();
        System.out.print("Enter new year: ");
        int year = scanner.nextInt();
        System.out.print("Enter new daily rate: ");
        double dailyRate = scanner.nextDouble();

        try {
            Car car = new Car();
            car.setCarId(carId);
            car.setMake(make);
            car.setModel(model);
            car.setYear(year);
            car.setDailyRate(dailyRate);
            carService.updateCar(car);
            System.out.println("Car updated successfully.");
        } catch (CarNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteCar(Scanner scanner) {
        System.out.print("Enter car ID: ");
        int carId = scanner.nextInt();

        try {
            carService.deleteCar(carId);
            System.out.println("Car deleted successfully.");
        } catch (CarNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void listAllCars() {
        try {
            List<Car> cars = carService.getAllCars();
            System.out.println("All Cars:");
            for (Car car : cars) {
                System.out.println("ID: " + car.getCarId() + ", Make: " + car.getMake() + ", Model: " + car.getModel() + ", Year: " + car.getYear() + ", Daily Rate: " + car.getDailyRate());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void registerCustomer(Scanner scanner) {
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter phone number: ");
        String phoneNumber = scanner.nextLine();
        System.out.print("Enter address: ");
        String address = scanner.nextLine();

        try {
            Customer customer = new Customer();
            customer.setName(name);
            customer.setEmail(email);
            customer.setPhoneNumber(phoneNumber);
            customer.setAddress(address);
            customerService.addCustomer(customer);
            System.out.println("Customer registered successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewCustomer(Scanner scanner) {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();

        try {
            Customer customer = customerService.getCustomer(customerId);
            System.out.println("Customer Details: ");
            System.out.println("ID: " + customer.getCustomerId());
            System.out.println("Name: " + customer.getName());
            System.out.println("Email: " + customer.getEmail());
            System.out.println("Phone Number: " + customer.getPhoneNumber());
            System.out.println("Address: " + customer.getAddress());
        } catch (CustomerNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateCustomer(Scanner scanner) {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.print("Enter new name: ");
        String name = scanner.nextLine();
        System.out.print("Enter new email: ");
        String email = scanner.nextLine();
        System.out.print("Enter new phone number: ");
        String phoneNumber = scanner.nextLine();
        System.out.print("Enter new address: ");
        String address = scanner.nextLine();

        try {
            Customer customer = new Customer();
            customer.setCustomerId(customerId);
            customer.setName(name);
            customer.setEmail(email);
            customer.setPhoneNumber(phoneNumber);
            customer.setAddress(address);
            customerService.updateCustomer(customer);
            System.out.println("Customer updated successfully.");
        } catch (CustomerNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteCustomer(Scanner scanner) {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();

        try {
            customerService.deleteCustomer(customerId);
            System.out.println("Customer deleted successfully.");
        } catch (CustomerNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void listAllCustomers() {
        try {
            List<Customer> customers = customerService.getAllCustomers();
            System.out.println("All Customers:");
            for (Customer customer : customers) {
                System.out.println("ID: " + customer.getCustomerId() + ", Name: " + customer.getName() + ", Email: " + customer.getEmail() + ", Phone Number: " + customer.getPhoneNumber() + ", Address: " + customer.getAddress());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void rentCar(Scanner scanner) {
        System.out.print("Enter car ID: ");
        int carId = scanner.nextInt();
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        System.out.print("Enter rental start date (YYYY-MM-DD): ");
        String startDate = scanner.next();
        System.out.print("Enter rental end date (YYYY-MM-DD): ");
        String endDate = scanner.next();
        scanner.nextLine();  // Consume newline

        try {
            Rental rental = new Rental();
            rental.setCarId(carId);
            rental.setCustomerId(customerId);
            rental.setRentalStartDate(java.sql.Date.valueOf(startDate));
            rental.setRentalEndDate(java.sql.Date.valueOf(endDate));
            rental.setTotalCharge(0);  // Total charge will be calculated later
            rentalService.rentCar(rental);
            System.out.println("Car rented successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void returnCar(Scanner scanner) {
        System.out.print("Enter rental ID: ");
        int rentalId = scanner.nextInt();

        try {
            rentalService.returnCar(rentalId);
            System.out.println("Car returned successfully.");
        } catch (RentalNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewRental(Scanner scanner) {
        System.out.print("Enter rental ID: ");
        int rentalId = scanner.nextInt();

        try {
            Rental rental = rentalService.getRental(rentalId);
            System.out.println("Rental Details: ");
            System.out.println("ID: " + rental.getRentalId());
            System.out.println("Car ID: " + rental.getCarId());
            System.out.println("Customer ID: " + rental.getCustomerId());
            System.out.println("Start Date: " + rental.getRentalStartDate());
            System.out.println("End Date: " + rental.getRentalEndDate());
            System.out.println("Total Charge: " + rental.getTotalCharge());
        } catch (RentalNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    private static void listAllRentals() {
        try {
            List<Rental> rentals = rentalService.getAllRentals();
            System.out.println("All Rentals:");
            for (Rental rental : rentals) {
                System.out.println("ID: " + rental.getRentalId() + ", Car ID: " + rental.getCarId() + ", Customer ID: " + rental.getCustomerId() + ", Start Date: " + rental.getRentalStartDate() + ", End Date: " + rental.getRentalEndDate() + ", Total Charge: " + rental.getTotalCharge());
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void calculateRentalCharges(Scanner scanner) throws CarNotFoundException {
        System.out.print("Enter rental ID: ");
        int rentalId = scanner.nextInt();

        try {
            double totalCharge = rentalService.calculateTotalCharge(rentalId);
            System.out.println("Total Charge: " + totalCharge);
        } catch (RentalNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}
