package com.ctc.service;

import com.ctc.dao.CustomerDAO;
import com.ctc.dao.CustomerDAOImpl;
import com.ctc.exceptions.CustomerNotFoundException;
import com.ctc.model.Customer;
import java.sql.SQLException;
import java.util.List;

/**
 * Service class to manage customer operations.
 */
public class CustomerService {

    private CustomerDAO customerDAO;

    public CustomerService() throws SQLException {
        this.customerDAO = new CustomerDAOImpl();
    }

    public void addCustomer(Customer customer) throws SQLException {
        customerDAO.addCustomer(customer);
    }

    public Customer getCustomer(int customerId) throws CustomerNotFoundException, SQLException {
        return customerDAO.getCustomer(customerId);
    }

    public void updateCustomer(Customer customer) throws CustomerNotFoundException, SQLException {
        customerDAO.updateCustomer(customer);
    }

    public void deleteCustomer(int customerId) throws CustomerNotFoundException, SQLException {
        customerDAO.deleteCustomer(customerId);
    }

    public List<Customer> getAllCustomers() throws SQLException {
        return customerDAO.getAllCustomers();
    }
}
