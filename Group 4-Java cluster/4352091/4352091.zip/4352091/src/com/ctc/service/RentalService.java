package com.ctc.service;

import com.ctc.dao.RentalDAO;
import com.ctc.dao.RentalDAOImpl;
import com.ctc.exceptions.CarNotFoundException;
import com.ctc.exceptions.RentalNotFoundException;
import com.ctc.model.Rental;
import java.sql.SQLException;
import java.util.List;

/**
 * Service class to manage rental operations.
 */
public class RentalService {

    private RentalDAO rentalDAO;

    public RentalService() throws SQLException {
        this.rentalDAO = new RentalDAOImpl();
    }

    public void rentCar(Rental rental) throws SQLException {
        rentalDAO.rentCar(rental);
    }

    public void returnCar(int rentalId) throws RentalNotFoundException, SQLException {
        rentalDAO.returnCar(rentalId);
    }

    public Rental getRental(int rentalId) throws RentalNotFoundException, SQLException {
        return rentalDAO.getRental(rentalId);
    }

    public List<Rental> getAllRentals() throws SQLException {
        return rentalDAO.getAllRentals();
    }

    public double calculateTotalCharge(int rentalId) throws RentalNotFoundException, SQLException, CarNotFoundException {
        return rentalDAO.calculateTotalCharge(rentalId);
    }
}
