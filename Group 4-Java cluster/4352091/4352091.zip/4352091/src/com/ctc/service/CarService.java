package com.ctc.service;

import com.ctc.dao.CarDAO;
import com.ctc.dao.CarDAOImpl;
import com.ctc.exceptions.CarNotFoundException;
import com.ctc.model.Car;
import java.sql.SQLException;
import java.util.List;

/**
 * Service class to manage car operations.
 */
public class CarService {

    private CarDAO carDAO;

    public CarService() throws SQLException {
        this.carDAO = new CarDAOImpl();
    }

    public void addCar(Car car) throws SQLException {
        carDAO.addCar(car);
    }

    public Car getCar(int carId) throws CarNotFoundException, SQLException {
        return carDAO.getCar(carId);
    }

    public void updateCar(Car car) throws CarNotFoundException, SQLException {
        carDAO.updateCar(car);
    }

    public void deleteCar(int carId) throws CarNotFoundException, SQLException {
        carDAO.deleteCar(carId);
    }

    public List<Car> getAllCars() throws SQLException {
        return carDAO.getAllCars();
    }
}
