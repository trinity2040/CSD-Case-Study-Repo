package com.ctc.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Utility class to manage the database connection.
 */
public class DatabaseConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/car_rental_db";
    private static final String USER = "Pandu";
    private static final String PASSWORD = "Pandu@8790";

    /**
     * Establishes and returns a connection to the database.
     * @return Connection object
     * @throws SQLException if a database access error occurs
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
