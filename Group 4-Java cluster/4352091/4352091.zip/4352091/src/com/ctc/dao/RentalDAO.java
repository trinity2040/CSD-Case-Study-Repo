package com.ctc.dao;

import com.ctc.model.Rental;
import com.ctc.exceptions.CarNotFoundException;
import com.ctc.exceptions.RentalNotFoundException;

import java.sql.SQLException;
import java.util.List;

/**
 * Interface for managing rental-related database operations.
 */
public interface RentalDAO {

    void rentCar(Rental rental) throws SQLException;

    void returnCar(int rentalId) throws RentalNotFoundException, SQLException;

    Rental getRental(int rentalId) throws RentalNotFoundException, SQLException;

    List<Rental> getAllRentals() throws SQLException;

    double calculateTotalCharge(int rentalId) throws RentalNotFoundException, SQLException, CarNotFoundException;
}
