package com.ctc.dao;

import com.ctc.model.Car;
import com.ctc.model.Rental;
import com.ctc.exceptions.CarNotFoundException;
import com.ctc.exceptions.RentalNotFoundException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of RentalDAO interface for managing rental-related database operations.
 */
public class RentalDAOImpl implements RentalDAO {

    private Connection connection;

    public RentalDAOImpl() throws SQLException {
        this.connection = DatabaseConnection.getConnection();
    }

    @Override
    public void rentCar(Rental rental) throws SQLException {
        String query = "INSERT INTO Rental (car_id, customer_id, rental_start_date, rental_end_date, total_charge) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, rental.getCarId());
            stmt.setInt(2, rental.getCustomerId());
            stmt.setDate(3, new java.sql.Date(rental.getRentalStartDate().getTime()));
            stmt.setDate(4, new java.sql.Date(rental.getRentalEndDate().getTime()));
            stmt.setDouble(5, rental.getTotalCharge());
            stmt.executeUpdate();
        }
    }

    @Override
    public void returnCar(int rentalId) throws RentalNotFoundException, SQLException {
        String query = "DELETE FROM Rental WHERE rental_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, rentalId);
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted == 0) {
                throw new RentalNotFoundException("Rental with ID " + rentalId + " not found.");
            }
        }
    }

    @Override
    public Rental getRental(int rentalId) throws RentalNotFoundException, SQLException {
        String query = "SELECT * FROM Rental WHERE rental_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, rentalId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Rental rental = new Rental();
                rental.setRentalId(rs.getInt("rental_id"));
                rental.setCarId(rs.getInt("car_id"));
                rental.setCustomerId(rs.getInt("customer_id"));
                rental.setRentalStartDate(rs.getDate("rental_start_date"));
                rental.setRentalEndDate(rs.getDate("rental_end_date"));
                rental.setTotalCharge(rs.getDouble("total_charge"));
                return rental;
            } else {
                throw new RentalNotFoundException("Rental with ID " + rentalId + " not found.");
            }
        }
    }

    @Override
    public List<Rental> getAllRentals() throws SQLException {
        List<Rental> rentals = new ArrayList<>();
        String query = "SELECT * FROM Rental";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Rental rental = new Rental();
                rental.setRentalId(rs.getInt("rental_id"));
                rental.setCarId(rs.getInt("car_id"));
                rental.setCustomerId(rs.getInt("customer_id"));
                rental.setRentalStartDate(rs.getDate("rental_start_date"));
                rental.setRentalEndDate(rs.getDate("rental_end_date"));
                rental.setTotalCharge(rs.getDouble("total_charge"));
                rentals.add(rental);
            }
        }
        return rentals;
    }

    @Override
    public double calculateTotalCharge(int rentalId) throws RentalNotFoundException, SQLException, CarNotFoundException {
        Rental rental = getRental(rentalId);
        long durationInMillis = rental.getRentalEndDate().getTime() - rental.getRentalStartDate().getTime();
        long durationInDays = durationInMillis / (1000 * 60 * 60 * 24);
        CarDAO carDAO = new CarDAOImpl();
        Car car = carDAO.getCar(rental.getCarId());
        return durationInDays * car.getDailyRate();
    }
}
