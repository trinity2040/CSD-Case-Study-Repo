package com.ctc.dao;

import com.ctc.model.Customer;
import com.ctc.exceptions.CustomerNotFoundException;

import java.sql.SQLException;
import java.util.List;

/**
 * Interface for managing customer-related database operations.
 */
public interface CustomerDAO {

    void addCustomer(Customer customer) throws SQLException;

    Customer getCustomer(int customerId) throws CustomerNotFoundException, SQLException;

    void updateCustomer(Customer customer) throws CustomerNotFoundException, SQLException;

    void deleteCustomer(int customerId) throws CustomerNotFoundException, SQLException;

    List<Customer> getAllCustomers() throws SQLException;
}
