package com.ctc.dao;

import com.ctc.model.Car;
import com.ctc.exceptions.CarNotFoundException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of CarDAO interface for managing car-related database operations.
 */
public class CarDAOImpl implements CarDAO {

    private Connection connection;

    public CarDAOImpl() throws SQLException {
        this.connection = DatabaseConnection.getConnection();
    }

    @Override
    public void addCar(Car car) throws SQLException {
        String query = "INSERT INTO Car (make, model, year, daily_rate) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, car.getMake());
            stmt.setString(2, car.getModel());
            stmt.setInt(3, car.getYear());
            stmt.setDouble(4, car.getDailyRate());
            stmt.executeUpdate();
        }
    }

    @Override
    public Car getCar(int carId) throws CarNotFoundException, SQLException {
        String query = "SELECT * FROM Car WHERE car_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, carId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Car car = new Car();
                car.setCarId(rs.getInt("car_id"));
                car.setMake(rs.getString("make"));
                car.setModel(rs.getString("model"));
                car.setYear(rs.getInt("year"));
                car.setDailyRate(rs.getDouble("daily_rate"));
                return car;
            } else {
                throw new CarNotFoundException("Car with ID " + carId + " not found.");
            }
        }
    }

    @Override
    public void updateCar(Car car) throws CarNotFoundException, SQLException {
        String query = "UPDATE Car SET make = ?, model = ?, year = ?, daily_rate = ? WHERE car_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, car.getMake());
            stmt.setString(2, car.getModel());
            stmt.setInt(3, car.getYear());
            stmt.setDouble(4, car.getDailyRate());
            stmt.setInt(5, car.getCarId());
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated == 0) {
                throw new CarNotFoundException("Car with ID " + car.getCarId() + " not found.");
            }
        }
    }

    @Override
    public void deleteCar(int carId) throws CarNotFoundException, SQLException {
        String query = "DELETE FROM Car WHERE car_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, carId);
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted == 0) {
                throw new CarNotFoundException("Car with ID " + carId + " not found.");
            }
        }
    }

    @Override
    public List<Car> getAllCars() throws SQLException {
        List<Car> cars = new ArrayList<>();
        String query = "SELECT * FROM Car";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Car car = new Car();
                car.setCarId(rs.getInt("car_id"));
                car.setMake(rs.getString("make"));
                car.setModel(rs.getString("model"));
                car.setYear(rs.getInt("year"));
                car.setDailyRate(rs.getDouble("daily_rate"));
                cars.add(car);
            }
        }
        return cars;
    }
}

