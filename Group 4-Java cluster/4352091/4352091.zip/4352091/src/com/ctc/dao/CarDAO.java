package com.ctc.dao;

import com.ctc.model.Car;
import com.ctc.exceptions.CarNotFoundException;

import java.sql.SQLException;
import java.util.List;

/**
 * Interface for managing car-related database operations.
 */
public interface CarDAO {

    void addCar(Car car) throws SQLException;

    Car getCar(int carId) throws CarNotFoundException, SQLException;

    void updateCar(Car car) throws CarNotFoundException, SQLException;

    void deleteCar(int carId) throws CarNotFoundException, SQLException;

    List<Car> getAllCars() throws SQLException;
}
