/**
 * 
 */
/**
 * 
 */
module Car_Rental_Management_System {
	requires java.sql;
}