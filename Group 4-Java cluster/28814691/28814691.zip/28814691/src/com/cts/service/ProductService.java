package com.cts.service;


public interface ProductService {
	void viewProductBySearch();
	void updateProduct();
	void deleteProduct();
	void viewAllProducts();
	void addProduct();
}
