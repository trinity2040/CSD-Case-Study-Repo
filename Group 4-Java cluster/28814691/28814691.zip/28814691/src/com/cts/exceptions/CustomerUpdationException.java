package com.cts.exceptions;

public class CustomerUpdationException extends Exception {

	public CustomerUpdationException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerUpdationException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public CustomerUpdationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CustomerUpdationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CustomerUpdationException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
