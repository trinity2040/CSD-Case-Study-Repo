package com.cts.exceptions;

public class ProductInsertionException extends Exception{

	public ProductInsertionException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ProductInsertionException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ProductInsertionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ProductInsertionException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public ProductInsertionException() {
		// TODO Auto-generated constructor stub
	}

}
