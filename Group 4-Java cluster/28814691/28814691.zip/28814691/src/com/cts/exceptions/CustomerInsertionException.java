package com.cts.exceptions;

public class CustomerInsertionException extends Exception {

	public CustomerInsertionException() {
		// TODO Auto-generated constructor stub
	}

	public CustomerInsertionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CustomerInsertionException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public CustomerInsertionException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CustomerInsertionException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
