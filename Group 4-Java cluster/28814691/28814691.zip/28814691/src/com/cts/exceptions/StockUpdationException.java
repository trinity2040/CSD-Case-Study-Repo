package com.cts.exceptions;

public class StockUpdationException extends Exception {

	public StockUpdationException() {
		// TODO Auto-generated constructor stub
	}

	public StockUpdationException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public StockUpdationException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public StockUpdationException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public StockUpdationException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
