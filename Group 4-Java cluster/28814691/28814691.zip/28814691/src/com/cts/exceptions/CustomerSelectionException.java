package com.cts.exceptions;

public class CustomerSelectionException extends Exception {

	public CustomerSelectionException() {
		// TODO Auto-generated constructor stub
	}

	public CustomerSelectionException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CustomerSelectionException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public CustomerSelectionException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CustomerSelectionException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}
