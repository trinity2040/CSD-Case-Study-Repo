CREATE DATABASE pharma_inventory;

USE pharma_inventory;

CREATE TABLE medications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL
);

CREATE TABLE suppliers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    contact_info VARCHAR(255)
);

CREATE TABLE inventory (
    id INT AUTO_INCREMENT PRIMARY KEY,
    medication_id INT,
    quantity INT NOT NULL,
    supplier_id INT,
    FOREIGN KEY (medication_id) REFERENCES medications(id),
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id)
);
