package dao;

import database.DatabaseConnection;
import models.Supplier;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SupplierDAO {
    public void addSupplier(Supplier supplier) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        String query = "INSERT INTO suppliers (name, contact_info) VALUES (?, ?)";
        PreparedStatement ps = conn.prepareStatement(query);
        ps.setString(1, supplier.getName());
        ps.setString(2, supplier.getContactInfo());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public List<Supplier> getAllSuppliers() throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        String query = "SELECT * FROM suppliers";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(query);
        List<Supplier> suppliers = new ArrayList<>();
        while (rs.next()) {
            Supplier supplier = new Supplier();
            supplier.setId(rs.getInt("id"));
            supplier.setName(rs.getString("name"));
            supplier.setContactInfo(rs.getString("contact_info"));
            suppliers.add(supplier);
        }
        rs.close();
        stmt.close();
        conn.close();
        return suppliers;
    }
}
