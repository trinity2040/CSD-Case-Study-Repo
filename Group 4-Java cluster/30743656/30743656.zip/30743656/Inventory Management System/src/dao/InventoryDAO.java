package dao;

import database.DatabaseConnection;
import models.Inventory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class InventoryDAO {
    public void addInventory(Inventory inventory) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        String query = "INSERT INTO inventory (medication_id, quantity, supplier_id) VALUES (?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(query);
        ps.setInt(1, inventory.getMedicationId());
        ps.setInt(2, inventory.getQuantity());
        ps.setInt(3, inventory.getSupplierId());
        ps.executeUpdate();
        ps.close();
        conn.close();
    }

    public List<Inventory> getAllInventory() throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        String query = "SELECT * FROM inventory";
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(query);
        List<Inventory> inventories = new ArrayList<>();
        while (rs.next()) {
            Inventory inv = new Inventory();
            inv.setId(rs.getInt("id"));
            inv.setMedicationId(rs.getInt("medication_id"));
            inv.setQuantity(rs.getInt("quantity"));
            inv.setSupplierId(rs.getInt("supplier_id"));
            inventories.add(inv);
        }
        rs.close();
        stmt.close();
        conn.close();
        return inventories;
    }
}
