package dao;

import models.Medication;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import database.DatabaseConnection;

public class MedicationDAO {

    public void addMedication(Medication medication) throws SQLException {
        String sql = "INSERT INTO medications (name, description, price) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, medication.getName());
            stmt.setString(2, medication.getDescription());
            stmt.setDouble(3, medication.getPrice());
            stmt.executeUpdate();
        }
    }

    public List<Medication> getAllMedications() throws SQLException {
        // Implementation for fetching medications
        return null;
    }
}
