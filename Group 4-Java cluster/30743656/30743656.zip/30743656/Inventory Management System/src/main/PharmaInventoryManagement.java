package main;

import dao.InventoryDAO;
import dao.MedicationDAO;
import dao.SupplierDAO;
import models.Inventory;
import models.Medication;
import models.Supplier;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class PharmaInventoryManagement {
    private static Scanner scanner = new Scanner(System.in);
    private static MedicationDAO medicationDAO = new MedicationDAO();
    private static SupplierDAO supplierDAO = new SupplierDAO();
    private static InventoryDAO inventoryDAO = new InventoryDAO();

    public static void main(String[] args) {
        while (true) {
            showMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addMedication();
                    break;
                case 2:
                    listMedications();
                    break;
                case 3:
                    addSupplier();
                    break;
                case 4:
                    listSuppliers();
                    break;
                case 5:
                    addInventory();
                    break;
                case 6:
                    listInventory();
                    break;
                case 7:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    private static void showMenu() {
        System.out.println("=== Pharma Inventory Management ===");
        System.out.println("1. Add Medication");
        System.out.println("2. List Medications");
        System.out.println("3. Add Supplier");
        System.out.println("4. List Suppliers");
        System.out.println("5. Add Inventory");
        System.out.println("6. List Inventory");
        System.out.println("7. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void addMedication() {
        System.out.print("Enter medication name: ");
        String name = scanner.nextLine();
        System.out.print("Enter medication description: ");
        String description = scanner.nextLine();
        System.out.print("Enter medication price: ");
        double price = scanner.nextDouble();
        scanner.nextLine(); // Consume newline

        Medication medication = new Medication();
        medication.setName(name);
        medication.setDescription(description);
        medication.setPrice(price);

        try {
            medicationDAO.addMedication(medication);
            System.out.println("Medication added successfully!");
        } catch (SQLException e) {
            System.out.println("Error adding medication: " + e.getMessage());
        }
    }

    private static void listMedications() {
        try {
            List<Medication> medications = medicationDAO.getAllMedications();
            for (Medication med : medications) {
                System.out.println("ID: " + med.getId() + ", Name: " + med.getName() +
                                   ", Description: " + med.getDescription() + ", Price: " + med.getPrice());
            }
        } catch (SQLException e) {
            System.out.println("Error listing medications: " + e.getMessage());
        }
    }

    private static void addSupplier() {
        System.out.print("Enter supplier name: ");
        String name = scanner.nextLine();
        System.out.print("Enter supplier contact info: ");
        String contactInfo = scanner.nextLine();

        Supplier supplier = new Supplier();
        supplier.setName(name);
        supplier.setContactInfo(contactInfo);

        try {
            supplierDAO.addSupplier(supplier);
            System.out.println("Supplier added successfully!");
        } catch (SQLException e) {
            System.out.println("Error adding supplier: " + e.getMessage());
        }
    }

    private static void listSuppliers() {
        try {
            List<Supplier> suppliers = supplierDAO.getAllSuppliers();
            for (Supplier supplier : suppliers) {
                System.out.println("ID: " + supplier.getId() + ", Name: " + supplier.getName() +
                                   ", Contact Info: " + supplier.getContactInfo());
            }
        } catch (SQLException e) {
            System.out.println("Error listing suppliers: " + e.getMessage());
        }
    }

    private static void addInventory() {
        System.out.print("Enter medication ID: ");
        int medicationId = scanner.nextInt();
        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();
        System.out.print("Enter supplier ID: ");
        int supplierId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Inventory inventory = new Inventory();
        inventory.setMedicationId(medicationId);
        inventory.setQuantity(quantity);
        inventory.setSupplierId(supplierId);

        try {
            inventoryDAO.addInventory(inventory);
            System.out.println("Inventory added successfully!");
        } catch (SQLException e) {
            System.out.println("Error adding inventory: " + e.getMessage());
        }
    }

    private static void listInventory() {
        try {
            List<Inventory> inventories = inventoryDAO.getAllInventory();
            for (Inventory inv : inventories) {
                System.out.println("ID: " + inv.getId() + ", Medication ID: " + inv.getMedicationId() +
                                   ", Quantity: " + inv.getQuantity() + ", Supplier ID: " + inv.getSupplierId());
            }
        } catch (SQLException e) {
            System.out.println("Error listing inventory: " + e.getMessage());
        }
    }
}
