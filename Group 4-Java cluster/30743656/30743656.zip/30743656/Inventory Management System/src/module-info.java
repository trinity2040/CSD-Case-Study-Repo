/**
 * 
 */
/**
 * @author Pankaj
 *
 */
module PharmaInventorySystem {
	requires java.sql;
}