Inventory Management System for Pharmaceutical Company
Welcome to the Inventory Management System, a Java-based application designed to streamline the management of pharmaceutical inventory. This system allows users to efficiently manage stock levels, track inventory movements, and ensure that the right products are always available.

Features 🌟
Add Products: Easily add new products to the inventory with all the necessary details.
View Products: Quickly view product details, including product ID, name, and stock levels.
Update Inventory: Modify product information and update stock quantities as needed.
Delete Products: Remove products that are no longer in stock or needed.
Stock Management: Monitor stock levels, and manage restocking and depletion.
Transaction Records: Keep track of all inventory movements, including incoming and outgoing stock.
Search Functionality: Find products quickly using search criteria like product name or ID.
User-Friendly Interface: Simple and intuitive design for ease of use.
Getting Started 🚀
Prerequisites
Java Development Kit (JDK)
MySQL Database
MySQL Connector/J (Java)

Usage 📋
Once the application is running, you can start managing the inventory by following the on-screen prompts. The main menu will guide you through various operations, such as adding new products, viewing existing products, updating inventory details, and managing stock levels.
Thank You! 🎉
We hope this system helps streamline your inventory management processes and enhances efficiency in your pharmaceutical company.