package com.cts.interfaces;

import com.cts.exception.MedicalRecordNotFoundException;
import com.cts.model.MedicalRecord;

public interface MedicalRecordService {
	public abstract void medicalRecord(MedicalRecord medicalRecord) throws MedicalRecordNotFoundException;
	public abstract void addMedicalRecord(MedicalRecord medicalRecord);
	public abstract void viewAllMedicalRecords();
	public abstract void updateMedicalRecord(MedicalRecord medicalRecord,int recordId) throws MedicalRecordNotFoundException;
	public abstract void deleteMedicalRecord(int recordId) throws MedicalRecordNotFoundException;
}
