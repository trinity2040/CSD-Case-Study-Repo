package com.cts.model;

public class PatientRecord {
	
	//Patient attribute names and getters and setters
	private String name;
	private String gender;
	private String age;
	private String contactNo;

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	
	
	
	//constuctor with 4 fields
	public PatientRecord(String name,  String age, String gender,String contactNo) {
		super();
		this.name = name;
		this.gender = gender;
		this.age = age;
		this.contactNo = contactNo;
	}	
}
