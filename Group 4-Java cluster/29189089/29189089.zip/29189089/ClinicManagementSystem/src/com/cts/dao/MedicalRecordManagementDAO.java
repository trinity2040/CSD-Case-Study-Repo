package com.cts.dao;

import java.sql.*;
import java.util.Scanner;

import com.cts.exception.MedicalRecordNotFoundException;
import com.cts.interfaces.MedicalRecordService;
import com.cts.model.MedicalRecord;
import com.cts.util.*;

public class MedicalRecordManagementDAO implements MedicalRecordService{
 
	
	@Override
	public void medicalRecord(MedicalRecord medicalRecord) throws MedicalRecordNotFoundException {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
	    System.out.println("\n--- Medical Record Management ---");
	    System.out.println("1. Add Medical Record");
	    System.out.println("2. View Medical Record");
	    System.out.println("3. Update Medical Record");
	    System.out.println("4. Delete Medical Record");
	    System.out.print("Choose an option: ");
	    int choice = sc.nextInt();

	    switch (choice) {
	        case 1:
	        	System.out.print("Enter patient ID: ");
	            int patientId = sc.nextInt();
	            sc.nextLine();  // consume the newline character
	            System.out.print("Enter diagnosis: ");
	            String diagnosis = sc.nextLine();
	            System.out.print("Enter treatment: ");
	            String treatment = sc.nextLine();
	            System.out.print("Enter date (YYYY-MM-DD): ");
	            String date = sc.nextLine();
	            
	            medicalRecord = new MedicalRecord(patientId,diagnosis,treatment,date);
	            addMedicalRecord(medicalRecord);
	            break;
	        case 2:
	            viewAllMedicalRecords();
	            break;
	        case 3:
	            System.out.print("Enter record ID: ");
	            int recordId = sc.nextInt();
	            sc.nextLine();
	            System.out.print("Enter new diagnosis: ");
	            diagnosis = sc.nextLine();
	            System.out.print("Enter new treatment: ");
	            treatment = sc.nextLine();
	            System.out.print("Enter new date (YYYY-MM-DD): ");
	            date = sc.nextLine();
	            
	            medicalRecord = new MedicalRecord(diagnosis,treatment,date);
	            updateMedicalRecord(medicalRecord,recordId);
	            break;
	        case 4:
	            System.out.print("Enter record ID: ");
	            recordId = sc.nextInt();
	            deleteMedicalRecord(recordId);
	            break;
	        default:
	            System.out.println("Invalid option.");
	    }

	}

	//	Adding medical Records
	
	@Override
	public void addMedicalRecord(MedicalRecord medicalRecord) {
		// TODO Auto-generated method stub
		try (Connection conn = ConnectionProvider.createConnection()) {

            String sql = "INSERT INTO MedicalRecord (patient_id, diagnosis, treatment, date) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, medicalRecord.getPatientId());
            pstmt.setString(2, medicalRecord.getDiagnosis());
            pstmt.setString(3, medicalRecord.getTreatment());
            pstmt.setString(4, medicalRecord.getDate());

            pstmt.executeUpdate();
            System.out.println("Medical record added successfully.");
        } catch (SQLException e) {
            System.out.println("Error adding medical record: " + e.getMessage());
        }
	}

	//viewing all medical records 
	
	@Override
	public void viewAllMedicalRecords() {
		// TODO Auto-generated method stub
		try (Connection conn = ConnectionProvider.createConnection()) {
            String sql = "SELECT * FROM MedicalRecord";         // Query to select all medical records
            PreparedStatement pstmt = conn.prepareStatement(sql);  // Create a statement object
            ResultSet rs = pstmt.executeQuery(sql);          // Execute the query and get the result set

            System.out.println("\n--- Medical Record List ---");

            
            System.out.printf("%-10s %-10s %-30s %-30s %-15s%n", "Record ID", "Patient ID", "Diagnosis", "Treatment", "Date");
            System.out.println("-----------------------------------------------------------------------------------------------------------");

            boolean hasRecords = false;  // Flag to check if there are any records in the database

            while (rs.next()) { 
                hasRecords = true;
                int recordId = rs.getInt("record_id");
                int patientId = rs.getInt("patient_id");
                String diagnosis = rs.getString("diagnosis");
                String treatment = rs.getString("treatment");
                String date = rs.getString("date");

                System.out.printf("%-10d %-10d %-30s %-30s %-15s%n", recordId, patientId, diagnosis, treatment, date);
            }

            if (!hasRecords) {
                System.out.println("No medical records found.");
            }

        } catch (SQLException e) {
            System.out.println("Error retrieving medical records: " + e.getMessage());
        }
    }

	//updating medical records
	
	@Override
	public void updateMedicalRecord(MedicalRecord medicalRecord, int recordId) throws MedicalRecordNotFoundException {
		// TODO Auto-generated method stub
		try (Connection conn = ConnectionProvider.createConnection()) {
			 
            String sql = "UPDATE MedicalRecord SET diagnosis = ?, treatment = ?, date = ? WHERE record_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, medicalRecord.getDiagnosis());
            pstmt.setString(2, medicalRecord.getTreatment());
            pstmt.setString(3, medicalRecord.getDate());
            pstmt.setInt(4, recordId);

            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Medical record updated successfully.");
            } else {
                throw new MedicalRecordNotFoundException(" Record with ID " + recordId + " not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating medical record: " + e.getMessage());
        }
    }


	//deleting medical records

	@Override
	public void deleteMedicalRecord(int recordId) throws MedicalRecordNotFoundException {
		// TODO Auto-generated method stub
		 try (Connection conn = ConnectionProvider.createConnection()) {
	            String sql = "DELETE FROM MedicalRecord WHERE record_id = ?";
	            PreparedStatement pstmt = conn.prepareStatement(sql);
	            pstmt.setInt(1, recordId);

	            int rowsDeleted = pstmt.executeUpdate();
	            if (rowsDeleted > 0) {
	                System.out.println("Medical record deleted successfully.");
	            } else {
	                System.out.println("Medical record not found.");
	            }
	        } catch (SQLException e) {
	            System.out.println("Error deleting medical record: " + e.getMessage());
	        }
		
	}
	
}

