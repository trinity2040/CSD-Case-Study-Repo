package com.cts.model;

public class MedicalRecord {
	    private String diagnosis;
	    private String treatment;
	    private int patientId;
	    private String date;
	    
	    
	    //getters  and setters of MedicalRecord
	    public String getDate() {
			return date;
		}
		public void setDate(String date) {
			this.date = date;
		}
		public int getPatientId() {
			return patientId;
		}
		public void setPatientId(int patientId) {
			this.patientId = patientId;
		}
		public String getDiagnosis() {
			return diagnosis;
		}
		public void setDiagnosis(String diagnosis) {
			this.diagnosis = diagnosis;
		}
		public String getTreatment() {
			return treatment;
		}
		public void setTreatment(String treatment) {
			this.treatment = treatment;
		}
		
		//parameterised constructor with 4 fields
		public MedicalRecord(int patientId,String diagnosis, String treatment, String date) {
			super();
			this.diagnosis = diagnosis;
			this.treatment = treatment;
			this.patientId = patientId;
			this.date = date;
		}
		
		//parameterised constructor with 3 fields
		public MedicalRecord(String diagnosis, String treatment, String date) {
			super();
			this.diagnosis = diagnosis;
			this.treatment = treatment;
			this.date = date;
		}
		
		
		
		
}
