package com.cts.exceptions;

public class InquiryNotFoundException extends Exception {
    public InquiryNotFoundException(String message) {
        super(message);
    }
}
