package com.cts.dao;

import com.cts.exceptions.InquiryNotFoundException;
import com.cts.model.Resolution;
import com.cts.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ResolutionDAO {

    public void addResolution(Resolution resolution) throws InquiryNotFoundException {
        // First, check if the inquiry exists
        if (!inquiryExists(resolution.getInquiryId())) {
            throw new InquiryNotFoundException("Inquiry with ID " + resolution.getInquiryId() + " not found.");
        }

        String sql = "INSERT INTO Resolution (inquiry_id, complaint_id, resolution_date, details) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, resolution.getInquiryId());
            stmt.setInt(2, resolution.getComplaintId());
            stmt.setString(3, resolution.getResolutionDate());
            stmt.setString(4, resolution.getDetails());
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.err.println("Error adding resolution: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
        }
    }

    public Resolution getResolution(int resolutionId) {
        String sql = "SELECT * FROM Resolution WHERE resolution_id = ?";
        Resolution resolution = null;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, resolutionId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    resolution = new Resolution();
                    resolution.setResolutionId(rs.getInt("resolution_id"));
                    resolution.setInquiryId(rs.getInt("inquiry_id"));
                    resolution.setComplaintId(rs.getInt("complaint_id"));
                    resolution.setResolutionDate(rs.getString("resolution_date"));
                    resolution.setDetails(rs.getString("details"));
                }
            }

        } catch (SQLException e) {
            System.err.println("Error fetching resolution: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
        }

        return resolution;
    }

    public void updateResolutionDetails(int resolutionId, String details) {
        String sql = "UPDATE Resolution SET details = ? WHERE resolution_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, details);
            stmt.setInt(2, resolutionId);
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.err.println("Error updating resolution details: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
        }
    }

    public void deleteResolution(int resolutionId) {
        String sql = "DELETE FROM Resolution WHERE resolution_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, resolutionId);
            stmt.executeUpdate();

        } catch (SQLException e) {
            System.err.println("Error deleting resolution: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
        }
    }

    // Method to check if an inquiry exists
    private boolean inquiryExists(int inquiryId) {
        String sql = "SELECT COUNT(*) FROM Inquiry WHERE inquiry_id = ?";
        boolean exists = false;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, inquiryId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    exists = rs.getInt(1) > 0;
                }
            }

        } catch (SQLException e) {
            System.err.println("Error checking inquiry existence: " + e.getMessage());
        }

        return exists;
    }
}
