package com.cts;

import com.cts.dao.InquiryDAO;
import com.cts.dao.ComplaintDAO;
import com.cts.dao.ResolutionDAO;
import com.cts.model.Inquiry;
import com.cts.model.Complaint;
import com.cts.model.Resolution;
import com.cts.exceptions.CustomerNotFoundException;
import com.cts.exceptions.InquiryNotFoundException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        InquiryDAO inquiryDAO = new InquiryDAO();
        ComplaintDAO complaintDAO = new ComplaintDAO();
        ResolutionDAO resolutionDAO = new ResolutionDAO();

        while (true) {
            System.out.println("Customer Service Management System");
            System.out.println("1. Record a new inquiry");
            System.out.println("2. View inquiry details");
            System.out.println("3. Update inquiry status");
            System.out.println("4. Delete an inquiry");
            System.out.println("5. Register a new complaint");
            System.out.println("6. View complaint details");
            System.out.println("7. Update complaint status");
            System.out.println("8. Delete a complaint");
            System.out.println("9. Provide a resolution");
            System.out.println("10. View resolution details");
            System.out.println("11. Update resolution information");
            System.out.println("12. Delete a resolution record");
            System.out.println("13. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            try {
                switch (choice) {
                    case 1 -> {
                        // Record a new inquiry
                        System.out.print("Enter customer ID: ");
                        int customerId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        System.out.print("Enter inquiry date (YYYY-MM-DD): ");
                        String inquiryDate = scanner.nextLine();
                        System.out.print("Enter description: ");
                        String description = scanner.nextLine();
                        System.out.print("Enter status: ");
                        String status = scanner.nextLine();
                        Inquiry inquiry = new Inquiry(0, customerId, inquiryDate, description, status);
                        inquiryDAO.addInquiry(inquiry);
                        System.out.println("Inquiry recorded.");
                    }
                    case 2 -> {
                        // View inquiry details
                        System.out.print("Enter inquiry ID: ");
                        int inquiryId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        Inquiry inquiryDetails = inquiryDAO.getInquiry(inquiryId);
                        if (inquiryDetails != null) {
                            System.out.println("Inquiry ID: " + inquiryDetails.getInquiryId());
                            System.out.println("Customer ID: " + inquiryDetails.getCustomerId());
                            System.out.println("Inquiry Date: " + inquiryDetails.getInquiryDate());
                            System.out.println("Description: " + inquiryDetails.getDescription());
                            System.out.println("Status: " + inquiryDetails.getStatus());
                        } else {
                            System.out.println("Inquiry not found.");
                        }
                    }
                    case 3 -> {
                        // Update inquiry status
                        System.out.print("Enter inquiry ID: ");
                        int updateInquiryId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        System.out.print("Enter new status: ");
                        String newStatus = scanner.nextLine();
                        inquiryDAO.updateInquiryStatus(updateInquiryId, newStatus);
                        System.out.println("Inquiry status updated.");
                    }
                    case 4 -> {
                        // Delete an inquiry
                        System.out.print("Enter inquiry ID: ");
                        int deleteInquiryId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        inquiryDAO.deleteInquiry(deleteInquiryId);
                        System.out.println("Inquiry deleted.");
                    }
                    case 5 -> {
                        // Register a new complaint
                        System.out.print("Enter customer ID: ");
                        int complaintCustomerId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        System.out.print("Enter complaint date (YYYY-MM-DD): ");
                        String complaintDate = scanner.nextLine();
                        System.out.print("Enter description: ");
                        String complaintDescription = scanner.nextLine();
                        System.out.print("Enter status: ");
                        String complaintStatus = scanner.nextLine();
                        Complaint complaint = new Complaint(0, complaintCustomerId, complaintDate, complaintDescription, complaintStatus);
                        complaintDAO.addComplaint(complaint);
                        System.out.println("Complaint registered.");
                    }
                    case 6 -> {
                        // View complaint details
                        System.out.print("Enter complaint ID: ");
                        int complaintId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        Complaint complaintDetails = complaintDAO.getComplaint(complaintId);
                        if (complaintDetails != null) {
                            System.out.println("Complaint ID: " + complaintDetails.getComplaintId());
                            System.out.println("Customer ID: " + complaintDetails.getCustomerId());
                            System.out.println("Complaint Date: " + complaintDetails.getComplaintDate());
                            System.out.println("Description: " + complaintDetails.getDescription());
                            System.out.println("Status: " + complaintDetails.getStatus());
                        } else {
                            System.out.println("Complaint not found.");
                        }
                    }
                    case 7 -> {
                        // Update complaint status
                        System.out.print("Enter complaint ID: ");
                        int updateComplaintId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        System.out.print("Enter new status: ");
                        String newComplaintStatus = scanner.nextLine();
                        complaintDAO.updateComplaintStatus(updateComplaintId, newComplaintStatus);
                        System.out.println("Complaint status updated.");
                    }
                    case 8 -> {
                        // Delete a complaint
                        System.out.print("Enter complaint ID: ");
                        int deleteComplaintId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        complaintDAO.deleteComplaint(deleteComplaintId);
                        System.out.println("Complaint deleted.");
                    }
                    case 9 -> {
                        // Provide a resolution
                        System.out.print("Enter inquiry ID (0 if not applicable): ");
                        int resolutionInquiryId = scanner.nextInt();
                        System.out.print("Enter complaint ID (0 if not applicable): ");
                        int resolutionComplaintId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        System.out.print("Enter resolution date (YYYY-MM-DD): ");
                        String resolutionDate = scanner.nextLine();
                        System.out.print("Enter details: ");
                        String resolutionDetails = scanner.nextLine();
                        Resolution resolution = new Resolution(0, resolutionInquiryId, resolutionComplaintId, resolutionDate, resolutionDetails);

                        try {
                            resolutionDAO.addResolution(resolution);
                            System.out.println("Resolution provided.");
                        } catch (InquiryNotFoundException e) {
                            System.out.println(e.getMessage());
                        }
                        
                    }
                    case 10 -> {
                        // View resolution details
                        System.out.print("Enter resolution ID: ");
                        int resolutionId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        Resolution resolutionDetailss = resolutionDAO.getResolution(resolutionId);
                        if (resolutionDetailss != null) {
                            System.out.println("Resolution ID: " + resolutionDetailss.getResolutionId());
                            System.out.println("Inquiry ID: " + resolutionDetailss.getInquiryId());
                            System.out.println("Complaint ID: " + resolutionDetailss.getComplaintId());
                            System.out.println("Resolution Date: " + resolutionDetailss.getResolutionDate());
                            System.out.println("Details: " + resolutionDetailss.getDetails());
                        } else {
                            System.out.println("Resolution not found.");
                        }
                    }
                    case 11 -> {
                        // Update resolution details
                        System.out.print("Enter resolution ID: ");
                        int updateResolutionId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        System.out.print("Enter new details: ");
                        String newDetails = scanner.nextLine();
                        resolutionDAO.updateResolutionDetails(updateResolutionId, newDetails);
                        System.out.println("Resolution details updated.");
                    }
                    case 12 -> {
                        // Delete a resolution record
                        System.out.print("Enter resolution ID: ");
                        int deleteResolutionId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        resolutionDAO.deleteResolution(deleteResolutionId);
                        System.out.println("Resolution record deleted.");
                    }
                    case 13 -> {
                        // Exit
                        System.out.println("Exiting...");
                        scanner.close();
                        return;
                    }
                    default -> System.out.println("Invalid choice, please try again.");
                }
            } catch (CustomerNotFoundException e) {
                System.out.println("Error: " + e.getMessage());
           
            } catch (Exception e) {
                System.out.println("Unexpected error: " + e.getMessage());
            }
        }
    }
}
