package com.cts.model;

public class Inquiry {
    private int inquiryId;
    private int customerId;
    private String inquiryDate;
    private String description;
    private String status;

    public Inquiry() {}

    public Inquiry(int inquiryId, int customerId, String inquiryDate, String description, String status) {
        this.inquiryId = inquiryId;
        this.customerId = customerId;
        this.inquiryDate = inquiryDate;
        this.description = description;
        this.status = status;
    }

    public int getInquiryId() {
        return inquiryId;
    }

    public void setInquiryId(int inquiryId) {
        this.inquiryId = inquiryId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getInquiryDate() {
        return inquiryDate;
    }

    public void setInquiryDate(String inquiryDate) {
        this.inquiryDate = inquiryDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
