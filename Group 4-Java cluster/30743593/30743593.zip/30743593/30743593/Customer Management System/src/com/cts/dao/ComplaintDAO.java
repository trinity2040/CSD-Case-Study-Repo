package com.cts.dao;

import com.cts.model.Complaint;
import com.cts.util.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ComplaintDAO {
        public void addComplaint(Complaint complaint) {
        String sql = "INSERT INTO Complaint (customer_id, complaint_date, description, status) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setInt(1, complaint.getCustomerId());
            stmt.setString(2, complaint.getComplaintDate());
            stmt.setString(3, complaint.getDescription());
            stmt.setString(4, complaint.getStatus());
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("Error adding complaint: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
        }
    }

    public Complaint getComplaint(int complaintId) {
        String sql = "SELECT * FROM Complaint WHERE complaint_id = ?";
        Complaint complaint = null;
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setInt(1, complaintId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    complaint = new Complaint();
                    complaint.setComplaintId(rs.getInt("complaint_id"));
                    complaint.setCustomerId(rs.getInt("customer_id"));
                    complaint.setComplaintDate(rs.getString("complaint_date"));
                    complaint.setDescription(rs.getString("description"));
                    complaint.setStatus(rs.getString("status"));
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error fetching complaint: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
        }
        
        return complaint;
    }
    public void updateComplaintStatus(int complaintId, String status) {
        String sql = "UPDATE Complaint SET status = ? WHERE complaint_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, status);
            stmt.setInt(2, complaintId);
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("Error updating complaint status: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
        }
    }

    
    public void deleteComplaint(int complaintId) {
        String sql = "DELETE FROM Complaint WHERE complaint_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setInt(1, complaintId);
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("Error deleting complaint: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
        }
    }
}
