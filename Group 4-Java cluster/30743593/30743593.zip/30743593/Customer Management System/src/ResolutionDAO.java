import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ResolutionDAO {
    public void addResolution(Resolution resolution) throws SQLException {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO Resolution (inquiry_id, complaint_id, resolution_date, details) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, resolution.getInquiryId());
                stmt.setInt(2, resolution.getComplaintId());
                stmt.setString(3, resolution.getResolutionDate());
                stmt.setString(4, resolution.getDetails());
                stmt.executeUpdate();
            }
        }
    }

    public Resolution getResolution(int resolutionId) throws SQLException {
        Resolution resolution = null;
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM Resolution WHERE resolution_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, resolutionId);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        resolution = new Resolution();
                        resolution.setResolutionId(rs.getInt("resolution_id"));
                        resolution.setInquiryId(rs.getInt("inquiry_id"));
                        resolution.setComplaintId(rs.getInt("complaint_id"));
                        resolution.setResolutionDate(rs.getString("resolution_date"));
                        resolution.setDetails(rs.getString("details"));
                    }
                }
            }
        }
        return resolution;
    }

    public void updateResolutionDetails(int resolutionId, String details) throws SQLException {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "UPDATE Resolution SET details = ? WHERE resolution_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, details);
                stmt.setInt(2, resolutionId);
                stmt.executeUpdate();
            }
        }
    }

    public void deleteResolution(int resolutionId) throws SQLException {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "DELETE FROM Resolution WHERE resolution_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, resolutionId);
                stmt.executeUpdate();
            }
        }
    }
}