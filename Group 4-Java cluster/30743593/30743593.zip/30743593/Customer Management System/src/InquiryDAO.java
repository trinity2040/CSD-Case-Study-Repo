import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class InquiryDAO {
    public void addInquiry(Inquiry inquiry) throws SQLException {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO Inquiry (customer_id, inquiry_date, description, status) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, inquiry.getCustomerId());
                stmt.setString(2, inquiry.getInquiryDate());
                stmt.setString(3, inquiry.getDescription());
                stmt.setString(4, inquiry.getStatus());
                stmt.executeUpdate();
            }
        }
    }

    public Inquiry getInquiry(int inquiryId) throws SQLException {
        Inquiry inquiry = null;
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM Inquiry WHERE inquiry_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, inquiryId);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        inquiry = new Inquiry();
                        inquiry.setInquiryId(rs.getInt("inquiry_id"));
                        inquiry.setCustomerId(rs.getInt("customer_id"));
                        inquiry.setInquiryDate(rs.getString("inquiry_date"));
                        inquiry.setDescription(rs.getString("description"));
                        inquiry.setStatus(rs.getString("status"));
                    }
                }
            }
        }
        return inquiry;
    }

    public void updateInquiryStatus(int inquiryId, String status) throws SQLException {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "UPDATE Inquiry SET status = ? WHERE inquiry_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, status);
                stmt.setInt(2, inquiryId);
                stmt.executeUpdate();
            }
        }
    }

    public void deleteInquiry(int inquiryId) throws SQLException {
        try (Connection conn = DBConnection.getConnection()) {
            String sql = "DELETE FROM Inquiry WHERE inquiry_id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, inquiryId);
                stmt.executeUpdate();
            }
        }
    }
}
