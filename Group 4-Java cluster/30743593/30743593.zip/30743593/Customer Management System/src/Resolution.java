public class Resolution {
    private int resolutionId;
    private int inquiryId;
    private int complaintId;
    private String resolutionDate;
    private String details;

    public Resolution() {}

    public Resolution(int resolutionId, int inquiryId, int complaintId, String resolutionDate, String details) {
        this.resolutionId = resolutionId;
        this.inquiryId = inquiryId;
        this.complaintId = complaintId;
        this.resolutionDate = resolutionDate;
        this.details = details;
    }

    public int getResolutionId() {
        return resolutionId;
    }

    public void setResolutionId(int resolutionId) {
        this.resolutionId = resolutionId;
    }

    public int getInquiryId() {
        return inquiryId;
    }

    public void setInquiryId(int inquiryId) {
        this.inquiryId = inquiryId;
    }

    public int getComplaintId() {
        return complaintId;
    }

    public void setComplaintId(int complaintId) {
        this.complaintId = complaintId;
    }

    public String getResolutionDate() {
        return resolutionDate;
    }

    public void setResolutionDate(String resolutionDate) {
        this.resolutionDate = resolutionDate;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }
}
