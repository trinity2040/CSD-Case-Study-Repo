package pack1;


import java.util.Scanner;
import java.sql.*;
public class manageShipment {
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
    	
    	Class.forName("com.mysql.jdbc.Driver");  
    	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/logistics","udayJDBC","Udaykiran13");
    	
        Scanner scanner = new Scanner(System.in);
        int input;

        while (true) {
            System.out.println("\nMain Menu:");
            System.out.println("1. Shipment ");
            System.out.println("2. Vehicle ");
            System.out.println("3. Driver ");
            System.out.println("4. quit");
            System.out.print("Choose an option: ");
            input = scanner.nextInt();

            if (input==4) {
                System.out.println("Exiting the system. Goodbye!");
                break;
            }

            switch (input) {
                case 1:
                    while (true) {
                        System.out.println("\nShipment Operations:");
                        System.out.println("1. Add Shipment");
                        System.out.println("2. view Shipment");
                        System.out.println("3. Update Shipment");
                        System.out.println("4. delete shipment");
                        System.out.println("5. main menu");
                        System.out.print("Choose an option: ");
                        input = scanner.nextInt();

                        if (input==5) {
                            break;
                        }
                        // Handle shipment operations here
                        switch(input) {
                        case 1:
                        	String insertStmt="INSERT INTO shipment (shipment_id,description, origin, destination, status,delivery_date) VALUES(?,?,?,?,?,?)";
                        	PreparedStatement pstmt=con.prepareStatement(insertStmt);
                        	
                        	
                        	System.out.print("Enter Shipment ID: ");
                            int ShipmentId = scanner.nextInt();
                            scanner.nextLine();  // Consume the newline character

                            System.out.print("Enter decription: ");
                            String description=scanner.nextLine();
                            
                            System.out.println("Enter origin: ");
                            String origin=scanner.nextLine();
                            
                            System.out.println("enter destination: ");
                            String destination=scanner.nextLine();
                            //scanner.nextLine();

                            System.out.println("Enter status 1.In-transit, 2.deliverd: ");
                            int st=scanner.nextInt();
                            scanner.nextLine();
                            String status="in-transit";
                            if(st==2)
                            	status="delivered";
                            
                            System.out.println("Enter date(YYYY-MM-DD): ");
                            String date=scanner.nextLine();

                            // Set the values into the PreparedStatement
                            pstmt.setInt(1, ShipmentId);
                            pstmt.setString(2, description);
                            pstmt.setString(3, origin);
                            pstmt.setString(4, destination);
                            pstmt.setString(5, status);
                            pstmt.setString(6, date);
                            
                            int rowsInserted=pstmt.executeUpdate();
                            if(rowsInserted>0)
                            	System.out.println("shipment "+ShipmentId +" added");
                            else
                            	System.out.println("failed");
                            
                        	break;
                        case 2:
                        	String viewStmt="SELECT *FROM shipment";
                        	pstmt=con.prepareStatement(viewStmt);
                        	
                        	ResultSet rs=pstmt.executeQuery();
                        	while(rs.next())
                        		System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getString(4)+" "+rs.getString(5)+" "+rs.getDate(6));
                        	break;
                        case 3:
                        	String updateStmt="UPDATE shipment SET description=?, origin=?, destination=?, status=?, delivery_date=? WHERE shipment_id=?";
                        	pstmt=con.prepareStatement(updateStmt);
                        	
                        	System.out.print("Enter Shipment ID: ");
                            ShipmentId = scanner.nextInt();
                            scanner.nextLine();  // Consume the newline character

                            System.out.print("Enter decription: ");
                             description=scanner.nextLine();
                            
                            System.out.println("Enter origin: ");
                            origin=scanner.nextLine();
                            
                            System.out.println("enter destination: ");
                            destination=scanner.nextLine();
                            //scanner.nextLine();

                            System.out.println("Enter status 1.In-transit, 2.deliverd: ");
                            st=scanner.nextInt();
                            scanner.nextLine();
                            status="in-transit";
                            if(st==2)
                            	status="delivered";
                            
                            System.out.println("Enter date(YYYY-MM-DD): ");
                            date=scanner.nextLine();

                            // Set the values into the PreparedStatement
                            pstmt.setInt(6, ShipmentId);
                            pstmt.setString(1, description);
                            pstmt.setString(2, origin);
                            pstmt.setString(3, destination);
                            pstmt.setString(4, status);
                            pstmt.setString(5, date);
                            
                            int rowsUpdate=pstmt.executeUpdate();
                            if(rowsUpdate>0)
                            	System.out.println("shipment "+ShipmentId+" is updated");
                            else
                            	System.out.println("update failed");
                        	
                        	break;
                        case 4:
                        	String deleteStmt="DELETE FROM shipment WHERE shipment_id=?";
                        	pstmt=con.prepareStatement(deleteStmt);
                        	
                        	System.out.println("Enter shipment ID: ");
                        	ShipmentId=scanner.nextInt();
                        	pstmt.setInt(1, ShipmentId);
                        	
                        	int rowsDelete=pstmt.executeUpdate();
                        	if(rowsDelete>0)
                        		System.out.println("Shipment "+ShipmentId+" is deleted");
                        	else
                        		System.out.println("delete failed");
                        	break;
                        default:
                            System.out.println("Invalid option. Please try again.");
                            break;
                        }
                    }
                    break;

                case 2:
                	while (true) {
                        System.out.println("\nVehicle Operations:");
                        System.out.println("1. Add");
                        System.out.println("2. view");
                        System.out.println("3. Update");
                        System.out.println("4. delete");
                        System.out.println("5. main menu");
                        System.out.print("Choose an option: ");
                        input = scanner.nextInt();

                        if (input==5) {
                            break;
                        }
                        // Handle shipment operations here
                        switch(input) {
                        case 1:
                        	String insertStmt="INSERT INTO vehicle (vehicle_id,make,model, year, capacity) values (?,?,?,?,?)";
                        	PreparedStatement pstmt=con.prepareStatement(insertStmt);
                        	
                        	System.out.print("Enter Vehicle ID: ");
                            int VehicleId = scanner.nextInt();
                            scanner.nextLine();  // Consume the newline character

                            System.out.print("Enter make: ");
                            String make=scanner.nextLine();
                            
                            System.out.println("Enter model: ");
                            String model=scanner.nextLine();
                            
                            System.out.println("enter year: ");
                            int year=scanner.nextInt();
                            //scanner.nextLine();

                            System.out.print("Enter capacity: ");
                            int capacity=scanner.nextInt();

                            // Set the values into the PreparedStatement
                            
                            pstmt.setInt(1, VehicleId);
                            pstmt.setString(2,make);
                            pstmt.setString(3, model);
                            pstmt.setInt(4, year);
                            pstmt.setInt(5, capacity);

                            // Execute the insert
                            int rowsInserted = pstmt.executeUpdate();
                            if(rowsInserted>0)
                            	System.out.println("Vehicle added");
                            else 
                            	System.out.println("failed");
                        	
                        	break;
                        case 2:
                        	String viewStmt="SELECT *FROM vehicle";
                        	pstmt=con.prepareStatement(viewStmt);
                        	
                        	ResultSet rs=pstmt.executeQuery();
                        	while(rs.next())
                        		System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getInt(4)+" "+rs.getInt(5));
                        	break;
                        case 3:
                        	String updateStmt="UPDATE vehicle SET make=?, model=?, year=?, capacity=? WHERE vehicle_id=?";
                        	pstmt=con.prepareStatement(updateStmt);
                        	System.out.print("Enter Vehicle ID: ");
                            VehicleId = scanner.nextInt();
                            scanner.nextLine();  // Consume the newline character

                            System.out.print("Enter make: ");
                            make=scanner.nextLine();
                            
                            System.out.println("Enter model: ");
                            model=scanner.nextLine();
                            
                            System.out.println("enter year: ");
                            year=scanner.nextInt();
                    
                            System.out.print("Enter capacity: ");
                            capacity=scanner.nextInt();
                            
                            pstmt.setString(1,make);
                            pstmt.setString(2, model);
                            pstmt.setInt(3, year);
                            pstmt.setInt(4, capacity);
                            pstmt.setInt(5, VehicleId);
                            int rowsUpdate=pstmt.executeUpdate();
                            if(rowsUpdate>0)
                            	System.out.println(VehicleId+" Vehicle Updated");
                            else
                            	System.out.println("update failed");
                        	break;
                        case 4:
                        	String deleteStmt="DELETE FROM vehicle WHERE vehicle_id=?";
                        	pstmt=con.prepareStatement(deleteStmt);
                        	System.out.println("Enter Vehicle ID: ");
                        	VehicleId=scanner.nextInt();
                        	pstmt.setInt(1, VehicleId);
                        	int rowsDelete=pstmt.executeUpdate();
                        	if(rowsDelete>0)
                        		System.out.println("Vehicle "+VehicleId+" is deleted");
                        	else
                        		System.out.println("Delete failed");
                        	break;
                        default:
                            System.out.println("Invalid option. Please try again.");
                            break;
                        
                        	
                        }
                    }
                    break;

                case 3:
                	while (true) {
                        System.out.println("\nDriver Operations:");
                        System.out.println("1. Add");
                        System.out.println("2. view");
                        System.out.println("3. Update");
                        System.out.println("4. delete");
                        System.out.println("5. main");
                        System.out.print("Choose an option: ");
                        input = scanner.nextInt();

                        if (input==5) {
                            break;
                        }
                        // Handle shipment operations here
                        switch(input) {
                        case 1:
                        	String insertStmt = "INSERT INTO driver (driver_id, name,email,phone_number, license_number) VALUES (?, ?, ?,?,?)";
                            PreparedStatement pstmt = con.prepareStatement(insertStmt);

                            // Collect user input
                            System.out.print("Enter Driver ID: ");
                            int driverId = scanner.nextInt();
                            scanner.nextLine();  // Consume the newline character

                            System.out.print("Enter Driver Name: ");
                            String driverName = scanner.nextLine();
                            
                            System.out.println("Enter email: ");
                            String email=scanner.nextLine();
                            
                            System.out.println("enter phn_n number: ");
                            int phn=scanner.nextInt();
                            scanner.nextLine();

                            System.out.print("Enter License Number: ");
                            String licenseNumber = scanner.nextLine();

                            // Set the values into the PreparedStatement
                            pstmt.setInt(1, driverId);
                            pstmt.setString(2, driverName);
                            pstmt.setString(3, email);
                            pstmt.setInt(4, phn);
                            pstmt.setString(5, licenseNumber);

                            // Execute the insert
                            int rowsInserted = pstmt.executeUpdate();

                            if (rowsInserted > 0) {
                                System.out.println("driver added");
                            }
                        	break;
                        case 2:
                        	
                        	    	
                        	String viewStmt="SELECT *FROM driver"; 
                        	pstmt=con.prepareStatement(viewStmt);
                        	ResultSet rs=pstmt.executeQuery();
                        	while(rs.next())  
                        	System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getInt(4)+" "+rs.getString(5)+"");                          	                              	  
                        	break;
                        case 3:
                        	 String updateStmt="UPDATE driver SET name= ?, email= ?,phone_number=?, license_number=? WHERE driver_id=? ";
                        	 pstmt=con.prepareStatement(updateStmt);
                        	 
                        	 System.out.print("Enter Driver ID: ");
                             driverId = scanner.nextInt();
                             scanner.nextLine();  // Consume the newline character

                             System.out.print("Enter Driver Name: ");
                             driverName = scanner.nextLine();
                             
                             System.out.println("Enter email: ");
                             email=scanner.nextLine();
                             
                             System.out.println("enter phn_n number: ");
                             phn=scanner.nextInt();
                             scanner.nextLine();

                             System.out.println("Enter License Number: ");
                             licenseNumber = scanner.nextLine();
                             
                             pstmt.setInt(5,driverId);
                             pstmt.setString(1, driverName);
                             pstmt.setString(2,email);
                             pstmt.setInt(3, phn);
                             pstmt.setString(4, licenseNumber);
                             
                             pstmt.executeUpdate();
                        	 break;
                        case 4:
                        	String deleteStmt="DELETE FROM driver WHERE driver_id=?";
                        	pstmt=con.prepareStatement(deleteStmt);
                        	System.out.println("Enter Driver ID: ");
                        	driverId=scanner.nextInt();
                        	pstmt.setInt(1, driverId);
                        	pstmt.executeUpdate();  
                        	break;
                        default:
                            System.out.println("Invalid option. Please try again.");
                            break;
                        
                        	
                        }
                    }
                    break;

                default:
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
        }

        scanner.close();
    }
}
