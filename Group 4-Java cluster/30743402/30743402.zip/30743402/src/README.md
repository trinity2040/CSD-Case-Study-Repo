## Automobile Inventory Management System

# Description
The Automobile Inventory Management System is a console-based Java application that allows users to manage vehicles, customers, and sales transactions. The system is built using Core Java and uses MySQL as the backend database, with JDBC for database operations. This application provides a simple menu-driven interface to perform ADD, View, Update, Delete operations on the data.

# Features
- **Vehile Management**: Add, view, update, and delete vehicle details.
- **Customer Management**: Register, view, update, and delete customers details.
- **Sales Transaction Management**: Record sales, view sales, generate reports, and calculate total sales revenue.

# System Requirements
- Java Development Kit (JDK) 8 or later
- MySQL Server
- MySQL Connector/J (JDBC Driver)
- Integrated Development Environment (IDE): IntelliJ IDEA, Eclipse, VS Code or any other Java IDE

# Setup Instructions

1. **Database Creation**:
   - Create a MySQL database named `automobileinventory`.
   - Create the following tables:

     ```sql
    CREATE TABLE Vehicle (
    vehicle_id INT AUTO_INCREMENT PRIMARY KEY,
    make VARCHAR(50) NOT NULL,
    model VARCHAR(50) NOT NULL,
    year INT NOT NULL,
    price DOUBLE NOT NULL,
    available_quantity INT NOT NULL
   );
   CREATE TABLE Customer (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phone_number VARCHAR(15) NOT NULL
   );
   CREATE TABLE SalesTransaction (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    vehicle_id INT NOT NULL,
    customer_id INT NULL,
    transaction_date DATE NOT NULL,
    amount DOUBLE NOT NULL,
    FOREIGN KEY (vehicle_id) REFERENCES Vehicle(vehicle_id),
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
   );
     ```

2. **Configure the Application**:
   - Open the DBconnection.java file located in the src/database  directory and update it with your MySQL database credentials:
 
   ```java
      private static final String URL = "jdbc:mysql://localhost:3306/automobileinventory";
      private static final String USER = "your_username";
      private static final String PASSWORD = "your_password";

   ```

3. **Run the Application**:
   - Compile and run the `main.java` class.
   - Follow the on-screen menu to manage Vehicles, Customers, Sales.

## Usage
- Select the appropriate menu option to perform operations like adding, viewing, generating, updating, or deleting records in the system. 
- The system would handling errors in the input data and give user friendly error messages.

## Notes
- Ensure that your MySQL server is running and accessible.
- Modify the database credentials in the `DBconnection.java` file if necessary.



