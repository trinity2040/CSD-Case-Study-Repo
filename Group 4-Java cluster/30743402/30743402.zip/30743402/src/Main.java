import java.sql.*;
import java.util.Scanner;

// Entity classes where OOPS concept has been used to maintain Encapsulation and Data Abstraction.
class Vehicle {
    private int vehicleId;
    private String make;
    private String model;
    private int year;
    private double price;
    private int availableQuantity;

    public Vehicle(String make, String model, int year, double price, int availableQuantity) {
        this.make = make;
        this.model = model;
        this.year = year;
        this.price = price;
        this.availableQuantity = availableQuantity;
    }

    public Vehicle(int vehicleId, String make, String model, int year, double price, int availableQuantity) {
        this.vehicleId = vehicleId;
        this.make = make;
        this.model = model;
        this.year = year;
        this.price = price;
        this.availableQuantity = availableQuantity;
    }

    public int getVehicleId() {
        return vehicleId;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public int getYear() {
        return year;
    }

    public double getPrice() {
        return price;
    }

    public int getAvailableQuantity() {
        return availableQuantity;
    }
}

class Customer {
    private int customerId;
    private String customerName;
    private String email;
    private String phoneNumber;

    public Customer(String customerName, String email, String phoneNumber) {
        this.customerName = customerName;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    public Customer(int customerId, String customerName, String email, String phoneNumber) {
        this.customerId = customerId;
        this.customerName = customerName;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getEmail() {
        return email;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }
}

class SalesTransaction {
    private int transactionId;
    private int vehicleId;
    private int customerId;
    private String transactionDate;
    private double amount;

    public SalesTransaction(int vehicleId, int customerId, String transactionDate, double amount) {
        this.vehicleId = vehicleId;
        this.customerId = customerId;
        this.transactionDate = transactionDate;
        this.amount = amount;
    }

    public int getTransactionId() {
        return transactionId;
    }

    public int getVehicleId() {
        return vehicleId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public double getAmount() {
        return amount;
    }
}

// Driver classes which are designed in such a way that the exceptions can be handled effectively.
class VehicleDAO {
    public void addVehicle(Vehicle vehicle) {
        String sql = "INSERT INTO Vehicle (make, model, year, price, available_quantity) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, vehicle.getMake());
            pstmt.setString(2, vehicle.getModel());
            pstmt.setInt(3, vehicle.getYear());
            pstmt.setDouble(4, vehicle.getPrice());
            pstmt.setInt(5, vehicle.getAvailableQuantity());
            pstmt.executeUpdate();
            System.out.println("Vehicle added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void viewVehicles() {
        String sql = "SELECT * FROM Vehicle";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            System.out.println("VEHICLES :");
            System.out.println("+-------------+---------------+---------------+----------+--------------+--------------------+");
            System.out.println("| Vehicle ID  | Make          | Model         | Year     | Price        | Available Quantity |");
            System.out.println("+-------------+---------------+---------------+----------+--------------+--------------------+");

            while (rs.next()) {
                int VehicleId = rs.getInt("vehicle_id");
                String Make = rs.getString("make");
                String Model = rs.getString("model");
                int Year = rs.getInt("year");
                Double price=  rs.getDouble("price");
                int availableQuantity = rs.getInt("available_quantity");
                // Format and display the Customer data in a table-like format
                System.out.printf("| %-11d | %-13s | %-13s | %-8d | %12.2f | %18d |\n",
                        VehicleId, Make, Model, Year, price, availableQuantity);
            }

            System.out.println("+-------------+---------------+---------------+-----------+-------------+--------------------+");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void viewVehicle(int vehicleId) {
        String sql = "SELECT * FROM Vehicle WHERE vehicle_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, vehicleId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Vehicle ID: " + rs.getInt("vehicle_id"));
                System.out.println("Make: " + rs.getString("make"));
                System.out.println("Model: " + rs.getString("model"));
                System.out.println("Year: " + rs.getInt("year"));
                System.out.println("Price: " + rs.getDouble("price"));
                System.out.println("Available Quantity: " + rs.getInt("available_quantity"));
            } else {
                System.out.println("Vehicle not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateVehicle(Vehicle vehicle) {
        String sql = "UPDATE Vehicle SET make = ?, model = ?, year = ?, price = ?, available_quantity = ? WHERE vehicle_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, vehicle.getMake());
            pstmt.setString(2, vehicle.getModel());
            pstmt.setInt(3, vehicle.getYear());
            pstmt.setDouble(4, vehicle.getPrice());
            pstmt.setInt(5, vehicle.getAvailableQuantity());
            pstmt.setInt(6, vehicle.getVehicleId());
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Vehicle updated successfully.");
            } else {
                System.out.println("Vehicle not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteVehicle(int vehicleId) {
        String sql = "DELETE FROM Vehicle WHERE vehicle_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, vehicleId);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Vehicle deleted successfully.");
            } else {
                System.out.println("Vehicle not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

class CustomerDAO {
    public void addCustomer(Customer customer) {
        String sql = "INSERT INTO Customer (customer_name, email, phone_number) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, customer.getCustomerName());
            pstmt.setString(2, customer.getEmail());
            pstmt.setString(3, customer.getPhoneNumber());
            pstmt.executeUpdate();
            System.out.println("Customer added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void viewCustomers(){
        String sql = "SELECT * FROM Customer";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            System.out.println("CUSTOMERS :");
            System.out.println("+--------------+----------------------+--------------------------------+-------------------+");
            System.out.println("| Customer ID  | Name                 | Email                          | Phone Number      |");
            System.out.println("+--------------+----------------------+--------------------------------+-------------------+");

            while (rs.next()) {
                int CustomerId = rs.getInt("customer_id");
                String Name = rs.getString("customer_name");
                String Email = rs.getString("email");
                String PhoneNumber = rs.getString("phone_number");
                // Format and display the Customer data in a table-like format
                System.out.printf("| %-12d | %-20s | %-30s | %-17s |\n",
                        CustomerId, Name, Email, PhoneNumber);
            }

            System.out.println("+--------------+----------------------+--------------------------------+-------------------+");
          } catch (SQLException e) {
            e.printStackTrace();
        }
        }
    public void viewCustomer(int customerId){
        String sql = "SELECT * FROM Customer WHERE customer_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, customerId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Name: " + rs.getString("customer_name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone Number: " + rs.getString("phone_number"));
            } else {
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateCustomer(Customer customer) {
        String sql = "UPDATE Customer SET customer_name = ?, email = ?, phone_number = ? WHERE customer_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, customer.getCustomerName());
            pstmt.setString(2, customer.getEmail());
            pstmt.setString(3, customer.getPhoneNumber());
            pstmt.setInt(4, customer.getCustomerId());
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Customer updated successfully.");
            } else {
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteCustomer(int customerId) {
        String sql = "DELETE FROM Customer WHERE customer_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, customerId);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Customer deleted successfully.");
            } else {
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

class SalesTransactionDAO {

    public void generateSalesReport(String startDate, String endDate) {
        String sql = "SELECT * FROM SalesTransaction WHERE transaction_date BETWEEN ? AND ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDate(1, Date.valueOf(startDate));
            pstmt.setDate(2, Date.valueOf(endDate));
            ResultSet rs = pstmt.executeQuery();

            System.out.println("Sales Report from " + startDate + " to " + endDate + ":");
            System.out.println("------------------------------------------------------");
            while (rs.next()) {
                System.out.println("Transaction ID: " + rs.getInt("transaction_id"));
                System.out.println("Vehicle ID: " + rs.getInt("vehicle_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Transaction Date: " + rs.getDate("transaction_date"));
                System.out.println("Amount: $" + rs.getDouble("amount"));
                System.out.println("------------------------------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void recordSale(SalesTransaction transaction) {
        String sql = "INSERT INTO SalesTransaction (vehicle_id, customer_id, transaction_date, amount) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, transaction.getVehicleId());
            pstmt.setInt(2, transaction.getCustomerId());
            pstmt.setDate(3, Date.valueOf(transaction.getTransactionDate()));
            pstmt.setDouble(4, transaction.getAmount());
            pstmt.executeUpdate();
            System.out.println("Sales transaction recorded successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void viewSalesTransactions() {
        String sql = "SELECT * FROM SalesTransaction";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            System.out.println("SALES :");
            System.out.println("+----------------+-------------+-------------+------------------+----------------+");
            System.out.println("| Transaction ID | Vechile ID  | Customer ID | Transaction Date | Amount         |");
            System.out.println("+----------------+-------------+-------------+------------------+----------------+");

            while (rs.next()) {
                int TransactionId =  rs.getInt("transaction_id");
                int VehicleId = rs.getInt("vehicle_id");
                int CustomerId = rs.getInt("customer_id");
                String TransactionDate = String.valueOf(rs.getDate("transaction_date"));
                Double Amount = rs.getDouble("amount");
                // Format and display the Customer data in a table-like format
                System.out.printf("| %-14d | %-11d | %-11d | %16s | %-14.2f |\n",
                        TransactionId, VehicleId, CustomerId, TransactionDate,Amount);
            }

            System.out.println("+---------------+--------------+-------------+------------------+----------------+");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void viewSalesTransaction(int transactionId) {
        String sql = "SELECT * FROM SalesTransaction WHERE transaction_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, transactionId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Transaction ID: " + rs.getInt("transaction_id"));
                System.out.println("Vehicle ID: " + rs.getInt("vehicle_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Transaction Date: " + rs.getDate("transaction_date"));
                System.out.println("Amount: " + rs.getDouble("amount"));
            } else {
                System.out.println("Transaction not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void calculateTotalSalesRevenue() {
        String sql = "SELECT SUM(amount) AS total_revenue FROM SalesTransaction";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Total Sales Revenue: $" + rs.getDouble("total_revenue"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

// Main application class which contains all the private menu classes
public class Main {

    public static void main(String[] args) {
        VehicleDAO vehicleDAO = new VehicleDAO();
        CustomerDAO customerDAO = new CustomerDAO();
        SalesTransactionDAO transactionDAO = new SalesTransactionDAO();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nWELCOME TO AUTOMOBILE INVENTORY MANAGEMENT SYSTEM  \n");
            System.out.println("1. Vehicle Management");
            System.out.println("2. Customer Management");
            System.out.println("3. Sales Transaction Management");
            System.out.println("4. Exit");
            System.out.print("Please select an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    vehicleManagementMenu(vehicleDAO, scanner);
                    break;
                case 2:
                    customerManagementMenu(customerDAO, scanner);
                    break;
                case 3:
                    salesTransactionManagementMenu(transactionDAO, scanner);
                    break;
                case 4:
                    try {
                        System.out.print("Exiting the system.");
                        int i = 6;
                        while (i != 0) {
                            System.out.print(".");
                            Thread.sleep(600);
                            i--;
                        }
                        System.out.println();
                        System.out.println("ThankYou For Using Automobile Inventory Management System!!!");
                        System.exit(0);
                    }
                    catch(Exception e)
                    {
                        System.out.println("Something went wrong...");
                    }
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void vehicleManagementMenu(VehicleDAO vehicleDAO, Scanner scanner) {
        System.out.println("\nVehicle Management");
        System.out.println("1. Add New Vehicle");
        System.out.println("2. View Vehicle Details");
        System.out.println("3. Update Vehicle Information");
        System.out.println("4. Delete Vehicle");
        System.out.print("Please select an option: ");
        int choice = scanner.nextInt();
        int year=0,quantity=0;
        double price=0;
        switch (choice) {
            case 1:

                System.out.print("Enter make: ");
                String make = scanner.next();
                System.out.print("Enter model: ");
                String model = scanner.next();
                try {
                    System.out.print("Enter year: ");
                    year = scanner.nextInt();
                    if(String.valueOf(year).length() !=4)
                    {
                        System.out.println("Invalid year!!, Format : YYYY");
                        break;
                    }
                } catch (Exception e) {
                    System.out.println("Error : "+e.getMessage());
                    System.out.println("Invalid year, the input should be in YYYY format.");
                }
                try {
                    System.out.print("Enter price: ");
                    price = scanner.nextDouble();
                    System.out.print("Enter available quantity: ");
                    quantity = scanner.nextInt();
                } catch (Exception e) {
                    System.out.println("Error : "+e.getMessage());
                    System.out.println("Invalid price, the input should be numerical");
                }
                Vehicle vehicle = new Vehicle(make, model, year, price, quantity);
                vehicleDAO.addVehicle(vehicle);
                break;
            case 2:
                System.out.println("1. View all Vehicles");
                System.out.println("2. View a Vehicle");
                System.out.print("Please select an option: ");
                int c1 = scanner.nextInt();
                switch (c1) {
                    case 1:
                        vehicleDAO.viewVehicles();
                        break;
                    case 2:
                        System.out.print("Enter Vehicle ID to view: ");
                        int vehicleId = scanner.nextInt();
                        vehicleDAO.viewVehicle(vehicleId);
                        break;
                }
                break;
            case 3:
                System.out.print("Enter Vehicle ID to update: ");
                int updateId = scanner.nextInt();
                System.out.print("Enter new make: ");
                make = scanner.next();
                System.out.print("Enter new model: ");
                model = scanner.next();
                try {
                    System.out.print("Enter new year: ");
                    year = scanner.nextInt();
                } catch (Exception e) {
                    System.out.println("Error : "+e.getMessage());
                    System.out.println("Invalid year, the input should be in YYYY format.");
                }
                try {
                    System.out.print("Enter new price: ");
                    price = scanner.nextDouble();
                    System.out.print("Enter new available quantity: ");
                    quantity = scanner.nextInt();
                } catch (Exception e) {
                    System.out.println("Error : "+e.getMessage());
                    System.out.println("Invalid price, the input should be numerical");
                }
                vehicle = new Vehicle(updateId, make, model, year, price, quantity);
                vehicleDAO.updateVehicle(vehicle);
                break;
            case 4:
                System.out.print("Enter Vehicle ID to delete: ");
                int deleteId = scanner.nextInt();
                vehicleDAO.deleteVehicle(deleteId);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void customerManagementMenu(CustomerDAO customerDAO, Scanner scanner) {
        System.out.println("\nCustomer Management");
        System.out.println("1. Register New Customer");
        System.out.println("2. View Customer Details");
        System.out.println("3. Update Customer Information");
        System.out.println("4. Delete Customer Account");
        System.out.print("Please select an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                System.out.print("Enter customer name: ");
                String name = scanner.next();
                System.out.print("Enter email: ");
                String email = scanner.next();
                System.out.print("Enter phone number: ");
                String phone = scanner.next();
                if(phone.length()<10)
                {
                    System.out.println("Invalid phone number less than 10 digits.");
                    break;
                }
                Customer customer = new Customer(name, email, phone);
                customerDAO.addCustomer(customer);
                break;
            case 2:
                System.out.println("1. View all Customers");
                System.out.println("2. View a Customer");
                System.out.print("Please select an option: ");
                int c = scanner.nextInt();
                switch (c) {
                    case 1:
                        customerDAO.viewCustomers();
                        break;
                    case 2:
                        System.out.print("Enter Customer ID to view: ");
                        int customerId = scanner.nextInt();
                        customerDAO.viewCustomer(customerId);
                        break;
                }
                break;
            case 3:
                System.out.print("Enter Customer ID to update: ");
                int updateId = scanner.nextInt();
                System.out.print("Enter new customer name: ");
                name = scanner.next();
                System.out.print("Enter new email: ");
                email = scanner.next();
                System.out.print("Enter new phone number: ");
                phone = scanner.next();
                if(phone.length()<10) {
                    System.out.println("Invalid phone number less than 10 digits.");
                    break;
                }
                    customer = new Customer(updateId, name, email, phone);
                customerDAO.updateCustomer(customer);
                break;
            case 4:
                System.out.print("Enter Customer ID to delete: ");
                int deleteId = scanner.nextInt();
                customerDAO.deleteCustomer(deleteId);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void salesTransactionManagementMenu(SalesTransactionDAO transactionDAO, Scanner scanner) {
        System.out.println("\nSales Transaction Management");
        System.out.println("1. Record Vehicle Sale");
        System.out.println("2. View Sales Transaction Details");
        System.out.println("3. Calculate Total Sales Revenue");
        System.out.println("4. Generate Sales Report");
        System.out.print("Please select an option: ");
        int choic = scanner.nextInt();
        switch (choic) {
            case 1:
                int vehicleId=0,customerId=0;
                String date="";
                double amount=0.0;
                try {
                    System.out.print("Enter vehicle ID: ");
                    vehicleId = scanner.nextInt();
                    System.out.print("Enter customer ID: ");
                    customerId = scanner.nextInt();
                    System.out.print("Enter transaction date (YYYY-MM-DD): ");
                    date = scanner.next();
                    System.out.print("Enter amount: ");
                    amount = scanner.nextDouble();
                } catch (Exception e) {

                    System.out.println("Entries are not valid.");
                }
                SalesTransaction transaction = new SalesTransaction(vehicleId, customerId, date, amount);
                transactionDAO.recordSale(transaction);
                break;
            case 2:
                System.out.println("1. View all Sales Transactions");
                System.out.println("2. View a Sales Transaction");
                System.out.print("Please select an option: ");
                int c2 = scanner.nextInt();
                switch (c2) {
                    case 1:
                        transactionDAO.viewSalesTransactions();
                        break;
                    case 2:
                        System.out.print("Enter Transaction ID to view: ");
                        int transactionId = scanner.nextInt();
                        transactionDAO.viewSalesTransaction(transactionId);
                        break;
                }
                break;
            case 3:
                transactionDAO.calculateTotalSalesRevenue();
                break;
            case 4:
                String startDate="",endDate="";
                try {
                    System.out.print("Enter start date (YYYY-MM-DD): ");
                    startDate = scanner.next();
                    System.out.print("Enter end date (YYYY-MM-DD): ");
                    endDate = scanner.next();
                } catch (Exception e) {
                    System.out.println("Entries are not valid.");
                }
                transactionDAO.generateSalesReport(startDate, endDate);

                break;
            default:
                System.out.println("Invalid choice. Please try again.");
                break;
        }
    }
}
