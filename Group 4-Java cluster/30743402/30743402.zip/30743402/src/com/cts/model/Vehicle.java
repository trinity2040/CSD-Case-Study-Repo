package com.cts.model;

import com.cts.exception.InvalidYearException;

public class Vehicle {
    private int vehicleId;
    private String make;
    private String model;
    private int year;
    private double price;
    private int availableQuantity;

    public Vehicle(String make, String model, int year, double price, int availableQuantity)throws InvalidYearException {
        this.make = make;
        this.model = model;
        if (String.valueOf(year).length() !=4 || year < 1886 || year > java.time.Year.now().getValue()) {
            throw new InvalidYearException("Year " + year + " is invalid. Must be of four digit and between 1886 and " + java.time.Year.now().getValue());
        }
        else{ this.year = year;}
        this.price = price;
        this.availableQuantity = availableQuantity;
    }

    public Vehicle(int vehicleId, String make, String model, int year, double price, int availableQuantity) {
        this.vehicleId = vehicleId;
        this.make = make;
        this.model = model;
        this.year = year;
        this.price = price;
        this.availableQuantity = availableQuantity;
    }

    public int getVehicleId() {
        return vehicleId;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public int getYear() {
        return year;
    }

    public double getPrice() {
        return price;
    }

    public int getAvailableQuantity() {
        return availableQuantity;
    }
}