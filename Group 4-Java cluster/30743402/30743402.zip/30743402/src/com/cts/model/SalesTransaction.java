package com.cts.model;

public class SalesTransaction {
    private int transactionId;
    private int vehicleId;
    private int customerId;
    private String transactionDate;
    private double amount;

    public SalesTransaction(int vehicleId, int customerId, String transactionDate, double amount) {
        this.vehicleId = vehicleId;
        this.customerId = customerId;
        this.transactionDate = transactionDate;
        this.amount = amount;
    }

    public int getTransactionId() {
        return transactionId;
    }

    public int getVehicleId() {
        return vehicleId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public String getTransactionDate() {
        return transactionDate;
    }

    public double getAmount() {
        return amount;
    }
}
