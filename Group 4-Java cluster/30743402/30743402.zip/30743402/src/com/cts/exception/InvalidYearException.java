package com.cts.exception;
public class InvalidYearException extends Exception {

    // Default constructor
    public InvalidYearException() {
        super("Invalid year provided.");
    }

    // Constructor that accepts a custom error message
    public InvalidYearException(String message) {
        super(message);
    }

    // Constructor that accepts a custom message and a cause
    public InvalidYearException(String message, Throwable cause) {
        super(message, cause);
    }

    // Constructor that accepts a cause
    public InvalidYearException(Throwable cause) {
        super(cause);
    }
}
