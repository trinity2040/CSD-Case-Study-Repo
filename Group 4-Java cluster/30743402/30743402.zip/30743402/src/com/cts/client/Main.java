package com.cts.client;

import com.cts.dao.CustomerDAO;
import com.cts.dao.SalesTransactionDAO;
import com.cts.dao.VehicleDAO;
import com.cts.model.SalesTransaction;
import com.cts.model.Customer;
import com.cts.model.Vehicle;
import com.cts.exception.InvalidYearException;

import java.util.Scanner;


// Main application class which contains all the private menu classes
public class Main {

    public static void main(String[] args) throws InvalidYearException {
        VehicleDAO vehicleDAO = new VehicleDAO();
        CustomerDAO customerDAO = new CustomerDAO();
        SalesTransactionDAO transactionDAO = new SalesTransactionDAO();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nWELCOME TO AUTOMOBILE INVENTORY MANAGEMENT SYSTEM  \n");
            System.out.println("1. Vehicle Management");
            System.out.println("2. Customer Management");
            System.out.println("3. Sales Transaction Management");
            System.out.println("4. Exit");
            System.out.print("Please select an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    vehicleManagementMenu(vehicleDAO, scanner);
                    break;
                case 2:
                    customerManagementMenu(customerDAO, scanner);
                    break;
                case 3:
                    salesTransactionManagementMenu(transactionDAO, scanner);
                    break;
                case 4:
                    try {
                        System.out.print("Exiting the system.");
                        int i = 5;
                        while (i != 0) {
                            System.out.print(".");
                            Thread.sleep(500);
                            i--;
                        }
                        System.out.println();
                        System.out.println("ThankYou For Using Automobile Inventory Management System!!!");
                        System.exit(0);
                    }
                    catch(Exception e)
                    {
                        System.out.println("Something went wrong...");
                    }
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void vehicleManagementMenu(VehicleDAO vehicleDAO, Scanner scanner) throws InvalidYearException {
        System.out.println("\nVehicle Management");
        System.out.println("1. Add New Vehicle");
        System.out.println("2. View Vehicle Details");
        System.out.println("3. Update Vehicle Information");
        System.out.println("4. Delete Vehicle");
        System.out.print("Please select an option: ");
        int choice = scanner.nextInt();
        int year=0,quantity=0;
        double price=0;
        switch (choice) {
            case 1:

                System.out.print("Enter make: ");
                String make = scanner.next();
                System.out.print("Enter model: ");
                String model = scanner.next();
                System.out.print("Enter year: ");
                year = scanner.nextInt();
                try {
                    System.out.print("Enter price: ");
                    price = scanner.nextDouble();
                    System.out.print("Enter available quantity: ");
                    quantity = scanner.nextInt();
                } catch (Exception e) {
                    System.out.println("Error : "+e.getMessage());
                    System.out.println("Invalid price, the input should be numerical");
                }
                try {
                    Vehicle vehicle = new Vehicle(make, model, year, price, quantity);
                    vehicleDAO.addVehicle(vehicle);
                } catch (InvalidYearException e) {
                    System.out.println("Caught exception: " + e.getMessage());
                }
                break;
            case 2:
                System.out.println("1. View all Vehicles");
                System.out.println("2. View a Vehicle");
                System.out.print("Please select an option: ");
                int c1 = scanner.nextInt();
                switch (c1) {
                    case 1:
                        vehicleDAO.viewVehicles();
                        break;
                    case 2:
                        System.out.print("Enter Vehicle ID to view: ");
                        int vehicleId = scanner.nextInt();
                        vehicleDAO.viewVehicle(vehicleId);
                        break;
                }
                break;
            case 3:
                System.out.print("Enter Vehicle ID to update: ");
                int updateId = scanner.nextInt();
                System.out.print("Enter new make: ");
                make = scanner.next();
                System.out.print("Enter new model: ");
                model = scanner.next();
                System.out.print("Enter new year: ");
                year = scanner.nextInt();
                try {
                    System.out.print("Enter new price: ");
                    price = scanner.nextDouble();
                    System.out.print("Enter new available quantity: ");
                    quantity = scanner.nextInt();
                } catch (Exception e) {
                    System.out.println("Error : "+e.getMessage());
                    System.out.println("Invalid price, the input should be numerical");
                }
                try {
                    Vehicle vehicle = new Vehicle(make, model, year, price, quantity);
                    vehicleDAO.addVehicle(vehicle);
                } catch (InvalidYearException e) {
                    System.out.println("Caught exception: " + e.getMessage());
                }
                break;
            case 4:
                System.out.print("Enter Vehicle ID to delete: ");
                int deleteId = scanner.nextInt();
                vehicleDAO.deleteVehicle(deleteId);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void customerManagementMenu(CustomerDAO customerDAO, Scanner scanner) {
        System.out.println("\nCustomer Management");
        System.out.println("1. Register New Customer");
        System.out.println("2. View Customer Details");
        System.out.println("3. Update Customer Information");
        System.out.println("4. Delete Customer Account");
        System.out.print("Please select an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                System.out.print("Enter customer name: ");
                String name = scanner.next();
                System.out.print("Enter email: ");
                String email = scanner.next();
                System.out.print("Enter phone number: ");
                String phone = scanner.next();
                if(phone.length()<10)
                {
                    System.out.println("Invalid phone number less than 10 digits.");
                    break;
                }
                Customer customer = new Customer(name, email, phone);
                customerDAO.addCustomer(customer);
                break;
            case 2:
                System.out.println("1. View all Customers");
                System.out.println("2. View a Customer");
                System.out.print("Please select an option: ");
                int c = scanner.nextInt();
                switch (c) {
                    case 1:
                        customerDAO.viewCustomers();
                        break;
                    case 2:
                        System.out.print("Enter Customer ID to view: ");
                        int customerId = scanner.nextInt();
                        customerDAO.viewCustomer(customerId);
                        break;
                }
                break;
            case 3:
                System.out.print("Enter Customer ID to update: ");
                int updateId = scanner.nextInt();
                System.out.print("Enter new customer name: ");
                name = scanner.next();
                System.out.print("Enter new email: ");
                email = scanner.next();
                System.out.print("Enter new phone number: ");
                phone = scanner.next();
                if(phone.length()<10) {
                    System.out.println("Invalid phone number less than 10 digits.");
                    break;
                }
                customer = new Customer(updateId, name, email, phone);
                customerDAO.updateCustomer(customer);
                break;
            case 4:
                System.out.print("Enter Customer ID to delete: ");
                int deleteId = scanner.nextInt();
                customerDAO.deleteCustomer(deleteId);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void salesTransactionManagementMenu(SalesTransactionDAO transactionDAO, Scanner scanner) {
        System.out.println("\nSales Transaction Management");
        System.out.println("1. Record Vehicle Sale");
        System.out.println("2. View Sales Transaction Details");
        System.out.println("3. Calculate Total Sales Revenue");
        System.out.println("4. Generate Sales Report");
        System.out.print("Please select an option: ");
        int choic = scanner.nextInt();
        switch (choic) {
            case 1:
                int vehicleId=0,customerId=0;
                String date="";
                double amount=0.0;
                try {
                    System.out.print("Enter vehicle ID: ");
                    vehicleId = scanner.nextInt();
                    System.out.print("Enter customer ID: ");
                    customerId = scanner.nextInt();
                    System.out.print("Enter transaction date (YYYY-MM-DD): ");
                    date = scanner.next();
                    System.out.print("Enter amount: ");
                    amount = scanner.nextDouble();
                } catch (Exception e) {

                    System.out.println("Entries are not valid.");
                }
                SalesTransaction transaction = new SalesTransaction(vehicleId, customerId, date, amount);
                transactionDAO.recordSale(transaction);
                break;
            case 2:
                System.out.println("1. View all Sales Transactions");
                System.out.println("2. View a Sales Transaction");
                System.out.print("Please select an option: ");
                int c2 = scanner.nextInt();
                switch (c2) {
                    case 1:
                        transactionDAO.viewSalesTransactions();
                        break;
                    case 2:
                        System.out.print("Enter Transaction ID to view: ");
                        int transactionId = scanner.nextInt();
                        transactionDAO.viewSalesTransaction(transactionId);
                        break;
                }
                break;
            case 3:
                transactionDAO.calculateTotalSalesRevenue();
                break;
            case 4:
                String startDate="",endDate="";
                try {
                    System.out.print("Enter start date (YYYY-MM-DD): ");
                    startDate = scanner.next();
                    System.out.print("Enter end date (YYYY-MM-DD): ");
                    endDate = scanner.next();
                } catch (Exception e) {
                    System.out.println("Entries are not valid.");
                }
                transactionDAO.generateSalesReport(startDate, endDate);

                break;
            default:
                System.out.println("Invalid choice. Please try again.");
                break;
        }
    }
}
