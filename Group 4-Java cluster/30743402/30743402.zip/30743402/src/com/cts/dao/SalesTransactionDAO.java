package com.cts.dao;
import com.cts.model.SalesTransaction;
import com.cts.util.DBConnection;
import java.sql.*;

public class SalesTransactionDAO {

    public void generateSalesReport(String startDate, String endDate) {
        String sql = "SELECT * FROM SalesTransaction WHERE transaction_date BETWEEN ? AND ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setDate(1, Date.valueOf(startDate));
            pstmt.setDate(2, Date.valueOf(endDate));
            ResultSet rs = pstmt.executeQuery();

            System.out.println("Sales Report from " + startDate + " to " + endDate + ":");
            System.out.println("------------------------------------------------------");
            while (rs.next()) {
                System.out.println("Transaction ID: " + rs.getInt("transaction_id"));
                System.out.println("Vehicle ID: " + rs.getInt("vehicle_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Transaction Date: " + rs.getDate("transaction_date"));
                System.out.println("Amount: $" + rs.getDouble("amount"));
                System.out.println("------------------------------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void recordSale(SalesTransaction transaction) {
        String sql = "INSERT INTO SalesTransaction (vehicle_id, customer_id, transaction_date, amount) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, transaction.getVehicleId());
            pstmt.setInt(2, transaction.getCustomerId());
            pstmt.setDate(3, Date.valueOf(transaction.getTransactionDate()));
            pstmt.setDouble(4, transaction.getAmount());
            pstmt.executeUpdate();
            System.out.println("Sales transaction recorded successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewSalesTransactions() {
        String sql = "SELECT * FROM SalesTransaction";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            System.out.println("SALES :");
            System.out.println("+----------------+-------------+-------------+------------------+----------------+");
            System.out.println("| Transaction ID | Vechile ID  | Customer ID | Transaction Date | Amount         |");
            System.out.println("+----------------+-------------+-------------+------------------+----------------+");

            while (rs.next()) {
                int TransactionId = rs.getInt("transaction_id");
                int VehicleId = rs.getInt("vehicle_id");
                int CustomerId = rs.getInt("customer_id");
                String TransactionDate = String.valueOf(rs.getDate("transaction_date"));
                Double Amount = rs.getDouble("amount");
                // Format and display the Customer data in a table-like format
                System.out.printf("| %-14d | %-11d | %-11d | %16s | %-14.2f |\n",
                        TransactionId, VehicleId, CustomerId, TransactionDate, Amount);
            }

            System.out.println("+---------------+--------------+-------------+------------------+----------------+");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewSalesTransaction(int transactionId) {
        String sql = "SELECT * FROM SalesTransaction WHERE transaction_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, transactionId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Transaction ID: " + rs.getInt("transaction_id"));
                System.out.println("Vehicle ID: " + rs.getInt("vehicle_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Transaction Date: " + rs.getDate("transaction_date"));
                System.out.println("Amount: " + rs.getDouble("amount"));
            } else {
                System.out.println("Transaction not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void calculateTotalSalesRevenue() {
        String sql = "SELECT SUM(amount) AS total_revenue FROM SalesTransaction";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Total Sales Revenue: $" + rs.getDouble("total_revenue"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
