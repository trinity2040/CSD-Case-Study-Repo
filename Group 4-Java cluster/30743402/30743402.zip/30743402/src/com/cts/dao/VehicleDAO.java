package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cts.model.Vehicle;
import com.cts.util.DBConnection;
// Driver classes which are designed in such a way that the exceptions can be handled effectively.
public class VehicleDAO {
    public void addVehicle(Vehicle vehicle) {
        String sql = "INSERT INTO Vehicle (make, model, year, price, available_quantity) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, vehicle.getMake());
            pstmt.setString(2, vehicle.getModel());
            pstmt.setInt(3, vehicle.getYear());
            pstmt.setDouble(4, vehicle.getPrice());
            pstmt.setInt(5, vehicle.getAvailableQuantity());
            pstmt.executeUpdate();
            System.out.println("Vehicle added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewVehicles() {
        String sql = "SELECT * FROM Vehicle";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            System.out.println("VEHICLES :");
            System.out.println("+-------------+---------------+---------------+----------+--------------+--------------------+");
            System.out.println("| Vehicle ID  | Make          | Model         | Year     | Price        | Available Quantity |");
            System.out.println("+-------------+---------------+---------------+----------+--------------+--------------------+");

            while (rs.next()) {
                int VehicleId = rs.getInt("vehicle_id");
                String Make = rs.getString("make");
                String Model = rs.getString("model");
                int Year = rs.getInt("year");
                Double price = rs.getDouble("price");
                int availableQuantity = rs.getInt("available_quantity");
                // Format and display the Customer data in a table-like format
                System.out.printf("| %-11d | %-13s | %-13s | %-8d | %12.2f | %18d |\n",
                        VehicleId, Make, Model, Year, price, availableQuantity);
            }

            System.out.println("+-------------+---------------+---------------+-----------+-------------+--------------------+");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewVehicle(int vehicleId) {
        String sql = "SELECT * FROM Vehicle WHERE vehicle_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, vehicleId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Vehicle ID: " + rs.getInt("vehicle_id"));
                System.out.println("Make: " + rs.getString("make"));
                System.out.println("Model: " + rs.getString("model"));
                System.out.println("Year: " + rs.getInt("year"));
                System.out.println("Price: " + rs.getDouble("price"));
                System.out.println("Available Quantity: " + rs.getInt("available_quantity"));
            } else {
                System.out.println("Vehicle not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateVehicle(Vehicle vehicle) {
        String sql = "UPDATE Vehicle SET make = ?, model = ?, year = ?, price = ?, available_quantity = ? WHERE vehicle_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, vehicle.getMake());
            pstmt.setString(2, vehicle.getModel());
            pstmt.setInt(3, vehicle.getYear());
            pstmt.setDouble(4, vehicle.getPrice());
            pstmt.setInt(5, vehicle.getAvailableQuantity());
            pstmt.setInt(6, vehicle.getVehicleId());
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Vehicle updated successfully.");
            } else {
                System.out.println("Vehicle not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteVehicle(int vehicleId) {
        String sql = "DELETE FROM Vehicle WHERE vehicle_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, vehicleId);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Vehicle deleted successfully.");
            } else {
                System.out.println("Vehicle not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
