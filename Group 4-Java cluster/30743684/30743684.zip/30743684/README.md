# Job Portal System

This is a console-based job portal system developed in Core Java, utilizing MySQL for the database and JDBC for database connectivity.
The application allows users to manage job listings, applicants, and interviews.

## Features
- Create, read, update, and delete job listings.
- Manage applicants and their details.
- Schedule and manage interviews.

## Setup
- Start your MySQL server.
- Create a database named 'job_portal'.
- Execute the SQL script found in 'resources/schema.sql'

## Usage
- Follow the instructions to navigate through the menu.
- The application provides options to manage job listings, applicants and interviews.


