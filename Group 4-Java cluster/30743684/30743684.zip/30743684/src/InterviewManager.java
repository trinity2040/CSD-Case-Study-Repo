import java.sql.*;
import java.util.Scanner;

public class InterviewManager {

    Scanner sc = new Scanner(System.in);


    // Function to schedule a new interview
    public void scheduleInterview(){
        try(Connection connection = DatabaseConnection.getConnection()){
            System.out.print("Enter job ID: ");
            int jobId = sc.nextInt();

            System.out.print("Enter applicant ID: ");
            int applicantId = sc.nextInt();

            System.out.print("Enter interview date (YYYY-MM-DD HH:MM:SS): ");
            Timestamp interviewDate = Timestamp.valueOf(sc.next() + " " + sc.next());
            sc.nextLine();

            String sql = "INSERT INTO interview (job_id, applicant_id, interview_date, status) VALUES (?, ?, ?, 'scheduled')";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, jobId);
            pstmt.setInt(2, applicantId);
            pstmt.setTimestamp(3, interviewDate);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Interview scheduled successfully.");
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
    }


    // Function to view all scheduled interview
    public void viewInterviews() {
        String sql = "SELECT * FROM interview";
        try (Connection connection = DatabaseConnection.getConnection()) {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                System.out.println("Interview ID: " + rs.getInt("interview_id"));
                System.out.println("Job ID: " + rs.getInt("job_id"));
                System.out.println("Applicant ID: " + rs.getInt("applicant_id"));
                System.out.println("Interview Date: " + rs.getTimestamp("interview_date"));
                System.out.println("Status: " + rs.getString("status"));
                System.out.println("----------------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    // Function to update existing interview
    public void updateInterview(int interviewId, int jobId, int applicantId, Timestamp interviewDate, String status) {
        String sql = "UPDATE interview SET job_id = ?, applicant_id = ?, interview_date = ?, status = ? WHERE interview_id = ?";
        try (Connection connection = DatabaseConnection.getConnection()) {
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, jobId);
            pstmt.setInt(2, applicantId);
            pstmt.setTimestamp(3, interviewDate);
            pstmt.setString(4, status);
            pstmt.setInt(5, interviewId);
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Interview updated successfully.");
            } else {
                System.out.println("Interview not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    // Function to cancel the scheduled interview
    public void cancelInterview(int interviewId) {
        String sql = "DELETE FROM interview WHERE interview_id = ?";
        try (Connection connection = DatabaseConnection.getConnection()) {
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, interviewId);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Interview cancelled successfully.");
            } else {
                System.out.println("Interview not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
