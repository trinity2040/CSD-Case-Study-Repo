import java.sql.Timestamp;
import java.util.Scanner;

public class Main {
   private static Scanner sc = new Scanner(System.in);

   // This Class will manage job listing operations
   private static JobListingManager jobManager = new JobListingManager();

   // This class will manage applicant listing operations
   private static ApplicantManager applicantManager = new ApplicantManager();

   // This class will manage interview listing operations
   private static InterviewManager interviewManager = new InterviewManager();


   // Program Execution will start from this method.
    public static void main(String[] args) {
        while (true) {
            System.out.println("\nJob Portal System");
            System.out.println("1. Manage Job Listings");
            System.out.println("2. Manage Applicants");
            System.out.println("3. Manage Interviews");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    manageJobListings();
                    break;
                case 2:
                    manageApplicants();
                    break;
                case 3:
                    manageInterviews();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }


    // Menu for Job listing management
    private static void manageJobListings() {
        System.out.println("\n1. Add Job");
        System.out.println("2. View Job");
        System.out.println("3. Update Job");
        System.out.println("4. Delete Job");
        System.out.print("Choose an option: ");
        int choice = sc.nextInt();

        switch (choice) {
            case 1:
                jobManager.addJob();
                break;
            case 2:

                jobManager.viewJob();
                break;
            case 3:
                System.out.print("Enter job ID: ");
                int jobId = sc.nextInt();
                sc.nextLine();

                System.out.print("Enter job title: ");
                String updatedTitle = sc.nextLine();

                System.out.print("Enter job description: ");
                String updatedDescription = sc.nextLine();

                System.out.print("Enter job requirements: ");
                String updatedRequirements = sc.nextLine();

                System.out.print("Enter job status (active/inactive): ");
                String updatedStatus = sc.nextLine();
                jobManager.updateJob(jobId,updatedTitle,updatedDescription,updatedRequirements,updatedStatus);
                break;
            case 4:
                System.out.print("Enter job ID: ");
                int jobID = sc.nextInt();
                jobManager.deleteJob(jobID);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");

        }
    }

    // Menu for Applicant management
    private static void manageApplicants() {
        System.out.println("\n1. Register Applicant");
        System.out.println("2. View Applicant");
        System.out.println("3. Update Applicant");
        System.out.println("4. Delete Applicant");
        System.out.print("Choose an option: ");
        int choice = sc.nextInt();

        switch (choice) {
            case 1:
                applicantManager.registerApplicant();
                break;
            case 2:
                applicantManager.viewApplicants();
                break;
            case 3:
                System.out.print("Enter Applicant ID to update: ");
                int applicantId = sc.nextInt();
                sc.nextLine();
                System.out.print("Enter new name: ");
                String newName = sc.nextLine();
                System.out.print("Enter new email: ");
                String newEmail = sc.nextLine();
                System.out.print("Enter new phone number: ");
                String newPhoneNumber = sc.nextLine();
                System.out.print("Enter new address: ");
                String newAddress = sc.nextLine();
                applicantManager.updateApplicant(applicantId, newName, newEmail, newPhoneNumber, newAddress);
                break;
            case 4:
                System.out.print("Enter Applicant ID to delete: ");
                int deleteApplicantId = sc.nextInt();
                applicantManager.deleteApplicant(deleteApplicantId);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");

        }
    }


    // Menu for Interview management
    private static void manageInterviews() {
        System.out.println("\n1. Schedule Interview");
        System.out.println("2. View Interview");
        System.out.println("3. Update Interview");
        System.out.println("4. Cancel Interview");
        System.out.print("Choose an option: ");
        int choice = sc.nextInt();

        switch (choice) {
            case 1:
                interviewManager.scheduleInterview();
                break;
            case 2:
                interviewManager.viewInterviews();
                break;
            case 3:
                System.out.print("Enter Interview ID to update: ");
                int interviewId = sc.nextInt();
                System.out.print("Enter new Job ID: ");
                int newJobId = sc.nextInt();
                System.out.print("Enter new Applicant ID: ");
                int newApplicantId = sc.nextInt();
                System.out.print("Enter new Interview Date (YYYY-MM-DD HH:MM:SS): ");
                Timestamp newInterviewDate = Timestamp.valueOf(sc.next() + " " + sc.next());
                sc.nextLine();
                System.out.print("Enter new status (scheduled/completed/cancelled): ");
                String newStatus = sc.nextLine();
                interviewManager.updateInterview(interviewId, newJobId, newApplicantId, newInterviewDate, newStatus);
                break;
            case 4:
                System.out.print("Enter Interview ID to cancel: ");
                int cancelInterviewId = sc.nextInt();
                interviewManager.cancelInterview(cancelInterviewId);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");

        }
    }
}
