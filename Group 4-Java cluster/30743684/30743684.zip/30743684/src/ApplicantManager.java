import java.sql.*;
import java.util.Scanner;

public class ApplicantManager {
    Scanner sc = new Scanner(System.in);


    // Function to register a new applicant
    public void registerApplicant(){
        try(Connection connection = DatabaseConnection.getConnection()){
            System.out.print("Enter applicant name: ");
            String name = sc.nextLine();
            System.out.print("Enter applicant email: ");
            String email = sc.nextLine();
            System.out.print("Enter applicant phone number: ");
            String phoneNumber = sc.nextLine();
            System.out.print("Enter applicant address: ");
            String address = sc.nextLine();

            String sql = "INSERT INTO applicant (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phoneNumber);
            pstmt.setString(4, address);
            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Applicant registered successfully.");
            }
        } catch(SQLException e){
            e.printStackTrace();
        }
    }


    // Function to view all registered applicants
    public void viewApplicants() {
        String sql = "SELECT * FROM applicant";
        try (Connection connection = DatabaseConnection.getConnection()) {
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()) {
                System.out.println("Applicant ID: " + rs.getInt("applicant_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone Number: " + rs.getString("phone_number"));
                System.out.println("Address: " + rs.getString("address"));
                System.out.println("----------------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    // Function to update the already registered applicant
    public void updateApplicant(int applicantId, String name, String email, String phoneNumber, String address) {
        String sql = "UPDATE applicant SET name = ?, email = ?, phone_number = ?, address = ? WHERE applicant_id = ?";
        try (Connection connection = DatabaseConnection.getConnection()) {
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phoneNumber);
            pstmt.setString(4, address);
            pstmt.setInt(5, applicantId);
            int rowsUpdated = pstmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Applicant updated successfully.");
            } else {
                System.out.println("Applicant not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    //Function to delete registered applicant
    public void deleteApplicant(int applicantId) {
        String sql = "DELETE FROM applicant WHERE applicant_id = ?";
        try (Connection connection = DatabaseConnection.getConnection()) {
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setInt(1, applicantId);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Applicant deleted successfully.");
            } else {
                System.out.println("Applicant not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
