import java.sql.*;
import java.util.Scanner;

public class JobListingManager {
    Scanner sc = new Scanner(System.in);


    // Function for adding new job listing
    public void addJob(){
        try(Connection connection = DatabaseConnection.getConnection()){
            System.out.print("Enter job title: ");
            String title = sc.nextLine();
            System.out.print("Enter job description: ");
            String description = sc.nextLine();
            System.out.print("Enter job requirements: ");
            String requirements = sc.nextLine();

            String sql = "INSERT INTO joblisting (title, description, requirements, posted_date, status) VALUES (?, ?, ?, CURDATE(), 'active')";
            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, title);
            pstmt.setString(2, description);
            pstmt.setString(3, requirements);
            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Job added successfully.");
            }
        }
        catch(SQLException e){
            e.printStackTrace();
        }
    }


    // Function to view all listed job
    public void viewJob() {
        String sql = "SELECT * FROM joblisting";

        try (Connection connection = DatabaseConnection.getConnection()) {

            PreparedStatement pstmt = connection.prepareStatement(sql);

            ResultSet rs = pstmt.executeQuery();

            while(rs.next()) {
                System.out.println("Job ID: " + rs.getInt("job_id"));
                System.out.println("Title: " + rs.getString("title"));
                System.out.println("Description: " + rs.getString("description"));
                System.out.println("Requirements: " + rs.getString("requirements"));
                System.out.println("Posted Date: " + rs.getDate("posted_date"));
                System.out.println("Status: " + rs.getString("status"));
                System.out.println("----------------------------------------");
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    // Function to Update already listed job
    public void updateJob(int jobId,String updatedTitle,String updatedDescription,String updatedRequirements,String updatedStatus)  {
        String sql = "UPDATE joblisting SET title = ?, description = ?, requirements = ?, status = ? WHERE job_id = ?";
        try (Connection connection = DatabaseConnection.getConnection()) {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setString(1, updatedTitle);
            stmt.setString(2, updatedDescription);
            stmt.setString(3, updatedRequirements);
            stmt.setString(4, updatedStatus);
            stmt.setInt(5, jobId);
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Job updated successfully.");
            } else {
                System.out.println("Job not found.");
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
    }

    //Function to Delete existing job
    public void deleteJob(int jobId) {
        String sql = "DELETE FROM joblisting WHERE job_id = ?";
        try(Connection connection = DatabaseConnection.getConnection()) {
            PreparedStatement stmt = connection.prepareStatement(sql);
            stmt.setInt(1, jobId);
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Job deleted successfully.");
            } else {
                System.out.println("Job not found.");
            }
        }catch(SQLException e){
            e.getLocalizedMessage();
        }
    }
}
