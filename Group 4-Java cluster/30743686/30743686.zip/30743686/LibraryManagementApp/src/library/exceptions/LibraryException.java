package library.exceptions;

/**
 * Custom exception class for handling library-related errors.
 */
public class LibraryException extends Exception {
    
    // Serial version UID for serialization
    private static final long serialVersionUID = 1L;

    // Constructor accepting a message
    public LibraryException(String message) {
        super(message);
    }

    // Constructor accepting a message and a cause
    public LibraryException(String message, Throwable cause) {
        super(message, cause);
    }

    // Constructor accepting a cause
    public LibraryException(Throwable cause) {
        super(cause);
    }
}


