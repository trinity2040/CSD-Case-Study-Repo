package library.operations;

import library.exceptions.LibraryException;

import java.sql.*;
import java.util.Scanner;

public class BookOperations {

    // Add a new book to the database
    public static void addBook(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter book title: ");
            String title = scanner.nextLine();
            System.out.print("Enter author name: ");
            String author = scanner.nextLine();
            System.out.print("Enter genre: ");
            String genre = scanner.nextLine();
            System.out.print("Enter price: ");
            double price = scanner.nextDouble();
            System.out.print("Enter available copies: ");
            int availableCopies = scanner.nextInt();

            if (price < 0 || availableCopies < 0) {
                throw new LibraryException("Price and available copies cannot be negative.");
            }

            String query = "INSERT INTO Book (title, author, genre, price, available_copies) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                stmt.setString(1, title);
                stmt.setString(2, author);
                stmt.setString(3, genre);
                stmt.setDouble(4, price);
                stmt.setInt(5, availableCopies);
                stmt.executeUpdate();
                System.out.println("Book added successfully.");
            }
        } catch (LibraryException e) {
            System.out.println("Input Error: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error adding book: " + e.getMessage());
        }
    }
    
 // View all book details
    public static void viewBookDetails(Connection connection) {
        String query = "SELECT * FROM Book";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(query)) {
            System.out.println("\n---------------------------------------------------------------------------------------------------------------------");
            System.out.printf("%-8s %-30s %-25s %-15s %-10s %-15s\n", 
                              "Book ID", "Title", "Author", "Genre", "Price", "Available Copies");
            System.out.println("-----------------------------------------------------------------------------------------------------------------------");

            while (rs.next()) {
                System.out.printf("%-8d %-30s %-25s %-15s %-10.2f %-15d\n", 
                                  rs.getInt("book_id"), rs.getString("title"), rs.getString("author"), 
                                  rs.getString("genre"), rs.getDouble("price"), rs.getInt("available_copies"));
            }
            System.out.println("-----------------------------------------------------------------------------------------------------------------------");

        } catch (SQLException e) {
            System.out.println("Error retrieving book details: " + e.getMessage());
        }
    }

 // Update book information
    public static void updateBookInfo(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter the book ID to update: ");
            int bookId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            // Check if the book ID exists in the database
            String checkQuery = "SELECT COUNT(*) AS count FROM Book WHERE book_id = ?";
            try (PreparedStatement checkStmt = connection.prepareStatement(checkQuery)) {
                checkStmt.setInt(1, bookId);
                ResultSet rs = checkStmt.executeQuery();
                rs.next();
                int count = rs.getInt("count");

                if (count == 0) {
                    System.out.println("Error: Book ID not found.");
                    return; // Exit the method if the book ID is not found
                }
            }

            // Proceed with updating the book information since the book ID exists
            System.out.print("Enter new title: ");
            String title = scanner.nextLine();
            System.out.print("Enter new author: ");
            String author = scanner.nextLine();
            System.out.print("Enter new genre: ");
            String genre = scanner.nextLine();
            System.out.print("Enter new price: ");
            double price = scanner.nextDouble();
            System.out.print("Enter new available copies: ");
            int availableCopies = scanner.nextInt();

            String query = "UPDATE Book SET title = ?, author = ?, genre = ?, price = ?, available_copies = ? WHERE book_id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                stmt.setString(1, title);
                stmt.setString(2, author);
                stmt.setString(3, genre);
                stmt.setDouble(4, price);
                stmt.setInt(5, availableCopies);
                stmt.setInt(6, bookId);
                stmt.executeUpdate();

                System.out.println("Book information updated successfully.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating book: " + e.getMessage());
        }
    }



    // Delete a book from the database
    public static void deleteBook(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter the book ID to delete: ");
            int bookId = scanner.nextInt();
            scanner.nextLine(); // Consume newline left-over

            // Check if the book is issued
            String checkIssuedQuery = "SELECT COUNT(*) AS count FROM Issue WHERE book_id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(checkIssuedQuery)) {
                stmt.setInt(1, bookId);
                ResultSet rs = stmt.executeQuery();
                rs.next();
                int issuedCount = rs.getInt("count");

                if (issuedCount > 0) {
                    throw new LibraryException("Cannot delete book. It is currently issued to members.");
                }
            }

            // Delete the book
            String query = "DELETE FROM Book WHERE book_id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(query)) {
                stmt.setInt(1, bookId);
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Book deleted successfully.");
                } else {
                    System.out.println("Book not found.");
                }
            }
        } catch (LibraryException e) {
            System.out.println("Operation Error: " + e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error deleting book: " + e.getMessage());
        }
    }
}




