package library.operations;

import library.exceptions.LibraryException;

import java.sql.*;
import java.util.Scanner;

public class IssueOperations {

    // Issue a book to a member
    public static void issueBook(Connection connection, Scanner scanner) {
        try {
            // Display available books
            String bookQuery = "SELECT * FROM Book WHERE available_copies > 0";
            System.out.println("\nAvailable Books:");
            try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(bookQuery)) {
                while (rs.next()) {
                    System.out.println("Book ID: " + rs.getInt("book_id") + ", Title: " + rs.getString("title") +
                            ", Available Copies: " + rs.getInt("available_copies"));
                }
            }

            // Display members
            String memberQuery = "SELECT * FROM Member";
            System.out.println("\nRegistered Members:");
            try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(memberQuery)) {
                while (rs.next()) {
                    System.out.println("Member ID: " + rs.getInt("member_id") + ", Name: " + rs.getString("name"));
                }
            }

            // Prompt for book ID and member ID
            System.out.print("\nEnter the Book ID to issue: ");
            int bookId = scanner.nextInt();
            System.out.print("Enter the Member ID to issue the book to: ");
            int memberId = scanner.nextInt();

            // Check available copies and issue the book
            try {
                issueBookToMember(connection, bookId, memberId);
            } catch (LibraryException e) {
                System.out.println("Error issuing book: " + e.getMessage());
            }
        } catch (SQLException e) {
            System.out.println("Error issuing book: " + e.getMessage());
        }
    }

    // Private method to handle issuing logic
    private static void issueBookToMember(Connection connection, int bookId, int memberId) throws LibraryException {
        try {
            connection.setAutoCommit(false); // Begin transaction

            // Validate book availability
            String bookQuery = "SELECT available_copies FROM Book WHERE book_id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(bookQuery)) {
                stmt.setInt(1, bookId);
                ResultSet rs = stmt.executeQuery();
                if (rs.next() && rs.getInt("available_copies") > 0) {
                    // Validate member's book limit
                    String memberQuery = "SELECT books_issued FROM Member WHERE member_id = ?";
                    try (PreparedStatement stmt2 = connection.prepareStatement(memberQuery)) {
                        stmt2.setInt(1, memberId);
                        ResultSet rs2 = stmt2.executeQuery();
                        if (rs2.next() && rs2.getInt("books_issued") < 3) { // assuming limit is 3 books
                            // Update issue table
                            String issueQuery = "INSERT INTO Issue (book_id, member_id, issue_date) VALUES (?, ?, NOW())";
                            try (PreparedStatement stmt3 = connection.prepareStatement(issueQuery)) {
                                stmt3.setInt(1, bookId);
                                stmt3.setInt(2, memberId);
                                stmt3.executeUpdate();
                            }

                            // Update book and member records
                            String updateBookQuery = "UPDATE Book SET available_copies = available_copies - 1 WHERE book_id = ?";
                            try (PreparedStatement stmt4 = connection.prepareStatement(updateBookQuery)) {
                                stmt4.setInt(1, bookId);
                                stmt4.executeUpdate();
                            }

                            String updateMemberQuery = "UPDATE Member SET books_issued = books_issued + 1 WHERE member_id = ?";
                            try (PreparedStatement stmt5 = connection.prepareStatement(updateMemberQuery)) {
                                stmt5.setInt(1, memberId);
                                stmt5.executeUpdate();
                            }

                            connection.commit(); // Commit transaction
                            System.out.println("Book issued successfully.");
                        } else {
                            throw new LibraryException("Member has reached the book issue limit.");
                        }
                    }
                } else {
                    throw new LibraryException("Book is not available.");
                }
            }

        } catch (SQLException e) {
            try {
                connection.rollback(); // Rollback transaction
                System.out.println("Transaction failed, rolling back. Error: " + e.getMessage());
            } catch (SQLException rollbackException) {
                System.out.println("Error during rollback: " + rollbackException.getMessage());
            }
        } finally {
            try {
                connection.setAutoCommit(true); // Reset auto-commit
            } catch (SQLException e) {
                System.out.println("Error resetting auto-commit: " + e.getMessage());
            }
        }
    }
}




