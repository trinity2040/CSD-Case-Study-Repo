package library;

import library.operations.BookOperations;
import library.operations.IssueOperations;
import library.utils.DBUtils;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class LibraryApp {
    // JDBC URL, username, and password of MySQL server
    static final String JDBC_URL = "jdbc:mysql://localhost:3306/LibraryDB";
    static final String JDBC_USER = "root"; // MySQL username
    static final String JDBC_PASSWORD = "admin123"; // MySQL password

    public static void main(String[] args) {
        try (Connection connection = DBUtils.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD)) {
            System.out.println("Connected to the database.");
            
            Scanner scanner = new Scanner(System.in); // Initialize scanner once
            displayMenu(connection, scanner);  // Pass scanner to the menu
            
            scanner.close(); // Close the scanner after the menu loop is completed
        } catch (SQLException e) {
            System.out.println("Connection failed: " + e.getMessage());
        }
    }

    public static void displayMenu(Connection connection, Scanner scanner) {
        int choice = 0;
        do {
            System.out.println("\nLibrary Management Menu:");
            System.out.println("1. Add a new book");
            System.out.println("2. View book details");
            System.out.println("3. Update book information");
            System.out.println("4. Delete a book");
            System.out.println("5. Issue a book");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            // Handle input validation
            if (scanner.hasNextInt()) {
                choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline left-over
            } else {
                System.out.println("Invalid input. Please enter a number between 1 and 6.");
                scanner.nextLine(); // Clear the invalid input
                continue; // Skip to the next iteration
            }

            switch (choice) {
                case 1:
                    BookOperations.addBook(connection, scanner);
                    break;
                case 2:
                    BookOperations.viewBookDetails(connection);
                    break;
                case 3:
                    BookOperations.updateBookInfo(connection, scanner);
                    break;
                case 4:
                    BookOperations.deleteBook(connection, scanner);
                    break;
                case 5:
                    IssueOperations.issueBook(connection, scanner);
                    break;
                case 6:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        } while (choice != 6);
    }
}




