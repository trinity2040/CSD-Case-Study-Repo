Setup :
1)Add MySQL JDBC Driver:

Download the MySQL Connector/J from MySQL's official site.
Place the mysql-connector-java-x.x.xx.jar file into the lib directory of your project or add it to your project's classpath.

2)Configure Database Connection:

Open LibraryApp.java and configure the JDBC URL, username, and password to match your MySQL setup:

static final String JDBC_URL = "jdbc:mysql://localhost:3306/LibraryDB";
static final String JDBC_USER = "root"; // MySQL username
static final String JDBC_PASSWORD = "passwd"; // MySQL password

3)Compile the Java Classes:

Use the following command to compile the Java classes. Make sure the MySQL JDBC driver JAR file is in your classpath:

javac -cp "lib/mysql-connector-java-x.x.xx.jar" library/*.java library/exceptions/*.java library/models/*.java library/operations/*.java library/utils/*.java

4)Run the Application:

Execute the application with the compiled classes and the MySQL JDBC driver JAR file in the classpath:

java -cp ".;lib/mysql-connector-java-x.x.xx.jar" library.LibraryApp


----------------------------------------------------------------------------------------------------------------------------------------------------------------------
Usage :
1)Start the Application:

2)Run the LibraryApp class. You will be presented with a menu of options.

Menu Options:

1. Add a new book: Enter details for the new book to be added.
2. View book details: Display a list of all books in the library.
3. Update book information: Modify details of an existing book.
4. Delete a book: Remove a book from the library, if it is not currently issued.
5. Issue a book: Select a book and a member to issue the book. Ensure the book is available and the member has not reached their limit of 3 issued books.
6. Exit: Close the application.

Handle Errors:

The application provides user-friendly error messages for invalid inputs and database issues.