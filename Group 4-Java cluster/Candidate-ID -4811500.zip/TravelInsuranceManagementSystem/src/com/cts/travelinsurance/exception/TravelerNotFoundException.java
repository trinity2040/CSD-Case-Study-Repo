package com.cts.travelinsurance.exception;

public class TravelerNotFoundException extends Exception {
    public TravelerNotFoundException(String message) {
        super(message);
    }
}
