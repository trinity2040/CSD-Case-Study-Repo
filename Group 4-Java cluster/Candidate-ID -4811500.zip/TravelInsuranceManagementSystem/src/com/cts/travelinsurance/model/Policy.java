
package com.cts.travelinsurance.model;

public class Policy {
    private int policyId;
    private String policyNumber;
    private String type;
    private double coverageAmount;
    private double premiumAmount;

    // Constructor for new policies (without policyId)
    public Policy(String policyNumber, String type, double coverageAmount, double premiumAmount) {
        this.policyNumber = policyNumber;
        this.type = type;
        this.coverageAmount = coverageAmount;
        this.premiumAmount = premiumAmount;
    }

    // Constructor for policies retrieved from database (with policyId)
    public Policy(int policyId, String policyNumber, String type, double coverageAmount, double premiumAmount) {
        this.policyId = policyId;
        this.policyNumber = policyNumber;
        this.type = type;
        this.coverageAmount = coverageAmount;
        this.premiumAmount = premiumAmount;
    }

    public Policy() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Getters and Setters
    public int getPolicyId() {
        return policyId;
    }

    public void setPolicyId(int policyId) {
        this.policyId = policyId;
    }

    public String getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(String policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getCoverageAmount() {
        return coverageAmount;
    }

    public void setCoverageAmount(double coverageAmount) {
        this.coverageAmount = coverageAmount;
    }

    public double getPremiumAmount() {
        return premiumAmount;
    }

    public void setPremiumAmount(double premiumAmount) {
        this.premiumAmount = premiumAmount;
    }
}


