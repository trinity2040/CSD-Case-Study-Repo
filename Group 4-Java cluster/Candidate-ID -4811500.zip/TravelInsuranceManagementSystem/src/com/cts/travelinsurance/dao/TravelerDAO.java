
package com.cts.travelinsurance.dao;

import com.cts.travelinsurance.exception.TravelerNotFoundException;
import com.cts.travelinsurance.model.Traveler;

import java.util.List;

public interface TravelerDAO {
    // Method to add a new traveler and return the generated travelerId
    int addTraveler(Traveler traveler);

    // Method to retrieve a traveler by ID, throws TravelerNotFoundException if not found
    Traveler getTravelerById(int travelerId) throws TravelerNotFoundException;

    // Method to update a traveler, throws TravelerNotFoundException if the traveler does not exist
    void updateTraveler(Traveler traveler) throws TravelerNotFoundException;

    // Method to delete a traveler by ID, throws TravelerNotFoundException if the traveler does not exist
    void deleteTraveler(int travelerId) throws TravelerNotFoundException;

    // Method to get a list of all travelers
    List<Traveler> getAllTravelers();
}
