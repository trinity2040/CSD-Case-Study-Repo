



package com.cts.travelinsurance.dao;

import com.cts.travelinsurance.model.Claim;
import com.cts.travelinsurance.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClaimDAOImpl implements ClaimDAO {

    private static final String INSERT_CLAIM_SQL = "INSERT INTO claim (policy_id, traveler_id, claim_date, status) VALUES (?, ?, ?, ?)";
    private static final String SELECT_CLAIM_BY_ID = "SELECT * FROM claim WHERE claim_id = ?";
    private static final String SELECT_ALL_CLAIMS = "SELECT * FROM claim";
    private static final String UPDATE_CLAIM_SQL = "UPDATE claim SET policy_id = ?, traveler_id = ?, claim_date = ?, status = ? WHERE claim_id = ?";
    private static final String DELETE_CLAIM_SQL = "DELETE FROM claim WHERE claim_id = ?";

    @Override
    public int addClaim(Claim claim) {
        int generatedId = -1;
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_CLAIM_SQL, Statement.RETURN_GENERATED_KEYS)) {

            preparedStatement.setInt(1, claim.getPolicyId());
            preparedStatement.setInt(2, claim.getTravelerId());
            preparedStatement.setString(3, claim.getClaimDate());
            preparedStatement.setString(4, claim.getStatus());

            preparedStatement.executeUpdate();
            
            ResultSet rs = preparedStatement.getGeneratedKeys();
            if (rs.next()) {
                generatedId = rs.getInt(1);
            }
        } catch (SQLException e) {
            System.out.println("Error adding claim: " + e.getMessage());
            e.printStackTrace();
        }
        return generatedId;
    }

    @Override
    public Claim getClaimById(int claimId) {
        Claim claim = null;
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_CLAIM_BY_ID)) {

            preparedStatement.setInt(1, claimId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                claim = new Claim(
                        resultSet.getInt("claim_id"),
                        resultSet.getInt("policy_id"),
                        resultSet.getInt("traveler_id"),
                        resultSet.getString("claim_date"),
                        resultSet.getString("status")
                );
            }
        } catch (SQLException e) {
            System.out.println("Error fetching claim: " + e.getMessage());
        }
        return claim;
    }

    @Override
    public List<Claim> getAllClaims() {
        List<Claim> claims = new ArrayList<>();
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_CLAIMS);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                claims.add(new Claim(
                        resultSet.getInt("claim_id"),
                        resultSet.getInt("policy_id"),
                        resultSet.getInt("traveler_id"),
                        resultSet.getString("claim_date"),
                        resultSet.getString("status")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error fetching all claims: " + e.getMessage());
        }
        return claims;
    }

    @Override
    public void updateClaim(Claim claim) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_CLAIM_SQL)) {

            preparedStatement.setInt(1, claim.getPolicyId());
            preparedStatement.setInt(2, claim.getTravelerId());
            preparedStatement.setString(3, claim.getClaimDate());
            preparedStatement.setString(4, claim.getStatus());
            preparedStatement.setInt(5, claim.getClaimId());

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error updating claim: " + e.getMessage());
        }
    }

    @Override
    public void deleteClaim(int claimId) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_CLAIM_SQL)) {

            preparedStatement.setInt(1, claimId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error deleting claim: " + e.getMessage());
        }
    }
}

