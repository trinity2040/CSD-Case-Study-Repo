
package com.cts.travelinsurance.dao;

import com.cts.travelinsurance.exception.TravelerNotFoundException;
import com.cts.travelinsurance.model.Traveler;
import com.cts.travelinsurance.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TravelerDAOImpl implements TravelerDAO {

    private static final String INSERT_TRAVELER_SQL = "INSERT INTO Traveler (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
    private static final String SELECT_TRAVELER_BY_ID = "SELECT * FROM Traveler WHERE traveler_id = ?";
    private static final String UPDATE_TRAVELER_SQL = "UPDATE Traveler SET email = ?, phone_number = ?, address = ? WHERE traveler_id = ?";
    private static final String DELETE_TRAVELER_SQL = "DELETE FROM Traveler WHERE traveler_id = ?";
    private static final String SELECT_ALL_TRAVELERS = "SELECT * FROM Traveler";

    @Override
    public int addTraveler(Traveler traveler) {
        int travelerId = -1;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(INSERT_TRAVELER_SQL, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, traveler.getName());
            pstmt.setString(2, traveler.getEmail());
            pstmt.setString(3, traveler.getPhoneNumber());
            pstmt.setString(4, traveler.getAddress());

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        travelerId = generatedKeys.getInt(1);
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Error adding traveler: " + e.getMessage());
        }

        return travelerId;
    }

    @Override
    public Traveler getTravelerById(int travelerId) throws TravelerNotFoundException {
        Traveler traveler = null;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(SELECT_TRAVELER_BY_ID)) {

            pstmt.setInt(1, travelerId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                traveler = new Traveler(
                        rs.getInt("traveler_id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("phone_number"),
                        rs.getString("address")
                );
            } else {
                throw new TravelerNotFoundException("Traveler with ID " + travelerId + " not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving traveler: " + e.getMessage());
        }

        return traveler;
    }

    @Override
    public void updateTraveler(Traveler traveler) throws TravelerNotFoundException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(UPDATE_TRAVELER_SQL)) {

            pstmt.setString(1, traveler.getEmail());
            pstmt.setString(2, traveler.getPhoneNumber());
            pstmt.setString(3, traveler.getAddress());
            pstmt.setInt(4, traveler.getTravelerId());

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows == 0) {
                throw new TravelerNotFoundException("Traveler with ID " + traveler.getTravelerId() + " not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating traveler: " + e.getMessage());
        }
    }

    @Override
    public void deleteTraveler(int travelerId) throws TravelerNotFoundException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(DELETE_TRAVELER_SQL)) {

            pstmt.setInt(1, travelerId);
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows == 0) {
                throw new TravelerNotFoundException("Traveler with ID " + travelerId + " not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting traveler: " + e.getMessage());
        }
    }

    @Override
    public List<Traveler> getAllTravelers() {
        List<Traveler> travelers = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(SELECT_ALL_TRAVELERS)) {

            while (rs.next()) {
                Traveler traveler = new Traveler(
                        rs.getInt("traveler_id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("phone_number"),
                        rs.getString("address")
                );
                travelers.add(traveler);
            }
        } catch (SQLException e) {
            System.out.println("Error listing travelers: " + e.getMessage());
        }

        return travelers;
    }
}
