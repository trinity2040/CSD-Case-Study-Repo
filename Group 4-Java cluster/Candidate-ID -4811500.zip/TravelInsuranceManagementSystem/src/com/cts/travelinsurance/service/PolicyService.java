package com.cts.travelinsurance.service;

import com.cts.travelinsurance.dao.PolicyDAO;
import com.cts.travelinsurance.exception.PolicyNotFoundException;
import com.cts.travelinsurance.model.Policy;
import java.util.List;

public class PolicyService {
    private PolicyDAO policyDAO;

    public PolicyService(PolicyDAO policyDAO) {
        this.policyDAO = policyDAO;
    }

    public void addPolicy(Policy policy) {
        policyDAO.addPolicy(policy);
    }

    public Policy getPolicyById(int policyId) throws PolicyNotFoundException {
        Policy policy = policyDAO.getPolicyById(policyId);
        if (policy == null) {
            throw new PolicyNotFoundException("Policy with ID " + policyId + " not found.");
        }
        return policy;
    }

    public void updatePolicy(Policy policy) throws PolicyNotFoundException {
        if (policyDAO.getPolicyById(policy.getPolicyId()) == null) {
            throw new PolicyNotFoundException("Policy with ID " + policy.getPolicyId() + " not found.");
        }
        policyDAO.updatePolicy(policy);
    }

    public void deletePolicy(int policyId) throws PolicyNotFoundException {
        if (policyDAO.getPolicyById(policyId) == null) {
            throw new PolicyNotFoundException("Policy with ID " + policyId + " not found.");
        }
        policyDAO.deletePolicy(policyId);
    }
}
