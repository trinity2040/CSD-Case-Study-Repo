package com.cts.exception;

public class InvalidRoomException extends Exception {
    public InvalidRoomException(String message) {
        super(message);
    }
}
