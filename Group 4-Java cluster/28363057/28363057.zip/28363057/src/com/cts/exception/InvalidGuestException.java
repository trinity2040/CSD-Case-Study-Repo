package com.cts.exception;


    public class InvalidGuestException extends Exception {
        public InvalidGuestException(String message) {
            super(message);
        }
    }
