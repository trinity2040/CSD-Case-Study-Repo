package com.cts.exception;

public class InvalidReservationException extends Exception {
    public InvalidReservationException(String message) {
        super(message);
    }
}
