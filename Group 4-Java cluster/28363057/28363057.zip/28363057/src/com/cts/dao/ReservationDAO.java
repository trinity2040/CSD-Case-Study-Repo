package com.cts.dao;

import com.cts.model.Reservation;

import java.util.ArrayList;
import java.util.List;

public class ReservationDAO {
    private List<Reservation> reservations = new ArrayList<>();
    private int nextReservationId = 1;

    public void addReservation(Reservation reservation) {
        reservation.setReservationId(nextReservationId++);
        reservations.add(reservation);
    }

    public List<Reservation> getAllReservations() {
        return reservations;
    }

    public void updateReservation(Reservation reservation) {
        for (Reservation r : reservations) {
            if (r.getReservationId() == reservation.getReservationId()) {
                r.setGuestId(reservation.getGuestId());
                r.setRoomNumber(reservation.getRoomNumber());
                r.setCheckInDate(reservation.getCheckInDate());
                r.setCheckOutDate(reservation.getCheckOutDate());
                return;
            }
        }
    }

    public void deleteReservation(int reservationId) {
        reservations.removeIf(r -> r.getReservationId() == reservationId);
    }
}
