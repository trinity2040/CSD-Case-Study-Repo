package com.cts.dao;

import com.cts.model.Guest;

import java.util.ArrayList;
import java.util.List;

public class GuestDAO {
    private List<Guest> guests = new ArrayList<>();
    private int nextGuestId = 1;

    public void addGuest(Guest guest) {
        guest.setGuestId(nextGuestId++);
        guests.add(guest);
    }

    public List<Guest> getAllGuests() {
        return guests;
    }

    public void updateGuest(Guest guest) {
        for (Guest g : guests) {
            if (g.getGuestId() == guest.getGuestId()) {
                g.setName(guest.getName());
                g.setEmail(guest.getEmail());
                return;
            }
        }
    }

    public void deleteGuest(int guestId) {
        guests.removeIf(g -> g.getGuestId() == guestId);
    }
}
