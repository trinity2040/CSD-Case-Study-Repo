package com.cts.client;

import com.cts.dao.GuestDAO;
import com.cts.dao.ReservationDAO;
import com.cts.dao.RoomDAO;
import com.cts.exception.InvalidGuestException;
import com.cts.exception.InvalidReservationException;
import com.cts.exception.InvalidRoomException;
import com.cts.model.Guest;
import com.cts.model.Reservation;
import com.cts.model.Room;

import java.sql.Date;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        RoomDAO roomDAO = new RoomDAO();
        GuestDAO guestDAO = new GuestDAO();
        ReservationDAO reservationDAO = new ReservationDAO();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nHotel Management System");
            System.out.println("1. Room Management");
            System.out.println("2. Guest Management");
            System.out.println("3. Reservation Management");
            System.out.println("4. Exit");
            System.out.print("Please select an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    roomManagementMenu(roomDAO, scanner);
                    break;
                case 2:
                    guestManagementMenu(guestDAO, scanner);
                    break;
                case 3:
                    reservationManagementMenu(reservationDAO, scanner);
                    break;
                case 4:
                    System.out.println("Exiting the system.");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void roomManagementMenu(RoomDAO roomDAO, Scanner scanner) {
        int choice;
        do {
            System.out.println("\nRoom Management Menu");
            System.out.println("1. Add Room");
            System.out.println("2. View All Rooms");
            System.out.println("3. Update Room");
            System.out.println("4. Delete Room");
            System.out.println("5. Back to Main Menu");
            choice = scanner.nextInt();

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter room number: ");
                        int roomNumber = scanner.nextInt();
                        System.out.print("Enter room type: ");
                        String roomType = scanner.next();
                        System.out.print("Enter room price: ");
                        double price = scanner.nextDouble();
                        Room room = new Room(roomNumber, roomType, price);
                        roomDAO.addRoom(room);
                        System.out.println("Room added successfully.");
                        break;
                    case 2:
                        System.out.println("Room List:");
                        for (Room r : roomDAO.getAllRooms()) {
                            System.out.println(r);
                        }
                        break;
                    case 3:
                        System.out.print("Enter room number to update: ");
                        roomNumber = scanner.nextInt();
                        Room updateRoom = findRoom(roomDAO, roomNumber);
                        System.out.print("Enter new room type: ");
                        roomType = scanner.next();
                        System.out.print("Enter new room price: ");
                        price = scanner.nextDouble();
                        updateRoom.setRoomType(roomType);
                        updateRoom.setPrice(price);
                        roomDAO.updateRoom(updateRoom);
                        System.out.println("Room updated successfully.");
                        break;
                    case 4:
                        System.out.print("Enter room number to delete: ");
                        roomNumber = scanner.nextInt();
                        Room deleteRoom = findRoom(roomDAO, roomNumber);
                        roomDAO.deleteRoom(deleteRoom.getRoomNumber());
                        System.out.println("Room deleted successfully.");
                        break;
                    case 5:
                        System.out.println("Returning to main menu...");
                        break;
                    default:
                        System.out.println("Invalid choice.");
                }
            } catch (InvalidRoomException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (choice != 5);
    }

    private static Room findRoom(RoomDAO roomDAO, int roomNumber) throws InvalidRoomException {
        for (Room room : roomDAO.getAllRooms()) {
            if (room.getRoomNumber() == roomNumber) {
                return room;
            }
        }
        throw new InvalidRoomException("Room with number " + roomNumber + " not found.");
    }

    private static void guestManagementMenu(GuestDAO guestDAO, Scanner scanner) {
        int choice;
        do {
            System.out.println("\nGuest Management Menu");
            System.out.println("1. Add Guest");
            System.out.println("2. View All Guests");
            System.out.println("3. Update Guest");
            System.out.println("4. Delete Guest");
            System.out.println("5. Back to Main Menu");
            choice = scanner.nextInt();

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter guest name: ");
                        String name = scanner.next();
                        System.out.print("Enter guest email: ");
                        String email = scanner.next();
                        Guest guest = new Guest(name, email);
                        guestDAO.addGuest(guest);
                        System.out.println("Guest added successfully.");
                        break;
                    case 2:
                        System.out.println("Guest List:");
                        for (Guest g : guestDAO.getAllGuests()) {
                            System.out.println(g);
                        }
                        break;
                    case 3:
                        System.out.print("Enter guest ID to update: ");
                        int guestId = scanner.nextInt();
                        Guest updateGuest = findGuest(guestDAO, guestId);
                        System.out.print("Enter new guest name: ");
                        name = scanner.next();
                        System.out.print("Enter new guest email: ");
                        email = scanner.next();
                        updateGuest.setName(name);
                        updateGuest.setEmail(email);
                        guestDAO.updateGuest(updateGuest);
                        System.out.println("Guest updated successfully.");
                        break;
                    case 4:
                        System.out.print("Enter guest ID to delete: ");
                        guestId = scanner.nextInt();
                        Guest deleteGuest = findGuest(guestDAO, guestId);
                        guestDAO.deleteGuest(deleteGuest.getGuestId());
                        System.out.println("Guest deleted successfully.");
                        break;
                    case 5:
                        System.out.println("Returning to main menu...");
                        break;
                    default:
                        System.out.println("Invalid choice.");
                }
            } catch (InvalidGuestException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (choice != 5);
    }

    private static Guest findGuest(GuestDAO guestDAO, int guestId) throws InvalidGuestException {
        for (Guest guest : guestDAO.getAllGuests()) {
            if (guest.getGuestId() == guestId) {
                return guest;
            }
        }
        throw new InvalidGuestException("Guest with ID " + guestId + " not found.");
    }

    private static void reservationManagementMenu(ReservationDAO reservationDAO, Scanner scanner) {
        int choice;
        do {
            System.out.println("\nReservation Management Menu");
            System.out.println("1. Add Reservation");
            System.out.println("2. View All Reservations");
            System.out.println("3. Update Reservation");
            System.out.println("4. Delete Reservation");
            System.out.println("5. Back to Main Menu");
            choice = scanner.nextInt();

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter guest ID: ");
                        int guestId = scanner.nextInt();
                        System.out.print("Enter room number: ");
                        int roomNumber = scanner.nextInt();
                        System.out.print("Enter check-in date (YYYY-MM-DD): ");
                        Date checkInDate = Date.valueOf(scanner.next());
                        System.out.print("Enter check-out date (YYYY-MM-DD): ");
                        Date checkOutDate = Date.valueOf(scanner.next());

                        if (checkInDate.after(checkOutDate)) {
                            throw new InvalidReservationException("Check-out date must be after check-in date.");
                        }

                        Reservation reservation = new Reservation(guestId, roomNumber, checkInDate, checkOutDate);
                        reservationDAO.addReservation(reservation);
                        System.out.println("Reservation added successfully.");
                        break;
                    case 2:
                        System.out.println("Reservation List:");
                        for (Reservation r : reservationDAO.getAllReservations()) {
                            System.out.println(r);
                        }
                        break;
                    case 3:
                        System.out.print("Enter reservation ID to update: ");
                        int reservationId = scanner.nextInt();
                        Reservation updateReservation = findReservation(reservationDAO, reservationId);
                        System.out.print("Enter new guest ID: ");
                        guestId = scanner.nextInt();
                        System.out.print("Enter new room number: ");
                        roomNumber = scanner.nextInt();
                        System.out.print("Enter new check-in date (YYYY-MM-DD): ");
                        checkInDate = Date.valueOf(scanner.next());
                        System.out.print("Enter new check-out date (YYYY-MM-DD): ");
                        checkOutDate = Date.valueOf(scanner.next());

                        if (checkInDate.after(checkOutDate)) {
                            throw new InvalidReservationException("Check-out date must be after check-in date.");
                        }

                        updateReservation.setGuestId(guestId);
                        updateReservation.setRoomNumber(roomNumber);
                        updateReservation.setCheckInDate(checkInDate);
                        updateReservation.setCheckOutDate(checkOutDate);
                        reservationDAO.updateReservation(updateReservation);
                        System.out.println("Reservation updated successfully.");
                        break;
                    case 4:
                        System.out.print("Enter reservation ID to delete: ");
                        reservationId = scanner.nextInt();
                        Reservation deleteReservation = findReservation(reservationDAO, reservationId);
                        reservationDAO.deleteReservation(deleteReservation.getReservationId());
                        System.out.println("Reservation deleted successfully.");
                        break;
                    case 5:
                        System.out.println("Returning to main menu...");
                        break;
                    default:
                        System.out.println("Invalid choice.");
                }
            } catch (InvalidReservationException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (choice != 5);
    }

    private static Reservation findReservation(ReservationDAO reservationDAO, int reservationId) throws InvalidReservationException {
        for (Reservation reservation : reservationDAO.getAllReservations()) {
            if (reservation.getReservationId() == reservationId) {
                return reservation;
            }
        }
        throw new InvalidReservationException("Reservation with ID " + reservationId + " not found.");
    }

}
