
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class GuestManager {
    public static void addRoom(Scanner scanner, Connection connection) {
        try {
            System.out.print("Enter Room Number: ");
            int roomNumber = scanner.nextInt();
            scanner.nextLine(); // consume newline
            System.out.print("Enter Room Type: ");
            String type = scanner.nextLine();
            System.out.print("Enter Price per Night: ");
            double pricePerNight = scanner.nextDouble();
            System.out.print("Is Room Available? (true/false): ");
            boolean availabilityStatus = scanner.nextBoolean();

            String sql = "INSERT INTO Room (room_number, type, price_per_night, availability_status) VALUES (?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, roomNumber);
            statement.setString(2, type);
            statement.setDouble(3, pricePerNight);
            statement.setBoolean(4, availabilityStatus);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new room was added successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewRoom(Scanner scanner, Connection connection) {
        try {
            System.out.print("Enter Room Number to View: ");
            int roomNumber = scanner.nextInt();

            String sql = "SELECT * FROM Room WHERE room_number = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, roomNumber);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("Room Number: " + resultSet.getInt("room_number"));
                System.out.println("Type: " + resultSet.getString("type"));
                System.out.println("Price per Night: " + resultSet.getDouble("price_per_night"));
                System.out.println("Availability Status: " + resultSet.getBoolean("availability_status"));
            } else {
                System.out.println("Room not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateRoom(Scanner scanner, Connection connection) {
        try {
            System.out.print("Enter Room Number to Update: ");
            int roomNumber = scanner.nextInt();
            scanner.nextLine(); // consume newline

            System.out.print("Enter New Room Type: ");
            String type = scanner.nextLine();
            System.out.print("Enter New Price per Night: ");
            double pricePerNight = scanner.nextDouble();
            System.out.print("Is Room Available? (true/false): ");
            boolean availabilityStatus = scanner.nextBoolean();

            String sql = "UPDATE Room SET type = ?, price_per_night = ?, availability_status = ? WHERE room_number = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, type);
            statement.setDouble(2, pricePerNight);
            statement.setBoolean(3, availabilityStatus);
            statement.setInt(4, roomNumber);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Room updated successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteRoom(Scanner scanner, Connection connection) {
        try {
            System.out.print("Enter Room Number to Delete: ");
            int roomNumber = scanner.nextInt();

            String sql = "DELETE FROM Room WHERE room_number = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, roomNumber);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Room deleted successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void addGuest(Scanner scanner, Connection connection) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'addGuest'");
    }

    public static void viewGuest(Scanner scanner, Connection connection) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'viewGuest'");
    }

    public static void updateGuest(Scanner scanner, Connection connection) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'updateGuest'");
    }

    public static void deleteGuest(Scanner scanner, Connection connection) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteGuest'");
    }
}

