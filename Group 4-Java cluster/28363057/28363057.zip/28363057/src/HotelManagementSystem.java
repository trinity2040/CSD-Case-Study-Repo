
import java.sql.*;
import java.util.Scanner;

public class HotelManagementSystem {
    private static final String databaseName = "My Db";
    private static final String DB_URL = "jdbc:mysql://localhost:3306/HotelManagement";
    private static final String USER = "root";  // Replace with your MySQL username
    private static final String PASSWORD = "#Moupi1234";  // Replace with your MySQL password

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            Connection connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
            int choice;

            do {
                System.out.println("Hotel Management System");
                System.out.println("1. Room Management");
                System.out.println("2. Guest Management");
                System.out.println("3. Reservation Management");
                System.out.println("0. Exit");
                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        manageRooms(scanner, connection);
                        break;
                    case 2:
                        manageGuests(scanner, connection);
                        break;
                    case 3:
                        manageReservations(scanner, connection);
                        break;
                    case 0:
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } while (choice != 0);

            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void manageRooms(Scanner scanner, Connection connection) {
        int choice;
        do {
            System.out.println("Room Management");
            System.out.println("1. Add New Room");
            System.out.println("2. View Room Details");
            System.out.println("3. Update Room Information");
            System.out.println("4. Delete Room");
            System.out.println("0. Back to Main Menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    RoomManager.addRoom(scanner, connection);
                    break;
                case 2:
                    RoomManager.viewRoom(scanner, connection);
                    break;
                case 3:
                    RoomManager.updateRoom(scanner, connection);
                    break;
                case 4:
                    RoomManager.deleteRoom(scanner, connection);
                    break;
                case 0:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);
    }

    private static void manageGuests(Scanner scanner, Connection connection) {
        int choice;
        do {
            System.out.println("Guest Management");
            System.out.println("1. Register New Guest");
            System.out.println("2. View Guest Details");
            System.out.println("3. Update Guest Information");
            System.out.println("4. Delete Guest");
            System.out.println("0. Back to Main Menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    GuestManager.addGuest(scanner, connection);
                    break;
                case 2:
                    GuestManager.viewGuest(scanner, connection);
                    break;
                case 3:
                    GuestManager.updateGuest(scanner, connection);
                    break;
                case 4:
                    GuestManager.deleteGuest(scanner, connection);
                    break;
                case 0:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);
    }

    private static void manageReservations(Scanner scanner, Connection connection) {
        int choice;
        do {
            System.out.println("Reservation Management");
            System.out.println("1. Make New Reservation");
            System.out.println("2. View Reservation Details");
            System.out.println("3. Update Reservation Information");
            System.out.println("4. Cancel Reservation");
            System.out.println("0. Back to Main Menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    ReservationManager.addReservation(scanner, connection);
                    break;
                case 2:
                    ReservationManager.viewReservation(scanner, connection);
                    break;
                case 3:
                    ReservationManager.updateReservation(scanner, connection);
                    break;
                case 4:
                    ReservationManager.cancelReservation(scanner, connection);
                    break;
                case 0:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 0);
    }
}

