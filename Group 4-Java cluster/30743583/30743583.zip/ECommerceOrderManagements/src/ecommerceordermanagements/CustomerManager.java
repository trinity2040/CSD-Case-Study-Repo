/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecommerceordermanagements;

/**
 *
 * @author gauth
 */
// com/yourcompany/customer/CustomerManager.java


import ecommerceordermanagements.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class CustomerManager {

    public void addCustomer() throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter customer name: ");
            String name = scanner.nextLine();

            System.out.print("Enter customer email: ");
            String email = scanner.nextLine();

            System.out.print("Enter customer phone number: ");
            String phoneNumber = scanner.nextLine();

            System.out.print("Enter customer address: ");
            String address = scanner.nextLine();

            String sql = "INSERT INTO Customer (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, name);
                statement.setString(2, email);
                statement.setString(3, phoneNumber);
                statement.setString(4, address);
                statement.executeUpdate();
                System.out.println("Customer added successfully!");
            }
        }
    }

    public void viewCustomer() throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter customer ID to view: ");
            int customerId = scanner.nextInt();

            String sql = "SELECT * FROM Customer WHERE customer_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, customerId);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        System.out.println("Customer ID: " + resultSet.getInt("customer_id"));
                        System.out.println("Name: " + resultSet.getString("name"));
                        System.out.println("Email: " + resultSet.getString("email"));
                        System.out.println("Phone Number: " + resultSet.getString("phone_number"));
                        System.out.println("Address: " + resultSet.getString("address"));
                    } else {
                        System.out.println("Customer not found.");
                    }
                }
            }
        }
    }

    public void updateCustomer() throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter customer ID to update: ");
            int customerId = scanner.nextInt();

            System.out.print("Enter new customer name: ");
            String name = scanner.next();

            System.out.print("Enter new customer email: ");
            String email = scanner.next();

            System.out.print("Enter new customer phone number: ");
            String phoneNumber = scanner.next();

            System.out.print("Enter new customer address: ");
            String address = scanner.next();

            String sql = "UPDATE Customer SET name = ?, email = ?, phone_number = ?, address = ? WHERE customer_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, name);
                statement.setString(2, email);
                statement.setString(3, phoneNumber);
                statement.setString(4, address);
                statement.setInt(5, customerId);
                int rowsUpdated = statement.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("Customer updated successfully!");
                } else {
                    System.out.println("Customer not found.");
                }
            }
        }
    }

    public void deleteCustomer() throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter customer ID to delete: ");
            int customerId = scanner.nextInt();

            String sql = "DELETE FROM Customer WHERE customer_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, customerId);
                int rowsDeleted = statement.executeUpdate();
                if (rowsDeleted > 0) {
                    System.out.println("Customer deleted successfully!");
                } else {
                    System.out.println("Customer not found.");
                }
            }
        }
    }
}