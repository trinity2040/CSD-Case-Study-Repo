/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecommerceordermanagements;

import ecommerceordermanagements.DatabaseConnection;
import ecommerceordermanagements.ProductManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class OrderManager {

    private final ProductManager productManager = new ProductManager();

    public void createOrder() throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter customer ID: ");
            int customerId = scanner.nextInt();

            System.out.print("Enter product ID: ");
            int productId = scanner.nextInt();

            System.out.print("Enter quantity: ");
            int quantity = scanner.nextInt();

            String checkProductSql = "SELECT price, quantity_in_stock FROM Product WHERE product_id = ?";
            try (PreparedStatement checkProductStmt = connection.prepareStatement(checkProductSql)) {
                checkProductStmt.setInt(1, productId);
                try (ResultSet resultSet = checkProductStmt.executeQuery()) {
                    if (resultSet.next()) {
                        double price = resultSet.getDouble("price");
                        int quantityInStock = resultSet.getInt("quantity_in_stock");

                        if (quantity > quantityInStock) {
                            System.out.println("Insufficient stock available. Available quantity: " + quantityInStock);
                            return;
                        }

                        double totalAmount = price * quantity;

                        // Insert order into Order table
                        String orderSql = "INSERT INTO `Order` (customer_id, order_date, total_amount, status) VALUES (?, NOW(), ?, 'pending')";
                        try (PreparedStatement orderStmt = connection.prepareStatement(orderSql, PreparedStatement.RETURN_GENERATED_KEYS)) {
                            orderStmt.setInt(1, customerId);
                            orderStmt.setDouble(2, totalAmount);
                            orderStmt.executeUpdate();

                            // Retrieve the generated order ID
                            try (ResultSet orderKeys = orderStmt.getGeneratedKeys()) {
                                if (orderKeys.next()) {
                                    int orderId = orderKeys.getInt(1);

                                    // Insert order item into OrderItem table
                                    String orderItemSql = "INSERT INTO OrderItem (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
                                    try (PreparedStatement orderItemStmt = connection.prepareStatement(orderItemSql)) {
                                        orderItemStmt.setInt(1, orderId);
                                        orderItemStmt.setInt(2, productId);
                                        orderItemStmt.setInt(3, quantity);
                                        orderItemStmt.setDouble(4, price);
                                        orderItemStmt.executeUpdate();

                                        // Update product stock
                                        String updateProductSql = "UPDATE Product SET quantity_in_stock = quantity_in_stock - ? WHERE product_id = ?";
                                        try (PreparedStatement updateProductStmt = connection.prepareStatement(updateProductSql)) {
                                            updateProductStmt.setInt(1, quantity);
                                            updateProductStmt.setInt(2, productId);
                                            updateProductStmt.executeUpdate();
                                        }

                                        System.out.println("Order created successfully with Order ID: " + orderId);
                                    }
                                }
                            }
                        }
                    } else {
                        System.out.println("Product not found.");
                    }
                }
            }
        }
    }

    public void viewOrder() throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter order ID to view: ");
            int orderId = scanner.nextInt();

            String sql = "SELECT * FROM `Order` WHERE order_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, orderId);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        System.out.println("Order ID: " + resultSet.getInt("order_id"));
                        System.out.println("Customer ID: " + resultSet.getInt("customer_id"));
                        System.out.println("Order Date: " + resultSet.getDate("order_date"));
                        System.out.println("Total Amount: " + resultSet.getDouble("total_amount"));
                        System.out.println("Status: " + resultSet.getString("status"));

                        // Fetch and display order items
                        String orderItemsSql = "SELECT * FROM OrderItem WHERE order_id = ?";
                        try (PreparedStatement orderItemsStmt = connection.prepareStatement(orderItemsSql)) {
                            orderItemsStmt.setInt(1, orderId);
                            try (ResultSet itemsResultSet = orderItemsStmt.executeQuery()) {
                                while (itemsResultSet.next()) {
                                    System.out.println(" - Product ID: " + itemsResultSet.getInt("product_id"));
                                    System.out.println("   Quantity: " + itemsResultSet.getInt("quantity"));
                                    System.out.println("   Price: " + itemsResultSet.getDouble("price"));
                                }
                            }
                        }
                    } else {
                        System.out.println("Order not found.");
                    }
                }
            }
        }
    }

    public void updateOrder() throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter order ID to update: ");
            int orderId = scanner.nextInt();

            System.out.print("Enter new status (pending/confirmed/shipped/delivered/cancelled): ");
            String status = scanner.next();

            String sql = "UPDATE `Order` SET status = ? WHERE order_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, status);
                statement.setInt(2, orderId);
                int rowsUpdated = statement.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("Order updated successfully!");
                } else {
                    System.out.println("Order not found.");
                }
            }
        }
    }

    public void cancelOrder() throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter order ID to cancel: ");
            int orderId = scanner.nextInt();

            // First, fetch the order items to restore the product stock
            String fetchOrderItemsSql = "SELECT * FROM OrderItem WHERE order_id = ?";
            try (PreparedStatement fetchOrderItemsStmt = connection.prepareStatement(fetchOrderItemsSql)) {
                fetchOrderItemsStmt.setInt(1, orderId);
                try (ResultSet resultSet = fetchOrderItemsStmt.executeQuery()) {
                    while (resultSet.next()) {
                        int productId = resultSet.getInt("product_id");
                        int quantity = resultSet.getInt("quantity");

                        // Update product stock
                        String updateProductSql = "UPDATE Product SET quantity_in_stock = quantity_in_stock + ? WHERE product_id = ?";
                        try (PreparedStatement updateProductStmt = connection.prepareStatement(updateProductSql)) {
                            updateProductStmt.setInt(1, quantity);
                            updateProductStmt.setInt(2, productId);
                            updateProductStmt.executeUpdate();
                        }
                    }
                }
            }

            // Update the order status to "cancelled"
            String cancelOrderSql = "UPDATE `Order` SET status = 'cancelled' WHERE order_id = ?";
            try (PreparedStatement cancelOrderStmt = connection.prepareStatement(cancelOrderSql)) {
                cancelOrderStmt.setInt(1, orderId);
                int rowsUpdated = cancelOrderStmt.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("Order cancelled successfully!");
                } else {
                    System.out.println("Order not found.");
                }
            }
       }}
}
