/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ecommerceordermanagements;

/**
 *
 * @author gauth
 */


//import com.yourcompany.db.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ProductManager {

    public void addProduct() throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter product name: ");
            String name = scanner.nextLine();

            System.out.print("Enter product description: ");
            String description = scanner.nextLine();

            System.out.print("Enter product price: ");
            double price = scanner.nextDouble();

            System.out.print("Enter quantity in stock: ");
            int quantityInStock = scanner.nextInt();

            String sql = "INSERT INTO Product (name, description, price, quantity_in_stock) VALUES (?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, name);
                statement.setString(2, description);
                statement.setDouble(3, price);
                statement.setInt(4, quantityInStock);
                statement.executeUpdate();
                System.out.println("Product added successfully!");
            }
        }
    }

    public void viewProduct() throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter product ID to view: ");
            int productId = scanner.nextInt();

            String sql = "SELECT * FROM Product WHERE product_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, productId);
                try (ResultSet resultSet = statement.executeQuery()) {
                    if (resultSet.next()) {
                        System.out.println("Product ID: " + resultSet.getInt("product_id"));
                        System.out.println("Name: " + resultSet.getString("name"));
                        System.out.println("Description: " + resultSet.getString("description"));
                        System.out.println("Price: " + resultSet.getDouble("price"));
                        System.out.println("Quantity in Stock: " + resultSet.getInt("quantity_in_stock"));
                    } else {
                        System.out.println("Product not found.");
                    }
                }
            }
        }
    }

    public void updateProduct() throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter product ID to update: ");
            int productId = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Enter new product name: ");
            String name = scanner.next();

            System.out.print("Enter new product description: ");
            String description = scanner.nextLine();

            System.out.print("Enter new product price: ");
            double price = scanner.nextDouble();

            System.out.print("Enter new quantity in stock: ");
            int quantityInStock = scanner.nextInt();

            String sql = "UPDATE Product SET name = ?, description = ?, price = ?, quantity_in_stock = ? WHERE product_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setString(1, name);
                statement.setString(2, description);
                statement.setDouble(3, price);
                statement.setInt(4, quantityInStock);
                statement.setInt(5, productId);
                int rowsUpdated = statement.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("Product updated successfully!");
                } else {
                    System.out.println("Product not found.");
                }
            }
        }
    }

    public void deleteProduct() throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter product ID to delete: ");
            int productId = scanner.nextInt();

            String sql = "DELETE FROM Product WHERE product_id = ?";
            try (PreparedStatement statement = connection.prepareStatement(sql)) {
                statement.setInt(1, productId);
                int rowsDeleted = statement.executeUpdate();
                if (rowsDeleted > 0) {
                    System.out.println("Product deleted successfully!");
                } else {
                    System.out.println("Product not found.");
                }
            }
        }
    }
}

