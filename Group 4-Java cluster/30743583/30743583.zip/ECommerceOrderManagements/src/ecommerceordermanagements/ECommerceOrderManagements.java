/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ecommerceordermanagements;

/**
 *
 * @author gauth
 */
//public class ECommerceOrderManagements {
//
//    /**
//     * @param args the command line arguments
//     */
//    public static void main(String[] args) {
//        // TODO code application logic here
//    }
//    
//}

import ecommerceordermanagements.ProductManager;
import ecommerceordermanagements.CustomerManager;
import ecommerceordermanagements.OrderManager;

import java.sql.SQLException;
import java.util.Scanner;

public class ECommerceOrderManagements {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        try {
            ProductManager productManager = new ProductManager();
            CustomerManager customerManager = new CustomerManager();
            OrderManager orderManager = new OrderManager();

            do {
                System.out.println("\n*** E-Commerce Management System ***");
                System.out.println("1. Manage Products");
                System.out.println("2. Manage Customers");
                System.out.println("3. Manage Orders");
                System.out.println("4. Exit");
                System.out.print("Enter your choice: ");
                choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        manageProducts(productManager, scanner);
                        break;
                    case 2:
                        manageCustomers(customerManager, scanner);
                        break;
                    case 3:
                        manageOrders(orderManager, scanner);
                        break;
                    case 4:
                        System.out.println("Exiting...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } while (choice != 4);

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }

    private static void manageProducts(ProductManager productManager, Scanner scanner) throws SQLException {
        int choice;
        do {
            System.out.println("\n--- Product Management ---");
            System.out.println("1. Add Product");
            System.out.println("2. View Product");
            System.out.println("3. Update Product");
            System.out.println("4. Delete Product");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    productManager.addProduct();
                    break;
                case 2:
                    productManager.viewProduct();
                    break;
                case 3:
                    productManager.updateProduct();
                    break;
                case 4:
                    productManager.deleteProduct();
                    break;
                case 5:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }

    private static void manageCustomers(CustomerManager customerManager, Scanner scanner) throws SQLException {
        int choice;
        do {
            System.out.println("\n--- Customer Management ---");
            System.out.println("1. Add Customer");
            System.out.println("2. View Customer");
            System.out.println("3. Update Customer");
            System.out.println("4. Delete Customer");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    customerManager.addCustomer();
                    break;
                case 2:
                    customerManager.viewCustomer();
                    break;
                case 3:
                    customerManager.updateCustomer();
                    break;
                case 4:
                    customerManager.deleteCustomer();
                    break;
                case 5:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }

    private static void manageOrders(OrderManager orderManager, Scanner scanner) throws SQLException {
        int choice;
        do {
            System.out.println("\n--- Order Management ---");
            System.out.println("1. Create Order");
            System.out.println("2. View Order");
            System.out.println("3. Update Order");
            System.out.println("4. Cancel Order");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    orderManager.createOrder();
                    break;
                case 2:
                    orderManager.viewOrder();
                    break;
                case 3:
                    orderManager.updateOrder();
                    break;
                case 4:
                    orderManager.cancelOrder();
                    break;
                case 5:
                    System.out.println("Returning to main menu...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }while(choice!=5);
}
}
