package com.healthinsurencemanagement;
import java.util.Scanner;
public class MainMenu {

	public static void main(String[] args) {
		PolicyManager policyManager = new PolicyManager();
        MemberManager memberManager = new MemberManager();
        ClaimManager claimManager = new ClaimManager();

        Scanner scanner = new Scanner(System.in);

        System.out.println("Health Insurance Management System");
        System.out.println("1. Add New Policy");
        System.out.println("2. View Policy Details");
        System.out.println("3. Update Policy Information");
        System.out.println("4. Delete Policy");
        System.out.println("5. Register New Member");
        System.out.println("6. View Member Details");
        System.out.println("7. Update Member Information");
        System.out.println("8. Delete Member");
        System.out.println("9. Submit New Claim");
        System.out.println("10. View Claim Details");
        System.out.println("11. Update Claim Information");
        System.out.println("12. Delete Claim");
        System.out.println("13. Exit");

        System.out.print("Select an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                policyManager.addPolicy();
                break;
            case 2:
                policyManager.viewPolicyDetails();
                break;
            case 3:
                policyManager.updatePolicy();
                break;
            case 4:
                policyManager.deletePolicy();
                break;
            case 5:
                memberManager.registerMember();
                break;
            case 6:
                memberManager.viewMemberDetails();
                break;
            case 7:
                memberManager.updateMember();
                break;
            case 8:
                memberManager.deleteMember();
                break;
            case 9:
                claimManager.submitClaim();
                break;
            case 10:
                claimManager.viewClaimDetails();
                break;
            case 11:
                claimManager.updateClaim();
                break;
            case 12:
                claimManager.deleteClaim();
                break;
            case 13:
                System.out.println("Exiting...");
                break;
            default:
                System.out.println("Invalid option. Exiting...");
        }

        scanner.close();

	}

}
