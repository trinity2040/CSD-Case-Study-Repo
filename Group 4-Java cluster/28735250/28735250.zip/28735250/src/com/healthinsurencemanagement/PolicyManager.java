package com.healthinsurencemanagement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class PolicyManager {
	public void addPolicy() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO Policy (policy_number, type, coverage_amount, premium_amount) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                Scanner scanner = new Scanner(System.in);

                System.out.print("Enter Policy Number: ");
                String policyNumber = scanner.nextLine();
                System.out.print("Enter Type: ");
                String type = scanner.nextLine();
                System.out.print("Enter Coverage Amount: ");
                double coverageAmount = scanner.nextDouble();
                System.out.print("Enter Premium Amount: ");
                double premiumAmount = scanner.nextDouble();

                pstmt.setString(1, policyNumber);
                pstmt.setString(2, type);
                pstmt.setDouble(3, coverageAmount);
                pstmt.setDouble(4, premiumAmount);

                int rowsAffected = pstmt.executeUpdate();
                System.out.println(rowsAffected + " policy added.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewPolicyDetails() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Policy";
            try (PreparedStatement pstmt = conn.prepareStatement(sql);
                 ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    System.out.println("Policy ID: " + rs.getInt("policy_id"));
                    System.out.println("Policy Number: " + rs.getString("policy_number"));
                    System.out.println("Type: " + rs.getString("type"));
                    System.out.println("Coverage Amount: " + rs.getDouble("coverage_amount"));
                    System.out.println("Premium Amount: " + rs.getDouble("premium_amount"));
                    System.out.println();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updatePolicy() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter Policy ID to Update: ");
            int policyId = scanner.nextInt();
            scanner.nextLine(); 

            System.out.print("Enter New Policy Number: ");
            String policyNumber = scanner.nextLine();
            System.out.print("Enter New Type: ");
            String type = scanner.nextLine();
            System.out.print("Enter New Coverage Amount: ");
            double coverageAmount = scanner.nextDouble();
            System.out.print("Enter New Premium Amount: ");
            double premiumAmount = scanner.nextDouble();

            String sql = "UPDATE Policy SET policy_number = ?, type = ?, coverage_amount = ?, premium_amount = ? WHERE policy_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, policyNumber);
                pstmt.setString(2, type);
                pstmt.setDouble(3, coverageAmount);
                pstmt.setDouble(4, premiumAmount);
                pstmt.setInt(5, policyId);

                int rowsAffected = pstmt.executeUpdate();
                System.out.println(rowsAffected + " policy updated.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletePolicy() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter Policy ID to Delete: ");
            int policyId = scanner.nextInt();

            String sql = "DELETE FROM Policy WHERE policy_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, policyId);

                int rowsAffected = pstmt.executeUpdate();
                System.out.println(rowsAffected + " policy deleted.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
