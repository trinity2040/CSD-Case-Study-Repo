package com.healthinsurencemanagement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class ClaimManager {
	public void submitClaim() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO Claim (policy_id, member_id, claim_date, status) VALUES (?, ?, ?, 'submitted')";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                Scanner scanner = new Scanner(System.in);

                System.out.print("Enter Policy ID: ");
                int policyId = scanner.nextInt();
                System.out.print("Enter Member ID: ");
                int memberId = scanner.nextInt();
                scanner.nextLine();  
                System.out.print("Enter Claim Date (YYYY-MM-DD): ");
                String claimDate = scanner.nextLine();

                pstmt.setInt(1, policyId);
                pstmt.setInt(2, memberId);
                pstmt.setString(3, claimDate);

                int rowsAffected = pstmt.executeUpdate();
                System.out.println(rowsAffected + " claim submitted.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewClaimDetails() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Claim";
            try (PreparedStatement pstmt = conn.prepareStatement(sql);
                 ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    System.out.println("Claim ID: " + rs.getInt("claim_id"));
                    System.out.println("Policy ID: " + rs.getInt("policy_id"));
                    System.out.println("Member ID: " + rs.getInt("member_id"));
                    System.out.println("Claim Date: " + rs.getDate("claim_date"));
                    System.out.println("Status: " + rs.getString("status"));
                    System.out.println();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateClaim() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter Claim ID to Update: ");
            int claimId = scanner.nextInt();
            scanner.nextLine(); 

            System.out.print("Enter New Status (submitted/processed): ");
            String status = scanner.nextLine();

            String sql = "UPDATE Claim SET status = ? WHERE claim_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, status);
                pstmt.setInt(2, claimId);

                int rowsAffected = pstmt.executeUpdate();
                System.out.println(rowsAffected + " claim updated.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteClaim() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter Claim ID to Delete: ");
            int claimId = scanner.nextInt();

            String sql = "DELETE FROM Claim WHERE claim_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, claimId);

                int rowsAffected = pstmt.executeUpdate();
                System.out.println(rowsAffected + " claim deleted.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
