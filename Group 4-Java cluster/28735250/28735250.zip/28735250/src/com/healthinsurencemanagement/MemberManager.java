package com.healthinsurencemanagement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class MemberManager {
	public void registerMember() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO Member (name, date_of_birth, email, phone_number) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                Scanner scanner = new Scanner(System.in);

                System.out.print("Enter Name: ");
                String name = scanner.nextLine();
                System.out.print("Enter Date of Birth (YYYY-MM-DD): ");
                String dob = scanner.nextLine();
                System.out.print("Enter Email: ");
                String email = scanner.nextLine();
                System.out.print("Enter Phone Number: ");
                String phoneNumber = scanner.nextLine();

                pstmt.setString(1, name);
                pstmt.setString(2, dob);
                pstmt.setString(3, email);
                pstmt.setString(4, phoneNumber);

                int rowsAffected = pstmt.executeUpdate();
                System.out.println(rowsAffected + " member registered.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewMemberDetails() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Member";
            try (PreparedStatement pstmt = conn.prepareStatement(sql);
                 ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    System.out.println("Member ID: " + rs.getInt("member_id"));
                    System.out.println("Name: " + rs.getString("name"));
                    System.out.println("Date of Birth: " + rs.getDate("date_of_birth"));
                    System.out.println("Email: " + rs.getString("email"));
                    System.out.println("Phone Number: " + rs.getString("phone_number"));
                    System.out.println();
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateMember() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter Member ID to Update: ");
            int memberId = scanner.nextInt();
            scanner.nextLine();  

            System.out.print("Enter New Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter New Date of Birth (YYYY-MM-DD): ");
            String dob = scanner.nextLine();
            System.out.print("Enter New Email: ");
            String email = scanner.nextLine();
            System.out.print("Enter New Phone Number: ");
            String phoneNumber = scanner.nextLine();

            String sql = "UPDATE Member SET name = ?, date_of_birth = ?, email = ?, phone_number = ? WHERE member_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, name);
                pstmt.setString(2, dob);
                pstmt.setString(3, email);
                pstmt.setString(4, phoneNumber);
                pstmt.setInt(5, memberId);

                int rowsAffected = pstmt.executeUpdate();
                System.out.println(rowsAffected + " member updated.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteMember() {
        try (Connection conn = DatabaseConnection.getConnection()) {
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter Member ID to Delete: ");
            int memberId = scanner.nextInt();

            String sql = "DELETE FROM Member WHERE member_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, memberId);

                int rowsAffected = pstmt.executeUpdate();
                System.out.println(rowsAffected + " member deleted.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
