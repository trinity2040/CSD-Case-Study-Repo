public class Complaint {
    private int complaintId;
    private int customerId;
    private String complaintDate;
    private String description;
    private String status;

    public Complaint() {}

    public Complaint(int complaintId, int customerId, String complaintDate, String description, String status) {
        this.complaintId = complaintId;
        this.customerId = customerId;
        this.complaintDate = complaintDate;
        this.description = description;
        this.status = status;
    }

    public int getComplaintId() {
        return complaintId;
    }

    public void setComplaintId(int complaintId) {
        this.complaintId = complaintId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getComplaintDate() {
        return complaintDate;
    }

    public void setComplaintDate(String complaintDate) {
        this.complaintDate = complaintDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
