import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class InquiryDAO {

    public void addInquiry(Inquiry inquiry) throws CustomerNotFoundException {
        // First, check if the customer exists
        if (!customerExists(inquiry.getCustomerId())) {
            throw new CustomerNotFoundException("Customer with ID " + inquiry.getCustomerId() + " not found.");
        }
        
        // Proceed with adding the inquiry if the customer exists
        String sql = "INSERT INTO Inquiry (customer_id, inquiry_date, description, status) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setInt(1, inquiry.getCustomerId());
            stmt.setString(2, inquiry.getInquiryDate());
            stmt.setString(3, inquiry.getDescription());
            stmt.setString(4, inquiry.getStatus());
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("Error adding inquiry: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
        }
    }

    public Inquiry getInquiry(int inquiryId) {
        String sql = "SELECT * FROM Inquiry WHERE inquiry_id = ?";
        Inquiry inquiry = null;
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setInt(1, inquiryId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    inquiry = new Inquiry();
                    inquiry.setInquiryId(rs.getInt("inquiry_id"));
                    inquiry.setCustomerId(rs.getInt("customer_id"));
                    inquiry.setInquiryDate(rs.getString("inquiry_date"));
                    inquiry.setDescription(rs.getString("description"));
                    inquiry.setStatus(rs.getString("status"));
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error fetching inquiry: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
        }
        
        return inquiry;
    }

    public void updateInquiryStatus(int inquiryId, String status) {
        String sql = "UPDATE Inquiry SET status = ? WHERE inquiry_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, status);
            stmt.setInt(2, inquiryId);
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("Error updating inquiry status: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
        }
    }

    public void deleteInquiry(int inquiryId) {
        String sql = "DELETE FROM Inquiry WHERE inquiry_id = ?";
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setInt(1, inquiryId);
            stmt.executeUpdate();
            
        } catch (SQLException e) {
            System.err.println("Error deleting inquiry: " + e.getMessage());
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
        }
    }

    private boolean customerExists(int customerId) {
        String sql = "SELECT COUNT(*) FROM Customer WHERE customer_id = ?";
        boolean exists = false;
        
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setInt(1, customerId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    exists = rs.getInt(1) > 0;
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error checking customer existence: " + e.getMessage());
        }
        
        return exists;
    }
}
