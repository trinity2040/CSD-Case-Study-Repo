package com.HospitalManagementSystem.hospital.dao;

import com.HospitalManagementSystem.hospital.exception.HospitalManagementException;

public abstract class DAO<T> {
    public abstract void add(T entity)throws HospitalManagementException;
    public abstract T get(int id) throws HospitalManagementException;
    public abstract void update(T entity)throws HospitalManagementException;
    public abstract boolean delete(int id) throws HospitalManagementException;
}
