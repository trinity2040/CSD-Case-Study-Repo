package com.HospitalManagementSystem.hospital.exception;

public class HospitalManagementException extends Exception {

    public HospitalManagementException(String message) {
        super(message);
    }

    public HospitalManagementException(String message, Throwable cause) {
        super(message, cause);
    }
}
