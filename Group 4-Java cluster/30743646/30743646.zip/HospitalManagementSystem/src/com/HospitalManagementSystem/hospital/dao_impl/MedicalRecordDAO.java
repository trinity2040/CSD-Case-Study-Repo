package com.HospitalManagementSystem.hospital.dao_impl;

import com.HospitalManagementSystem.hospital.dao.DAO;
import com.HospitalManagementSystem.hospital.exception.HospitalManagementException;
import com.HospitalManagementSystem.hospital.model.MedicalRecord;
import com.HospitalManagementSystem.hospital.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MedicalRecordDAO extends DAO<MedicalRecord> {

    private final Connection connection;

    // Constructor to initialize the database connection
    public MedicalRecordDAO() throws SQLException {
        this.connection = DatabaseConnection.getConnection();
    }

    // Method to add a new medical record to the database
    @Override
    public void add(MedicalRecord record) throws HospitalManagementException {
        String sql = "INSERT INTO medical_record (patient_id, doctor_id, date, diagnosis, treatment) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, record.getPatientId());
            statement.setInt(2, record.getDoctorId());
            statement.setString(3, record.getDate());
            statement.setString(4, record.getDiagnosis());
            statement.setString(5, record.getTreatment());
            statement.executeUpdate();
            System.out.println("Medical Record added successfully");

        } catch (SQLException e) {
            throw new HospitalManagementException("Error while adding medical record", e);
        }
    }

    // Method to retrieve a medical record by its ID
    @Override
    public MedicalRecord get(int id) throws HospitalManagementException {
        MedicalRecord record = null;
        String sql = "SELECT * FROM medical_record WHERE record_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                record = new MedicalRecord(
                        resultSet.getInt("record_id"),
                        resultSet.getInt("patient_id"),
                        resultSet.getInt("doctor_id"),
                        resultSet.getString("date"),
                        resultSet.getString("diagnosis"),
                        resultSet.getString("treatment")
                );
            }
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while retrieving medical record with ID: " + id, e);
        }
        return record;
    }

    // Method to update an existing medical record in the database
    @Override
    public void update(MedicalRecord record) throws HospitalManagementException {
        String sql = "UPDATE medical_record SET patient_id = ?, doctor_id = ?, date = ?, diagnosis = ?, treatment = ? WHERE record_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, record.getPatientId());
            statement.setInt(2, record.getDoctorId());
            statement.setString(3, record.getDate());
            statement.setString(4, record.getDiagnosis());
            statement.setString(5, record.getTreatment());
            statement.setInt(6, record.getRecordId());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while updating medical record with ID: " + record.getRecordId(), e);
        }
    }

    // Method to delete a medical record from the database by its ID
    @Override
    public boolean delete(int id) throws HospitalManagementException {
        String sql = "DELETE FROM medical_record WHERE record_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            int affectedRows = statement.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while deleting medical record with ID: " + id, e);
        }
    }

    // Method to retrieve all medical records from the database
    // This is a specific method for the MedicalRecordDAO class
    public List<MedicalRecord> getAllMedicalRecords() throws HospitalManagementException {
        List<MedicalRecord> records = new ArrayList<>();
        String sql = "SELECT * FROM medical_record";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                records.add(new MedicalRecord(
                        rs.getInt("record_id"),
                        rs.getInt("patient_id"),
                        rs.getInt("doctor_id"),
                        rs.getString("date"),
                        rs.getString("diagnosis"),
                        rs.getString("treatment")
                ));
            }
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while retrieving all medical records", e);
        }
        return records;
    }

}
