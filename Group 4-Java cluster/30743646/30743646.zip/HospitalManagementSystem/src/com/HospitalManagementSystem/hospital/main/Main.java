package com.HospitalManagementSystem.hospital.main;

import com.HospitalManagementSystem.hospital.dao_impl.PatientDAO;
import com.HospitalManagementSystem.hospital.dao_impl.DoctorDAO;
import com.HospitalManagementSystem.hospital.dao_impl.MedicalRecordDAO;
import com.HospitalManagementSystem.hospital.exception.HospitalManagementException;
import com.HospitalManagementSystem.hospital.model.Patient;
import com.HospitalManagementSystem.hospital.model.Doctor;
import com.HospitalManagementSystem.hospital.model.MedicalRecord;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws SQLException {
        // Initialize scanner for user input
        Scanner scanner = new Scanner(System.in);

        // Instantiate DAO objects for managing patients, doctors, and medical records
        PatientDAO patientDAO = new PatientDAO();
        DoctorDAO doctorDAO = new DoctorDAO();
        MedicalRecordDAO recordDAO = new MedicalRecordDAO();

        // Main loop for the menu-driven application
        while (true) {
            System.out.println("------------------------------");
            System.out.println("Welcome to Hospital Management System");
            System.out.println("1. Manage Patients");
            System.out.println("2. Manage Doctors");
            System.out.println("3. Manage Medical Records");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            try {
                switch (choice) {
                    case 1:
                        managePatients(scanner, patientDAO); // Handle patient management
                        break;
                    case 2:
                        manageDoctors(scanner, doctorDAO); // Handle doctor management
                        break;
                    case 3:
                        manageMedicalRecords(scanner, recordDAO); // Handle medical record management
                        break;
                    case 4:
                        System.out.println("Exiting...");
                        System.exit(0); // Exit the application
                    default:
                        System.out.println("Invalid choice. Please try again."); // Handle invalid menu option
                }
            } catch (HospitalManagementException | SQLException e) {
                System.out.println("Error: " + e.getMessage()); // Handle exceptions
            }
        }
    }

    // Method to manage patient-related operations
    private static void managePatients(Scanner scanner, PatientDAO patientDAO) throws HospitalManagementException {
        boolean isBack = false;
        while (!isBack) {
            System.out.println("1. Register a new patient");
            System.out.println("2. View patient details");
            System.out.println("3. Update patient information");
            System.out.println("4. Delete a patient");
            System.out.println("5. View all patients");
            System.out.println("6. Go Back");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    // Register a new patient
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter date of birth (YYYY-MM-DD): ");
                    String dob = scanner.nextLine();
                    System.out.print("Enter gender: ");
                    String gender = scanner.nextLine();
                    System.out.print("Enter address: ");
                    String address = scanner.nextLine();

                    Patient patient = new Patient(0, name, dob, gender, address);
                    patientDAO.add(patient); // Add patient to the database
                    break;
                case 2:
                    // View details of a specific patient
                    System.out.print("Enter patient ID: ");
                    int id = scanner.nextInt();
                    Patient p = patientDAO.get(id);
                    if (p != null) {
                        // Display patient details
                        System.out.println("Patient ID: " + p.getPatientId());
                        System.out.println("Name: " + p.getName());
                        System.out.println("Date of Birth: " + p.getDateOfBirth());
                        System.out.println("Gender: " + p.getGender());
                        System.out.println("Address: " + p.getAddress());
                    } else {
                        System.out.println("Patient not found.");
                    }
                    break;
                case 3:
                    // Update patient information
                    System.out.print("Enter patient ID to update: ");
                    id = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    Patient existingPatient = patientDAO.get(id);
                    if (existingPatient != null) {
                        // Prompt user for new values (if any)
                        System.out.print("Enter new name (leave blank to keep current): ");
                        name = scanner.nextLine();
                        System.out.print("Enter new date of birth (leave blank to keep current): ");
                        dob = scanner.nextLine();
                        System.out.print("Enter new gender (leave blank to keep current): ");
                        gender = scanner.nextLine();
                        System.out.print("Enter new address (leave blank to keep current): ");
                        address = scanner.nextLine();

                        // Update patient information
                        if (!name.isEmpty()) existingPatient.setName(name);
                        if (!dob.isEmpty()) existingPatient.setDateOfBirth(dob);
                        if (!gender.isEmpty()) existingPatient.setGender(gender);
                        if (!address.isEmpty()) existingPatient.setAddress(address);

                        patientDAO.update(existingPatient);
                        System.out.println("Patient information updated successfully!");
                    } else {
                        System.out.println("Patient not found.");
                    }
                    break;
                case 4:
                    // Delete a patient
                    System.out.print("Enter patient ID to delete: ");
                    id = scanner.nextInt();
                    boolean deleteSuccess = patientDAO.delete(id);
                    if (deleteSuccess) {
                        System.out.println("Patient deleted successfully!");
                    } else {
                        System.out.println("Failed to delete patient/Patient does not exist.");
                    }
                    break;
                case 5:
                    // View all patients
                    List<Patient> patients = patientDAO.getAllPatients();
                    if (patients.isEmpty()) {
                        System.out.println("No patients found.");
                    } else {
                        System.out.println("List of all patients:");
                        System.out.println("------------------------------");
                        for (Patient p1 : patients) {
                            // Display each patient's details
                            System.out.println("Patient ID: " + p1.getPatientId());
                            System.out.println("Name: " + p1.getName());
                            System.out.println("Date of Birth: " + p1.getDateOfBirth());
                            System.out.println("Gender: " + p1.getGender());
                            System.out.println("Address: " + p1.getAddress());
                            System.out.println("------------------------------");
                        }
                    }
                    break;
                case 6:
                    isBack = true; // Return to the main menu
                    break;
                default:
                    System.out.println("Invalid choice."); // Handle invalid submenu option
            }
        }
    }

    // Method to manage doctor-related operations
    private static void manageDoctors(Scanner scanner, DoctorDAO doctorDAO) throws HospitalManagementException {
        boolean isBack = false;
        while (!isBack) {
            System.out.println("1. Register a new doctor");
            System.out.println("2. View doctor details");
            System.out.println("3. Update doctor information");
            System.out.println("4. Delete a doctor");
            System.out.println("5. View all doctors");
            System.out.println("6. Go Back");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    // Register a new doctor
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter specialization: ");
                    String specialization = scanner.nextLine();
                    System.out.print("Enter contact number: ");
                    String contactNumber = scanner.nextLine();
                    System.out.print("Enter email: ");
                    String email = scanner.nextLine();
                    Doctor doctor = new Doctor(0, name, specialization, contactNumber, email);

                    doctorDAO.add(doctor); // Add doctor to the database
                    break;
                case 2:
                    // View details of a specific doctor
                    System.out.print("Enter doctor ID: ");
                    int id = scanner.nextInt();
                    Doctor d = doctorDAO.get(id);
                    if (d != null) {
                        // Display doctor details
                        System.out.println("Doctor ID: " + d.getDoctorId());
                        System.out.println("Name: " + d.getName());
                        System.out.println("Specialization: " + d.getSpecialization());
                        System.out.println("Contact Number: " + d.getContactNumber());
                        System.out.println("Email: " + d.getEmail());
                    } else {
                        System.out.println("Doctor not found.");
                    }
                    break;
                case 3:
                    // Update doctor information
                    System.out.print("Enter doctor ID to update: ");
                    id = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    Doctor existingDoctor = doctorDAO.get(id);
                    if (existingDoctor != null) {
                        // Prompt user for new values (if any)
                        System.out.print("Enter new name (leave blank to keep current): ");
                        name = scanner.nextLine();
                        System.out.print("Enter new specialization (leave blank to keep current): ");
                        specialization = scanner.nextLine();
                        System.out.print("Enter new contact number (leave blank to keep current): ");
                        contactNumber = scanner.nextLine();
                        System.out.print("Enter new email (leave blank to keep current): ");
                        email = scanner.nextLine();

                        // Update doctor information
                        if (!name.isEmpty()) existingDoctor.setName(name);
                        if (!specialization.isEmpty()) existingDoctor.setSpecialization(specialization);
                        if (!contactNumber.isEmpty()) existingDoctor.setContactNumber(contactNumber);
                        if (!email.isEmpty()) existingDoctor.setEmail(email);

                        doctorDAO.update(existingDoctor);
                        System.out.println("Doctor information updated successfully!");
                    } else {
                        System.out.println("Doctor not found.");
                    }
                    break;
                case 4:
                    // Delete a doctor
                    System.out.print("Enter doctor ID to delete: ");
                    id = scanner.nextInt();
                    boolean deleteSuccess = doctorDAO.delete(id);
                    if (deleteSuccess) {
                        System.out.println("Doctor deleted successfully!");
                    } else {
                        System.out.println("Failed to delete doctor/Doctor does not exist.");
                    }
                    break;
                case 5:
                    // View all doctors
                    List<Doctor> doctors = doctorDAO.getAllDoctors();
                    if (doctors.isEmpty()) {
                        System.out.println("No doctors found.");
                    } else {
                        System.out.println("List of all doctors:");
                        System.out.println("------------------------------");
                        for (Doctor d1 : doctors) {
                            // Display each doctor's details
                            System.out.println("Doctor ID: " + d1.getDoctorId());
                            System.out.println("Name: " + d1.getName());
                            System.out.println("Specialization: " + d1.getSpecialization());
                            System.out.println("Contact Number: " + d1.getContactNumber());
                            System.out.println("Email: " + d1.getEmail());
                            System.out.println("------------------------------");
                        }
                    }
                    break;
                case 6:
                    isBack = true; // Return to the main menu
                    break;
                default:
                    System.out.println("Invalid choice."); // Handle invalid submenu option
            }
        }
    }

    // Method to manage medical record-related operations
    private static void manageMedicalRecords(Scanner scanner, MedicalRecordDAO recordDAO) throws HospitalManagementException {
        boolean isBack = false;
        while (!isBack) {
            System.out.println("1. Add new medical record");
            System.out.println("2. View medical record details");
            System.out.println("3. Update medical record");
            System.out.println("4. Delete a medical record");
            System.out.println("5. View all medical records");
            System.out.println("6. Go Back");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    // Add new medical record
                    System.out.print("Enter patient ID: ");
                    int patientId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter doctor ID: ");
                    int doctorId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter diagnosis: ");
                    String diagnosis = scanner.nextLine();
                    System.out.print("Enter treatment: ");
                    String treatment = scanner.nextLine();
                    MedicalRecord record = new MedicalRecord(0, patientId, doctorId, diagnosis, treatment);

                    recordDAO.add(record); // Add medical record to the database
                    break;
                case 2:
                    // View details of a specific medical record
                    System.out.print("Enter medical record ID: ");
                    int id = scanner.nextInt();
                    MedicalRecord r = recordDAO.get(id);
                    if (r != null) {
                        // Display medical record details
                        System.out.println("Medical Record ID: " + r.getRecordId());
                        System.out.println("Patient ID: " + r.getPatientId());
                        System.out.println("Doctor ID: " + r.getDoctorId());
                        System.out.println("Diagnosis: " + r.getDiagnosis());
                        System.out.println("Treatment: " + r.getTreatment());
                    } else {
                        System.out.println("Medical record not found.");
                    }
                    break;
                case 3:
                    // Update medical record
                    System.out.print("Enter medical record ID to update: ");
                    id = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    MedicalRecord existingRecord = recordDAO.get(id);
                    if (existingRecord != null) {
                        // Prompt user for new values (if any)
                        System.out.print("Enter new diagnosis (leave blank to keep current): ");
                        diagnosis = scanner.nextLine();
                        System.out.print("Enter new treatment (leave blank to keep current): ");
                        treatment = scanner.nextLine();

                        // Update medical record information
                        if (!diagnosis.isEmpty()) existingRecord.setDiagnosis(diagnosis);
                        if (!treatment.isEmpty()) existingRecord.setTreatment(treatment);

                        recordDAO.update(existingRecord);
                        System.out.println("Medical record updated successfully!");
                    } else {
                        System.out.println("Medical record not found.");
                    }
                    break;
                case 4:
                    // Delete a medical record
                    System.out.print("Enter medical record ID to delete: ");
                    id = scanner.nextInt();
                    boolean deleteSuccess = recordDAO.delete(id);
                    if (deleteSuccess) {
                        System.out.println("Medical record deleted successfully!");
                    } else {
                        System.out.println("Failed to delete medical record/Medical record does not exist.");
                    }
                    break;
                case 5:
                    // View all medical records
                    List<MedicalRecord> records = recordDAO.getAllRecords();
                    if (records.isEmpty()) {
                        System.out.println("No medical records found.");
                    } else {
                        System.out.println("List of all medical records:");
                        System.out.println("------------------------------");
                        for (MedicalRecord r1 : records) {
                            // Display each medical record's details
                            System.out.println("Medical Record ID: " + r1.getRecordId());
                            System.out.println("Patient ID: " + r1.getPatientId());
                            System.out.println("Doctor ID: " + r1.getDoctorId());
                            System.out.println("Diagnosis: " + r1.getDiagnosis());
                            System.out.println("Treatment: " + r1.getTreatment());
                            System.out.println("------------------------------");
                        }
                    }
                    break;
                case 6:
                    isBack = true; // Return to the main menu
                    break;
                default:
                    System.out.println("Invalid choice."); // Handle invalid submenu option
            }
        }
    }
}
