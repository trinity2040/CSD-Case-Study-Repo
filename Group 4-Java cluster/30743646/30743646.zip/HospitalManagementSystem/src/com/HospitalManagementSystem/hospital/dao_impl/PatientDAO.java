package com.HospitalManagementSystem.hospital.dao_impl;

import com.HospitalManagementSystem.hospital.dao.DAO;
import com.HospitalManagementSystem.hospital.exception.HospitalManagementException;
import com.HospitalManagementSystem.hospital.model.Patient;
import com.HospitalManagementSystem.hospital.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PatientDAO extends DAO<Patient> {

    private final Connection connection;

    public PatientDAO() throws SQLException {
        this.connection = DatabaseConnection.getConnection(); // Establishes a connection to the database
    }

    @Override
    public void add(Patient patient) throws HospitalManagementException {
        String sql = "INSERT INTO Patient (name, date_of_birth, gender, address) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection(); // Creates a new connection for this operation
             PreparedStatement stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            stmt.setString(1, patient.getName()); // Sets the name parameter in the prepared statement
            stmt.setString(2, patient.getDateOfBirth()); // Sets the date_of_birth parameter
            stmt.setString(3, patient.getGender()); // Sets the gender parameter
            stmt.setString(4, patient.getAddress()); // Sets the address parameter

            int affectedRows = stmt.executeUpdate();
            if (affectedRows > 0) {
                ResultSet generatedKeys = stmt.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int id = generatedKeys.getInt(1);
                    patient.setPatientId(id); // Sets the retrieved ID on the patient object
                    System.out.println("Patient registered successfully with ID = " + id);
                } else {
                    throw new HospitalManagementException("Failed to retrieve generated patient ID.");
                }
            } else {
                throw new HospitalManagementException("No rows affected. Failed to add patient.");
            }
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while adding patient", e);
        }
    }


@Override
    public Patient get(int id) throws HospitalManagementException {
        String sql = "SELECT * FROM patient WHERE patient_id = ?";
        try (Connection conn = DatabaseConnection.getConnection(); // Creates a new connection for this operation
             PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setInt(1, id);// Sets the ID parameter in the prepared statement
            ResultSet resultSet = statement.executeQuery(); // Executes the query and retrieves the result set
            if (resultSet.next()) {
                return new Patient(
                        resultSet.getInt("patient_id"),
                        resultSet.getString("name"),
                        resultSet.getString("date_of_birth"),
                        resultSet.getString("gender"),
                        resultSet.getString("address")
                );
            } else {
                throw new HospitalManagementException("Patient with ID: " + id + " not found.");
            }
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while retrieving patient with ID: " + id, e);
        }
    }



    @Override
    public void update(Patient patient) throws HospitalManagementException {
        String sql = "UPDATE Patient SET name = ?, date_of_birth = ?, gender = ?, address = ? WHERE patient_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, patient.getName()); // Sets the name parameter
            statement.setString(2, patient.getDateOfBirth()); // Sets the date_of_birth parameter
            statement.setString(3, patient.getGender()); // Sets the gender parameter
            statement.setString(4, patient.getAddress()); // Sets the address parameter
            statement.setInt(5, patient.getPatientId()); // Sets the patient_id parameter (used for WHERE clause)
            statement.executeUpdate(); // Executes the update
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while updating patient with ID: " + patient.getPatientId(), e);
        }
    }

    @Override
    public boolean delete(int id) throws HospitalManagementException {
        String sql = "DELETE FROM Patient WHERE patient_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            int affectedRows = statement.executeUpdate();
            if (affectedRows > 0) {
                return true;
            } else {
                throw new HospitalManagementException("No rows affected. Patient with ID: " + id + " may not exist.");
            }
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while deleting patient with ID: " + id, e);
        }
    }

    // This method would not be directly implemented in the generic DAO
    // You can add it here if needed for specific functionalities in PatientDAO
    public List<Patient> getAllPatients() throws HospitalManagementException {
        List<Patient> patients = new ArrayList<>();
        String sql = "SELECT * FROM Patient";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                patients.add(new Patient(
                        rs.getInt("patient_id"),
                        rs.getString("name"),
                        rs.getString("date_of_birth"),
                        rs.getString("gender"),
                        rs.getString("address")
                ));
            }
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while retrieving all patients", e);
        }
        return patients;
    }
}