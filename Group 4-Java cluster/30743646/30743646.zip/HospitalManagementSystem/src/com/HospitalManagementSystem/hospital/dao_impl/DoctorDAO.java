package com.HospitalManagementSystem.hospital.dao_impl;

import com.HospitalManagementSystem.hospital.dao.DAO;
import com.HospitalManagementSystem.hospital.exception.HospitalManagementException;
import com.HospitalManagementSystem.hospital.model.Doctor;
import com.HospitalManagementSystem.hospital.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class DoctorDAO extends DAO<Doctor> {

    private final Connection connection;

    // Constructor to initialize the database connection
    public DoctorDAO() throws SQLException {
        this.connection = DatabaseConnection.getConnection();
    }

    // Method to add a new doctor to the database
    @Override
    public void add(Doctor doctor) {
        try {
            String sql = "INSERT INTO doctor (name, specialization, contact_number, email) VALUES (?, ?, ?, ?)";
            try (PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                statement.setString(1, doctor.getName());
                statement.setString(2, doctor.getSpecialization());
                statement.setString(3, doctor.getContactNumber());
                statement.setString(4, doctor.getEmail());
                statement.executeUpdate();
                ResultSet generatedKeys = statement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int id = generatedKeys.getInt(1);
                    doctor.setDoctorId(id); // Set the ID back to the Doctor object (optional)
                    System.out.println("Doctor registered successfully with ID = " + id);
                } else {
                    throw new HospitalManagementException("Failed to retrieve generated doctor ID.");
                }
            }
        } catch (SQLException | HospitalManagementException e) {
            // Handle the SQLException and wrap it in a RuntimeException or another unchecked exception
            throw new RuntimeException("Error while adding doctor", e);
        }
    }

    // Method to retrieve a doctor by their ID
    @Override
    public Doctor get(int id) throws HospitalManagementException {
        Doctor doctor = null;
        String sql = "SELECT * FROM doctor WHERE doctor_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                doctor = new Doctor(
                        resultSet.getInt("doctor_id"),
                        resultSet.getString("name"),
                        resultSet.getString("specialization"),
                        resultSet.getString("contact_number"),
                        resultSet.getString("email")
                );
            }
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while retrieving doctor with ID: " + id, e);
        }
        return doctor;
    }

    // Method to update an existing doctor's details in the database
    @Override
    public void update(Doctor doctor) throws HospitalManagementException {
        String sql = "UPDATE doctor SET name = ?, specialization = ?, contact_number = ?, email = ? WHERE doctor_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, doctor.getName());
            statement.setString(2, doctor.getSpecialization());
            statement.setString(3, doctor.getContactNumber());
            statement.setString(4, doctor.getEmail());
            statement.setInt(5, doctor.getDoctorId());
            statement.executeUpdate();
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while updating doctor with ID: " + doctor.getDoctorId(), e);
        }
    }

    // Method to delete a doctor from the database by their ID
    @Override
    public boolean delete(int id) throws HospitalManagementException {
        String sql = "DELETE FROM doctor WHERE doctor_id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            int rowsDeleted = statement.executeUpdate();
            return rowsDeleted > 0; // True if at least one row was deleted
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while deleting doctor with ID: " + id, e);
        }
    }

    // Method to retrieve all doctors from the database
    // This is a specific method for the DoctorDAO class
    public List<Doctor> getAllDoctors() throws HospitalManagementException {
        List<Doctor> doctors = new ArrayList<>();
        String sql = "SELECT * FROM doctor"; // Can be modified for filtering

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                doctors.add(new Doctor(
                        rs.getInt("doctor_id"),
                        rs.getString("name"),
                        rs.getString("specialization"),
                        rs.getString("contact_number"),
                        rs.getString("email")
                ));
            }
        } catch (SQLException e) {
            throw new HospitalManagementException("Error while retrieving all doctors", e);
        }
        return doctors;
    }

}
