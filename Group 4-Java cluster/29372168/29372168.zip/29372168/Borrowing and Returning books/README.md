## Getting Started

Welcome to the VS Code Java world. Here is a guideline to help you get started to write Java code in Visual Studio Code.

## Folder Structure

The workspace contains two folders by default, where:

- `main`: the folder to maintain sources
- `lib`: the folder to maintain dependencies

Meanwhile, the compiled output files will be generated in the `bin` folder by default.

> If you want to customize the folder structure, open `.vscode/settings.json` and update the related settings there.

## Dependency Management

The `JAVA PROJECTS` view allows you to manage your dependencies. More details can be found [here](https://github.com/microsoft/vscode-java-dependency#manage-dependencies).


Prerequisites
1.Java Development Kit (JDK) 8+
2.MySQL Server
3.MySQL Connector/J
4.IDE(Visual studio code)



Database Setup
1.Start MySQL Server.
2.Create the Database and Tables.
3.Insert Sample Data 

Open the Project in an IDE
1.Open the project folder in your preferred IDE.
2.Add MySQL Connector/J to Classpath

Running the Application
1.Compile and Run
In your IDE, you can usually right-click on LibraryManagementSystem.java and select Run.