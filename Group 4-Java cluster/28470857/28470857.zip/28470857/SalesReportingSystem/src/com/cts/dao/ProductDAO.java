package com.cts.dao;

import com.cts.exception.SalesReportingException;
import com.cts.model.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

    private Connection connection;

    public ProductDAO(Connection connection) {
        this.connection = connection;
    }

    // Method to add a new product to the database
    public void addProduct(Product product) throws SalesReportingException {
        String query = "INSERT INTO Product (name, category, price) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, product.getName());
            pstmt.setString(2, product.getCategory());
            pstmt.setDouble(3, product.getPrice());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new SalesReportingException("Error adding product: " + e.getMessage(), e);
        }
    }

    // Method to retrieve all products from the database
    public List<Product> getAllProducts() throws SalesReportingException {
        List<Product> products = new ArrayList<>();
        String query = "SELECT * FROM Product";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                int productId = rs.getInt("product_id");
                String name = rs.getString("name");
                String category = rs.getString("category");
                double price = rs.getDouble("price");

                Product product = new Product(productId, name, category, price);
                products.add(product);
            }
        } catch (SQLException e) {
            throw new SalesReportingException("Error retrieving products: " + e.getMessage(), e);
        }
        return products;
    }

    // Method to update a product in the database
    public void updateProduct(Product product) throws SalesReportingException {
        String query = "UPDATE Product SET name = ?, category = ?, price = ? WHERE product_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, product.getName());
            pstmt.setString(2, product.getCategory());
            pstmt.setDouble(3, product.getPrice());
            pstmt.setInt(4, product.getProductId());
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected == 0) {
                throw new SalesReportingException("No product found with ID " + product.getProductId());
            }
        } catch (SQLException e) {
            throw new SalesReportingException("Error updating product: " + e.getMessage(), e);
        }
    }

    // Method to delete a product from the database
    public void deleteProduct(int productId) throws SalesReportingException {
        String query = "DELETE FROM Product WHERE product_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, productId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected == 0) {
                throw new SalesReportingException("No product found with ID " + productId);
            }
        } catch (SQLException e) {
            throw new SalesReportingException("Error deleting product: " + e.getMessage(), e);
        }
    }
}
