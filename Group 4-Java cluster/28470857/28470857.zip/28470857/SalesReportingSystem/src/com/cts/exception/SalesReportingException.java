package com.cts.exception;

public class SalesReportingException extends Exception {

    // Constructor with no arguments
    public SalesReportingException() {
        super();
    }

    // Constructor that accepts a message
    public SalesReportingException(String message) {
        super(message);
    }

    // Constructor that accepts a message and a cause
    public SalesReportingException(String message, Throwable cause) {
        super(message, cause);
    }

    // Constructor that accepts a cause
    public SalesReportingException(Throwable cause) {
        super(cause);
    }
}



