package com.cts.client;

import com.cts.dao.CustomerDAO;
import com.cts.dao.ProductDAO;
import com.cts.dao.SalesDAO;
import com.cts.exception.SalesReportingException;
import com.cts.exception.InvalidPhoneNumberException;
import com.cts.model.Customer;
import com.cts.model.Product;
import com.cts.model.Sales;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class SalesReportingSystem {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/RetailSalesDB";
    private static final String USER = "root";
    private static final String PASS = "kiranp7010";

    private static Connection connection;

    public static void main(String[] args) {
        try {
            connection = DriverManager.getConnection(DB_URL, USER, PASS);
            System.out.println("Connected to the database successfully!");

            Scanner scanner = new Scanner(System.in);
            boolean exit = false;

            while (!exit) {
                System.out.println("\nSales Reporting System Menu:");
                System.out.println("1. Manage Products");
                System.out.println("2. Manage Customers");
                System.out.println("3. Manage Sales");
                System.out.println("4. Exit");
                System.out.print("Choose an option: ");
                
                int choice = scanner.nextInt();
                scanner.nextLine();  

                switch (choice) {
                    case 1:
                        handleProductOperations(scanner);
                        break;
                    case 2:
                        handleCustomerOperations(scanner);
                        break;
                    case 3:
                        handleSalesOperations(scanner);
                        break;
                    case 4:
                        exit = true;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }

        } catch (SQLException e) {
            System.err.println("Failed to connect to the database: " + e.getMessage());
        } finally {
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                    System.out.println("Disconnected from the database.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private static void handleProductOperations(Scanner scanner) {
        ProductDAO productDAO = new ProductDAO(connection);

        System.out.println("\nProduct Operations:");
        System.out.println("1. Add Product");
        System.out.println("2. View Products");
        System.out.println("3. Update Product");
        System.out.println("4. Delete Product");
        System.out.print("Choose an option: ");

        int choice = scanner.nextInt();
        scanner.nextLine();  

        try {
            switch (choice) {
                case 1:
                    System.out.print("Enter product name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter product category: ");
                    String category = scanner.nextLine();
                    System.out.print("Enter product price: ");
                    double price = scanner.nextDouble();

                    Product product = new Product(name, category, price);
                    productDAO.addProduct(product);
                    System.out.println("Product added successfully.");
                    break;

                case 2:
                    System.out.println("Products List:");
                    for (Product p : productDAO.getAllProducts()) {
                        System.out.println(p);
                    }
                    break;

                case 3:
                    System.out.print("Enter product ID to update: ");
                    int productId = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                    System.out.print("Enter new product name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter new product category: ");
                    String newCategory = scanner.nextLine();
                    System.out.print("Enter new product price: ");
                    double newPrice = scanner.nextDouble();

                    Product updatedProduct = new Product(productId, newName, newCategory, newPrice);
                    productDAO.updateProduct(updatedProduct);
                    System.out.println("Product updated successfully.");
                    break;

                case 4:
                    System.out.print("Enter product ID to delete: ");
                    int deleteProductId = scanner.nextInt();
                    productDAO.deleteProduct(deleteProductId);
                    System.out.println("Product deleted successfully.");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } catch (SalesReportingException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static void handleCustomerOperations(Scanner scanner) {
        CustomerDAO customerDAO = new CustomerDAO(connection);

        System.out.println("\nCustomer Operations:");
        System.out.println("1. Add Customer");
        System.out.println("2. View Customers");
        System.out.println("3. Update Customer");
        System.out.println("4. Delete Customer");
        System.out.print("Choose an option: ");

        int choice = scanner.nextInt();
        scanner.nextLine();  

        try {
            switch (choice) {
                case 1:
                    System.out.print("Enter customer name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter customer email: ");
                    String email = scanner.nextLine();
                    System.out.print("Enter customer phone: ");
                    String phone = scanner.nextLine();
                    System.out.print("Enter customer address: ");
                    String address = scanner.nextLine();

                    // Validate phone number
                    if (!isValidPhoneNumber(phone)) {
                        throw new InvalidPhoneNumberException("Invalid phone number. It must be a 10-digit number.");
                    }

                    Customer customer = new Customer(name, email, phone, address);
                    customerDAO.addCustomer(customer);
                    System.out.println("Customer added successfully.");
                    break;

                case 2:
                    System.out.println("Customers List:");
                    for (Customer c : customerDAO.getAllCustomers()) {
                        System.out.println(c);
                    }
                    break;

                case 3:
                    System.out.print("Enter customer ID to update: ");
                    int customerId = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                    System.out.print("Enter new customer name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter new customer email: ");
                    String newEmail = scanner.nextLine();
                    System.out.print("Enter new customer phone: ");
                    String newPhone = scanner.nextLine();
                    System.out.print("Enter new customer address: ");
                    String newAddress = scanner.nextLine();

                    // Validate phone number
                    if (!isValidPhoneNumber(newPhone)) {
                        throw new InvalidPhoneNumberException("Invalid phone number. It must be a 10-digit number.");
                    }

                    Customer updatedCustomer = new Customer(customerId, newName, newEmail, newPhone, newAddress);
                    customerDAO.updateCustomer(updatedCustomer);
                    System.out.println("Customer updated successfully.");
                    break;

                case 4:
                    System.out.print("Enter customer ID to delete: ");
                    int deleteCustomerId = scanner.nextInt();
                    customerDAO.deleteCustomer(deleteCustomerId);
                    System.out.println("Customer deleted successfully.");
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } catch (SalesReportingException e) {
            System.err.println("Error: " + e.getMessage());
        } catch (InvalidPhoneNumberException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static void handleSalesOperations(Scanner scanner) {
        SalesDAO salesDAO = new SalesDAO(connection);

        System.out.println("\nSales Operations:");
        System.out.println("1. Add Sale");
        System.out.println("2. View Sales");
        System.out.println("3. Update Sale");
        System.out.println("4. Delete Sale");
        System.out.print("Choose an option: ");

        int choice = scanner.nextInt();
        scanner.nextLine();  

        try {
            switch (choice) {
                case 1:
                	System.out.print("Enter product ID: ");
                    int productId = scanner.nextInt();
                    System.out.print("Enter customer ID: ");
                    int customerId = scanner.nextInt();
                    System.out.print("Enter quantity: ");
                    int quantity = scanner.nextInt();
                    System.out.print("Enter total amount: ");
                    double totalAmount = scanner.nextDouble();
                    scanner.nextLine();  // Consume newline
                    System.out.print("Enter sale date (YYYY-MM-DD): ");
                    String saleDateString = scanner.nextLine();

                    // Convert the string to java.sql.Date
                    Date saleDate = Date.valueOf(saleDateString);

                    Sales sale = new Sales(productId, customerId, saleDate, quantity, totalAmount);
                    salesDAO.addSale(sale);
                    System.out.println("Sale added successfully.");
                    break;

                case 2:
                    System.out.println("Sales List:");
                    for (Sales s : salesDAO.getAllSales()) {
                        System.out.println(s);
                    }
                    break;

                case 3:
                    System.out.print("Enter sale ID to update: ");
                    int saleId = scanner.nextInt();
                    scanner.nextLine();  
                    System.out.print("Enter new product ID: ");
                    int newProductId = scanner.nextInt();
                    System.out.print("Enter new customer ID: ");
                    int newCustomerId = scanner.nextInt();
                    System.out.print("Enter new quantity: ");
                    int newQuantity = scanner.nextInt();
                    System.out.print("Enter new total amount: ");
                    double newTotalAmount = scanner.nextDouble();
                    scanner.nextLine();  
                    System.out.print("Enter new sale date (YYYY-MM-DD): ");
                    String newSaleDateString = scanner.nextLine();

                    // Convert the string to java.sql.Date
                    Date newSaleDate = Date.valueOf(newSaleDateString);

                    Sales updatedSale = new Sales(saleId, newProductId, newCustomerId, newSaleDate, newQuantity, newTotalAmount);
                    salesDAO.updateSale(updatedSale);
                    System.out.println("Sale updated successfully.");
                    break;

                case 4:
                    System.out.print("Enter sale ID to delete: ");
                    int deleteSaleId = scanner.nextInt();
                    salesDAO.deleteSale(deleteSaleId);
                    System.out.println("Sale deleted successfully.");
                    break;

              

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } catch (SalesReportingException e) {
            System.err.println("Error: " + e.getMessage());
        }
    }

    private static boolean isValidPhoneNumber(String phoneNumber) {
        try {
            // Check if phone number is numeric and exactly 10 digits
            if (phoneNumber.length() != 10) {
                return false;
            }

            Long.parseLong(phoneNumber); // Check if it's a valid number

            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
