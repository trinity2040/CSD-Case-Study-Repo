package csd.project.studentenrollmentsystem.dao;

import java.util.List;

import csd.project.studentenrollmentsystem.entity.*;

public interface CourseDao {
	List<Course> findAll();
    Course findById(int courseId);
    int createCourse(Course course);
    int updateCourse(Course course);
    int deleteCourse(int courseId);
}
