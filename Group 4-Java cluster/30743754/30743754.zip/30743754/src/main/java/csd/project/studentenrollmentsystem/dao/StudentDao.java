package csd.project.studentenrollmentsystem.dao;

import java.util.List;


import csd.project.studentenrollmentsystem.entity.*;
public interface StudentDao {
	 List<Student> findAll();
	    Student findById(int studentId);
	    int createStudent(Student student);
	    int updateStudent(Student student);
	    int deleteStudent(int studentId);
}
