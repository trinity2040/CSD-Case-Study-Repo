package com.gymManagementSystem.models;

public class MembershipPlan {
    private int planId;
    private String planName;
    private int durationInMonths;
    private double price;

    // Constructor
    public MembershipPlan(int planId, String planName, int durationInMonths, double price) {
        this.planId = planId;
        this.planName = planName;
        this.durationInMonths = durationInMonths;
        this.price = price;
    }

    // Getters and Setters
    public int getPlanId() {
        return planId;
    }

    public void setPlanId(int planId) {
        this.planId = planId;
    }

    public String getPlanName() {
        return planName;
    }

    public void setPlanName(String planName) {
        this.planName = planName;
    }

    public int getDurationInMonths() {
        return durationInMonths;
    }

    public void setDurationInMonths(int durationInMonths) {
        this.durationInMonths = durationInMonths;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "MembershipPlan [ID=" + planId + ", Name=" + planName + 
               ", Duration (Months)=" + durationInMonths + ", Price=" + price + "]";
    }
}