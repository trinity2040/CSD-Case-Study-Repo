package com.gymManagementSystem.models;
public class Member {
	private int memberId;
    private String name;
    private int add;
    private String phone;
    private String email;
	 public Member(int memberId, String name, int add, String phone, String email) {
	        this.memberId = memberId;
	        this.name = name;
	        this.add = add;
	        this.phone = phone;
	        this.email = email;
	    }

	    // Getters and Setters
	    public int getMemberId() {
	        return memberId;
	    }

	    public void setMemberId(int memberId) {
	        this.memberId = memberId;
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public int getAdd() {
	        return add;
	    }

	    public void setAdd(int add) {
	        this.add = add;
	    }

	    public String getPhone() {
	        return phone;
	    }

	    public void setPhone(String phone) {
	        this.phone = phone;
	    }

	    public String getEmail() {
	        return email;
	    }

	    public void setEmail(String email) {
	        this.email = email;
	    }

	    @Override
	    public String toString() {
	        return "Member [ID=" + memberId + ", Name=" + name + ", Add=" + add + 
	               ", Phone=" + phone + ", Email=" + email + "]";
	    }
	}
