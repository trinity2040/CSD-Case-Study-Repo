package com.gymManagementSystem.exceptions;

public class MembershipExpiredException extends Exception {
    public MembershipExpiredException(String message) {
        super(message);
    }
}