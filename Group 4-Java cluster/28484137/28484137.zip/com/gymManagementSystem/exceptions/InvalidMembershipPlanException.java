package com.gymManagementSystem.exceptions;

public class InvalidMembershipPlanException extends Exception {
    public InvalidMembershipPlanException(String message) {
        super(message);
    }
}