#Basic Banking System
##Overview
This is a basic Gym Management System system implemented in Java using JDBC and MySQL. The system allows for managing customer accounts and performing transactions such as deposits, withdrawals, and transfers.
##Database Setup
1. Install MySQL and create a new database:
```sql
CREATE DATABASE GymManagement;

USE GymManagement;
CREATE TABLE Trainers (
    trainer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    specialty VARCHAR(100),
    phone VARCHAR(15),
    email VARCHAR(100)
);
CREATE TABLE MembershipPlans (
    plan_id INT AUTO_INCREMENT PRIMARY KEY,
    plan_name VARCHAR(100) NOT NULL,
    duration_in_months INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL
);
CREATE TABLE Members (
    member_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    age INT NOT NULL,
    phone VARCHAR(15),
    email VARCHAR(100),
    plan_id INT,
    start_date DATE NOT NULL,
    duration_in_months INT NOT NULL,
    membership_status ENUM('Active', 'Expired', 'Renewed') DEFAULT 'Active',
    FOREIGN KEY (plan_id) REFERENCES MembershipPlans(plan_id)
);
```
2.Update the MySQL credentials in the DatabaseConnection.java file:
```java
private static final String USER = "root";
private static final String PASSWORD = "password"; // Change to your MySQL password
##Usage
Implement menu options for managing members, trainers, and membership plans