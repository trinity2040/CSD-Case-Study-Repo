package GymPractice;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
import java.time.LocalDate;

import com.gym.manage.DatabaseConnection;

public class GymManagement {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("Gym Membership Management System");
            System.out.println("1. Manage Members");
            System.out.println("2. Manage Trainers");
            System.out.println("3. Manage Membership Plans");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    manageMembers(scanner);
                    break;
                case 2:
                    manageTrainers(scanner);
                    break;
                case 3:
                    manageMembershipPlans(scanner);
                    break;
                case 4:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        scanner.close();
    }

    private static void manageMembers(Scanner scanner) {
        boolean back = false;
        while (!back) {
            System.out.println("\nManage Members");
            System.out.println("1. Add Member");
            System.out.println("2. View Members");
            System.out.println("3. Delete Member");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addMember(scanner);
                    break;
                case 2:
                    viewMembers();
                    break;
                case 3:
                    deleteMember(scanner);
                    break;
                case 4:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageTrainers(Scanner scanner) {
        boolean back = false;
        while (!back) {
            System.out.println("\nManage Trainers");
            System.out.println("1. Add Trainer");
            System.out.println("2. View Trainers");
            System.out.println("3. Delete Trainer");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addTrainer(scanner);
                    break;
                case 2:
                    viewTrainers();
                    break;
                case 3:
                    deleteTrainer(scanner);
                    break;
                case 4:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageMembershipPlans(Scanner scanner) {
        boolean back = false;
        while (!back) {
            System.out.println("\nManage Membership Plans");
            System.out.println("1. Add Plan");
            System.out.println("2. View Plans");
            System.out.println("3. Delete Plan");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addMembershipPlan(scanner);
                    break;
                case 2:
                    viewMembershipPlans();
                    break;
                case 3:
                    deleteMembershipPlan(scanner);
                    break;
                case 4:
                    back = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addMember(Scanner scanner) {
        System.out.print("Enter member name: ");
        String name = scanner.next();
        System.out.print("Enter member age: ");
        int age = scanner.nextInt();
        System.out.print("Enter member phone: ");
        String phone = scanner.next();
        System.out.print("Enter member email: ");
        String email = scanner.next();

        String sql = "INSERT INTO Members (name, age, phone, email) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, name);
            pstmt.setInt(2, age);
            pstmt.setString(3, phone);
            pstmt.setString(4, email);
            pstmt.executeUpdate();

            System.out.println("Member added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewMembers() {
        String sql = "SELECT * FROM Members";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                System.out.println("Member ID: " + rs.getInt("member_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Age: " + rs.getInt("age"));
                System.out.println("Phone: " + rs.getString("phone"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("-------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteMember(Scanner scanner) {
        System.out.print("Enter member ID to delete: ");
        int memberId = scanner.nextInt();

        String sql = "DELETE FROM Members WHERE member_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, memberId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Member deleted successfully!");
            } else {
                System.out.println("Member not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void addTrainer(Scanner scanner) {
        System.out.print("Enter trainer name: ");
        String name = scanner.next();
        System.out.print("Enter trainer specialty: ");
        String specialty = scanner.next();
        System.out.print("Enter trainer phone: ");
        String phone = scanner.next();
        System.out.print("Enter trainer email: ");
        String email = scanner.next();

        String sql = "INSERT INTO Trainers (name, specialty, phone, email) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, name);
            pstmt.setString(2, specialty);
            pstmt.setString(3, phone);
            pstmt.setString(4, email);
            pstmt.executeUpdate();

            System.out.println("Trainer added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewTrainers() {
        String sql = "SELECT * FROM Trainers";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                System.out.println("Trainer ID: " + rs.getInt("trainer_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Specialty: " + rs.getString("specialty"));
                System.out.println("Phone: " + rs.getString("phone"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("-------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void deleteTrainer(Scanner scanner) {
        System.out.print("Enter trainer ID to delete: ");
        int trainerId = scanner.nextInt();

        String sql = "DELETE FROM Trainers WHERE trainer_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, trainerId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Trainer deleted successfully!");
            } else {
                System.out.println("Trainer not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void addMembershipPlan(Scanner scanner) {
        System.out.print("Enter plan name: ");
        String planName = scanner.next();
        System.out.print("Enter duration in months: ");
        int duration = scanner.nextInt();
        System.out.print("Enter price: ");
        double price = scanner.nextDouble();

        String sql = "INSERT INTO MembershipPlans (plan_name, duration_in_months, price) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, planName);
            pstmt.setInt(2, duration);
            pstmt.setDouble(3, price);
            pstmt.executeUpdate();

            System.out.println("Membership plan added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void viewMembershipPlans() {
        String sql = "SELECT * FROM MembershipPlans";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                System.out.println("Plan ID: " + rs.getInt("plan_id"));
                System.out.println("Plan Name: " + rs.getString("plan_name"));
                System.out.println("Duration (Months): " + rs.getInt("duration_in_months"));
                System.out.println("Price: " + rs.getDouble("price"));
                System.out.println("-------------------------------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public double calculateMembershipFees(int planId, int durationInMonths) {
        String query = "SELECT price FROM MembershipPlan WHERE plan_id = ?";
        double totalFee = 0;

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, planId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                double price = resultSet.getDouble("price");
                totalFee = price * durationInMonths;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return totalFee;
    }
    
    public boolean isMembershipExpired(int memberId) {
        String query = "SELECT start_date, duration_in_months FROM Member WHERE member_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setInt(1, memberId);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                LocalDate startDate = resultSet.getDate("start_date").toLocalDate();
                int durationInMonths = resultSet.getInt("duration_in_months");

                LocalDate endDate = startDate.plusMonths(durationInMonths);
                return LocalDate.now().isAfter(endDate);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    public boolean renewMembership(int memberId, int planId) {
        String planQuery = "SELECT duration_months FROM MembershipPlan WHERE plan_id = ?";
        String memberQuery = "UPDATE Member SET start_date = ?, duration_in_months = ?, membership_status = 'Renewed' WHERE member_id = ?";
        
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement planStatement = connection.prepareStatement(planQuery);
             PreparedStatement memberStatement = connection.prepareStatement(memberQuery)) {

            // Get the new plan duration
            planStatement.setInt(1, planId);
            ResultSet planResult = planStatement.executeQuery();
            if (!planResult.next()) {
                return false; // Plan not found
            }
            int newDuration = planResult.getInt("duration_months");

            // Update the membership start date and duration
            LocalDate newStartDate = LocalDate.now();

            memberStatement.setDate(1, java.sql.Date.valueOf(newStartDate));
            memberStatement.setInt(2, newDuration);
            memberStatement.setInt(3, memberId);

            int rowsUpdated = memberStatement.executeUpdate();
            return rowsUpdated > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    
    private static void deleteMembershipPlan(Scanner scanner) {
        System.out.print("Enter plan ID to delete: ");
        int planId = scanner.nextInt();

        String sql = "DELETE FROM MembershipPlans WHERE plan_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, planId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Membership plan deleted successfully!");
            } else {
                System.out.println("Plan not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
