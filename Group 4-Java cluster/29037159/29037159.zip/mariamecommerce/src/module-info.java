/**
 * 
 */
/**
 * 
 */
module mariamecommerce {
	requires java.sql;
}