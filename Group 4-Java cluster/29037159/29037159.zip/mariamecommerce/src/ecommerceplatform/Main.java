package ecommerceplatform;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        ProductDAO productDAO = new ProductDAO();
        OrderDAO orderDAO = new OrderDAO();
        CustomerDAO customerDAO = new CustomerDAO();

        while (true) {
            System.out.println("1. Manage Products");
            System.out.println("2. Manage Orders");
            System.out.println("3. Manage Customers");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    manageProducts(productDAO);
                    break;
                case 2:
                    manageOrders(orderDAO);
                    break;
                case 3:
                    manageCustomers(customerDAO);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close(); // Close scanner here
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageProducts(ProductDAO productDAO) {
        while (true) {
            System.out.println("\nProduct Management");
            System.out.println("1. Add Product");
            System.out.println("2. View Product");
            System.out.println("3. Update Product");
            System.out.println("4. Delete Product");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    addProduct(productDAO);
                    break;
                case 2:
                    viewProduct(productDAO);
                    break;
                case 3:
                    updateProduct(productDAO);
                    break;
                case 4:
                    deleteProduct(productDAO);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageOrders(OrderDAO orderDAO) {
        while (true) {
            System.out.println("\nOrder Management");
            System.out.println("1. Place Order");
            System.out.println("2. View Order");
            System.out.println("3. Update Order Status");
            System.out.println("4. Cancel Order");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    placeOrder(orderDAO);
                    break;
                case 2:
                    viewOrder(orderDAO);
                    break;
                case 3:
                    updateOrderStatus(orderDAO);
                    break;
                case 4:
                    cancelOrder(orderDAO);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageCustomers(CustomerDAO customerDAO) {
        while (true) {
            System.out.println("\nCustomer Management");
            System.out.println("1. Add Customer");
            System.out.println("2. View Customer");
            System.out.println("3. Back to Main Menu");
            System.out.print("Choose an option: ");

            int choice = getIntInput();

            switch (choice) {
                case 1:
                    addCustomer(customerDAO);
                    break;
                case 2:
                    viewCustomer(customerDAO);
                    break;
                case 3:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void addProduct(ProductDAO productDAO) {
        scanner.nextLine(); // Consume the newline left-over
        System.out.print("Enter product name: ");
        String name = scanner.nextLine();
        System.out.print("Enter product description: ");
        String description = scanner.nextLine();
        System.out.print("Enter product price: ");
        double price = getDoubleInput();
        System.out.print("Enter quantity available: ");
        int quantityAvailable = getIntInput();
        System.out.print("Enter product category: ");
        String category = scanner.nextLine();

        Product product = new Product(name, description, price, quantityAvailable, category);
        int id = productDAO.addProduct(product);
        System.out.println("Product added with ID: " + id);
    }

    private static void viewProduct(ProductDAO productDAO) {
        System.out.print("Enter product ID to view: ");
        int id = getIntInput();
        Product product = productDAO.getProductById(id);

        if (product != null) {
            System.out.println(product);
        } else {
            System.out.println("Product not found.");
        }
    }

    private static void updateProduct(ProductDAO productDAO) {
        System.out.print("Enter product ID to update: ");
        int id = getIntInput();
        Product product = productDAO.getProductById(id);

        if (product != null) {
            scanner.nextLine(); // Consume the newline left-over
            System.out.print("Enter new product name (leave blank to keep current): ");
            String name = scanner.nextLine();
            if (!name.isBlank()) product.setName(name);

            System.out.print("Enter new description (leave blank to keep current): ");
            String description = scanner.nextLine();
            if (!description.isBlank()) product.setDescription(description);

            System.out.print("Enter new price (0 to keep current): ");
            double price = getDoubleInput();
            if (price > 0) product.setPrice(price);

            System.out.print("Enter new quantity available (-1 to keep current): ");
            int quantityAvailable = getIntInput();
            if (quantityAvailable >= 0) product.setQuantityAvailable(quantityAvailable);

            System.out.print("Enter new category (leave blank to keep current): ");
            String category = scanner.nextLine();
            if (!category.isBlank()) product.setCategory(category);

            productDAO.updateProduct(product);
            System.out.println("Product updated.");
        } else {
            System.out.println("Product not found.");
        }
    }

    private static void deleteProduct(ProductDAO productDAO) {
        System.out.print("Enter product ID to delete: ");
        int id = getIntInput();
        productDAO.deleteProduct(id);
        System.out.println("Product deleted.");
    }

    private static void placeOrder(OrderDAO orderDAO) {
        System.out.print("Enter customer ID: ");
        int customerId = getIntInput();
        System.out.print("Enter product ID: ");
        int productId = getIntInput();
        System.out.print("Enter quantity: ");
        int quantity = getIntInput();
        scanner.nextLine(); // Consume the newline left-over
        System.out.print("Enter order status: ");
        String status = scanner.nextLine();

        Order order = new Order(customerId, productId, quantity, new java.util.Date(), status);
        int id = orderDAO.placeOrder(order);
        System.out.println("Order placed with ID: " + id);
    }

    private static void viewOrder(OrderDAO orderDAO) {
        System.out.print("Enter order ID to view: ");
        int id = getIntInput();
        Order order = orderDAO.getOrderById(id);

        if (order != null) {
            System.out.println(order);
        } else {
            System.out.println("Order not found.");
        }
    }

    private static void updateOrderStatus(OrderDAO orderDAO) {
        System.out.print("Enter order ID to update status: ");
        int id = getIntInput();
        scanner.nextLine(); // Consume the newline left-over
        System.out.print("Enter new status: ");
        String status = scanner.nextLine();

        orderDAO.updateOrderStatus(id, status);
        System.out.println("Order status updated.");
    }

    private static void cancelOrder(OrderDAO orderDAO) {
        System.out.print("Enter order ID to cancel: ");
        int id = getIntInput();
        orderDAO.cancelOrder(id);
        System.out.println("Order canceled.");
    }

    private static void addCustomer(CustomerDAO customerDAO) {
        scanner.nextLine(); // Consume the newline left-over
        System.out.print("Enter customer name: ");
        String name = scanner.nextLine();
        System.out.print("Enter customer email: ");
        String email = scanner.nextLine();
        System.out.print("Enter customer address: ");
        String address = scanner.nextLine();
        System.out.print("Enter customer phone number: ");
        String phoneNumber = scanner.nextLine();

        Customer customer = new Customer(name, email, address, phoneNumber);
        int id = customerDAO.addCustomer(customer);
        System.out.println("Customer added with ID: " + id);
    }

    private static void viewCustomer(CustomerDAO customerDAO) {
        System.out.print("Enter customer ID to view: ");
        int id = getIntInput();
        Customer customer = customerDAO.getCustomerById(id);

        if (customer != null) {
            System.out.println(customer);
        } else {
            System.out.println("Customer not found.");
        }
    }

    private static int getIntInput() {
        while (true) {
            try {
                int value = scanner.nextInt();
                scanner.nextLine(); // Consume the newline left-over
                return value;
            } catch (InputMismatchException e) {
                System.out.print("Invalid input. Please enter an integer: ");
                scanner.next(); // Clear invalid input
            }
        }
    }

    private static double getDoubleInput() {
        while (true) {
            try {
                double value = scanner.nextDouble();
                scanner.nextLine(); // Consume the newline left-over
                return value;
            } catch (InputMismatchException e) {
                System.out.print("Invalid input. Please enter a number: ");
                scanner.next(); // Clear invalid input
            }
        }
    }
}
