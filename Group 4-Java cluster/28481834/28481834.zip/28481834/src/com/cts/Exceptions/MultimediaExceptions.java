package com.cts.Exceptions;

public class MultimediaExceptions {

    // Exception when a media item is not found
    //--------------------------------------------
    public static class MediaItemNotFoundException extends Exception {
        public MediaItemNotFoundException(String message) {
            super(message);
        }
    }

    // Exception when a user is not found
    //--------------------------------------------
    public static class UserNotFoundException extends Exception {
        public UserNotFoundException(String message) {
            super(message);
        }
    }

    // Exception when a rental is not found
    //--------------------------------------------
    public static class RentalNotFoundException extends Exception {
        public RentalNotFoundException(String message) {
            super(message);
        }
    }

    // Exception when a rental operation is not possible (no available copies)
    //------------------------------------------------------------------------
    public static class NotAvailableException extends Exception {
        public NotAvailableException(String message) {
            super(message);
        }
    }

}


