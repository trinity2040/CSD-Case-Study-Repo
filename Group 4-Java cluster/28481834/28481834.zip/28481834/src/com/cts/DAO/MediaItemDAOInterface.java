package com.cts.DAO;

import com.cts.model.Media_item;

import java.util.List;

public interface MediaItemDAOInterface {
    void addMediaItem(Media_item item);
    Media_item getMediaItem(int itemId);
    void updateMediaItem(Media_item item);
    void deleteMediaItem(int itemId);
    List<Media_item> getAllMediaItems();
    void updateAvailableCopies(int itemId, int newAvailableCopies);
}
