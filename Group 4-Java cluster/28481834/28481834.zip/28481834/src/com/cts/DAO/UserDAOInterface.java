package com.cts.DAO;

import com.cts.model.User;
import java.util.List;

public interface UserDAOInterface {
    void addUser(User user);
    User getUser(int userId);
    List<User> getAllUsers();
    void updateUser(User user);
    void deleteUser(int userId);
}
