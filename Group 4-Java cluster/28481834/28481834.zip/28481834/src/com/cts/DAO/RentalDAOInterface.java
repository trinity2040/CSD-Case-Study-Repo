package com.cts.DAO;

import com.cts.model.Rental;

import java.util.List;

public interface RentalDAOInterface {
    void addRental(Rental rental);
    Rental getRental(int rentalId);
    void updateRental(Rental rental);
    double calculateLateFee(int rentalId, double dailyLateFee, Rental rental);
    List<Rental> getRentalsByUser(int userId);
    List<Rental> getAllRentals();
}
