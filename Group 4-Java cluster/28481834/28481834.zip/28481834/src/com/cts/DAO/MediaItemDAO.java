package com.cts.DAO;

import com.cts.model.Media_item;
import com.cts.util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class MediaItemDAO implements MediaItemDAOInterface {
    @Override
    public void addMediaItem(Media_item item) {
        String query = "INSERT INTO media_item (title, type, genre, release_date, available_copies, total_copies) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, item.getTitle());
            stmt.setString(2, item.getType());
            stmt.setString(3, item.getGenre());
            stmt.setObject(4, item.getReleaseDate());
            stmt.setInt(5, item.getAvailableCopies());
            stmt.setInt(6, item.getTotalCopies());
            stmt.executeUpdate();
            System.out.println("Media item added successfully!");
            System.out.println("====================================");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Media_item getMediaItem(int itemId) {
        String query = "SELECT * FROM media_item WHERE item_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, itemId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Media_item item = new Media_item();
                item.setItemId(rs.getInt("item_id"));
                item.setTitle(rs.getString("title"));
                item.setType(rs.getString("type"));
                item.setGenre(rs.getString("genre"));
                item.setReleaseDate(rs.getObject("release_date", LocalDate.class));
                item.setAvailableCopies(rs.getInt("available_copies"));
                item.setTotalCopies(rs.getInt("total_copies"));
                return item;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void updateMediaItem(Media_item item) {
        String query = "UPDATE media_item SET title = ?, type = ?, genre = ?, release_date = ?, available_copies = ?, total_copies = ? WHERE item_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, item.getTitle());
            stmt.setString(2, item.getType());
            stmt.setString(3, item.getGenre());
            stmt.setObject(4, item.getReleaseDate());
            stmt.setInt(5, item.getAvailableCopies());
            stmt.setInt(6, item.getTotalCopies());
            stmt.setInt(7, item.getItemId());
            stmt.executeUpdate();
            System.out.println("Media item updated successfully!");
            System.out.println("====================================");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteMediaItem(int itemId) {
        String query = "DELETE FROM media_item WHERE item_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, itemId);
            stmt.executeUpdate();
            System.out.println("Media item deleted successfully!");
            System.out.println("====================================");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Media_item> getAllMediaItems() {
        List<Media_item> items = new ArrayList<>();
        String query = "SELECT * FROM media_item";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Media_item item = new Media_item();
                item.setItemId(rs.getInt("item_id"));
                item.setTitle(rs.getString("title"));
                item.setType(rs.getString("type"));
                item.setGenre(rs.getString("genre"));
                item.setReleaseDate(rs.getObject("release_date", LocalDate.class));
                item.setAvailableCopies(rs.getInt("available_copies"));
                item.setTotalCopies(rs.getInt("total_copies"));
                items.add(item);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return items;
    }

    @Override
    public void updateAvailableCopies(int itemId, int newAvailableCopies) {
        String query = "UPDATE media_item SET available_copies = ? WHERE item_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, newAvailableCopies);
            stmt.setInt(2, itemId);
            stmt.executeUpdate();
            System.out.println("Available copies updated successfully!");
            System.out.println("====================================");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
