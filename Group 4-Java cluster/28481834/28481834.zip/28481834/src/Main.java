import com.cts.DAO.MediaItemDAO;
import com.cts.DAO.User_DAO;
import com.cts.DAO.Rental_DAO;
import com.cts.Exceptions.MultimediaExceptions.*;
import com.cts.model.Media_item;
import com.cts.model.User;
import com.cts.model.Rental;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class Main {

    private static final Scanner scanner = new Scanner(System.in);
    private static final MediaItemDAO mediaItemDAO = new MediaItemDAO();
    private static final User_DAO userDAO = new User_DAO();
    private static final Rental_DAO rentalDAO = new Rental_DAO();

    public static void main(String[] args) {
        boolean exit = false;
        while (!exit) {
            showMainMenu();
            int choice = scanner.nextInt();
            scanner.nextLine();
            switch (choice) {
                case 1:
                    manageMediaItems();
                    break;
                case 2:
                    manageUsers();
                    break;
                case 3:
                    manageRentals();
                    break;
                case 4:
                    exit = true;
                    System.out.println("====================================");
                    System.out.println("Exiting the system. Goodbye!");
                    System.out.println("====================================");
                    break;
                default:
                    System.out.println("====================================");
                    System.out.println("Invalid choice! Please try again.");
                    System.out.println("====================================");
            }
        }
        scanner.close();
    }


    //Main Menu
    //----------------------------------------------------------
    private static void showMainMenu() {
        System.out.println("=== Multimedia Management System ===");
        System.out.println("1. Manage Media Items");
        System.out.println("2. Manage Users");
        System.out.println("3. Manage Rentals");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    //Media Item Menu
    //----------------------------------------------------------
    private static void manageMediaItems(){
        System.out.println("=== Media Item Management ===");
        System.out.println("1. Add New Media Item");
        System.out.println("2. View Media Item Details");
        System.out.println("3. Update Media Item Information");
        System.out.println("4. Delete Media Item");
        System.out.println("5. View All Media Items");
        System.out.println("6. Back to Main Menu");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();
        switch (choice) {
            case 1:
                addMediaItem();
                break;
            case 2:
                viewMediaItemDetails();
                break;
            case 3:
                updateMediaItem();
                break;
            case 4:
                deleteMediaItem();
                break;
            case 5:
                viewAllMediaItems();
                break;
            case 6:
                return;
            default:
                System.out.println("====================================");
                System.out.println("Invalid choice! Please try again.");
                System.out.println("====================================");
        }
    }


    //User Menu
    //----------------------------------------------------------
    private static void manageUsers() {
        System.out.println("=== User Management ===");
        System.out.println("1. Register New User");
        System.out.println("2. View User Details");
        System.out.println("3. View All Users");
        System.out.println("4. Update Users");
        System.out.println("5. Delete Users");
        System.out.println("6. Back to Main Menu");
        System.out.print("Enter your choice: ");

        int choice = scanner.nextInt();
        scanner.nextLine();

        switch (choice) {
            case 1:
                registerUser();
                break;
            case 2:
                viewUserDetails();
                break;
            case 3:
                viewAllUserDetails();
                break;
            case 4:
                updateUserDetails();
                break;
            case 5:
                DeleteUsers();
                break;
            case 6:
                return;
            default:
                System.out.println("====================================");
                System.out.println("Invalid choice! Please try again.");
                System.out.println("====================================");
        }
    }


    //Rental Menu
    //----------------------------------------------------------
    private static void manageRentals() {
        System.out.println("=== Rental Management ===");
        System.out.println("1. Rent Out Media Item");
        System.out.println("2. View Rental Details By Rental ID");
        System.out.println("3. Update Rental Information");
        System.out.println("4. View All Rentals");
        System.out.println("5. View Rentals of Specific Users");
        System.out.println("6. Back to Main Menu");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();
        switch (choice) {
            case 1:
                rentOut();
                break;
            case 2:
                viewRentalDetails();
                break;
            case 3:
                updateRentalInformation();
                break;
            case 4:
                viewAllRentalDetails();
                break;
            case 5:
                viewRentalDetailsUsers();
                break;
            case 6:
                return;
            default:
                System.out.println("====================================");
                System.out.println("Invalid choice! Please try again.");
                System.out.println("====================================");
        }
    }

    //             Media Item Management Methods
    //----------------------------------------------------------

    //Add Media Details
    //----------------------------------------------------------
    private static void addMediaItem() {
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter type (Movie, Music, etc.): ");
        String type = scanner.nextLine();
        System.out.print("Enter genre: ");
        String genre = scanner.nextLine();
        System.out.print("Enter release date (YYYY-MM-DD): ");
        String releaseDate = scanner.nextLine();
        System.out.print("Enter available copies: ");
        int availableCopies = scanner.nextInt();
        System.out.print("Enter total copies: ");
        int totalCopies = scanner.nextInt();

        Media_item item = new Media_item();
        item.setTitle(title);
        item.setType(type);
        item.setGenre(genre);
        item.setReleaseDate(LocalDate.parse(releaseDate));
        item.setAvailableCopies(availableCopies);
        item.setTotalCopies(totalCopies);
        mediaItemDAO.addMediaItem(item);
    }

    //View Media Details
    //----------------------------------------------------------
    private static void viewMediaItemDetails(){
        System.out.print("Enter Media Item ID: ");
        int itemId = scanner.nextInt();
        try {
            Media_item item = mediaItemDAO.getMediaItem(itemId);
            if (item == null) {
                throw new MediaItemNotFoundException("Media item with ID " + itemId + " not found!");
            } else {
                System.out.println("===================================");
                System.out.println(item.getTitle() + "  Details");
                System.out.println("====================================");
                System.out.println("Item ID: " + item.getItemId());
                System.out.println("Title: " + item.getTitle());
                System.out.println("Type: " + item.getType());
                System.out.println("Genre: " + item.getGenre());
                System.out.println("Release Date: " + item.getReleaseDate());
                System.out.println("Available Copies: " + item.getAvailableCopies());
                System.out.println("Total Copies: " + item.getTotalCopies());
            }
        } catch (MediaItemNotFoundException e) {
            System.out.println("====================================");
            System.out.println(e.getMessage());
            System.out.println("====================================");
        }
    }

    //Update Media Details
    //----------------------------------------------------------
    private static void updateMediaItem() {
        System.out.print("Enter Media Item ID to update: ");
        int itemId = scanner.nextInt();
        scanner.nextLine();
        try {
            Media_item item = mediaItemDAO.getMediaItem(itemId);
            if (item == null) {
                throw new MediaItemNotFoundException("Media item with ID " + itemId + " not found!");
            } else {
                System.out.print("Enter new title: ");
                String title = scanner.nextLine();
                System.out.print("Enter new type: ");
                String type = scanner.nextLine();
                System.out.print("Enter new genre: ");
                String genre = scanner.nextLine();
                System.out.print("Enter new release date: ");
                String releaseDate = scanner.nextLine();
                System.out.print("Enter new available copies: ");
                int availableCopies = scanner.nextInt();
                System.out.print("Enter new total copies: ");
                int totalCopies = scanner.nextInt();

                if (!title.isEmpty()) item.setTitle(title);
                if (!type.isEmpty()) item.setType(type);
                if (!genre.isEmpty()) item.setGenre(genre);
                if (!releaseDate.isEmpty()) item.setReleaseDate(LocalDate.parse(releaseDate));
                if (availableCopies != 0) item.setAvailableCopies(availableCopies);
                if (totalCopies != 0) item.setTotalCopies(totalCopies);

                mediaItemDAO.updateMediaItem(item);
            }
        }catch (MediaItemNotFoundException e) {
            System.out.println("====================================");
            System.out.println(e.getMessage());
            System.out.println("====================================");
        }
    }

    //Delete Media Details
    //----------------------------------------------------------
    private static void deleteMediaItem() {
        System.out.print("Enter Media Item ID to delete: ");
        int itemId = scanner.nextInt();

        mediaItemDAO.deleteMediaItem(itemId);
    }

    //View All Media Details
    //----------------------------------------------------------
    private static void viewAllMediaItems() {
        List<Media_item> items = mediaItemDAO.getAllMediaItems();
        if (items.isEmpty()) {
            System.out.println("No media items found.");
        } else {
            for (Media_item item : items) {
                System.out.println("===================================");
                System.out.println(item.getTitle()+"  Details");
                System.out.println("====================================");
                System.out.println("Item ID: " + item.getItemId());
                System.out.println("Title: " + item.getTitle());
                System.out.println("Type: " + item.getType());
                System.out.println("Genre: " + item.getGenre());
                System.out.println("Release Date: " + item.getReleaseDate());
                System.out.println("Available Copies: " + item.getAvailableCopies());
                System.out.println("Total Copies: " + item.getTotalCopies());
                System.out.println("====================================");
            }
        }
    }

    //                 User Management Methods
    //----------------------------------------------------------

    //Add User Details
    //----------------------------------------------------------
    private static void registerUser() {
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter contact number: ");
        String contactNumber = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter address: ");
        String address = scanner.nextLine();

        User user = new User();
        user.setName(name);
        user.setContact_number(contactNumber);
        user.setEmail(email);
        user.setAddress(address);

        userDAO.addUser(user);
    }

    //View User Details
    //----------------------------------------------------------
    private static void viewUserDetails() {
        System.out.print("Enter User ID: ");
        int userId = scanner.nextInt();
        User user = userDAO.getUser(userId);
        try {
            if (user == null) {
                throw new UserNotFoundException("User with ID " + userId + " not found!");
            }
            else{
                System.out.println("===================================");
                System.out.println(user.getName()+" User Details");
                System.out.println("====================================");
                System.out.println("User ID: " + user.getUser_id());
                System.out.println("Name: " + user.getName());
                System.out.println("Contact Number: " + user.getContact_number());
                System.out.println("Email: " + user.getEmail());
                System.out.println("Address: " + user.getAddress());
            }
        } catch (UserNotFoundException e) {
            System.out.println("================================");
            System.out.println(e.getMessage());
            System.out.println("================================");
        }
    }

    //View All User Details
    //----------------------------------------------------------
    private static void viewAllUserDetails(){
        List<User> users = User_DAO.getAllUsersDetials();
        if (users.isEmpty()) {
            System.out.println("No media items found.");
        } else {
            for (User user : users) {
                System.out.println("==================================");
                System.out.println(user.getName()+" User Details");
                System.out.println("==================================");
                System.out.println("User ID: " + user.getUser_id());
                System.out.println("Name: " + user.getName());
                System.out.println("Contact Number: " + user.getContact_number());
                System.out.println("Email: " + user.getEmail());
                System.out.println("Address: " + user.getAddress());
                System.out.println("====================================");
            }
        }
    }

    //Update User Details
    //----------------------------------------------------------
    private static void updateUserDetails(){
        System.out.println("Enter the User Id to be Updated:");
        int updateUserId = scanner.nextInt();
        scanner.nextLine();
        try {
            User user = userDAO.getUser(updateUserId);
            if (user == null) {
                throw new UserNotFoundException("User with ID " + updateUserId + " not found!");
            } else {
                System.out.print("Enter new name: ");
                String name = scanner.nextLine();
                System.out.print("Enter new contact number: ");
                String contact_number = scanner.nextLine();
                System.out.print("Enter new email: ");
                String email = scanner.nextLine();
                System.out.print("Enter new address: ");
                String address = scanner.nextLine();

                if (!name.isEmpty()) user.setName(name);
                if (!contact_number.isEmpty()) user.setContact_number(contact_number);
                if (!email.isEmpty()) user.setEmail(email);
                if (!address.isEmpty()) user.setAddress(address);
                userDAO.updateUser(user);
            }
        }
        catch (UserNotFoundException e) {
            System.out.println("================================");
            System.out.println(e.getMessage());
            System.out.println("================================");
        }

    }

    //Delete User Details
    //----------------------------------------------------------
    private static void DeleteUsers() {
        System.out.print("Enter User ID to delete: ");
        int itemId = scanner.nextInt();

        userDAO.deleteUser(itemId);
    }


    //                 Rental Management Methods
    //----------------------------------------------------------

    //Add Rental Details
    //----------------------------------------------------------
    private static void rentOut() {
        try {
            System.out.print("Enter Media Item ID: ");
            int itemId = scanner.nextInt();
            System.out.print("Enter User ID: ");
            int userId = scanner.nextInt();
            Media_item media = mediaItemDAO.getMediaItem(itemId);
            if (media == null) {
                throw new MediaItemNotFoundException("Media item with ID " + itemId + " not found!");
            }
            if (media.getAvailableCopies() <= 0) {
                throw new NotAvailableException("No available copies for the media item!");
            }
            Rental rental = new Rental();
            rental.setItem_id(itemId);
            rental.setUser_id(userId);
            rental.setRental_date(LocalDate.now());
            rental.setReturned(false);
            rentalDAO.addRental(rental);
            int newAvailableCopies = media.getAvailableCopies() - 1;
            mediaItemDAO.updateAvailableCopies(rental.getItem_id(), newAvailableCopies);
        } catch (MediaItemNotFoundException | NotAvailableException e) {
            System.out.println("===============================================");
            System.out.println(e.getMessage());
            System.out.println("===============================================");
        }
    }


    //View Rental Details By RentalID
    //----------------------------------------------------------
    private static void viewRentalDetails() {
        System.out.print("Enter Rental ID: ");
        int rentalId = scanner.nextInt();
        try {
        Rental rental = rentalDAO.getRental(rentalId);
        if (rental == null) {
            throw new RentalNotFoundException("Rental ID " + rental + " not found!");
        }
        else {
            Media_item itemName = mediaItemDAO.getMediaItem(rental.getItem_id());
            User userName = userDAO.getUser(rental.getUser_id());

            System.out.println("-----Rental Details---------");
            System.out.println("Rental ID: " + rental.getRental_id());
            System.out.println("Item ID: " + rental.getItem_id());
            System.out.println("Media Item Name: " + itemName.getTitle());
            System.out.println("User ID: " + rental.getUser_id());
            System.out.println("User Name: " + userName.getName());
            System.out.println("Rental Date: " + rental.getRental_date());
            System.out.println("Return Date: " + rental.getReturn_date());
            System.out.println("Returned: " + rental.getReturned());
            System.out.println("================================");
        }
        }
        catch (RentalNotFoundException e) {
            System.out.println("===============================================");
            System.out.println(e.getMessage());
            System.out.println("===============================================");
        }

    }

    //Update Rental Detail(Return Item) And Calculate Late Fee
    //----------------------------------------------------------
    private static void updateRentalInformation() {
        System.out.print("Enter Rental ID to update: ");
        int rentalId = scanner.nextInt();
        scanner.nextLine();
        try {
            Rental rental = rentalDAO.getRental(rentalId);
            if (rental == null) {
                throw new RentalNotFoundException("Rental ID not found");
            }
            Media_item media = mediaItemDAO.getMediaItem(rental.getItem_id());
            if (media == null) {
                System.out.println("Media item associated with this rental not found.");
                return;
            }
            int available = media.getAvailableCopies();
            System.out.println("Current Return Date: " + rental.getReturn_date());
            System.out.println("Current Returned Status: " + rental.getReturned());
            System.out.print("Mark as returned? (yes/no): ");
            String markReturned = scanner.nextLine();
            if (markReturned.equalsIgnoreCase("yes")) {
                System.out.print("Enter return date (YYYY-MM-DD): ");
                String returnDateStr = scanner.nextLine();
                LocalDate returnDate;
                try {
                    returnDate = LocalDate.parse(returnDateStr);
                } catch (Exception e) {
                    System.out.println("Invalid date format. Please use YYYY-MM-DD.");
                    return;
                }
                rental.setReturned(true);
                rental.setReturn_date(returnDate);
                double lateFee = rentalDAO.calculateLateFee(rentalId, 5, rental); // Assuming $5 per day late fee
                if (lateFee > 0) {
                    System.out.println("Late Fee: $" + lateFee);
                } else {
                    System.out.println("Returned on time. No late fee.");
                }
                rentalDAO.updateRental(rental);
                int newAvailableCopies = available + 1;
                mediaItemDAO.updateAvailableCopies(rental.getItem_id(), newAvailableCopies);
            } else {
                System.out.println("Rental not marked as returned.");
            }
        } catch (RentalNotFoundException e) {
            System.out.println("===============================================");
            System.out.println(e.getMessage());
            System.out.println("===============================================");
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }


    //View Rental Details By UserID
    //----------------------------------------------------------
     private static void viewRentalDetailsUsers() {
         System.out.print("Enter User ID: ");
         int UserId = scanner.nextInt();
         List<Rental> Rentals = rentalDAO.getRentalsByUser(UserId);
         if (Rentals.isEmpty()) {
             System.out.println("No Rentals found.");
             System.out.println("================================");
         }
         else {
             for (Rental rental : Rentals) {
                 Media_item itemName = mediaItemDAO.getMediaItem(rental.getItem_id());
                 User userName = userDAO.getUser(rental.getUser_id());
                 System.out.println("-----Rental Details---------");
                 System.out.println("================================");
                 System.out.println("Rental ID: " + rental.getRental_id());
                 System.out.println("Item ID: " + rental.getItem_id());
                 System.out.println("Media Item Name: " + itemName.getTitle());
                 System.out.println("User ID: " + rental.getUser_id());
                 System.out.println("User Name: " + userName.getName());
                 System.out.println("Rental Date: " + rental.getRental_date());
                 System.out.println("Return Date: " + rental.getReturn_date());
                 System.out.println("Returned: " + rental.getReturned());
                 System.out.println("================================");
             }
         }

    }


    //View All Rental Details
    //----------------------------------------------------------
    private static void viewAllRentalDetails() {
        List<Rental> Rentals = rentalDAO.getAllRentals();
        if (Rentals.isEmpty()) {
            System.out.println("No Rentals found.");
            System.out.println("================================");
        }
        else {
            for (Rental rental : Rentals) {
                Media_item itemName = mediaItemDAO.getMediaItem(rental.getItem_id());
                User userName = userDAO.getUser(rental.getUser_id());
                System.out.println("-----Rental Details---------");
                System.out.println("================================");
                System.out.println("Rental ID: " + rental.getRental_id());
                System.out.println("Item ID: " + rental.getItem_id());
                System.out.println("Media Item Name: " + itemName.getTitle());
                System.out.println("User ID: " + rental.getUser_id());
                System.out.println("User Name: " + userName.getName());
                System.out.println("Rental Date: " + rental.getRental_date());
                System.out.println("Return Date: " + rental.getReturn_date());
                System.out.println("Returned: " + rental.getReturned());
                System.out.println("================================");
            }
        }

    }

}