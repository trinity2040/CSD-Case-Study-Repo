package model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Media_item {
    private int itemId;
    private String title;
    private String type;
    private String genre;
    private LocalDate releaseDate;
    private int availableCopies;
    private int totalCopies;

    // Date formatter
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    // Constructor
    public Media_item(int itemId, String title, String type, String genre, LocalDate releaseDate, int availableCopies, int totalCopies) {
        this.itemId = itemId;
        this.title = title;
        this.type = type;
        this.genre = genre;
        this.releaseDate = releaseDate;
        this.availableCopies = availableCopies;
        this.totalCopies = totalCopies;
    }

    public Media_item() {

    }

    // Getters and setters
    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public LocalDate getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(LocalDate releaseDate) {
        this.releaseDate = releaseDate;
    }

    // Additional method to set release date from String
    public void setReleaseDate(String releaseDate) {
        this.releaseDate = LocalDate.parse(releaseDate, formatter);
    }

    // Additional method to get release date as String
    public String getReleaseDateAsString() {
        return releaseDate.format(formatter);
    }

    public int getAvailableCopies() {
        return availableCopies;
    }

    public void setAvailableCopies(int availableCopies) {
        this.availableCopies = availableCopies;
    }

    public int getTotalCopies() {
        return totalCopies;
    }

    public void setTotalCopies(int totalCopies) {
        this.totalCopies = totalCopies;
    }

    @Override
    public String toString() {
        return "MediaItem{" +
                "itemId=" + itemId +
                ", title='" + title + '\'' +
                ", type='" + type + '\'' +
                ", genre='" + genre + '\'' +
                ", releaseDate=" + releaseDate +
                ", availableCopies=" + availableCopies +
                ", totalCopies=" + totalCopies +
                '}';
    }
}
