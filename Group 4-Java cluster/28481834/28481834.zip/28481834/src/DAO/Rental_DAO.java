package DAO;

import model.Rental;
import model.Media_item;
import util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.time.temporal.ChronoUnit;
public class Rental_DAO {

    // Rent out a media item to a user
    public void addRental(Rental rental) {
        String query = "INSERT INTO rental(item_id, user_id, rental_date, return_date, returned) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
                stmt.setInt(1, rental.getItem_id());
                stmt.setInt(2, rental.getUser_id());
                stmt.setDate(3, Date.valueOf(rental.getRental_date()));
                stmt.setDate(4, rental.getReturn_date() != null ? Date.valueOf(rental.getReturn_date()) : null);
                stmt.setBoolean(5, rental.getReturned());
                stmt.executeUpdate();
                System.out.println("Rental added successfully!");
            System.out.println("====================================");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // View rental details by rental ID
    public Rental getRental(int rentalId) {
        String query = "SELECT * FROM rental WHERE rental_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, rentalId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Rental rental = new Rental();
                rental.setRental_id(rs.getInt("rental_id"));
                rental.setItem_id(rs.getInt("item_id"));
                rental.setUser_id(rs.getInt("user_id"));
                rental.setRental_date(rs.getDate("rental_date").toLocalDate());
                rental.setReturn_date(rs.getDate("return_date") != null ? rs.getDate("return_date").toLocalDate() : null);
                rental.setReturned(rs.getBoolean("returned"));
                return rental;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Update rental information when an item is returned
    public void updateRental(Rental rental) {
        String query = "UPDATE rental SET return_date = ?, returned = ? WHERE rental_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setDate(1, rental.getReturn_date() != null ? Date.valueOf(rental.getReturn_date()) : null);
            stmt.setBoolean(2, rental.getReturned());
            stmt.setInt(3, rental.getRental_id());
            stmt.executeUpdate();
            System.out.println("Rental updated successfully and closed!");
            System.out.println("====================================");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Calculate late fees for overdue items
    public double calculateLateFee(int rentalId, double dailyLateFee, Rental rental) {
        String query = "SELECT rental_date FROM rental WHERE rental_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, rentalId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                LocalDate rentalDate = rs.getDate("rental_date").toLocalDate();
//                LocalDate returnDate = rs.getDate("return_date").toLocalDate();
                LocalDate returnDate = rental.getReturn_date();
                // Calculate the difference in days
                long daysBetween = ChronoUnit.DAYS.between(rentalDate, returnDate);

                System.out.println("Days between rental and return: " + daysBetween);
                if (daysBetween > 7) {
                    long extra_Days = daysBetween -7;
                    return extra_Days * dailyLateFee;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    // View all rentals for a specific user
    public List<Rental> getRentalsByUser(int userId) {
        List<Rental> rentals = new ArrayList<>();
        String query = "SELECT * FROM rental WHERE useR_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Rental rental = new Rental();
                rental.setRental_id(rs.getInt("rental_id"));
                rental.setItem_id(rs.getInt("item_id"));
                rental.setUser_id(rs.getInt("user_id"));
                rental.setRental_date(rs.getDate("rental_date").toLocalDate());
                rental.setReturn_date(rs.getDate("return_date") != null ? rs.getDate("return_date").toLocalDate() : null);
                rental.setReturned(rs.getBoolean("returned"));
                rentals.add(rental);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rentals;
    }


    // View all rentals
    public List<Rental> getAllRentals() {
        List<Rental> rentals = new ArrayList<>();
        String query = "SELECT * FROM rental";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                Rental rental = new Rental();
                rental.setRental_id(rs.getInt("rental_id"));
                rental.setItem_id(rs.getInt("item_id"));
                rental.setUser_id(rs.getInt("user_id"));
                rental.setRental_date(rs.getDate("rental_date").toLocalDate());
                rental.setReturn_date(rs.getDate("return_date") != null ? rs.getDate("return_date").toLocalDate() : null);
                rental.setReturned(rs.getBoolean("returned"));
                rentals.add(rental);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rentals;
    }
}