# Case Study-116: Multimedia Management System

## Description
This project is a menu-driven console application that simulates a multimedia library management system. The application allows users to manage media items, users, and rentals using a MySQL database.

## Features
- **Media Item Management**: Add, view, update, and delete media items (movies, music albums, etc.).
- **User Management**: Register, view, update, and delete users.
- **Rental Management**: Rent out media items to users, view rental details, update rental status, and calculate late fees for overdue items.

## Technologies
- Java (Core)
- MySQL
- JDBC

## Setup Instructions
1. **Database Setup**:
   - Create a MySQL database named `multimedia`.
   - Create the following tables:

     ```sql
CREATE TABLE mediaItem (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100),
    type VARCHAR(50),
    genre VARCHAR(50),
    release_date DATE,
    available_copies INT,
    total_copies INT
);

CREATE TABLE user (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    contact_number VARCHAR(15),
    email VARCHAR(100),
    address VARCHAR(255)
);

CREATE TABLE rental (
    rental_id INT AUTO_INCREMENT PRIMARY KEY,
    item_id INT,
    user_id INT,
    rental_date DATE,
    return_date DATE,
    returned BOOLEAN,
    FOREIGN KEY (item_id) REFERENCES mediaItem(item_id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES user(user_id) ON DELETE CASCADE
);

     ```

2. **Java Setup**:
   - Download the project and place the `mysql-connector-java-x.x.xx.jar` in the `lib/` directory.
   - Add the MySQL connector JAR to your project’s classpath.

3. **Run the Application**:
   - Compile and run the `main.java` class.
   - Follow the on-screen menu to manage media items, users, and rentals.

## Usage
- Select the appropriate menu option to perform operations like adding, viewing, updating, or deleting records in the system.

## Notes
- Ensure that your MySQL server is running and accessible.
- Modify the database credentials in the `DatabaseConnection.java` file if necessary.




