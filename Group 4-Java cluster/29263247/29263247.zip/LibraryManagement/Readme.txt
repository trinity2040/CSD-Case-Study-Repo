Library Management System



Overview

The Library Management System is a menu-based console application developed using Core Java, MySQL, and JDBC. The application allows users to manage books, authors, and library members, as well as handle borrowing and returning books.

Features

1. Book Management
	Add a new book
	View book details
	Update book information
	Delete a book
2. Author Management
	Add a new author
	View author details
	Update author information
	Delete an author
3. Library Member Management
	Register a new library member
	View member details
	Update member information
	Delete a member
4. Borrowing and Returning Books
	Issue a book to a member
	Return a book from a member
	View borrowing history of a member


Prerequisites
	Java Development Kit (JDK): Version 8 or higher
	MySQL Server: Version 5.7 or higher
	MySQL JDBC Driver: mysql-connector-java-8.0.xx.jar


Setup Instructions

1. Clone the Repository

Clone this repository to your local machine using:
git clone <repository-url>

2. Database Setup

Start your MySQL server.
Open MySQL Workbench or any other MySQL client.
Create the database and tables using the provided SQL script:

CREATE DATABASE library_db;

USE library_db;

CREATE TABLE Author (
    author_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    biography TEXT
);

CREATE TABLE Book (
    book_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    author_id INT,
    ISBN VARCHAR(20),
    quantity_available INT NOT NULL,
    FOREIGN KEY (author_id) REFERENCES Author(author_id)
);

CREATE TABLE LibraryMember (
    member_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    address VARCHAR(200),
    phone_number VARCHAR(15),
    email VARCHAR(50)
);

CREATE TABLE BorrowingHistory (
    borrowing_id INT AUTO_INCREMENT PRIMARY KEY,
    book_id INT,
    member_id INT,
    issue_date DATE,
    return_date DATE,
    FOREIGN KEY (book_id) REFERENCES Book(book_id),
    FOREIGN KEY (member_id) REFERENCES LibraryMember(member_id)
);


3. Configuration

Open the DatabaseConnection.java file in your Java IDE.
Update the URL, USER, and PASSWORD fields with your MySQL database credentials:

private static final String URL = "jdbc:mysql://localhost:3306/library_db";
private static final String USER = "root";
private static final String PASSWORD = "yourpassword";


4. Build and Run

Compile the Java files:
javac -cp .:mysql-connector-java-8.0.xx.jar *.java
Run the application:
java -cp .:mysql-connector-java-8.0.xx.jar LibraryManagementSystem


5. Usage

Upon running the application, you will be presented with a menu:


Library Management System:
1. Manage Books
2. Manage Authors
3. Manage Members
4. Borrow/Return Books
5. Exit
Choose the desired option by entering the corresponding number. Follow the prompts to add, view, update, or delete records.

Note: First create an author and then create a book to avoid violation of foreign key constraints

6. Exception Handling

The application includes basic exception handling to manage common errors such as SQL exceptions. If an error occurs, a user-friendly error message will be displayed.

Troubleshooting

Ensure that the MySQL server is running and accessible.
Verify that the MySQL JDBC driver is correctly added to the classpath.
Check for typos or syntax errors in the database connection details.

Authors
[Harshini Mamulla]