package LibraryManagement;

import java.util.*;
public class LibraryCatalogApp {

	    private BookManager bookManager;
	    private AuthorManager authorManager;
	    private MemberManager memberManager;
	    private BorrowingManager borrowingManager;

	    public LibraryCatalogApp() {
	        bookManager = new BookManager();
	        authorManager = new AuthorManager();
	        memberManager = new MemberManager();
	        borrowingManager = new BorrowingManager();
	    }

	    public void showMenu() {
	        Scanner scanner = new Scanner(System.in);
	        while (true) {
	            System.out.println("Library Catalog Menu:");
	            System.out.println("---------------------");
	            System.out.println("1. Add Book");
	            System.out.println("2. View Book");
	            System.out.println("3. Update Book");
	            System.out.println("4. Delete Book");
	            System.out.println("5. Add Author");
	            System.out.println("6. View Author");
	            System.out.println("7. Update Author");
	            System.out.println("8. Delete Author");
	            System.out.println("9. Register Member");
	            System.out.println("10. View Member");
	            System.out.println("11. Update Member");
	            System.out.println("12. Delete Member");
	            System.out.println("13. Issue Book");
	            System.out.println("14. Return Book");
	            System.out.println("15. View Borrowing History");
	            System.out.println("0. Exit");

	            int choice = scanner.nextInt();
	            scanner.nextLine();  // Consume newline
	            switch (choice) {
	                case 1: bookManager.addBook(scanner); break;
	                case 2: bookManager.viewBook(scanner); break;
	                case 3: bookManager.updateBook(scanner); break;
	                case 4: bookManager.deleteBook(scanner); break;
	                case 5: authorManager.addAuthor(scanner); break;
	                case 6: authorManager.viewAuthor(scanner); break;
	                case 7: authorManager.updateAuthor(scanner); break;
	                case 8: authorManager.deleteAuthor(scanner); break;
	                case 9: memberManager.registerMember(scanner); break;
	                case 10: memberManager.viewMember(scanner); break;
	                case 11: memberManager.updateMember(scanner); break;
	                case 12: memberManager.deleteMember(scanner); break;
	                case 13: borrowingManager.issueBook(scanner); break;
	                case 14: borrowingManager.returnBook(scanner); break;
	                case 15: borrowingManager.viewBorrowingHistory(scanner); break;
	                case 0: System.out.println("Exited"); return;
	                default: System.out.println("Invalid choice. Please provide correct option.");
	            }
	        }
	    }

	    public static void main(String[] args) {
	        LibraryCatalogApp app = new LibraryCatalogApp();
	        app.showMenu();
	    }
	}
