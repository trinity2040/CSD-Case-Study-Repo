package LibraryManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class MemberManager {

    public void registerMember(Scanner scanner) {
        System.out.println("Enter member name:");
        String name = scanner.nextLine();
        System.out.println("Enter address:");
        String address = scanner.nextLine();
        System.out.println("Enter phone number:");
        String phoneNumber = scanner.nextLine();
        System.out.println("Enter email:");
        String email = scanner.nextLine();

        String query = "INSERT INTO LibraryMember (name, address, phone_number, email) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, name);
            stmt.setString(2, address);
            stmt.setString(3, phoneNumber);
            stmt.setString(4, email);
            stmt.executeUpdate();
            System.out.println("Member registered successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewMember(Scanner scanner) {
        System.out.println("Enter member ID to view:");
        int memberId = scanner.nextInt();

        String query = "SELECT * FROM LibraryMember WHERE member_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, memberId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Member ID: " + rs.getInt("member_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Address: " + rs.getString("address"));
                System.out.println("Phone Number: " + rs.getString("phone_number"));
                System.out.println("Email: " + rs.getString("email"));
            } else {
                System.out.println("Member not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateMember(Scanner scanner) {
        System.out.println("Enter member ID to update:");
        int memberId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.println("Enter new name:");
        String name = scanner.nextLine();
        System.out.println("Enter new address:");
        String address = scanner.nextLine();
        System.out.println("Enter new phone number:");
        String phoneNumber = scanner.nextLine();
        System.out.println("Enter new email:");
        String email = scanner.nextLine();

        String query = "UPDATE LibraryMember SET name = ?, address = ?, phone_number = ?, email = ? WHERE member_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, name);
            stmt.setString(2, address);
            stmt.setString(3, phoneNumber);
            stmt.setString(4, email);
            stmt.setInt(5, memberId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Member updated successfully.");
            } else {
                System.out.println("Member not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteMember(Scanner scanner) {
        System.out.println("Enter member ID to delete:");
        int memberId = scanner.nextInt();

        String query = "DELETE FROM LibraryMember WHERE member_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, memberId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Member deleted successfully.");
            } else {
                System.out.println("Member not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

