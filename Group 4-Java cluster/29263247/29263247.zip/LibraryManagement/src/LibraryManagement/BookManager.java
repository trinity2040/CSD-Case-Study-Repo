package LibraryManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class BookManager {

    public void addBook(Scanner scanner) {
        System.out.println("Enter book title:");
        String title = scanner.nextLine();
        System.out.println("Enter author ID:");
        int authorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.println("Enter ISBN:");
        String isbn = scanner.nextLine();
        System.out.println("Enter quantity available:");
        int quantity = scanner.nextInt();

        String query = "INSERT INTO Book (title, author_id, ISBN, quantity_available) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, title);
            stmt.setInt(2, authorId);
            stmt.setString(3, isbn);
            stmt.setInt(4, quantity);
            stmt.executeUpdate();
            System.out.println("Book added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewBook(Scanner scanner) {
        System.out.println("Enter book ID to view:");
        int bookId = scanner.nextInt();

        String query = "SELECT * FROM Book WHERE book_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, bookId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Book ID: " + rs.getInt("book_id"));
                System.out.println("Title: " + rs.getString("title"));
                System.out.println("Author ID: " + rs.getInt("author_id"));
                System.out.println("ISBN: " + rs.getString("ISBN"));
                System.out.println("Quantity Available: " + rs.getInt("quantity_available"));
            } else {
                System.out.println("Book not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateBook(Scanner scanner) {
        System.out.println("Enter book ID to update:");
        int bookId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.println("Enter new title:");
        String title = scanner.nextLine();
        System.out.println("Enter new author ID:");
        int authorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.println("Enter new ISBN:");
        String isbn = scanner.nextLine();
        System.out.println("Enter new quantity available:");
        int quantity = scanner.nextInt();

        String query = "UPDATE Book SET title = ?, author_id = ?, ISBN = ?, quantity_available = ? WHERE book_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, title);
            stmt.setInt(2, authorId);
            stmt.setString(3, isbn);
            stmt.setInt(4, quantity);
            stmt.setInt(5, bookId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Book updated successfully.");
            } else {
                System.out.println("Book not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteBook(Scanner scanner) {
        System.out.println("Enter book ID to delete:");
        int bookId = scanner.nextInt();

        String query = "DELETE FROM Book WHERE book_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, bookId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Book deleted successfully.");
            } else {
                System.out.println("Book not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
