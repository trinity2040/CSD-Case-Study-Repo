package LibraryManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class AuthorManager {

    public void addAuthor(Scanner scanner) {
        System.out.println("Enter author name:");
        String name = scanner.nextLine();
        System.out.println("Enter author biography:");
        String biography = scanner.nextLine();

        String query = "INSERT INTO Author (name, biography) VALUES (?, ?)";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, name);
            stmt.setString(2, biography);
            stmt.executeUpdate();
            System.out.println("Author added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewAuthor(Scanner scanner) {
        System.out.println("Enter author ID to view:");
        int authorId = scanner.nextInt();

        String query = "SELECT * FROM Author WHERE author_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, authorId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Author ID: " + rs.getInt("author_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Biography: " + rs.getString("biography"));
            } else {
                System.out.println("Author not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateAuthor(Scanner scanner) {
        System.out.println("Enter author ID to update:");
        int authorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.println("Enter new name:");
        String name = scanner.nextLine();
        System.out.println("Enter new biography:");
        String biography = scanner.nextLine();

        String query = "UPDATE Author SET name = ?, biography = ? WHERE author_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, name);
            stmt.setString(2, biography);
            stmt.setInt(3, authorId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Author updated successfully.");
            } else {
                System.out.println("Author not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteAuthor(Scanner scanner) {
        System.out.println("Enter author ID to delete:");
        int authorId = scanner.nextInt();

        String query = "DELETE FROM Author WHERE author_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, authorId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Author deleted successfully.");
            } else {
                System.out.println("Author not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

