package LibraryManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Scanner;

public class BorrowingManager {

    public void issueBook(Scanner scanner) {
        System.out.println("Enter member ID:");
        int memberId = scanner.nextInt();
        System.out.println("Enter book ID:");
        int bookId = scanner.nextInt();

        // Check if book is available
        String checkQuery = "SELECT quantity_available FROM Book WHERE book_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {

            checkStmt.setInt(1, bookId);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next()) {
                int quantityAvailable = rs.getInt("quantity_available");
                if (quantityAvailable > 0) {
                    // Issue book
                    String insertQuery = "INSERT INTO BorrowingHistory (book_id, member_id, issue_date) VALUES (?, ?, ?)";
                    try (PreparedStatement insertStmt = conn.prepareStatement(insertQuery)) {
                        insertStmt.setInt(1, bookId);
                        insertStmt.setInt(2, memberId);
                        insertStmt.setDate(3, new java.sql.Date(new Date().getTime()));
                        insertStmt.executeUpdate();
                        System.out.println("Book issued successfully.");

                        // Update quantity
                        String updateQuery = "UPDATE Book SET quantity_available = ? WHERE book_id = ?";
                        try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {
                            updateStmt.setInt(1, quantityAvailable - 1);
                            updateStmt.setInt(2, bookId);
                            updateStmt.executeUpdate();
                        }
                    }
                } else {
                    System.out.println("Book not available.");
                }
            } else {
                System.out.println("Book not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void returnBook(Scanner scanner) {
        System.out.println("Enter member ID:");
        int memberId = scanner.nextInt();
        System.out.println("Enter book ID:");
        int bookId = scanner.nextInt();

        // Check if the book was borrowed by the member
        String checkQuery = "SELECT * FROM BorrowingHistory WHERE book_id = ? AND member_id = ? AND return_date IS NULL";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement checkStmt = conn.prepareStatement(checkQuery)) {

            checkStmt.setInt(1, bookId);
            checkStmt.setInt(2, memberId);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next()) {
                // Return book
                String updateQuery = "UPDATE BorrowingHistory SET return_date = ? WHERE book_id = ? AND member_id = ?";
                try (PreparedStatement updateStmt = conn.prepareStatement(updateQuery)) {
                    updateStmt.setDate(1, new java.sql.Date(new Date().getTime()));
                    updateStmt.setInt(2, bookId);
                    updateStmt.setInt(3, memberId);
                    updateStmt.executeUpdate();
                    System.out.println("Book returned successfully.");

                    // Update quantity
                    String updateBookQuery = "UPDATE Book SET quantity_available = quantity_available + 1 WHERE book_id = ?";
                    try (PreparedStatement updateBookStmt = conn.prepareStatement(updateBookQuery)) {
                        updateBookStmt.setInt(1, bookId);
                        updateBookStmt.executeUpdate();
                    }
                }
            } else {
                System.out.println("No borrowing record found for this book and member.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewBorrowingHistory(Scanner scanner) {
        System.out.println("Enter member ID to view borrowing history:");
        int memberId = scanner.nextInt();

        String query = "SELECT * FROM BorrowingHistory WHERE member_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, memberId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                System.out.println("Borrowing ID: " + rs.getInt("borrowing_id"));
                System.out.println("Book ID: " + rs.getInt("book_id"));
                System.out.println("Issue Date: " + rs.getDate("issue_date"));
                System.out.println("Return Date: " + rs.getDate("return_date"));
                System.out.println("----------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
