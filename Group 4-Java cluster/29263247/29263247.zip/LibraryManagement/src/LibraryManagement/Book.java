package LibraryManagement;
	public class Book {
	    private int bookId;
	    private String title;
	    private int authorId;
	    private String isbn;
	    private int quantityAvailable;

	    public Book(int bookId, String title, int authorId, String isbn, int quantityAvailable) {
	        this.bookId = bookId;
	        this.title = title;
	        this.authorId = authorId;
	        this.isbn = isbn;
	        this.quantityAvailable = quantityAvailable;
	    }

	    // Getters and setters
	    public int getBookId() {
	        return bookId;
	    }

	    public void setBookId(int bookId) {
	        this.bookId = bookId;
	    }

	    public String getTitle() {
	        return title;
	    }

	    public void setTitle(String title) {
	        this.title = title;
	    }

	    public int getAuthorId() {
	        return authorId;
	    }

	    public void setAuthorId(int authorId) {
	        this.authorId = authorId;
	    }

	    public String getIsbn() {
	        return isbn;
	    }

	    public void setIsbn(String isbn) {
	        this.isbn = isbn;
	    }

	    public int getQuantityAvailable() {
	        return quantityAvailable;
	    }

	    public void setQuantityAvailable(int quantityAvailable) {
	        this.quantityAvailable = quantityAvailable;
	    }
	}

