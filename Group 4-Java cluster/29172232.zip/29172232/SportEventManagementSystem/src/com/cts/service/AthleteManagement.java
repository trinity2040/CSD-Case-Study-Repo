package com.cts.service;

import com.cts.domain.Athlete;
import com.cts.customException.AthleteNotFoundException;  // Import the custom exception
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class AthleteManagement {
    private AthleteDAO athleteDAO;
    private Scanner scanner;

    public AthleteManagement(AthleteDAO athleteDAO) {
        this.athleteDAO = athleteDAO;
        this.scanner = new Scanner(System.in);  // Initialize the scanner here
    }

    public void addAthlete() {
        System.out.println("Enter athlete ID:");
        int athleteId = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.println("Enter athlete name:");
        String name = scanner.nextLine();
        System.out.println("Enter athlete country:");
        String country = scanner.nextLine();
        System.out.println("Enter athlete age:");
        int age = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.println("Enter athlete sport:");
        String sport = scanner.nextLine();

        Athlete athlete = new Athlete();
        athlete.setAthleteId(athleteId);
        athlete.setName(name);
        athlete.setCountry(country);
        athlete.setAge(age);
        athlete.setSport(sport);

        try {
            athleteDAO.addAthlete(athlete);
            System.out.println("Athlete added successfully.");
        } catch (SQLException e) {
            System.out.println("Error adding athlete: " + e.getMessage());
        }
    }

    public void viewAthlete() {
        System.out.println("Enter athlete ID to view:");
        int athleteId = scanner.nextInt();

        try {
            Athlete athlete = athleteDAO.getAthlete(athleteId);
            System.out.println("Athlete ID: " + athlete.getAthleteId());
            System.out.println("Name: " + athlete.getName());
            System.out.println("Country: " + athlete.getCountry());
            System.out.println("Age: " + athlete.getAge());
            System.out.println("Sport: " + athlete.getSport());
        } catch (AthleteNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (SQLException e) {
            System.out.println("Error retrieving athlete: " + e.getMessage());
        }
    }

    public void updateAthlete() {
        System.out.println("Enter athlete ID to update:");
        int athleteId = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.println("Enter new name:");
        String name = scanner.nextLine();
        System.out.println("Enter new country:");
        String country = scanner.nextLine();
        System.out.println("Enter new age:");
        int age = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.println("Enter new sport:");
        String sport = scanner.nextLine();

        Athlete athlete = new Athlete();
        athlete.setAthleteId(athleteId);
        athlete.setName(name);
        athlete.setCountry(country);
        athlete.setAge(age);
        athlete.setSport(sport);

        try {
            athleteDAO.updateAthlete(athlete);
            System.out.println("Athlete updated successfully.");
        } catch (SQLException e) {
            System.out.println("Error updating athlete: " + e.getMessage());
        }
    }

    public void deleteAthlete() {
        System.out.println("Enter athlete ID to delete:");
        int athleteId = scanner.nextInt();

        try {
            athleteDAO.deleteAthlete(athleteId);
            System.out.println("Athlete deleted successfully.");
        } catch (SQLException e) {
            System.out.println("Error deleting athlete: " + e.getMessage());
        }
    }

    public void viewAllAthletes() {
        try {
            List<Athlete> athletes = athleteDAO.getAllAthletes();
            if (athletes != null && !athletes.isEmpty()) {
                for (Athlete athlete : athletes) {
                    System.out.println("Athlete ID: " + athlete.getAthleteId());
                    System.out.println("Name: " + athlete.getName());
                    System.out.println("Country: " + athlete.getCountry());
                    System.out.println("Age: " + athlete.getAge());
                    System.out.println("Sport: " + athlete.getSport());
                    System.out.println("-------------------");
                }
            } else {
                System.out.println("No athletes found.");
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving athletes: " + e.getMessage());
        }
    }

    // Method to close the scanner when done
    public void close() {
        if (scanner != null) {
            scanner.close();
        }
    }
}
