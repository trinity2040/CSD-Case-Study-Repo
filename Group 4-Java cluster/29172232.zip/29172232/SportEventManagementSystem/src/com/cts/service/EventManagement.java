package com.cts.service;

import java.text.SimpleDateFormat;
import java.util.Scanner;

import com.cts.domain.Event;

public class EventManagement {
    private EventDAO eventDAO;
    private Scanner scanner;

    public EventManagement(EventDAO eventDAO) {
        this.eventDAO = eventDAO;
        this.scanner = new Scanner(System.in);  // Initialize the scanner here
    }

    public void addEvent() {
        System.out.println("Enter event ID:");
        int eventId = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.println("Enter event name:");
        String name = scanner.nextLine();
        System.out.println("Enter event date (yyyy-MM-dd):");
        String dateStr = scanner.nextLine();
        System.out.println("Enter event venue:");
        String venue = scanner.nextLine();
        System.out.println("Enter event type:");
        String type = scanner.nextLine();

        java.util.Date date;
        try {
            date = new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
        } catch (Exception e) {
            System.out.println("Invalid date format.");
            return;
        }

        Event event = new Event();
        event.setEventId(eventId);
        event.setName(name);
        event.setDate(date);
        event.setVenue(venue);
        event.setType(type);

        try {
            eventDAO.addEvent(event);
            System.out.println("Event added successfully.");
        } catch (Exception e) {
            System.out.println("Error adding event: " + e.getMessage());
        }
    }

    public void viewEvent() {
        System.out.println("Enter event ID to view:");
        int eventId = scanner.nextInt();

        try {
            Event event = eventDAO.getEvent(eventId);
            if (event != null) {
                System.out.println("Event ID: " + event.getEventId());
                System.out.println("Name: " + event.getName());
                System.out.println("Date: " + new SimpleDateFormat("yyyy-MM-dd").format(event.getDate()));
                System.out.println("Venue: " + event.getVenue());
                System.out.println("Type: " + event.getType());
            } else {
                System.out.println("Event not found.");
            }
        } catch (Exception e) {
            System.out.println("Error retrieving event: " + e.getMessage());
        }
    }

    public void updateEvent() {
        System.out.println("Enter event ID to update:");
        int eventId = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.println("Enter new event name:");
        String name = scanner.nextLine();
        System.out.println("Enter new event date (yyyy-MM-dd):");
        String dateStr = scanner.nextLine();
        System.out.println("Enter new event venue:");
        String venue = scanner.nextLine();
        System.out.println("Enter new event type:");
        String type = scanner.nextLine();

        java.util.Date date;
        try {
            date = new SimpleDateFormat("yyyy-MM-dd").parse(dateStr);
        } catch (Exception e) {
            System.out.println("Invalid date format.");
            return;
        }

        Event event = new Event();
        event.setEventId(eventId);
        event.setName(name);
        event.setDate(date);
        event.setVenue(venue);
        event.setType(type);

        try {
            eventDAO.updateEvent(event);
            System.out.println("Event updated successfully.");
        } catch (Exception e) {
            System.out.println("Error updating event: " + e.getMessage());
        }
    }

    public void deleteEvent() {
        System.out.println("Enter event ID to delete:");
        int eventId = scanner.nextInt();

        try {
            eventDAO.deleteEvent(eventId);
            System.out.println("Event deleted successfully.");
        } catch (Exception e) {
            System.out.println("Error deleting event: " + e.getMessage());
        }
    }

    // Method to close the scanner when done
    public void close() {
        if (scanner != null) {
            scanner.close();
        }
    }
}
