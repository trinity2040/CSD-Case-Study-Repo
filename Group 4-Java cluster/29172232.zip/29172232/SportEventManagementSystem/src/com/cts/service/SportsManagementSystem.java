package com.cts.service;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;
import Databaseutil.DatabaseConnection;
import com.cts.customException.DatabaseCustomException; // Correct package

public class SportsManagementSystem {

    private static Connection connection;
    private static Scanner scanner;

    public static void main(String[] args) {
        try {
            // Establish database connection
            connection = DatabaseConnection.getConnection();

            // Initialize DAOs and management classes
            AthleteDAO athleteDAO = new AthleteDAOImpl(connection);
            AthleteManagement athleteManagement = new AthleteManagement(athleteDAO);

            EventDAO eventDAO = new EventDAOImpl(connection);
            EventManagement eventManagement = new EventManagement(eventDAO);

            ResultDAO resultDAO = new ResultDAOImpl(connection);
            ResultManagement resultManagement = new ResultManagement(resultDAO);

            scanner = new Scanner(System.in);
            while (true) {
                System.out.println("\n--- Sports Management System ---");
                System.out.println("1. Athlete Management");
                System.out.println("2. Event Management");
                System.out.println("3. Result Management");
                System.out.println("4. Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        handleAthleteManagement(athleteManagement);
                        break;
                    case 2:
                        handleEventManagement(eventManagement);
                        break;
                    case 3:
                        handleResultManagement(resultManagement);
                        break;
                    case 4:
                        System.out.println("Exiting...");
                        // Properly handle closing the connection
                        try {
                            if (connection != null && !connection.isClosed()) {
                                connection.close();
                            }
                        } catch (SQLException e) {
                            System.out.println("Error closing the database connection: " + e.getMessage());
                        }
                        // Close the scanner
                        if (scanner != null) {
                            scanner.close();
                        }
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (DatabaseCustomException e) {
            System.out.println("Error connecting to database: " + e.getMessage());
            e.printStackTrace();  // Optional: Print stack trace for debugging
        }
    }

    private static void handleAthleteManagement(AthleteManagement athleteManagement) {
        while (true) {
            System.out.println("\n--- Athlete Management ---");
            System.out.println("1. Add Athlete");
            System.out.println("2. View Athlete");
            System.out.println("3. Update Athlete");
            System.out.println("4. Delete Athlete");
            System.out.println("5. Return to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    athleteManagement.addAthlete();
                    break;
                case 2:
                    athleteManagement.viewAthlete();
                    break;
                case 3:
                    athleteManagement.updateAthlete();
                    break;
                case 4:
                    athleteManagement.deleteAthlete();
                    break;
                case 5:
                    return;  // Return to main menu
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void handleEventManagement(EventManagement eventManagement) {
        while (true) {
            System.out.println("\n--- Event Management ---");
            System.out.println("1. Add Event");
            System.out.println("2. View Event");
            System.out.println("3. Update Event");
            System.out.println("4. Delete Event");
            System.out.println("5. Return to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    eventManagement.addEvent();
                    break;
                case 2:
                    eventManagement.viewEvent();
                    break;
                case 3:
                    eventManagement.updateEvent();
                    break;
                case 4:
                    eventManagement.deleteEvent();
                    break;
                case 5:
                    return;  // Return to main menu
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void handleResultManagement(ResultManagement resultManagement) {
        while (true) {
            System.out.println("\n--- Result Management ---");
            System.out.println("1. Add Result");
            System.out.println("2. View Result");
            System.out.println("3. Update Result");
            System.out.println("4. Delete Result");
            System.out.println("5. Return to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    resultManagement.addResult();
                    break;
                case 2:
                    resultManagement.viewResult();
                    break;
                case 3:
                    resultManagement.updateResult();
                    break;
                case 4:
                    resultManagement.deleteResult();
                    break;
                case 5:
                    return;  // Return to main menu
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}

