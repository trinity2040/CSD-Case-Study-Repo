package com.cts.service;

import java.sql.SQLException;
import java.util.List;

import com.cts.domain.Event;

public interface EventDAO {
    void addEvent(Event event) throws SQLException;
    Event getEvent(int eventId) throws SQLException;
    List<Event> getAllEvents() throws SQLException;
    void updateEvent(Event event) throws SQLException;
    void deleteEvent(int eventId) throws SQLException;
}

