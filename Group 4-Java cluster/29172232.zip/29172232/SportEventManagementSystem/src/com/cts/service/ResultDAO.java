package com.cts.service;

import java.sql.SQLException;

import com.cts.domain.Result;

public interface ResultDAO {
    void addResult(Result result) throws SQLException;
    Result getResult(int resultId) throws SQLException;
    void updateResult(Result result) throws SQLException;
    void deleteResult(int resultId) throws SQLException;
}
