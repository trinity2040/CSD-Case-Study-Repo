package com.cts.service;

import java.sql.SQLException;
import java.util.List;

import com.cts.domain.Athlete;

public interface AthleteDAO {
    void addAthlete(Athlete athlete) throws SQLException;
    Athlete getAthlete(int athleteId) throws SQLException;
    List<Athlete> getAllAthletes() throws SQLException;
    void updateAthlete(Athlete athlete) throws SQLException;
    void deleteAthlete(int athleteId) throws SQLException;
}

