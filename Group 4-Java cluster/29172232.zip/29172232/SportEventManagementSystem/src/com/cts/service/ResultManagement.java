package com.cts.service;

import java.text.SimpleDateFormat;
import java.util.Scanner;
import com.cts.domain.Result;
  // Ensure the correct package for ResultDAO

public class ResultManagement {
    private ResultDAO resultDAO;
    private Scanner scanner;

    public ResultManagement(ResultDAO resultDAO) {
        this.resultDAO = resultDAO;
        this.scanner = new Scanner(System.in);  // Initialize the scanner here
    }

    public void addResult() {
        System.out.println("Enter result ID:");
        int resultId = scanner.nextInt();
        System.out.println("Enter event ID:");
        int eventId = scanner.nextInt();
        System.out.println("Enter athlete ID:");
        int athleteId = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.println("Enter result:");
        String result = scanner.nextLine();
        System.out.println("Enter result date (yyyy-MM-dd):");
        String resultDateStr = scanner.nextLine();
        java.util.Date resultDate;
        try {
            resultDate = new SimpleDateFormat("yyyy-MM-dd").parse(resultDateStr);
        } catch (Exception e) {
            System.out.println("Invalid date format.");
            return;
        }

        Result resultObj = new Result();
        resultObj.setResultId(resultId);
        resultObj.setEventId(eventId);
        resultObj.setAthleteId(athleteId);
        resultObj.setResult(result);
        resultObj.setResultDate(resultDate);

        try {
            resultDAO.addResult(resultObj);
            System.out.println("Result added successfully.");
        } catch (Exception e) {
            System.out.println("Error adding result: " + e.getMessage());
        }
    }

    public void viewResult() {
        System.out.println("Enter result ID to view:");
        int id = scanner.nextInt();

        try {
            Result result = resultDAO.getResult(id);
            if (result != null) {
                System.out.println("Result ID: " + result.getResultId());
                System.out.println("Event ID: " + result.getEventId());
                System.out.println("Athlete ID: " + result.getAthleteId());
                System.out.println("Result: " + result.getResult());
                System.out.println("Result Date: " + new SimpleDateFormat("yyyy-MM-dd").format(result.getResultDate()));
            } else {
                System.out.println("Result not found.");
            }
        } catch (Exception e) {
            System.out.println("Error retrieving result: " + e.getMessage());
        }
    }

    public void updateResult() {
        System.out.println("Enter result ID to update:");
        int id = scanner.nextInt();
        System.out.println("Enter new event ID:");
        int eventId = scanner.nextInt();
        System.out.println("Enter new athlete ID:");
        int athleteId = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.println("Enter new result:");
        String result = scanner.nextLine();
        System.out.println("Enter new result date (yyyy-MM-dd):");
        String resultDateStr = scanner.nextLine();
        java.util.Date resultDate;
        try {
            resultDate = new SimpleDateFormat("yyyy-MM-dd").parse(resultDateStr);
        } catch (Exception e) {
            System.out.println("Invalid date format.");
            return;
        }

        Result resultObj = new Result();
        resultObj.setResultId(id);
        resultObj.setEventId(eventId);
        resultObj.setAthleteId(athleteId);
        resultObj.setResult(result);
        resultObj.setResultDate(resultDate);

        try {
            resultDAO.updateResult(resultObj);
            System.out.println("Result updated successfully.");
        } catch (Exception e) {
            System.out.println("Error updating result: " + e.getMessage());
        }
    }

    public void deleteResult() {
        System.out.println("Enter result ID to delete:");
        int id = scanner.nextInt();

        try {
            resultDAO.deleteResult(id);
            System.out.println("Result deleted successfully.");
        } catch (Exception e) {
            System.out.println("Error deleting result: " + e.getMessage());
        }
    }

    // Method to close the scanner when done
    public void close() {
        if (scanner != null) {
            scanner.close();
        }
    }
}
