package com.cts.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cts.domain.Result;

public class ResultDAOImpl implements ResultDAO {
    private Connection connection;

    public ResultDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void addResult(Result result) throws SQLException {
        String query = "INSERT INTO Result (result_id, event_id, athlete_id, result, result_date) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, result.getResultId());
            stmt.setInt(2, result.getEventId());
            stmt.setInt(3, result.getAthleteId());
            stmt.setString(4, result.getResult());
            stmt.setDate(5, new java.sql.Date(result.getResultDate().getTime()));
            stmt.executeUpdate();
        }
    }

    @Override
    public Result getResult(int resultId) throws SQLException {
        String query = "SELECT * FROM Result WHERE result_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, resultId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Result result = new Result();
                    result.setResultId(rs.getInt("result_id"));
                    result.setEventId(rs.getInt("event_id"));
                    result.setAthleteId(rs.getInt("athlete_id"));
                    result.setResult(rs.getString("result"));
                    result.setResultDate(rs.getDate("result_date"));
                    return result;
                }
            }
        }
        return null;
    }

    @Override
    public void updateResult(Result result) throws SQLException {
        String query = "UPDATE Result SET event_id = ?, athlete_id = ?, result = ?, result_date = ? WHERE result_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, result.getEventId());
            stmt.setInt(2, result.getAthleteId());
            stmt.setString(3, result.getResult());
            stmt.setDate(4, new java.sql.Date(result.getResultDate().getTime()));
            stmt.setInt(5, result.getResultId());
            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteResult(int resultId) throws SQLException {
        String query = "DELETE FROM Result WHERE result_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, resultId);
            stmt.executeUpdate();
        }
    }
}
