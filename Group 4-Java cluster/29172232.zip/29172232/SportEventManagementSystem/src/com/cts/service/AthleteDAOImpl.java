package com.cts.service;

import com.cts.domain.Athlete;
import com.cts.customException.AthleteNotFoundException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AthleteDAOImpl implements AthleteDAO {
    private Connection connection;

    public AthleteDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void addAthlete(Athlete athlete) throws SQLException {
        String query = "INSERT INTO Athlete (athlete_id, name, country, age, sport) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, athlete.getAthleteId());
            stmt.setString(2, athlete.getName());
            stmt.setString(3, athlete.getCountry());
            stmt.setInt(4, athlete.getAge());
            stmt.setString(5, athlete.getSport());
            stmt.executeUpdate();
        }
    }

    @Override
    public Athlete getAthlete(int athleteId) throws SQLException {
        String query = "SELECT * FROM Athlete WHERE athlete_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, athleteId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    Athlete athlete = new Athlete();
                    athlete.setAthleteId(rs.getInt("athlete_id"));
                    athlete.setName(rs.getString("name"));
                    athlete.setCountry(rs.getString("country"));
                    athlete.setAge(rs.getInt("age"));
                    athlete.setSport(rs.getString("sport"));
                    return athlete;
                } else {
                    throw new AthleteNotFoundException("Athlete with ID " + athleteId + " not found.");
                }
            }
        }
    }

    @Override
    public List<Athlete> getAllAthletes() throws SQLException {
        List<Athlete> athletes = new ArrayList<>();
        String query = "SELECT * FROM Athlete";
        try (PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Athlete athlete = new Athlete();
                athlete.setAthleteId(rs.getInt("athlete_id"));
                athlete.setName(rs.getString("name"));
                athlete.setCountry(rs.getString("country"));
                athlete.setAge(rs.getInt("age"));
                athlete.setSport(rs.getString("sport"));
                athletes.add(athlete);
            }
        }
        return athletes;
    }

    @Override
    public void updateAthlete(Athlete athlete) throws SQLException {
        String query = "UPDATE Athlete SET name = ?, country = ?, age = ?, sport = ? WHERE athlete_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, athlete.getName());
            stmt.setString(2, athlete.getCountry());
            stmt.setInt(3, athlete.getAge());
            stmt.setString(4, athlete.getSport());
            stmt.setInt(5, athlete.getAthleteId());
            stmt.executeUpdate();
        }
    }

    @Override
    public void deleteAthlete(int athleteId) throws SQLException {
        String query = "DELETE FROM Athlete WHERE athlete_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, athleteId);
            stmt.executeUpdate();
        }
    }
}
