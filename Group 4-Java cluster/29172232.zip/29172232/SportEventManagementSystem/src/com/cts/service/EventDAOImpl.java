package com.cts.service;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.cts.domain.Event;

public class EventDAOImpl implements EventDAO {
    private Connection connection;

    public EventDAOImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public void addEvent(Event event) throws SQLException {
        String sql = "INSERT INTO Event (event_id, name, date, venue, type) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, event.getEventId());
        statement.setString(2, event.getName());
        statement.setDate(3, new java.sql.Date(event.getDate().getTime()));
        statement.setString(4, event.getVenue());
        statement.setString(5, event.getType());
        statement.executeUpdate();
    }

    @Override
    public Event getEvent(int eventId) throws SQLException {
        String sql = "SELECT * FROM Event WHERE event_id = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, eventId);
        ResultSet resultSet = statement.executeQuery();
        
        if (resultSet.next()) {
            Event event = new Event();
            event.setEventId(resultSet.getInt("event_id"));
            event.setName(resultSet.getString("name"));
            event.setDate(resultSet.getDate("date"));
            event.setVenue(resultSet.getString("venue"));
            event.setType(resultSet.getString("type"));
            return event;
        } else {
            return null;
        }
    }

    @Override
    public List<Event> getAllEvents() throws SQLException {
        List<Event> events = new ArrayList<>();
        String sql = "SELECT * FROM Event";
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(sql);
        
        while (resultSet.next()) {
            Event event = new Event();
            event.setEventId(resultSet.getInt("event_id"));
            event.setName(resultSet.getString("name"));
            event.setDate(resultSet.getDate("date"));
            event.setVenue(resultSet.getString("venue"));
            event.setType(resultSet.getString("type"));
            events.add(event);
        }
        
        return events;
    }

    @Override
    public void updateEvent(Event event) throws SQLException {
        String sql = "UPDATE Event SET name = ?, date = ?, venue = ?, type = ? WHERE event_id = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setString(1, event.getName());
        statement.setDate(2, new java.sql.Date(event.getDate().getTime()));
        statement.setString(3, event.getVenue());
        statement.setString(4, event.getType());
        statement.setInt(5, event.getEventId());
        statement.executeUpdate();
    }

    @Override
    public void deleteEvent(int eventId) throws SQLException {
        String sql = "DELETE FROM Event WHERE event_id = ?";
        PreparedStatement statement = connection.prepareStatement(sql);
        statement.setInt(1, eventId);
        statement.executeUpdate();
    }
}
