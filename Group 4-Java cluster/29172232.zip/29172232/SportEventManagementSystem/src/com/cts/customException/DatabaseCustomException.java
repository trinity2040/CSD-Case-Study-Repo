package com.cts.customException;

public class DatabaseCustomException extends Exception {
    private static final long serialVersionUID = 1L; // Unique ID for serialization

    public DatabaseCustomException(String message) {
        super(message);
    }

    public DatabaseCustomException(String message, Throwable cause) {
        super(message, cause);
    }
}
