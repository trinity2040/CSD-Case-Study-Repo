package com.cts.customException;

import java.io.Serializable;

public class AthleteNotFoundException extends RuntimeException implements Serializable {

    private static final long serialVersionUID = 1L;

    public AthleteNotFoundException(String message) {
        super("\033[0;31m" + message + "\033[0m"); // Set message to red
    }

    public AthleteNotFoundException(String message, Throwable cause) {
        super("\033[0;31m" + message + "\033[0m", cause); // Set message to red with cause
    }
}


