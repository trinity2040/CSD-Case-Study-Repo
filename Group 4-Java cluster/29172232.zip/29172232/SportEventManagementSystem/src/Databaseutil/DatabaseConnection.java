package Databaseutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import com.cts.customException.DatabaseCustomException; // Correct package

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3307/Sports_management";
    private static final String USER = "root";
    private static final String PASSWORD = "Dharsh@21";

    public static Connection getConnection() throws DatabaseCustomException {
        try {
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            throw new DatabaseCustomException("Failed to establish a database connection.", e);
        }
    }
}




