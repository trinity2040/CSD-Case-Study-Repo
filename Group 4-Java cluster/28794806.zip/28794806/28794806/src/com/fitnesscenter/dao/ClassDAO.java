package com.fitnesscenter.dao;

import com.fitnesscenter.models.FitnessClass;
import java.sql.*;

public class ClassDAO {
    private Connection connection;

    public ClassDAO(Connection connection) {
        this.connection = connection;
    }

    public void addClass(FitnessClass fitnessClass) throws SQLException {
        String query = "INSERT INTO Class (trainer_id, class_name, schedule, capacity, status) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, fitnessClass.getTrainerId());
            stmt.setString(2, fitnessClass.getClassName());
            stmt.setTimestamp(3, Timestamp.valueOf(fitnessClass.getSchedule()));
            stmt.setInt(4, fitnessClass.getCapacity());
            stmt.setString(5, fitnessClass.getStatus());
            stmt.executeUpdate();
        }
    }

    public FitnessClass getClass(int classId) throws SQLException {
        String query = "SELECT * FROM Class WHERE class_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, classId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new FitnessClass(rs.getInt("class_id"), rs.getInt("trainer_id"), rs.getString("class_name"),
                        rs.getTimestamp("schedule").toLocalDateTime(), rs.getInt("capacity"),
                        rs.getString("status"));
            }
            return null;
        }
    }

    public void updateClass(FitnessClass fitnessClass) throws SQLException {
        String query = "UPDATE Class SET trainer_id = ?, class_name = ?, schedule = ?, capacity = ?, status = ? WHERE class_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, fitnessClass.getTrainerId());
            stmt.setString(2, fitnessClass.getClassName());
            stmt.setTimestamp(3, Timestamp.valueOf(fitnessClass.getSchedule()));
            stmt.setInt(4, fitnessClass.getCapacity());
            stmt.setString(5, fitnessClass.getStatus());
            stmt.setInt(6, fitnessClass.getClassId());
            stmt.executeUpdate();
        }
    }

    public void deleteClass(int classId) throws SQLException {
        String query = "DELETE FROM Class WHERE class_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, classId);
            stmt.executeUpdate();
        }
    }
}
