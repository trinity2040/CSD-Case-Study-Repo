package com.fitnesscenter.services;

import com.fitnesscenter.models.FitnessClass;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDateTime;

public class ClassService {
    private Connection connection;

    public ClassService(Connection connection) {
        this.connection = connection;
    }

    public void scheduleClass(FitnessClass fitnessClass) {
        String sql = "INSERT INTO class (trainer_id, class_name, schedule, capacity, status) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, fitnessClass.getTrainerId());
            stmt.setString(2, fitnessClass.getClassName());
            stmt.setObject(3, fitnessClass.getSchedule());
            stmt.setInt(4, fitnessClass.getCapacity());
            stmt.setString(5, fitnessClass.getStatus());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while scheduling class: " + e.getMessage());
        }
    }

    public void viewClass(int classId) {
        String sql = "SELECT * FROM class WHERE class_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, classId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    System.out.println("Class Details:");
                    System.out.println("Class ID: " + rs.getInt("class_id"));
                    System.out.println("Trainer ID: " + rs.getInt("trainer_id"));
                    System.out.println("Class Name: " + rs.getString("class_name"));
                    System.out.println("Schedule: " + rs.getObject("schedule", LocalDateTime.class));
                    System.out.println("Capacity: " + rs.getInt("capacity"));
                    System.out.println("Status: " + rs.getString("status"));
                } else {
                    System.out.println("No class found with ID: " + classId);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while viewing class: " + e.getMessage());
        }
    }

    public void updateClass(FitnessClass fitnessClass) {
        String sql = "UPDATE class SET trainer_id = ?, class_name = ?, schedule = ?, capacity = ?, status = ? WHERE class_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, fitnessClass.getTrainerId());
            stmt.setString(2, fitnessClass.getClassName());
            stmt.setObject(3, fitnessClass.getSchedule());
            stmt.setInt(4, fitnessClass.getCapacity());
            stmt.setString(5, fitnessClass.getStatus());
            stmt.setInt(6, fitnessClass.getClassId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while updating class: " + e.getMessage());
        }
    }

    public void cancelClass(int classId) {
        String sql = "UPDATE class SET status = 'cancelled' WHERE class_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, classId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while cancelling class: " + e.getMessage());
        }
    }
}
