package com.fitnesscenter.main;

import com.fitnesscenter.models.Member;
import com.fitnesscenter.models.Trainer;
import com.fitnesscenter.models.FitnessClass;
import com.fitnesscenter.services.MemberService;
import com.fitnesscenter.services.TrainerService;
import com.fitnesscenter.services.ClassService;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.Scanner;

public class FitnessCenterApp {

    private static Connection getConnection() throws SQLException {
        // Replace these placeholders with your actual database connection details
        String url = "jdbc:mysql://127.0.0.1:3306/fitness1";
        String username = "root";
        String password = "1009";
        return DriverManager.getConnection(url, username, password);
    }

    private static void showMemberMenu(MemberService memberService, Scanner scanner) {
        while (true) {
            System.out.println("Member Menu:");
            System.out.println("1. Register Member");
            System.out.println("2. View Member");
            System.out.println("3. Update Member");
            System.out.println("4. Delete Member");
            System.out.println("5. Back to Main Menu");
            System.out.print("Select an option: ");
            int option = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (option) {
                case 1:
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter email: ");
                    String email = scanner.nextLine();
                    System.out.print("Enter phone number: ");
                    String phoneNumber = scanner.nextLine();
                    System.out.print("Enter membership type: ");
                    String membershipType = scanner.nextLine();
                    Member member = new Member(0, name, email, phoneNumber, membershipType);
                    memberService.registerMember(member);
                    break;
                case 2:
                    System.out.print("Enter member ID: ");
                    int memberId = scanner.nextInt();
                    memberService.viewMember(memberId);
                    break;
                case 3:
                    System.out.print("Enter member ID: ");
                    memberId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter new name: ");
                    name = scanner.nextLine();
                    System.out.print("Enter new email: ");
                    email = scanner.nextLine();
                    System.out.print("Enter new phone number: ");
                    phoneNumber = scanner.nextLine();
                    System.out.print("Enter new membership type: ");
                    membershipType = scanner.nextLine();
                    member = new Member(memberId, name, email, phoneNumber, membershipType);
                    memberService.updateMember(member);
                    break;
                case 4:
                    System.out.print("Enter member ID: ");
                    memberId = scanner.nextInt();
                    memberService.deleteMember(memberId);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void showTrainerMenu(TrainerService trainerService, Scanner scanner) {
        while (true) {
            System.out.println("Trainer Menu:");
            System.out.println("1. Add Trainer");
            System.out.println("2. View Trainer");
            System.out.println("3. Update Trainer");
            System.out.println("4. Delete Trainer");
            System.out.println("5. Back to Main Menu");
            System.out.print("Select an option: ");
            int option = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (option) {
                case 1:
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter email: ");
                    String email = scanner.nextLine();
                    System.out.print("Enter phone number: ");
                    String phoneNumber = scanner.nextLine();
                    System.out.print("Enter specialization: ");
                    String specialization = scanner.nextLine();
                    Trainer trainer = new Trainer(0, name, email, phoneNumber, specialization);
                    trainerService.addTrainer(trainer);
                    break;
                case 2:
                    System.out.print("Enter trainer ID: ");
                    int trainerId = scanner.nextInt();
                    trainerService.viewTrainer(trainerId);
                    break;
                case 3:
                    System.out.print("Enter trainer ID: ");
                    trainerId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter new name: ");
                    name = scanner.nextLine();
                    System.out.print("Enter new email: ");
                    email = scanner.nextLine();
                    System.out.print("Enter new phone number: ");
                    phoneNumber = scanner.nextLine();
                    System.out.print("Enter new specialization: ");
                    specialization = scanner.nextLine();
                    trainer = new Trainer(trainerId, name, email, phoneNumber, specialization);
                    trainerService.updateTrainer(trainer);
                    break;
                case 4:
                    System.out.print("Enter trainer ID: ");
                    trainerId = scanner.nextInt();
                    trainerService.deleteTrainer(trainerId);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void showClassMenu(ClassService classService, Scanner scanner) {
        while (true) {
            System.out.println("Class Menu:");
            System.out.println("1. Schedule Class");
            System.out.println("2. View Class");
            System.out.println("3. Update Class");
            System.out.println("4. Cancel Class");
            System.out.println("5. Back to Main Menu");
            System.out.print("Select an option: ");
            int option = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (option) {
                case 1:
                    System.out.print("Enter trainer ID: ");
                    int trainerId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter class name: ");
                    String className = scanner.nextLine();
                    System.out.print("Enter schedule (yyyy-MM-ddTHH:mm): ");
                    String schedule = scanner.nextLine();
                    System.out.print("Enter capacity: ");
                    int capacity = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter status: ");
                    String status = scanner.nextLine();
                    FitnessClass fitnessClass = new FitnessClass(0, trainerId, className, LocalDateTime.parse(schedule), capacity, status);
                    classService.scheduleClass(fitnessClass);
                    break;
                case 2:
                    System.out.print("Enter class ID: ");
                    int classId = scanner.nextInt();
                    classService.viewClass(classId);
                    break;
                case 3:
                    System.out.print("Enter class ID: ");
                    classId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter new trainer ID: ");
                    trainerId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter new class name: ");
                    className = scanner.nextLine();
                    System.out.print("Enter new schedule (YYYY-MM-DD HH:MM:SS): ");
                    schedule = scanner.nextLine();
                    System.out.print("Enter new capacity: ");
                    capacity = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter new status: ");
                    status = scanner.nextLine();
                    fitnessClass = new FitnessClass(classId, trainerId, className, LocalDateTime.parse(schedule), capacity, status);
                    classService.updateClass(fitnessClass);
                    break;
                case 4:
                    System.out.print("Enter class ID: ");
                    classId = scanner.nextInt();
                    classService.cancelClass(classId);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    public static void main(String[] args) {
        try (Connection connection = getConnection()) {
            MemberService memberService = new MemberService(connection);
            TrainerService trainerService = new TrainerService(connection);
            ClassService classService = new ClassService(connection);

            Scanner scanner = new Scanner(System.in);
            boolean running = true;

            while (running) {
                System.out.println("Fitness Center Management System");
                System.out.println("1. Manage Members");
                System.out.println("2. Manage Trainers");
                System.out.println("3. Manage Classes");
                System.out.println("4. Exit");
                System.out.print("Select an option: ");
                int option = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (option) {
                    case 1:
                        showMemberMenu(memberService, scanner);
                        break;
                    case 2:
                        showTrainerMenu(trainerService, scanner);
                        break;
                    case 3:
                        showClassMenu(classService, scanner);
                        break;
                    case 4:
                        running = false;
                        break;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
