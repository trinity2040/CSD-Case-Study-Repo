CREATE DATABASE telecom_management;

USE telecom_management;

CREATE TABLE Customer (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100),
    email VARCHAR(100),
    contact_number VARCHAR(15),
    address TEXT
);

CREATE TABLE Service (
    service_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100),
    description TEXT,
    price DECIMAL(10, 2)
);

CREATE TABLE Subscription (
    subscription_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT,
    service_id INT,
    subscription_date DATE,
    status VARCHAR(10),
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id),
    FOREIGN KEY (service_id) REFERENCES Service(service_id)
);
SELECT * FROM Customer;
SELECT * FROM Service;
SELECT * FROM Subscription;

INSERT INTO Customer (customer_id,name, email, contact_number, address)
VALUES ('12345','John Doe', 'john.doe@example.com', '1234567890', '123 Main St');

INSERT INTO Service (service_id,name, description, price)
VALUES ('5678','Internet Plan', 'High-speed internet', 50.99);

INSERT INTO Subscription (subscription_id,customer_id, service_id, subscription_date, status)
VALUES (1,12345, 5678, CURDATE(), 'Active');