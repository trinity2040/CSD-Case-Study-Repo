package com.cts.telecommunication.model;

import com.cts.telecommunication.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ServiceManager {


    public void addService(String name, String description, double price) {
        String query = "INSERT INTO Service (name, description, price) VALUES (?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            // Set the parameters for the prepared statement
            statement.setString(1, name);
            statement.setString(2, description);
            statement.setDouble(3, price);
            // Execute the SQL insert operation
            statement.executeUpdate();
            System.out.println("Service added successfully.");
        } catch (SQLException e) {
            // Handle any SQL exceptions that occur during the operation
            System.out.println("Error adding service: " + e.getMessage());
        }
    }

    /**
     * Retrieves and displays a service from the Service table based on the service ID.
     *
     * @param serviceId The ID of the service to be retrieved.
     */
    public void viewService(int serviceId) {
        String query = "SELECT * FROM Service WHERE service_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            // Set the service ID parameter for the prepared statement
            statement.setInt(1, serviceId);
            // Execute the SQL query and get the result set
            ResultSet resultSet = statement.executeQuery();
            // Check if a service was found with the given ID
            if (resultSet.next()) {
                System.out.println("Service ID: " + resultSet.getInt("service_id"));
                System.out.println("Name: " + resultSet.getString("name"));
                System.out.println("Description: " + resultSet.getString("description"));
                System.out.println("Price: " + resultSet.getDouble("price"));
            } else {
                System.out.println("Service not found.");
            }
        } catch (SQLException e) {
            // Handle any SQL exceptions that occur during the operation
            System.out.println("Error retrieving service: " + e.getMessage());
        }
    }

    /**
     * Updates an existing service in the Service table based on the service ID.
     *
     * @param serviceId The ID of the service to be updated.
     * @param name The new name for the service.
     * @param description The new description for the service.
     * @param price The new price for the service.
     */
    public void updateService(int serviceId, String name, String description, double price) {
        String query = "UPDATE Service SET name = ?, description = ?, price = ? WHERE service_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            // Set the parameters for the prepared statement
            statement.setString(1, name);
            statement.setString(2, description);
            statement.setDouble(3, price);
            statement.setInt(4, serviceId);
            // Execute the SQL update operation
            int rowsUpdated = statement.executeUpdate();
            // Check if the service was successfully updated
            if (rowsUpdated > 0) {
                System.out.println("Service updated successfully.");
            } else {
                System.out.println("Service not found.");
            }
        } catch (SQLException e) {
            // Handle any SQL exceptions that occur during the operation
            System.out.println("Error updating service: " + e.getMessage());
        }
    }

    /**
     * Deletes a service from the Service table based on the service ID.
     *
     * @param serviceId The ID of the service to be deleted.
     */
    public void deleteService(int serviceId) {
        String query = "DELETE FROM Service WHERE service_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            // Set the service ID parameter for the prepared statement
            statement.setInt(1, serviceId);
            // Execute the SQL delete operation
            int rowsDeleted = statement.executeUpdate();
            // Check if the service was successfully deleted
            if (rowsDeleted > 0) {
                System.out.println("Service deleted successfully.");
            } else {
                System.out.println("Service not found.");
            }
        } catch (SQLException e) {
            // Handle any SQL exceptions that occur during the operation
            System.out.println("Error deleting service: " + e.getMessage());
        }
    }
}
