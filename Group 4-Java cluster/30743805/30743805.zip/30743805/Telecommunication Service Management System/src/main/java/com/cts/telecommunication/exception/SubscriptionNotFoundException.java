package com.cts.telecommunication.exception;


public class SubscriptionNotFoundException extends Exception {
    public SubscriptionNotFoundException(String message) {
        super(message);
    }
}
