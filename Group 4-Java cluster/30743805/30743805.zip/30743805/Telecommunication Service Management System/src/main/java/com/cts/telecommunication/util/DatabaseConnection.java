package com.cts.telecommunication.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    // Database URL including the host, port, and database name
    private static final String URL = "jdbc:mysql://localhost:3306/telecom_management";

    // Database user credentials
    private static final String USER = "root";
    private static final String PASSWORD = "Subramanyam@258";

    /**
     * Establishes a connection to the database.
     * @return A Connection object if successful; null if the connection fails.
     */
    public static Connection getConnection() {
        Connection connection = null;
        try {
            // Attempt to establish a connection to the database using the provided URL, username, and password
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            // Handle any SQL exceptions that occur during the connection attempt
            System.out.println("Error connecting to database: " + e.getMessage());
        }
        // Return the established connection, or null if the connection failed
        return connection;
    }
}
