package com.cts.telecommunication.service;

import com.cts.telecommunication.model.CustomerManager;
import com.cts.telecommunication.model.ServiceManager;
import com.cts.telecommunication.model.SubscriptionManager;

import java.util.Scanner;

public class MainMenu {

    // Instances of the managers to handle customer, service, and subscription operations.
    private static final CustomerManager customerManager = new CustomerManager();
    private static final ServiceManager serviceManager = new ServiceManager();
    private static final SubscriptionManager subscriptionManager = new SubscriptionManager();

    public static void main(String[] args) {
        // Scanner object to take user input.
        Scanner scanner = new Scanner(System.in);

        // Main loop to display the menu and handle user choices.
        while (true) {
            System.out.println("\nTelecommunication Service Management System");
            System.out.println("1. Manage Customers");
            System.out.println("2. Manage Services");
            System.out.println("3. Manage Subscriptions");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            // Switch statement to handle user input and call the appropriate management method.
            switch (choice) {
                case 1:
                    manageCustomers(scanner);  // Manage customer-related operations.
                    break;
                case 2:
                    manageServices(scanner);  // Manage service-related operations.
                    break;
                case 3:
                    manageSubscriptions(scanner);  // Manage subscription-related operations.
                    break;
                case 4:
                    System.out.println("Exiting... Goodbye!");
                    scanner.close();  // Close the scanner before exiting.
                    return;  // Exit the loop and terminate the program.
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }


    private static void manageCustomers(Scanner scanner) {
        System.out.println("\nCustomer Management");
        System.out.println("1. Add Customer");
        System.out.println("2. View Customer");
        System.out.println("3. Update Customer");
        System.out.println("4. Remove Customer");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline left by nextInt().

        switch (choice) {
            case 1:
                System.out.print("Enter name: ");
                String name = scanner.nextLine();
                System.out.print("Enter email: ");
                String email = scanner.nextLine();
                System.out.print("Enter contact number: ");
                String contactNumber = scanner.nextLine();
                System.out.print("Enter address: ");
                String address = scanner.nextLine();
                customerManager.addCustomer(name, email, contactNumber, address);  // Call to add a new customer.
                break;
            case 2:
                System.out.print("Enter Customer ID: ");
                int customerId = scanner.nextInt();
                customerManager.viewCustomer(customerId);  // Call to view customer details.
                break;
            case 3:
                System.out.print("Enter Customer ID: ");
                customerId = scanner.nextInt();
                scanner.nextLine();  // Consume newline.
                System.out.print("Enter new name: ");
                name = scanner.nextLine();
                System.out.print("Enter new email: ");
                email = scanner.nextLine();
                System.out.print("Enter new contact number: ");
                contactNumber = scanner.nextLine();
                System.out.print("Enter new address: ");
                address = scanner.nextLine();
                customerManager.updateCustomer(customerId, name, email, contactNumber, address);  // Call to update customer details.
                break;
            case 4:
                System.out.print("Enter Customer ID: ");
                customerId = scanner.nextInt();
                customerManager.deleteCustomer(customerId);  // Call to delete a customer.
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }


    private static void manageServices(Scanner scanner) {
        System.out.println("\nService Management");
        System.out.println("1. Add Service");
        System.out.println("2. View Service");
        System.out.println("3. Update Service");
        System.out.println("4. Remove Service");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline left by nextInt().

        switch (choice) {
            case 1:
                System.out.print("Enter service name: ");
                String name = scanner.nextLine();
                System.out.print("Enter service description: ");
                String description = scanner.nextLine();
                System.out.print("Enter service price: ");
                double price = scanner.nextDouble();
                serviceManager.addService(name, description, price);  // Call to add a new service.
                break;
            case 2:
                System.out.print("Enter Service ID: ");
                int serviceId = scanner.nextInt();
                serviceManager.viewService(serviceId);  // Call to view service details.
                break;
            case 3:
                System.out.print("Enter Service ID: ");
                serviceId = scanner.nextInt();
                scanner.nextLine();  // Consume newline.
                System.out.print("Enter new service name: ");
                name = scanner.nextLine();
                System.out.print("Enter new service description: ");
                description = scanner.nextLine();
                System.out.print("Enter new service price: ");
                price = scanner.nextDouble();
                serviceManager.updateService(serviceId, name, description, price);  // Call to update service details.
                break;
            case 4:
                System.out.print("Enter Service ID: ");
                serviceId = scanner.nextInt();
                serviceManager.deleteService(serviceId);  // Call to delete a service.
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    /**
     * Manages subscription-related operations such as adding, viewing, updating, and removing subscriptions.
     *
     * @param scanner The Scanner object used to read user input.
     */
    private static void manageSubscriptions(Scanner scanner) {
        System.out.println("\nSubscription Management");
        System.out.println("1. Add Subscription");
        System.out.println("2. View Subscription");
        System.out.println("3. Update Subscription");
        System.out.println("4. Remove Subscription");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                System.out.print("Enter Customer ID: ");
                int customerId = scanner.nextInt();
                System.out.print("Enter Service ID: ");
                int serviceId = scanner.nextInt();
                subscriptionManager.addSubscription(customerId, serviceId);  // Call to add a new subscription.
                break;
            case 2:
                System.out.print("Enter Subscription ID: ");
                int subscriptionId = scanner.nextInt();
                subscriptionManager.viewSubscription(subscriptionId);  // Call to view subscription details.
                break;
            case 3:
                System.out.print("Enter Subscription ID: ");
                subscriptionId = scanner.nextInt();
                scanner.nextLine();  // Consume newline.
                System.out.print("Enter new status (active/inactive): ");
                String status = scanner.nextLine();
                subscriptionManager.updateSubscription(subscriptionId, status);  // Call to update subscription status.
                break;
            case 4:
                System.out.print("Enter Subscription ID: ");
                subscriptionId = scanner.nextInt();
                subscriptionManager.deleteSubscription(subscriptionId);  // Call to delete a subscription.
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
}
