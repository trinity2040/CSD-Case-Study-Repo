package com.cts.telecommunication.model;

import com.cts.telecommunication.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class CustomerManager {

    /**
     * Adds a new customer to the database.
     * @param name The name of the customer.
     * @param email The email of the customer.
     * @param contactNumber The contact number of the customer.
     * @param address The address of the customer.
     */
    public void addCustomer(String name, String email, String contactNumber, String address) {
        // SQL query to insert a new customer into the Customer table
        String query = "INSERT INTO Customer (name, email, contact_number, address) VALUES (?, ?, ?, ?)";
        // Try-with-resources to ensure that resources are closed after use
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            // Set the parameters for the prepared statement
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, contactNumber);
            statement.setString(4, address);
            // Execute the update query to insert the customer
            statement.executeUpdate();
            System.out.println("Customer added successfully.");
        } catch (SQLException e) {
            // Handle any SQL exceptions that occur during the operation
            System.out.println("Error adding customer: " + e.getMessage());
        }
    }

    /**
     * Views the details of a customer based on their customer ID.
     * @param customerId The ID of the customer to view.
     */
    public void viewCustomer(int customerId) {
        // SQL query to select a customer from the Customer table based on customer_id
        String query = "SELECT * FROM Customer WHERE customer_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            // Set the customer ID parameter for the query
            statement.setInt(1, customerId);
            // Execute the query and get the result set
            ResultSet resultSet = statement.executeQuery();
            // If a customer is found, display their details
            if (resultSet.next()) {
                System.out.println("Customer ID: " + resultSet.getInt("customer_id"));
                System.out.println("Name: " + resultSet.getString("name"));
                System.out.println("Email: " + resultSet.getString("email"));
                System.out.println("Contact Number: " + resultSet.getString("contact_number"));
                System.out.println("Address: " + resultSet.getString("address"));
            } else {
                // If no customer is found with the given ID, display a message
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            // Handle any SQL exceptions that occur during the operation
            System.out.println("Error retrieving customer: " + e.getMessage());
        }
    }

    /**
     * Updates the details of an existing customer.
     * @param customerId The ID of the customer to update.
     * @param name The new name of the customer.
     * @param email The new email of the customer.
     * @param contactNumber The new contact number of the customer.
     * @param address The new address of the customer.
     */
    public void updateCustomer(int customerId, String name, String email, String contactNumber, String address) {
        // SQL query to update customer details in the Customer table
        String query = "UPDATE Customer SET name = ?, email = ?, contact_number = ?, address = ? WHERE customer_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            // Set the parameters for the update query
            statement.setString(1, name);
            statement.setString(2, email);
            statement.setString(3, contactNumber);
            statement.setString(4, address);
            statement.setInt(5, customerId);
            // Execute the update query and check how many rows were updated
            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Customer updated successfully.");
            } else {
                // If no rows were updated, it means the customer was not found
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            // Handle any SQL exceptions that occur during the operation
            System.out.println("Error updating customer: " + e.getMessage());
        }
    }

    /**
     * Deletes a customer from the database.
     * @param customerId The ID of the customer to delete.
     */
    public void deleteCustomer(int customerId) {
        // SQL query to delete a customer from the Customer table
        String query = "DELETE FROM Customer WHERE customer_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            // Set the customer ID parameter for the delete query
            statement.setInt(1, customerId);
            // Execute the delete query and check how many rows were deleted
            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Customer deleted successfully.");
            } else {
                // If no rows were deleted, it means the customer was not found
                System.out.println("Customer not found.");
            }
        } catch (SQLException e) {
            // Handle any SQL exceptions that occur during the operation
            System.out.println("Error deleting customer: " + e.getMessage());
        }
    }
}

