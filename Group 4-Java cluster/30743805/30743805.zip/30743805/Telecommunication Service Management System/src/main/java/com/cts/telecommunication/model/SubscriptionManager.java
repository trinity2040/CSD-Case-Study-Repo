package com.cts.telecommunication.model;

import com.cts.telecommunication.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SubscriptionManager {

    public void addSubscription(int customerId, int serviceId) {
        String query = "INSERT INTO Subscription (customer_id, service_id, subscription_date, status) VALUES (?, ?, NOW(), 'active')";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            // Set the customer ID and service ID parameters for the prepared statement
            statement.setInt(1, customerId);
            statement.setInt(2, serviceId);
            // Execute the SQL insert operation
            statement.executeUpdate();
            System.out.println("Subscription added successfully.");
        } catch (SQLException e) {
            // Handle any SQL exceptions that occur during the operation
            System.out.println("Error adding subscription: " + e.getMessage());
        }
    }


    public void viewSubscription(int subscriptionId) {
        String query = "SELECT * FROM Subscription WHERE subscription_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            // Set the subscription ID parameter for the prepared statement
            statement.setInt(1, subscriptionId);
            // Execute the SQL query and get the result set
            ResultSet resultSet = statement.executeQuery();
            // Check if a subscription was found with the given ID
            if (resultSet.next()) {
                System.out.println("Subscription ID: " + resultSet.getInt("subscription_id"));
                System.out.println("Customer ID: " + resultSet.getInt("customer_id"));
                System.out.println("Service ID: " + resultSet.getInt("service_id"));
                System.out.println("Subscription Date: " + resultSet.getDate("subscription_date"));
                System.out.println("Status: " + resultSet.getString("status"));
            } else {
                System.out.println("Subscription not found.");
            }
        } catch (SQLException e) {
            // Handle any SQL exceptions that occur during the operation
            System.out.println("Error retrieving subscription: " + e.getMessage());
        }
    }


    public void updateSubscription(int subscriptionId, String status) {
        String query = "UPDATE Subscription SET status = ? WHERE subscription_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            // Set the status and subscription ID parameters for the prepared statement
            statement.setString(1, status);
            statement.setInt(2, subscriptionId);
            // Execute the SQL update operation
            int rowsUpdated = statement.executeUpdate();
            // Check if the subscription was successfully updated
            if (rowsUpdated > 0) {
                System.out.println("Subscription updated successfully.");
            } else {
                System.out.println("Subscription not found.");
            }
        } catch (SQLException e) {
            // Handle any SQL exceptions that occur during the operation
            System.out.println("Error updating subscription: " + e.getMessage());
        }
    }

    /**
     * Deletes a subscription from the Subscription table based on the subscription ID.
     *
     * @param subscriptionId The ID of the subscription to be deleted.
     */
    public void deleteSubscription(int subscriptionId) {
        String query = "DELETE FROM Subscription WHERE subscription_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            // Set the subscription ID parameter for the prepared statement
            statement.setInt(1, subscriptionId);
            // Execute the SQL delete operation
            int rowsDeleted = statement.executeUpdate();
            // Check if the subscription was successfully deleted
            if (rowsDeleted > 0) {
                System.out.println("Subscription deleted successfully.");
            } else {
                System.out.println("Subscription not found.");
            }
        } catch (SQLException e) {
            // Handle any SQL exceptions that occur during the operation
            System.out.println("Error deleting subscription: " + e.getMessage());
        }
    }
}
