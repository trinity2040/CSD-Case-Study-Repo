
# Telecommunication Service Management System

## Overview

Developed a menu-based console application b using  Core Java, MySQL, and JDBC. The application will simulate a telecommunication service management system, allowing users to manage customers, services, and service subscriptions.


## Features

### 1.	Customer Management:
- Add new customers,View customer details , Update customer information ,Remove customers

### 2. Service Management:
- Add new services (e.g., mobile, internet, TV) , View service details , Update service information , Remove services
### 3. Subscription Management:
- Subscribe customers to services , View subscription details , Update subscription information , Remove subscriptions

## Project Structure

**`com.cts.telecommunication.model`**: Contains the data models with encapsulation.
**`com.cts.telecommunication.dao`**: Contains interfaces and implementations for database operations.
**`com.cts.telecommunication.service`**: Contains interfaces and implementations for business logic.
**`com.cts.telecommunication.util`**: Contains utility classes, such as the database connection.
**`com.cts.telecommunication.exception`**: Contains custom exception classes.





## Setup Instructions

### 1. Database Configuration

- Update the database credentials in `com/cts/telecommunication/DatabaseConnection.java` (for the source code) or `applications.properties.properties` (for the pre-built application):
  - Database URL
  - Username
  - Password

### 2. Running the Application

- Open the project in IntelliJ or your preferred IDE.
- Navigate to the main file located at `Telecommunication Service Management System`.
- Run the application.
- Ensure that MySQL is installed and running on your local machine.

### 3. Ensure Connector j will be add to intellij jar files

## External Libraries

The project requires the following external libraries:

- **JDK**: Version 22 (recommended) or later.
- **MySQL Connector**: Version 9 (recommended).

## Notes

- The application is designed to handle exceptions gracefully and provide user-friendly error messages.
- The code adheres to standard coding conventions and is thoroughly documented for clarity.

## Submission Details

This project has been uploaded to a public GitHub repository. The repository link is provided below:

**https://github.com/RajkumarTsbv299/CSD-Case-Study-Repo**

