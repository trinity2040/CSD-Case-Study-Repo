package com.cts.model;

import java.sql.Date;

public class Sample {
    private int sampleId;
    private String name;
    private int experimentId;
    private Date collectionDate;
    private String description;

    // Getters and Setters

    public int getSampleId() {
        return sampleId;
    }

    public void setSampleId(int sampleId) {
        this.sampleId = sampleId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getExperimentId() {
        return experimentId;
    }

    public void setExperimentId(int experimentId) {
        this.experimentId = experimentId;
    }

    public Date getCollectionDate() {
        return collectionDate;
    }

    public void setCollectionDate(Date collectionDate) {
        this.collectionDate = collectionDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public String toString() {
        return "Sample{" +
                "sampleId=" + sampleId +
                ", name='" + name + '\'' +
                ", experimentId=" + experimentId +
                ", collectionDate=" + collectionDate +
                ", description='" + description + '\'' +
                '}';
    }
}
