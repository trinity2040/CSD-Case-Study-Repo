package com.cts.dao;

import com.cts.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SampleDAO {

    //Add Sample
    public static void addSample(String name, int experimentId, Date collectionDate, String description) {
        String query = "INSERT INTO Sample (sample_name, experiment_id, collection_date, description) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setInt(2, experimentId);
            stmt.setDate(3, collectionDate);
            stmt.setString(4, description);
            stmt.executeUpdate();
            System.out.println("Sample added successfully.");
        } catch (SQLException e) {
            System.err.println("Error adding sample: " + e.getMessage());
        }
    }

    //View Sample
    public static void viewSample(int sampleId) {
        String query = "SELECT * FROM Sample WHERE sample_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, sampleId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Sample ID: " + rs.getInt("sample_id"));
                System.out.println("Name: " + rs.getString("sample_name"));
                System.out.println("Experiment ID: " + rs.getInt("experiment_id"));
                System.out.println("Collection Date: " + rs.getDate("collection_date"));
                System.out.println("Description: " + rs.getString("description"));
            } else {
                System.out.println("Sample not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error viewing sample: " + e.getMessage());
        }
    }

    //Update Sample
    public static void updateSample(int sampleId, String name, int experimentId, Date collectionDate, String description) {
        String query = "UPDATE Sample SET sample_name = ?, experiment_id = ?, collection_date = ?, description = ? WHERE sample_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setInt(2, experimentId);
            stmt.setDate(3, collectionDate);
            stmt.setString(4, description);
            stmt.setInt(5, sampleId);
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Sample updated successfully.");
            } else {
                System.out.println("Sample not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error updating sample: " + e.getMessage());
        }
    }

    //Delete Sample
    public static void deleteSample(int sampleId) {
        String query = "DELETE FROM Sample WHERE sample_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, sampleId);
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Sample deleted successfully.");
            } else {
                System.out.println("Sample not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error deleting sample: " + e.getMessage());
        }
    }
}
