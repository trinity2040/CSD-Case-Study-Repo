package com.cts.main;

import com.cts.dao.ExperimentDAO;
import com.cts.dao.ResearcherDAO;
import com.cts.dao.SampleDAO;
import com.cts.util.InputValidator;
import com.cts.exception.ValidationException;

import java.sql.Date;
import java.util.Scanner;

public class LIMSMenu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("------------------------------");
            System.out.println("Laboratory Information Management System");
            System.out.println("1. Manage Researchers");
            System.out.println("2. Manage Experiments");
            System.out.println("3. Manage Samples");
            System.out.println("4. Exit");
            System.out.println("------------------------------");
            System.out.print("Enter your choice: ");


            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    manageResearchers(scanner);
                    break;
                case 2:
                    manageExperiments(scanner);
                    break;
                case 3:
                    manageSamples(scanner);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    //Manage Researcher
    private static void manageResearchers(Scanner scanner) {
        while (true) {
            System.out.println("------------------------------");
            System.out.println("Manage Researchers");
            System.out.println("1. Add Researcher");
            System.out.println("2. View Researcher");
            System.out.println("3. Update Researcher");
            System.out.println("4. Delete Researcher");
            System.out.println("5. Back to Main Menu");
            System.out.println("------------------------------");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    addResearcher(scanner);
                    break;
                case 2:
                    viewResearcher(scanner);
                    break;
                case 3:
                    updateResearcher(scanner);
                    break;
                case 4:
                    deleteResearcher(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    //Manage Experiments
    private static void manageExperiments(Scanner scanner) {
        while (true) {
            System.out.println("------------------------------");
            System.out.println("Manage Experiments");
            System.out.println("1. Add Experiment");
            System.out.println("2. View Experiment");
            System.out.println("3. Update Experiment");
            System.out.println("4. Delete Experiment");
            System.out.println("5. Back to Main Menu");
            System.out.println("------------------------------");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    addExperiment(scanner);
                    break;
                case 2:
                    viewExperiment(scanner);
                    break;
                case 3:
                    updateExperiment(scanner);
                    break;
                case 4:
                    deleteExperiment(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    //Manage Samples
    private static void manageSamples(Scanner scanner) {
        while (true) {
            System.out.println("------------------------------");
            System.out.println("Manage Samples");
            System.out.println("1. Add Sample");
            System.out.println("2. View Sample");
            System.out.println("3. Update Sample");
            System.out.println("4. Delete Sample");
            System.out.println("5. Back to Main Menu");
            System.out.println("------------------------------");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    addSample(scanner);
                    break;
                case 2:
                    viewSample(scanner);
                    break;
                case 3:
                    updateSample(scanner);
                    break;
                case 4:
                    deleteSample(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }



//Add Researcher
private static void addResearcher(Scanner scanner) {
        try {
            System.out.print("Enter name: ");
            String name = scanner.nextLine();
            InputValidator.validateStringInput(name, "Name");

            System.out.print("Enter specialization: ");
            String specialization = scanner.nextLine();
            InputValidator.validateStringInput(specialization, "Specialization");

            System.out.print("Enter email: ");
            String email = scanner.nextLine();
            InputValidator.validateEmail(email);

            System.out.print("Enter phone number: ");
            String phoneNumber = scanner.nextLine();
            InputValidator.validatePhoneNumber(phoneNumber);

            ResearcherDAO.addResearcher(name, specialization, email, phoneNumber);
        } catch (ValidationException e) {
            System.err.println("Validation error: " + e.getMessage());
        }
    }

    //View Researcher
    private static void viewResearcher(Scanner scanner) {
        System.out.print("Enter researcher ID: ");
        int researcherId = scanner.nextInt();
        ResearcherDAO.viewResearcher(researcherId);
    }

    //Update Researcher
    private static void updateResearcher(Scanner scanner) {
        try {
            System.out.print("Enter researcher ID: ");
            int researcherId = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            System.out.print("Enter new name: ");
            String name = scanner.nextLine();
            InputValidator.validateStringInput(name, "Name");

            System.out.print("Enter new specialization: ");
            String specialization = scanner.nextLine();
            InputValidator.validateStringInput(specialization, "Specialization");

            System.out.print("Enter new email: ");
            String email = scanner.nextLine();
            InputValidator.validateEmail(email);

            System.out.print("Enter new phone number: ");
            String phoneNumber = scanner.nextLine();
            InputValidator.validatePhoneNumber(phoneNumber);

            ResearcherDAO.updateResearcher(researcherId, name, specialization, email, phoneNumber);
        } catch (ValidationException e) {
            System.err.println("Validation error: " + e.getMessage());
        }
    }

    //Delete Researcher
    private static void deleteResearcher(Scanner scanner) {
        System.out.print("Enter researcher ID: ");
        int researcherId = scanner.nextInt();
        ResearcherDAO.deleteResearcher(researcherId);
    }

    //Add Experiment
    private static void addExperiment(Scanner scanner) {
        try {
            System.out.print("Enter experiment name: ");
            String name = scanner.nextLine();
            InputValidator.validateStringInput(name, "Experiment Name");

            System.out.print("Enter researcher ID: ");
            int researcherId = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            System.out.print("Enter start date (yyyy-mm-dd): ");
            Date startDate = Date.valueOf(scanner.nextLine());

            System.out.print("Enter end date (yyyy-mm-dd): ");
            Date endDate = Date.valueOf(scanner.nextLine());

            InputValidator.validateDateRange(startDate, endDate);

            System.out.print("Enter status: ");
            String status = scanner.nextLine();
            InputValidator.validateStringInput(status, "Status");

            ExperimentDAO.addExperiment(name, researcherId, startDate, endDate, status);
        } catch (ValidationException e) {
            System.err.println("Validation error: " + e.getMessage());
        }
    }

    //View Experiment
    private static void viewExperiment(Scanner scanner) {
        System.out.print("Enter experiment ID: ");
        int experimentId = scanner.nextInt();
        ExperimentDAO.viewExperiment(experimentId);
    }

    //Update Experiment
    private static void updateExperiment(Scanner scanner) {
        try {
            System.out.print("Enter experiment ID: ");
            int experimentId = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            System.out.print("Enter new experiment name: ");
            String name = scanner.nextLine();
            InputValidator.validateStringInput(name, "Experiment Name");

            System.out.print("Enter new researcher ID: ");
            int researcherId = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            System.out.print("Enter new start date (yyyy-mm-dd): ");
            Date startDate = Date.valueOf(scanner.nextLine());

            System.out.print("Enter new end date (yyyy-mm-dd): ");
            Date endDate = Date.valueOf(scanner.nextLine());

            InputValidator.validateDateRange(startDate, endDate);

            System.out.print("Enter new status: ");
            String status = scanner.nextLine();
            InputValidator.validateStringInput(status, "Status");

            ExperimentDAO.updateExperiment(experimentId, name, researcherId, startDate, endDate, status);
        } catch (ValidationException e) {
            System.err.println("Validation error: " + e.getMessage());
        }
    }

    //Delete Experiment
    private static void deleteExperiment(Scanner scanner) {
        System.out.print("Enter experiment ID: ");
        int experimentId = scanner.nextInt();
        ExperimentDAO.deleteExperiment(experimentId);
    }

    //Add Sample
    private static void addSample(Scanner scanner) {
        try {
            System.out.print("Enter sample name: ");
            String name = scanner.nextLine();
            InputValidator.validateStringInput(name, "Sample Name");

            System.out.print("Enter experiment ID: ");
            int experimentId = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            System.out.print("Enter collection date (yyyy-mm-dd): ");
            Date collectionDate = Date.valueOf(scanner.nextLine());

            System.out.print("Enter description: ");
            String description = scanner.nextLine();
            InputValidator.validateStringInput(description, "Description");

            SampleDAO.addSample(name, experimentId, collectionDate, description);
        } catch (ValidationException e) {
            System.err.println("Validation error: " + e.getMessage());
        }
    }

    //View Sample
    private static void viewSample(Scanner scanner) {
        System.out.print("Enter sample ID: ");
        int sampleId = scanner.nextInt();
        SampleDAO.viewSample(sampleId);
    }

    //Update Sample
    private static void updateSample(Scanner scanner) {
        try {
            System.out.print("Enter sample ID: ");
            int sampleId = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            System.out.print("Enter new sample name: ");
            String name = scanner.nextLine();
            InputValidator.validateStringInput(name, "Sample Name");

            System.out.print("Enter new experiment ID: ");
            int experimentId = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            System.out.print("Enter new collection date (yyyy-mm-dd): ");
            Date collectionDate = Date.valueOf(scanner.nextLine());

            System.out.print("Enter new description: ");
            String description = scanner.nextLine();
            InputValidator.validateStringInput(description, "Description");

            SampleDAO.updateSample(sampleId, name, experimentId, collectionDate, description);
        } catch (ValidationException e) {
            System.err.println("Validation error: " + e.getMessage());
        }
    }

    //Delete Sample
    private static void deleteSample(Scanner scanner) {
        System.out.print("Enter sample ID: ");
        int sampleId = scanner.nextInt();
        SampleDAO.deleteSample(sampleId);
    }
}
