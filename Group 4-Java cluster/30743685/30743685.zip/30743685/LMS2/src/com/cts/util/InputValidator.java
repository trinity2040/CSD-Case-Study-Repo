package com.cts.util;

import com.cts.exception.ValidationException;

public class InputValidator {

    public static void validateStringInput(String input, String fieldName) throws ValidationException {
        if (input == null || input.trim().isEmpty()) {
            throw new ValidationException(fieldName + " cannot be empty.");
        }
    }

    public static void validateEmail(String email) throws ValidationException {
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        if (!email.matches(emailRegex)) {
            throw new ValidationException("Invalid email format.");
        }
    }

    public static void validatePhoneNumber(String phoneNumber) throws ValidationException {
        String phoneRegex = "\\d{10}";
        if (!phoneNumber.matches(phoneRegex)) {
            throw new ValidationException("Invalid phone number. It should be a 10-digit number.");
        }
    }

    public static void validateDateRange(java.sql.Date startDate, java.sql.Date endDate) throws ValidationException {
        if (startDate.after(endDate)) {
            throw new ValidationException("Start date cannot be after end date.");
        }
    }
}
