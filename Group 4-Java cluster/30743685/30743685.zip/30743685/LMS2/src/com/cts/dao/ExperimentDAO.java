package com.cts.dao;

import com.cts.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ExperimentDAO {
    //Add Experiment
    public static void addExperiment(String name, int researcherId, Date startDate, Date endDate, String status) {
        String query = "INSERT INTO Experiment (experiment_name, researcher_id, start_date, end_date, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setInt(2, researcherId);
            stmt.setDate(3, startDate);
            stmt.setDate(4, endDate);
            stmt.setString(5, status);
            stmt.executeUpdate();
            System.out.println("Experiment added successfully.");
        } catch (SQLException e) {
            System.err.println("Error adding experiment: " + e.getMessage());
        }
    }

    //View Experiment
    public static void viewExperiment(int experimentId) {
        String query = "SELECT * FROM Experiment WHERE experiment_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, experimentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Experiment ID: " + rs.getInt("experiment_id"));
                System.out.println("Name: " + rs.getString("experiment_name"));
                System.out.println("Researcher ID: " + rs.getInt("researcher_id"));
                System.out.println("Start Date: " + rs.getDate("start_date"));
                System.out.println("End Date: " + rs.getDate("end_date"));
                System.out.println("Status: " + rs.getString("status"));
            } else {
                System.out.println("Experiment not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error viewing experiment: " + e.getMessage());
        }
    }

    //Update Experimrnt
    public static void updateExperiment(int experimentId, String name, int researcherId, Date startDate, Date endDate, String status) {
        String query = "UPDATE Experiment SET experiment_name = ?, researcher_id = ?, start_date = ?, end_date = ?, status = ? WHERE experiment_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setInt(2, researcherId);
            stmt.setDate(3, startDate);
            stmt.setDate(4, endDate);
            stmt.setString(5, status);
            stmt.setInt(6, experimentId);
            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Experiment updated successfully.");
            } else {
                System.out.println("Experiment not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error updating experiment: " + e.getMessage());
        }
    }

    //Delete Experiment
    public static void deleteExperiment(int experimentId) {
        String query = "DELETE FROM Experiment WHERE experiment_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, experimentId);
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Experiment deleted successfully.");
            } else {
                System.out.println("Experiment not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error deleting experiment: " + e.getMessage());
        }
    }
}
