Laboratory Information Management System (LIMS)
Overview
The Laboratory Information Management System (LIMS) is a console-based application designed to manage researchers, experiments, and samples in a laboratory setting. The system is built using Core Java and MySQL with JDBC for database interactions. It provides functionalities to add, view, update, and delete records for researchers, experiments, and samples.

Features
Researcher Management: Add, view, update, and delete researchers.
Experiment Management: Add, view, update, and delete experiments associated with researchers.
Sample Management: Add, view, update, and delete samples associated with experiments.
Custom Exceptions: Handles errors gracefully using custom exceptions.
Input Validation: Ensures that all inputs meet required formats (e.g., email, phone number).

Description of Packages
main: Contains the main class LIMSMenu.java which provides the menu-driven interface to interact with the system.

dao: Data Access Object (DAO) classes responsible for database operations.

DatabaseConnection.java: Manages the connection to the MySQL database.
ResearcherDAO.java: Manages CRUD operations for researchers.
ExperimentDAO.java: Manages CRUD operations for experiments.
SampleDAO.java: Manages CRUD operations for samples.
model: Contains the data models representing the entities in the system.

Researcher.java: Represents a researcher.
Experiment.java: Represents an experiment.
Sample.java: Represents a sample.
util: Utility classes.

InputValidator.java: Validates input data (e.g., email, phone number).
CustomExceptions.java: Custom exception handling.
exception: Contains custom exception classes.

DatabaseException.java: Handles database-related exceptions.
ValidationException.java: Handles validation-related exceptions.
ResearcherNotFoundException.java: Handles cases where a researcher is not found.

Usage
Main Menu:

Manage Researchers
Manage Experiments
Manage Samples
Exit
Operations:

Add, view, update, and delete records for researchers, experiments, and samples.