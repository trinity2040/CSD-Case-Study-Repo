package lims;

public class Main {
    public static void main(String[] args) {
        LIMSMenu.main(args);
    }
}
