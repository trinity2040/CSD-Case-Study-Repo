package lims;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Researcher {
    // Add a new researcher
    public static void addResearcher(String name, String specialization, String email, String phone) {
        String query = "INSERT INTO Researcher (researcher_name, specialization, email, phone_number) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setString(2, specialization);
            stmt.setString(3, email);
            stmt.setString(4, phone);
            stmt.executeUpdate();
            System.out.println("Researcher added successfully.");
        } catch (SQLException e) {
            System.err.println("Error adding researcher: " + e.getMessage());
        }
    }

    // View researcher details
    public static void viewResearcher(int researcherId) {
        String query = "SELECT * FROM Researcher WHERE researcher_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, researcherId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Researcher ID: " + rs.getInt("researcher_id"));
                System.out.println("Name: " + rs.getString("researcher_name"));
                System.out.println("Specialization: " + rs.getString("specialization"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone: " + rs.getString("phone_number"));
            } else {
                System.out.println("Researcher not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error viewing researcher: " + e.getMessage());
        }
    }

    // Update researcher information
    public static void updateResearcher(int researcherId, String name, String specialization, String email, String phone) {
        String query = "UPDATE Researcher SET researcher_name = ?, specialization = ?, email = ?, phone_number = ? WHERE researcher_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setString(2, specialization);
            stmt.setString(3, email);
            stmt.setString(4, phone);
            stmt.setInt(5, researcherId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Researcher updated successfully.");
            } else {
                System.out.println("Researcher not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error updating researcher: " + e.getMessage());
        }
    }

    // Delete a researcher
    public static void deleteResearcher(int researcherId) {
        String query = "DELETE FROM Researcher WHERE researcher_id = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, researcherId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Researcher deleted successfully.");
            } else {
                System.out.println("Researcher not found.");
            }
        } catch (SQLException e) {
            System.err.println("Error deleting researcher: " + e.getMessage());
        }
    }
}
