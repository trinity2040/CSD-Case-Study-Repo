package lims;

import java.sql.Date;
import java.util.Scanner;

public class LIMSMenu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\nLaboratory Information Management System");
            System.out.println("1. Manage Researchers");
            System.out.println("2. Manage Experiments");
            System.out.println("3. Manage Samples");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    manageResearchers(scanner);
                    break;
                case 2:
                    manageExperiments(scanner);
                    break;
                case 3:
                    manageSamples(scanner);
                    break;
                case 4:
                    System.out.println("Exiting the application.");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageResearchers(Scanner scanner) {
        System.out.println("\nManage Researchers");
        System.out.println("1. Add Researcher");
        System.out.println("2. View Researcher");
        System.out.println("3. Update Researcher");
        System.out.println("4. Delete Researcher");
        System.out.println("5. Back to Main Menu");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                System.out.print("Enter name: ");
                String name = scanner.next();
                System.out.print("Enter specialization: ");
                String specialization = scanner.next();
                System.out.print("Enter email: ");
                String email = scanner.next();
                System.out.print("Enter phone number: ");
                String phone = scanner.next();
                Researcher.addResearcher(name, specialization, email, phone);
                break;
            case 2:
                System.out.print("Enter researcher ID: ");
                int researcherId = scanner.nextInt();
                Researcher.viewResearcher(researcherId);
                break;
            case 3:
                System.out.print("Enter researcher ID: ");
                researcherId = scanner.nextInt();
                System.out.print("Enter new name: ");
                name = scanner.next();
                System.out.print("Enter new specialization: ");
                specialization = scanner.next();
                System.out.print("Enter new email: ");
                email = scanner.next();
                System.out.print("Enter new phone number: ");
                phone = scanner.next();
                Researcher.updateResearcher(researcherId, name, specialization, email, phone);
                break;
            case 4:
                System.out.print("Enter researcher ID: ");
                researcherId = scanner.nextInt();
                Researcher.deleteResearcher(researcherId);
                break;
            case 5:
                return;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void manageExperiments(Scanner scanner) {
        System.out.println("\nManage Experiments");
        System.out.println("1. Add Experiment");
        System.out.println("2. View Experiment");
        System.out.println("3. Update Experiment");
        System.out.println("4. Delete Experiment");
        System.out.println("5. Back to Main Menu");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                System.out.print("Enter experiment name: ");
                String name = scanner.next();
                System.out.print("Enter researcher ID: ");
                int researcherId = scanner.nextInt();
                System.out.print("Enter start date (YYYY-MM-DD): ");
                Date startDate = Date.valueOf(scanner.next());
                System.out.print("Enter end date (YYYY-MM-DD): ");
                Date endDate = Date.valueOf(scanner.next());
                System.out.print("Enter status (Planned, In Progress, Completed): ");
                String status = scanner.next();
                Experiment.addExperiment(name, researcherId, startDate, endDate, status);
                break;
            case 2:
                System.out.print("Enter experiment ID: ");
                int experimentId = scanner.nextInt();
                Experiment.viewExperiment(experimentId);
                break;
            case 3:
                System.out.print("Enter experiment ID: ");
                experimentId = scanner.nextInt();
                System.out.print("Enter new experiment name: ");
                name = scanner.next();
                System.out.print("Enter new researcher ID: ");
                researcherId = scanner.nextInt();
                System.out.print("Enter new start date (YYYY-MM-DD): ");
                startDate = Date.valueOf(scanner.next());
                System.out.print("Enter new end date (YYYY-MM-DD): ");
                endDate = Date.valueOf(scanner.next());
                System.out.print("Enter new status (Planned, In Progress, Completed): ");
                status = scanner.next();
                Experiment.updateExperiment(experimentId, name, researcherId, startDate, endDate, status);
                break;
            case 4:
                System.out.print("Enter experiment ID: ");
                experimentId = scanner.nextInt();
                Experiment.deleteExperiment(experimentId);
                break;
            case 5:
                return;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void manageSamples(Scanner scanner) {
        System.out.println("\nManage Samples");
        System.out.println("1. Add Sample");
        System.out.println("2. View Sample");
        System.out.println("3. Update Sample");
        System.out.println("4. Delete Sample");
        System.out.println("5. Back to Main Menu");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                System.out.print("Enter sample name: ");
                String name = scanner.next();
                System.out.print("Enter experiment ID: ");
                int experimentId = scanner.nextInt();
                System.out.print("Enter collection date (YYYY-MM-DD): ");
                Date collectionDate = Date.valueOf(scanner.next());
                System.out.print("Enter description: ");
                String description = scanner.next();
                Sample.addSample(name, experimentId, collectionDate, description);
                break;
            case 2:
                System.out.print("Enter sample ID: ");
                int sampleId = scanner.nextInt();
                Sample.viewSample(sampleId);
                break;
            case 3:
                System.out.print("Enter sample ID: ");
                sampleId = scanner.nextInt();
                System.out.print("Enter new sample name: ");
                name = scanner.next();
                System.out.print("Enter new experiment ID: ");
                experimentId = scanner.nextInt();
                System.out.print("Enter new collection date (YYYY-MM-DD): ");
                collectionDate = Date.valueOf(scanner.next());
                System.out.print("Enter new description: ");
                description = scanner.next();
                Sample.updateSample(sampleId, name, experimentId, collectionDate, description);
                break;
            case 4:
                System.out.print("Enter sample ID: ");
                sampleId = scanner.nextInt();
                Sample.deleteSample(sampleId);
                break;
            case 5:
                return;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }
}
