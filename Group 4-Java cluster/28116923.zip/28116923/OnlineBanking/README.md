
# Online Banking Console Application
Overview
This project is a console-based online banking system developed in Core Java with MySQL and JDBC for database interactions. It allows users to manage accounts, transactions, and customers through a text-based menu interface. The system includes functionalities for account management, transaction management, and customer management.

Functionalities
1. Account Management
Add a New Account: Create a new account for a customer with an initial balance.
View Account Details: Retrieve and display details of a specific account.
Update Account Information: Modify the balance of an existing account.
Delete an Account: Remove an account from the system.
2. Transaction Management
Deposit Money: Add funds to an account.
Withdraw Money: Remove funds from an account.
View Transaction History: Display a list of transactions for a specific account.
Transfer Money: Transfer funds between two accounts.
3. Customer Management
Register a New Customer: Add a new customer to the system.
View Customer Details: Retrieve and display details of a specific customer.
Update Customer Information: Modify customer details.
Delete a Customer: Remove a customer from the system.
Database Schema
The application uses the following MySQL database schema:

Customer Table:

customer_id (Primary Key, INT, Auto Increment)
name (VARCHAR(100))
email (VARCHAR(100))
phone_number (VARCHAR(20))
address (TEXT)
Account Table:

account_number (Primary Key, INT, Auto Increment)
customer_id (Foreign Key, INT)
balance (DOUBLE)
Transaction Table:

transaction_id (Primary Key, INT, Auto Increment)
account_number (Foreign Key, INT)
transaction_date (DATETIME)
transaction_type (VARCHAR(50))
amount (DOUBLE)
Getting Started
Prerequisites
Java Development Kit (JDK) 8 or higher
MySQL Server
MySQL JDBC Driver (Connector/J)
IDE (e.g., IntelliJ IDEA, Eclipse) or text editor


Setup Instructions
Clone the Repository:

bash
Copy code
git clone https://github.com/yourusername/online-banking-system.git
cd online-banking-system
Configure Database:

Create a new MySQL database.
Import the SQL schema provided above into your database.
Update Database Connection Details:

Open DatabaseConnection.java.
Update the URL, USER, and PASSWORD variables to match your MySQL configuration.
Build and Run the Application:

Compile the Java files:
bash
Copy code
javac -cp .:path/to/mysql-connector-java.jar *.java
Run the application:
bash
Copy code
java -cp .:path/to/mysql-connector-java.jar Main
Usage
Start the Application:

Run the Main class to start the console-based menu interface.
Menu Options:

Follow the on-screen instructions to select options for account management, transaction management, or customer management.
Example:

To add a new account, select the appropriate menu option and provide the required details (customer ID and initial balance).
Exception Handling
Database Errors: Proper error messages are provided if database operations fail.
Input Validation: The application handles invalid inputs and prompts the user accordingly.
Notes
Make sure the MySQL server is running before starting the application.
Ensure that the MySQL JDBC driver is included in the classpath.
This is a console-based application with no graphical user interface.



