package com.cts.Service;

import com.cts.dao.AccountDAO;
import com.cts.dao.AccountDAOImpl;
import com.cts.model.Account;
import com.cts.exception.AccountNotFoundException;

import java.sql.SQLException;

public class AccountManager {
    private final AccountDAO accountDAO = new AccountDAOImpl();

    public int addAccount(int customerId, double initialBalance) throws SQLException, AccountNotFoundException {
        return accountDAO.addAccount(customerId, initialBalance);
    }
 
    

    public Account getAccountByNumber(int accountNumber) throws SQLException, AccountNotFoundException {
        try {
            return accountDAO.getAccountByNumber(accountNumber);
        } catch (SQLException e) {
            throw new SQLException("Error accessing the database", e);
        } catch (Exception e) {
            throw new AccountNotFoundException("Account not found with number: " + accountNumber);
        }
    }


    public void viewAccountDetails(int accountNumber) throws SQLException, AccountNotFoundException {
        try {
            Account account = accountDAO.getAccountByNumber(accountNumber);
            if (account == null) {
                throw new AccountNotFoundException("Account with number " + accountNumber + " does not exist.");
            }
            System.out.println("Account Number: " + account.getAccountNumber());
            System.out.println("Customer ID: " + account.getCustomerId());
            System.out.println("Balance: " + account.getBalance());
        } catch (SQLException e) {
            throw new SQLException("Error retrieving account details: " + e.getMessage(), e);
        }
    }

    public void updateAccount(int accountNumber, double newBalance) throws SQLException, AccountNotFoundException {
        try {
            accountDAO.updateAccount(accountNumber, newBalance);
        } catch (SQLException e) {
            throw new SQLException("Error updating account", e);
        }
    }

    public void deleteAccount(int accountNumber) throws SQLException, AccountNotFoundException {
        accountDAO.deleteAccount(accountNumber);
    }
}
