package com.cts.Service;

import com.cts.dao.TransactionDAO;
import com.cts.dao.TransactionDAOImpl;
import com.cts.exception.AccountNotFoundException;
import com.cts.exception.InsufficientBalanceException;

import java.sql.SQLException;

public class TransactionManager {
    private final TransactionDAO transactionDAO = new TransactionDAOImpl();

    public void deposit(int accountNumber, double amount) throws SQLException, AccountNotFoundException {
        transactionDAO.deposit(accountNumber, amount);
    }

    public void withdraw(int accountNumber, double amount) throws SQLException, AccountNotFoundException, InsufficientBalanceException {
        // Implement balance check if necessary
        transactionDAO.withdraw(accountNumber, amount);
    }

    public void transfer(int fromAccount, int toAccount, double amount) throws SQLException, AccountNotFoundException, InsufficientBalanceException {
        transactionDAO.transfer(fromAccount, toAccount, amount);
    }

    public void viewTransactionHistory(int accountNumber) throws SQLException {
        transactionDAO.viewTransactionHistory(accountNumber);
    }
}
