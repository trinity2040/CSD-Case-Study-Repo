package com.cts.dao;

import java.sql.SQLException;

public interface TransactionDAO {
    void deposit(int accountNumber, double amount) throws SQLException;
    void withdraw(int accountNumber, double amount) throws SQLException;
    void transfer(int fromAccount, int toAccount, double amount) throws SQLException;
    void viewTransactionHistory(int accountNumber) throws SQLException;
}
