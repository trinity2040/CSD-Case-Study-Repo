package com.cts.dao;

import com.cts.model.Account;
import com.cts.exception.AccountNotFoundException;
import com.cts.util.DataBaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AccountDAOImpl implements AccountDAO {

    @Override
    public int addAccount(int customerId, double initialBalance) throws SQLException {
        String query = "INSERT INTO Account (customer_id, balance) VALUES (?, ?)";
        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, customerId);
            pstmt.setDouble(2, initialBalance);
            pstmt.executeUpdate();

            try (ResultSet rs = pstmt.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1); // Return the generated account ID
                } else {
                    throw new SQLException("Failed to retrieve the account ID.");
                }
            }
        }
    }

    @Override
    public void updateAccount(int accountNumber, double newBalance) throws SQLException, AccountNotFoundException {
        String query = "UPDATE Account SET balance = ? WHERE account_number = ?";
        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setDouble(1, newBalance);
            pstmt.setInt(2, accountNumber);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new AccountNotFoundException("Account with number " + accountNumber + " not found.");
            }
        }
    }

    @Override
    public void deleteAccount(int accountNumber) throws SQLException, AccountNotFoundException {
        String query = "DELETE FROM Account WHERE account_number = ?";
        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, accountNumber);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new AccountNotFoundException("Account with number " + accountNumber + " not found.");
            }
        }
    }

    @Override
    public Account getAccountByNumber(int accountNumber) throws SQLException, AccountNotFoundException {
        String query = "SELECT * FROM Account WHERE account_number = ?";
        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, accountNumber);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new Account(
                        rs.getInt("account_number"),
                        rs.getInt("customer_id"),
                        rs.getDouble("balance")
                    );
                } else {
                    throw new AccountNotFoundException("Account with number " + accountNumber + " not found.");
                }
            }
        }
    }

    @Override
    public List<Account> getAccountsByCustomerId(int customerId) throws SQLException {
        String query = "SELECT * FROM Account WHERE customer_id = ?";
        List<Account> accounts = new ArrayList<>();
        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, customerId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    accounts.add(new Account(
                        rs.getInt("account_number"),
                        rs.getInt("customer_id"),
                        rs.getDouble("balance")
                    ));
                }
            }
        }
        return accounts;
    }
}
