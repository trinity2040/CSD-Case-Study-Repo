package com.cts.dao;

import com.cts.model.Account;
import com.cts.exception.AccountNotFoundException;
import java.sql.SQLException;
import java.util.List;

public interface AccountDAO {

    
    int addAccount(int customerId, double initialBalance) throws SQLException;

   
    void updateAccount(int accountNumber, double newBalance) throws SQLException, AccountNotFoundException;

    
    void deleteAccount(int accountNumber) throws SQLException, AccountNotFoundException;

    
    Account getAccountByNumber(int accountNumber) throws SQLException, AccountNotFoundException;

   
    List<Account> getAccountsByCustomerId(int customerId) throws SQLException;
}
