package com.cts.dao;

import com.cts.Exception.AccountNotFoundException;
import com.cts.Exception.InsufficientBalanceException;
import com.cts.dao.TransactionDAO;
import com.cts.util.DataBaseConnection;

import java.sql.*;

public class TransactionDAOImpl implements TransactionDAO {

    @Override
    public void deposit(int accountNumber, double amount) throws SQLException {
        String query = "UPDATE Account SET balance = balance + ? WHERE account_number = ?";
        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setDouble(1, amount);
            pstmt.setInt(2, accountNumber);
            pstmt.executeUpdate();
        }
    }

    @Override
    public void withdraw(int accountNumber, double amount) throws SQLException {
        String query = "UPDATE Account SET balance = balance - ? WHERE account_number = ?";
        if (!accountExists(accountNumber)) {
            throw new AccountNotFoundException("Account does not exist.");
        }

        double currentBalance = getAccountBalance(accountNumber);
        if (amount > currentBalance) {
            throw new InsufficientBalanceException("Insufficient balance.");
        }
        try (Connection conn = DataBaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setDouble(1, amount);
            pstmt.setInt(2, accountNumber);
            pstmt.executeUpdate();
        }
    }

    @Override
    public void transfer(int fromAccount, int toAccount, double amount) throws SQLException {
        try (Connection conn = DataBaseConnection.getConnection()) {
            conn.setAutoCommit(false);

            withdraw(fromAccount, amount);
            deposit(toAccount, amount);

            conn.commit();
        } catch (SQLException e) {
            try (Connection conn = DataBaseConnection.getConnection()) {
                conn.rollback();
            }
            throw e;
        }
    }

    @Override
    public void viewTransactionHistory(int accountNumber) throws SQLException {
        // Implement if needed
    }
}
