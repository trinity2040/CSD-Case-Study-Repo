package com.cts.dao;

import com.cts.model.Customer;
import java.sql.SQLException;

public interface CustomerDAO {
    int addCustomer(Customer customer) throws SQLException;
    Customer getCustomerById(int customerId) throws SQLException;
    void updateCustomer(Customer customer) throws SQLException;
    void deleteCustomer(int customerId) throws SQLException;
}
