package com.cts.model;

import java.time.LocalDateTime;

public class Transaction {
    private int id;
    private int accountNumber;
    private String transactionType;
    private double amount;
    private LocalDateTime transactionDate;

    // Constructor
    public Transaction(int id, int accountNumber, String transactionType, double amount, LocalDateTime transactionDate) {
        this.id = id;
        this.accountNumber = accountNumber;
        this.transactionType = transactionType;
        this.amount = amount;
        this.transactionDate = transactionDate;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public LocalDateTime getTransactionDate() {
        return transactionDate;
    }

    public void setTransactionDate(LocalDateTime transactionDate) {
        this.transactionDate = transactionDate;
    }

    @Override
    public String toString() {
        return "Transaction ID: " + id +
               ", Account Number: " + accountNumber +
               ", Type: " + transactionType +
               ", Amount: " + amount +
               ", Date: " + transactionDate;
    }
}

