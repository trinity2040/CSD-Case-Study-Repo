/**
 * 
 */
/**
 * 
 */
module OnlineBanking {
	requires java.sql;
}