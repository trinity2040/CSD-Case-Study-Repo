package com.cts.services;
import java.sql.*;

import com.cts.BankingDatabase.DatabaseConnection;
public class AccountsManager {
	// Method to update account balance
    public void updateAccount(int accountNumber, double newBalance) throws SQLException {
        String query = "UPDATE Account SET balance = ? WHERE account_number = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setDouble(1, newBalance);
            pstmt.setInt(2, accountNumber);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("Account not found.");
            } else {
                System.out.println("Account updated successfully.");
            }
        }
    }

    // Method to delete an account
    public void deleteAccount(int accountNumber) throws SQLException {
        String query = "DELETE FROM Account WHERE account_number = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, accountNumber);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                System.out.println("Account not found.");
            } else {
                System.out.println("Account deleted successfully.");
            }
        }
    }
 // Method to add a new account
    public int addAccount(int customerId, double initialBalance) throws SQLException {
        String query = "INSERT INTO Account (customer_id, balance) VALUES (?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query,Statement.RETURN_GENERATED_KEYS)) {
            pstmt.setInt(1, customerId);
            pstmt.setDouble(2, initialBalance);
            int affectedRows = pstmt.executeUpdate();
            
            // Check if the update was successful and get the generated keys
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        // Return the generated account number
                        return generatedKeys.getInt(1);
                    } else {
                        throw new SQLException("Failed to retrieve account number.");
                    }
                }
            } else {
                throw new SQLException("Account creation failed.");
            }
        }
        }
    

    // Method to view account details
    public void viewAccountDetails(int accountNumber) throws SQLException {
        String query = "SELECT * FROM Account WHERE account_number = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, accountNumber);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                System.out.println("Account Number: " + rs.getInt("account_number"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Balance: " + rs.getDouble("balance"));
            } else {
                System.out.println("Account not found.");
            }
        }
    }
    
}


	
	

	
