package com.cts.services;
import java.sql.*;


import com.cts.BankingDatabase.DatabaseConnection;
public class CustomerManager{
	
	
// Method to register a new customer
	
public int registerCustomer(String name, String email, String phone, String address) throws SQLException {
    String query = "INSERT INTO Customer (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(query,Statement.RETURN_GENERATED_KEYS)) {
        pstmt.setString(1, name);
        pstmt.setString(2, email);
        pstmt.setString(3, phone);
        pstmt.setString(4, address);
       // pstmt.executeUpdate();
        int affectedRows = pstmt.executeUpdate();
        
        // If the insertion was successful and affected rows is greater than 0
        if (affectedRows > 0) {
            // Retrieve the generated keys
            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    // Return the generated customer ID
                    return generatedKeys.getInt(1);
                } else {
                    throw new SQLException("Failed to retrieve customer ID.");
                }
            }
        } else {
            throw new SQLException("Customer registration failed.");
        }
    }
}
        
        
  

// Method to view customer details
public void viewCustomerDetails(int customerId) throws SQLException {
    String query = "SELECT * FROM Customer WHERE customer_id = ?";
    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(query)) {
        pstmt.setInt(1, customerId);
        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            System.out.println("Customer ID: " + rs.getInt("customer_id"));
            System.out.println("Name: " + rs.getString("name"));
            System.out.println("Email: " + rs.getString("email"));
            System.out.println("Phone Number: " + rs.getString("phone_number"));
            System.out.println("Address: " + rs.getString("address"));
        } else {
            System.out.println("Customer not found.");
        }
    }
}

public void updateCustomer(int customerId, String name, String email, String phone, String address) throws SQLException {
    String query = "UPDATE Customer SET name = ?, email = ?, phone_number = ?, address = ? WHERE customer_id = ?";
    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(query)) {
        pstmt.setString(1, name);
        pstmt.setString(2, email);
        pstmt.setString(3, phone);
        pstmt.setString(4, address);
        pstmt.setInt(5, customerId);
        int rowsAffected = pstmt.executeUpdate();
        if (rowsAffected == 0) {
            System.out.println("Customer not found.");
        } else {
            System.out.println("Customer updated successfully.");
        }
    }
}

// Method to delete a customer
public void deleteCustomer(int customerId) throws SQLException {
    String query = "DELETE FROM Customer WHERE customer_id = ?";
    try (Connection conn = DatabaseConnection.getConnection();
         PreparedStatement pstmt = conn.prepareStatement(query)) {
        pstmt.setInt(1, customerId);
        int rowsAffected = pstmt.executeUpdate();
        if (rowsAffected == 0) {
            System.out.println("Customer not found.");
        } else {
            System.out.println("Customer deleted successfully.");
        }
    }
}
}