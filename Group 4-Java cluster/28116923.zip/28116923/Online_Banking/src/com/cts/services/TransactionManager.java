package com.cts.services;
import java.sql.*;

import com.cts.BankingDatabase.DatabaseConnection;


public class TransactionManager {
    public void deposit(int accountNumber, double amount) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        try {
            conn.setAutoCommit(false);

            // Update account balance
            String updateBalance = "UPDATE Account SET balance = balance + ? WHERE account_number = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(updateBalance)) {
                pstmt.setDouble(1, amount);
                pstmt.setInt(2, accountNumber);
                pstmt.executeUpdate();
            }

            // Record deposit transaction
            String insertTransaction = "INSERT INTO Transaction (account_number, transaction_date, transaction_type, amount) VALUES (?, NOW(), 'deposit', ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(insertTransaction)) {
                pstmt.setInt(1, accountNumber);
                pstmt.setDouble(2, amount);
                pstmt.executeUpdate();
            }

            conn.commit();
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
            conn.close();
        }
    }

    public void withdraw(int accountNumber, double amount) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        try {
            conn.setAutoCommit(false);

            // Check balance
            String balanceQuery = "SELECT balance FROM Account WHERE account_number = ?";
            double balance;
            try (PreparedStatement pstmt = conn.prepareStatement(balanceQuery)) {
                pstmt.setInt(1, accountNumber);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    balance = rs.getDouble("balance");
                } else {
                    throw new SQLException("Account not found.");
                }
            }

            // Ensure sufficient balance
            if (balance >= amount) {
                // Update account balance
                String updateBalance = "UPDATE Account SET balance = balance - ? WHERE account_number = ?";
                try (PreparedStatement pstmt = conn.prepareStatement(updateBalance)) {
                    pstmt.setDouble(1, amount);
                    pstmt.setInt(2, accountNumber);
                    pstmt.executeUpdate();
                }

                // Record withdrawal transaction
                String insertTransaction = "INSERT INTO Transaction (account_number, transaction_date, transaction_type, amount) VALUES (?, NOW(), 'withdrawal', ?)";
                try (PreparedStatement pstmt = conn.prepareStatement(insertTransaction)) {
                    pstmt.setInt(1, accountNumber);
                    pstmt.setDouble(2, amount);
                    pstmt.executeUpdate();
                }

                conn.commit();
            } else {
                throw new SQLException("Insufficient balance.");
            }
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
            conn.close();
        }
    }

    public void viewTransactionHistory(int accountNumber) throws SQLException {
        String query = "SELECT * FROM Transaction WHERE account_number = ? ORDER BY transaction_date DESC";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, accountNumber);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                System.out.println("Transaction ID: " + rs.getInt("transaction_id"));
                System.out.println("Date: " + rs.getTimestamp("transaction_date"));
                System.out.println("Type: " + rs.getString("transaction_type"));
                System.out.println("Amount: " + rs.getDouble("amount"));
                System.out.println("-----------");
            }
        }
    }

    public void transfer(int fromAccount, int toAccount, double amount) throws SQLException {
        Connection conn = DatabaseConnection.getConnection();
        try {
            conn.setAutoCommit(false);

            // Check balance in the source account
            String balanceQuery = "SELECT balance FROM Account WHERE account_number = ?";
            double balance;
            try (PreparedStatement pstmt = conn.prepareStatement(balanceQuery)) {
                pstmt.setInt(1, fromAccount);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    balance = rs.getDouble("balance");
                } else {
                    throw new SQLException("Source account not found.");
                }
            }

            // Ensure sufficient balance
            if (balance >= amount) {
                // Withdraw from source account
                String updateFrom = "UPDATE Account SET balance = balance - ? WHERE account_number = ?";
                try (PreparedStatement pstmt = conn.prepareStatement(updateFrom)) {
                    pstmt.setDouble(1, amount);
                    pstmt.setInt(2, fromAccount);
                    pstmt.executeUpdate();
                }

                // Deposit into destination account
                String updateTo = "UPDATE Account SET balance = balance + ? WHERE account_number = ?";
                try (PreparedStatement pstmt = conn.prepareStatement(updateTo)) {
                    pstmt.setDouble(1, amount);
                    pstmt.setInt(2, toAccount);
                    pstmt.executeUpdate();
                }

                // Record transactions
                String insertTransactionFrom = "INSERT INTO Transaction (account_number, transaction_date, transaction_type, amount) VALUES (?, NOW(), 'transfer', ?)";
                try (PreparedStatement pstmt = conn.prepareStatement(insertTransactionFrom)) {
                    pstmt.setInt(1, fromAccount);
                    pstmt.setDouble(2, amount);
                    pstmt.executeUpdate();
                }

                String insertTransactionTo = "INSERT INTO Transaction (account_number, transaction_date, transaction_type, amount) VALUES (?, NOW(), 'transfer', ?)";
                try (PreparedStatement pstmt = conn.prepareStatement(insertTransactionTo)) {
                    pstmt.setInt(1, toAccount);
                    pstmt.setDouble(2, amount);
                    pstmt.executeUpdate();
                }

                conn.commit();
            } else {
                throw new SQLException("Insufficient balance.");
            }
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
            conn.close();
        }
    }
}