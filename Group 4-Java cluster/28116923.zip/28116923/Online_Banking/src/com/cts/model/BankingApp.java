package com.cts.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.cts.BankingDatabase.DatabaseConnection;
import com.cts.services.AccountsManager;
import com.cts.services.CustomerManager;
import com.cts.services.TransactionManager;

public class BankingApp {
    private static final Scanner scanner = new Scanner(System.in);
    private static final AccountsManager accountManager = new AccountsManager();
    private static final TransactionManager transactionManager = new TransactionManager();
    private static final CustomerManager customerManager = new CustomerManager();

    public static void main(String[] args) {
        while (true) {
        	System.out.println("---------- ONLINE BANKING ----------");
        	System.out.println();
            System.out.println("1. Account Management");
            System.out.println("2. Transaction Management");
            System.out.println("3. Customer Management");
            System.out.println("4. Exit");
            System.out.println("===============================");

            System.out.print("Select an option: ");
            System.out.println();
           

            int option = getValidOption();
            try {
                switch (option) {
                    case 1:
                        accountManagementMenu();
                        break;
                    case 2:
                        transactionManagementMenu();
                        break;
                    case 3:
                        customerManagementMenu();
                        break;
                    case 4:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid option. Try again.");
                }
            } catch (SQLException e) {
                System.out.println("Database error: " + e.getMessage());
            }
        }
    }

    private static int getValidOption() {
        while (true) {
            try {
                return scanner.nextInt();
            } catch (Exception e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next(); // Clear the invalid input
            }
        }
    }

    private static void accountManagementMenu() throws SQLException {
        while (true) {
            System.out.println("1. Add Account");
            System.out.println("2. View Account Details");
            System.out.println("3. Update Account");
            System.out.println("4. Delete Account");
            System.out.println("5. Back to Main Menu");
            System.out.println("===============================");

            System.out.print("Select an option: ");
            System.out.println();
            

            int option = getValidOption();
            try {
                switch (option) {
                    case 1:
                        addAccount();
                        break;
                    case 2:
                        viewAccountDetails();
                        break;
                    case 3:
                        updateAccount();
                        break;
                    case 4:
                        deleteAccount();
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid option. Try again.");
                }
            } catch (SQLException e) {
                System.out.println("Database error: " + e.getMessage());
            }
        }
    }

    private static void addAccount() throws SQLException {
    	AccountsManager accountManager = new AccountsManager();
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        
        // Check if the customer exists
        if (!customerExists(customerId)) {
            System.out.println("Customer ID does not exist. Please register the customer first.");
            return;
        }

        System.out.print("Enter initial balance: ");
        double initialBalance = scanner.nextDouble();
        accountManager.addAccount(customerId, initialBalance);
        System.out.println("Account added successfully.");
        int accountnumber=accountManager.addAccount(customerId, initialBalance);
        System.out.println("Please Note Your Account Number: " + accountnumber);

    }

    private static void viewAccountDetails() throws SQLException {
        System.out.print("Enter account number: ");
        int accountNumber = scanner.nextInt();
        accountManager.viewAccountDetails(accountNumber);
    }

    private static void updateAccount() throws SQLException {
        System.out.print("Enter account number: ");
        int accountNumber = scanner.nextInt();

        // Check if the account exists
        if (!accountExists(accountNumber)) {
            System.out.println("Account does not exist.");
            return;
        }

        System.out.print("Enter new balance: ");
        double newBalance = scanner.nextDouble();
        accountManager.updateAccount(accountNumber, newBalance);
        System.out.println("Account updated successfully.");
    }

    private static void deleteAccount() throws SQLException {
        System.out.print("Enter account number: ");
        int accountNumber = scanner.nextInt();

        // Check if the account exists
        if (!accountExists(accountNumber)) {
            System.out.println("Account does not exist.");
            return;
        }

        accountManager.deleteAccount(accountNumber);
        System.out.println("Account deleted successfully.");
    }

    private static void transactionManagementMenu() throws SQLException {
        while (true) {
            System.out.println("1. Deposit Money");
            System.out.println("2. Withdraw Money");
            System.out.println("3. View Transaction History");
            System.out.println("4. Transfer Money");
            System.out.println("5. Back to Main Menu");
            System.out.println("===============================");

            System.out.print("Select an option: ");
            System.out.println();
            

            int option = getValidOption();
            try {
                switch (option) {
                    case 1:
                        depositMoney();
                        break;
                    case 2:
                        withdrawMoney();
                        break;
                    case 3:
                        viewTransactionHistory();
                        break;
                    case 4:
                        transferMoney();
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid option. Try again.");
                }
            } catch (SQLException e) {
                System.out.println("Database error: " + e.getMessage());
            }
        }
    }

    private static void depositMoney() throws SQLException {
        System.out.print("Enter account number: ");
        int accountNumber = scanner.nextInt();
        System.out.print("Enter deposit amount: ");
        double amount = scanner.nextDouble();
        transactionManager.deposit(accountNumber, amount);
        System.out.println("Money deposited successfully.");
    }

    private static void withdrawMoney() throws SQLException {
        System.out.print("Enter account number: ");
        int accountNumber = scanner.nextInt();
        System.out.print("Enter withdrawal amount: ");
        double amount = scanner.nextDouble();
        transactionManager.withdraw(accountNumber, amount);
        System.out.println("Money withdrawn successfully.");
    }

    private static void viewTransactionHistory() throws SQLException {
        System.out.print("Enter account number: ");
        int accountNumber = scanner.nextInt();
        transactionManager.viewTransactionHistory(accountNumber);
    }

    private static void transferMoney() throws SQLException {
        System.out.print("Enter source account number: ");
        int fromAccount = scanner.nextInt();
        System.out.print("Enter destination account number: ");
        int toAccount = scanner.nextInt();
        System.out.print("Enter transfer amount: ");
        double amount = scanner.nextDouble();
        
        // Check if both accounts exist
        if (!accountExists(fromAccount) || !accountExists(toAccount)) {
            System.out.println("One or both account numbers do not exist.");
            return;
        }

        transactionManager.transfer(fromAccount, toAccount, amount);
        System.out.println("Money transferred successfully.");
    }

    private static void customerManagementMenu() throws SQLException {
        while (true) {
            System.out.println("1. Register Customer");
            System.out.println("2. View Customer Details");
            System.out.println("3. Update Customer");
            System.out.println("4. Delete Customer");
            System.out.println("5. Back to Main Menu");
            System.out.println("===============================");

            System.out.print("Select an option: ");
            System.out.println();
           
            int option = getValidOption();
            try {
                switch (option) {
                    case 1:
                        registerCustomer();
                        break;
                    case 2:
                        viewCustomerDetails();
                        break;
                    case 3:
                        updateCustomer();
                        break;
                    case 4:
                        deleteCustomer();
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid option. Try again.");
                }
            } catch (SQLException e) {
                System.out.println("Database error: " + e.getMessage());
            }
        }
    }

    private static void registerCustomer() throws SQLException {
        System.out.print("Enter name: ");
        String name = scanner.next();
        System.out.print("Enter email: ");
        String email = scanner.next();
        System.out.print("Enter phone number: ");
        String phone = scanner.next();
        System.out.print("Enter address: ");
        String address = scanner.next();
        customerManager.registerCustomer(name, email, phone, address);
        System.out.println("Customer registered successfully.");
        int customerId = customerManager.registerCustomer(name, email, phone, address);
        System.out.println("Dear Customer Please Note your Customer ID : " + customerId);
    }

    private static void viewCustomerDetails() throws SQLException {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        customerManager.viewCustomerDetails(customerId);
    }

    private static void updateCustomer() throws SQLException {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();

        // Check if the customer exists
        if (!customerExists(customerId)) {
            System.out.println("Customer does not exist.");
            return;
        }

        System.out.print("Enter new name: ");
        String name = scanner.next();
        System.out.print("Enter new email: ");
        String email = scanner.next();
        System.out.print("Enter new phone number: ");
        String phone = scanner.next();
        System.out.print("Enter new address: ");
        String address = scanner.next();
        customerManager.updateCustomer(customerId, name, email, phone, address);
        System.out.println("Customer updated successfully.");
    }

    private static void deleteCustomer() throws SQLException {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();

        // Check if the customer exists
        if (!customerExists(customerId)) {
            System.out.println("Customer does not exist.");
            return;
        }

        customerManager.deleteCustomer(customerId);
        System.out.println("Customer deleted successfully.");
    }
    private static boolean accountExists(int accountNumber) throws SQLException {
        String query = "SELECT COUNT(*) FROM Account WHERE account_number = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, accountNumber);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }

  

        private static boolean customerExists(int customerId) throws SQLException {
            String query = "SELECT COUNT(*) FROM Customer WHERE customer_id = ?";
            try (Connection conn = DatabaseConnection.getConnection();
                 PreparedStatement pstmt = conn.prepareStatement(query)) {
                pstmt.setInt(1, customerId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
            return false;
        }
        }
     	
