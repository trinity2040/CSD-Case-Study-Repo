# Customer Support Ticketing System

## Project Overview

This project is a console-based Customer Support Ticketing System developed in Core Java using JDBC for database interactions. The application allows users to manage support tickets, assign them to agents, and track the resolution of issues. The system is designed to interact with a MySQL database.

## Features

- **Ticket Management**
    - Create new support tickets.
    - View details of existing tickets.
    - Update ticket information (status, priority).
    - Delete tickets.

- **Agent Assignment**
    - Create new agents.
    - View agent details.
    - Update agent information (availability, skillset).

- **Ticket Resolution**
    - Track ticket resolution status.
    - Close tickets.
    - View ticket history.

## Prerequisites

- **Java Development Kit (JDK):** Ensure that JDK 11 or higher is installed on your system.
- **MySQL Server:** Install MySQL Server and MySQL Workbench (optional).
- **IDE:** You can use any Java IDE such as IntelliJ IDEA, Eclipse, or Visual Studio Code.
- **MySQL JDBC Driver:** Download the MySQL Connector/J (JDBC driver).

## Setup Instructions

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/CustomerSupportTicketing.git
cd CustomerSupportTicketing
```
## 2. Set Up the MySQL Database
   - Open MySQL Workbench or use the command line to create the database:
````bash
   CREATE DATABASE customer_support_ticketing;
````
- Create the required tables by executing the following SQL commands:
sql
````bash
USE customer_support_ticketing;

CREATE TABLE Agent (
    agent_id INT PRIMARY KEY,
    agent_name VARCHAR(100),
    skillset VARCHAR(100),
    availability VARCHAR(50)
);

CREATE TABLE Ticket (
    ticket_id INT PRIMARY KEY,
    customer_name VARCHAR(100),
    issue_description TEXT,
    status VARCHAR(50),
    priority VARCHAR(50),
    assigned_agent_id INT,
    FOREIGN KEY (assigned_agent_id) REFERENCES Agent(agent_id)
);

CREATE TABLE TicketHistory (
    history_id INT PRIMARY KEY,
    ticket_id INT,
    update_date TIMESTAMP,
    update_description TEXT,
    FOREIGN KEY (ticket_id) REFERENCES Ticket(ticket_id)
);
````
## 3. Add MySQL JDBC Driver
   - Download the MySQL Connector/J from the official MySQL site.
   - Place the .jar file in a lib directory at the root level of the project.
   - Add the .jar file to your project's classpath using your IDE.
## 4. Configure the Database Connection
  - Open the DatabaseConnection.java file located in the customersupport package.
  - Replace the URL, USER, and PASSWORD with your MySQL database credentials:
````bash
private static final String URL = "jdbc:mysql://localhost:3306/customer_support_ticketing";
private static final String USER = "your_username";
private static final String PASSWORD = "your_password";
````
## 5. Compile and Run the Project
   - Open the project in your IDE.
  - Compile the project to ensure there are no errors.
  - Run the App.java file as a Java application.
## 6. Test the Application
  - Use the console interface to interact with the application:
  - Create, view, update, and delete tickets.
  - Create agents, view details, and update agent information.
  - Track ticket resolution, close tickets, and view ticket history.
## 7. Verify Database Changes
   - Open MySQL Workbench or use the command line to verify that the changes made by the application are reflected in the database tables.
# Project Structure
````bash
CustomerSupportTicketing/
|
|__ src/
|    |__ com.cts/
|        |__com.cts.main/
|        |       |__App.java
|        |__com.cts.dao/
|        |       |__TicketDAO.java
|        |       |__AgentDAO.java
|        |       |__com.cts.dao.iml/
|        |                |__AgentDAOIML.java
|        |                |__TicketDAOIML.java
|        |__com.cts.exception/
|        |       |__DatabaseOperationException.java
|        |       |__EntityNotFoundException.java
|        |__com.cts.util/
|                |__DatabaseConnection.java
|
|__ lib/
|    |__ mysql-connector-java-8.0.33.jar
|
|__ README.md
````
# Contact
For any questions or suggestions, please contact:

- Name: Sourav Das
- Email: dassourav845@gmail.com