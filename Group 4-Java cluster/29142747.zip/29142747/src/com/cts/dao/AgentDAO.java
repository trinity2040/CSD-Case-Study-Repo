package com.cts.dao;

import com.cts.exception.DatabaseOperationException;
import com.cts.exception.EntityNotFoundException;

import java.sql.Connection;

public interface AgentDAO {
    void insertAgent(Connection connection, int agentId, String agentName, String skillset, String availability) throws DatabaseOperationException;

    void getAgentDetails(Connection connection, int agentId) throws DatabaseOperationException, EntityNotFoundException;

    void updateAgentAvailability(Connection connection, int agentId, String newAvailability) throws DatabaseOperationException;

    void deleteAgent(Connection connection, int agentId) throws DatabaseOperationException;


}
