package com.cts.dao.iml;


import com.cts.dao.TicketDAO;
import com.cts.exception.DatabaseOperationException;
import com.cts.exception.EntityNotFoundException;

import java.sql.*;

public class TicketDAOIML implements TicketDAO {

    @Override
    public void insertTicket(Connection connection, int ticketId, String customerName, String issueDescription, String status, String priority, int agentId) throws DatabaseOperationException {
        String query = "INSERT INTO Ticket (ticket_id, customer_name, issue_description, status, priority, assigned_agent_id) VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, ticketId);
            pstmt.setString(2, customerName);
            pstmt.setString(3, issueDescription);
            pstmt.setString(4, status);
            pstmt.setString(5, priority);
            pstmt.setInt(6, agentId);

            int rowsInserted = pstmt.executeUpdate();
            System.out.println("Ticket inserted: " + rowsInserted);

            // Log the creation in TicketHistory
            logTicketHistory(connection, ticketId, "Ticket created with status: " + status);

        } catch (SQLException e) {
            throw new DatabaseOperationException("Failed to insert ticket.", e);
        }
    }

    @Override
    public void updateTicketStatus(Connection connection, int ticketId, String newStatus) throws DatabaseOperationException {
        String query = "UPDATE Ticket SET status = ? WHERE ticket_id = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, newStatus);
            pstmt.setInt(2, ticketId);

            int rowsUpdated = pstmt.executeUpdate();
            System.out.println("Ticket status updated: " + rowsUpdated);

            // Log the status update in TicketHistory
            logTicketHistory(connection, ticketId, "Ticket status updated to: " + newStatus);

        } catch (SQLException e) {
            throw new DatabaseOperationException("Failed to update ticket status.", e);
        }
    }

    @Override
    public void deleteTicket(Connection connection, int ticketId) throws DatabaseOperationException {
        String query = "DELETE FROM Ticket WHERE ticket_id = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, ticketId);

            int rowsDeleted = pstmt.executeUpdate();
            System.out.println("Ticket deleted: " + rowsDeleted);

            // Log the deletion in TicketHistory
            logTicketHistory(connection, ticketId, "Ticket deleted");

        } catch (SQLException e) {
            throw new DatabaseOperationException("Failed to delete ticket.", e);
        }
    }

    @Override
    public void getTicketHistory(Connection connection, int ticketId) throws DatabaseOperationException {
        String query = "SELECT * FROM TicketHistory WHERE ticket_id = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, ticketId);
            ResultSet rs = pstmt.executeQuery();

            System.out.println("Ticket History:");
            while (rs.next()) {
                System.out.println("History ID: " + rs.getInt("history_id"));
                System.out.println("Update Date: " + rs.getTimestamp("update_date"));
                System.out.println("Update Description: " + rs.getString("update_description"));
                System.out.println("--------");
            }

        } catch (SQLException e) {
            throw new DatabaseOperationException("Failed to retrieve ticket history.", e);
        }
    }

    // Method to log changes in TicketHistory
    public void logTicketHistory(Connection connection, int ticketId, String updateDescription) throws DatabaseOperationException {
        String query = "INSERT INTO TicketHistory (ticket_id, update_date, update_description) VALUES (?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, ticketId);
            pstmt.setTimestamp(2, new Timestamp(System.currentTimeMillis())); // Current timestamp
            pstmt.setString(3, updateDescription);

            pstmt.executeUpdate();
            System.out.println("Ticket history updated: " + updateDescription);

        } catch (SQLException e) {
            throw new DatabaseOperationException("Failed to log ticket history.", e);
        }
    }
    public void getTicketDetails(Connection connection, int ticketId) throws DatabaseOperationException, EntityNotFoundException {
        // SQL query to retrieve ticket details based on ticket ID
        String query = "SELECT * FROM Ticket WHERE ticket_id = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            // Setting the parameter for the SQL query
            pstmt.setInt(1, ticketId);
            ResultSet rs = pstmt.executeQuery();

            // Processing the result set
            if (rs.next()) {
                // Logging the details of the ticket
                System.out.println("Ticket ID: " + rs.getInt("ticket_id"));
                System.out.println("Customer Name: " + rs.getString("customer_name"));
                System.out.println("Issue Description: " + rs.getString("issue_description"));
                System.out.println("Status: " + rs.getString("status"));
                System.out.println("Priority: " + rs.getString("priority"));
                System.out.println("Assigned Agent ID: " + rs.getInt("assigned_agent_id"));
            } else {
                // Throwing custom exception if ticket is not found
                throw new EntityNotFoundException("Ticket with ID " + ticketId + " not found.");
            }

        } catch (SQLException e) {
            // Handling SQL exceptions and throwing a custom exception
            throw new DatabaseOperationException("Failed to retrieve ticket details.", e);
        }
    }

}
