package com.cts.dao.iml;

import com.cts.dao.AgentDAO;
import com.cts.exception.DatabaseOperationException;
import com.cts.exception.EntityNotFoundException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AgentDAOIML implements AgentDAO {

    @Override
    public void insertAgent(Connection connection, int agentId, String agentName, String skillset, String availability) throws DatabaseOperationException {
        // SQL query to insert a new agent
        String query = "INSERT INTO Agent (agent_id, agent_name, skillset, availability) VALUES (?, ?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            // Setting the parameters for the SQL query
            pstmt.setInt(1, agentId);
            pstmt.setString(2, agentName);
            pstmt.setString(3, skillset);
            pstmt.setString(4, availability);

            // Executing the update and logging the number of rows inserted
            int rowsInserted = pstmt.executeUpdate();
            System.out.println("Agent inserted: " + rowsInserted);

        } catch (SQLException e) {
            // Handling SQL exceptions and wrapping them in a custom exception
            throw new DatabaseOperationException("Failed to insert agent.", e);
        }
    }

    @Override
    public void getAgentDetails(Connection connection, int agentId) throws DatabaseOperationException, EntityNotFoundException {
        // SQL query to retrieve agent details based on agent ID
        String query = "SELECT * FROM Agent WHERE agent_id = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            // Setting the parameter for the SQL query
            pstmt.setInt(1, agentId);
            ResultSet rs = pstmt.executeQuery();

            // Processing the result set
            if (rs.next()) {
                // Logging the details of the agent
                System.out.println("Agent ID: " + rs.getInt("agent_id"));
                System.out.println("Agent Name: " + rs.getString("agent_name"));
                System.out.println("Skillset: " + rs.getString("skillset"));
                System.out.println("Availability: " + rs.getString("availability"));
            } else {
                // Throwing custom exception if agent is not found
                throw new EntityNotFoundException("Agent with ID " + agentId + " not found.");
            }

        } catch (SQLException e) {
            // Handling SQL exceptions and wrapping them in a custom exception
            throw new DatabaseOperationException("Failed to retrieve agent details.", e);
        }
    }

    @Override
    public void updateAgentAvailability(Connection connection, int agentId, String newAvailability) throws DatabaseOperationException {
        // SQL query to update the availability of an agent
        String query = "UPDATE Agent SET availability = ? WHERE agent_id = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            // Setting the parameters for the SQL query
            pstmt.setString(1, newAvailability);
            pstmt.setInt(2, agentId);

            // Executing the update and logging the number of rows updated
            int rowsUpdated = pstmt.executeUpdate();
            System.out.println("Agent availability updated: " + rowsUpdated);

        } catch (SQLException e) {
            // Handling SQL exceptions and wrapping them in a custom exception
            throw new DatabaseOperationException("Failed to update agent availability.", e);
        }
    }

    @Override
    public void deleteAgent(Connection connection, int agentId) throws DatabaseOperationException {
        // SQL query to delete an agent based on agent ID
        String query = "DELETE FROM Agent WHERE agent_id = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            // Setting the parameter for the SQL query
            pstmt.setInt(1, agentId);

            // Executing the update and logging the number of rows deleted
            int rowsDeleted = pstmt.executeUpdate();
            System.out.println("Agent deleted: " + rowsDeleted);

        } catch (SQLException e) {
            // Handling SQL exceptions and wrapping them in a custom exception
            throw new DatabaseOperationException("Failed to delete agent.", e);
        }
    }
}
