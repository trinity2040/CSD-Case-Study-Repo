package com.cts.dao;

import com.cts.exception.DatabaseOperationException;
import com.cts.exception.EntityNotFoundException;

import java.sql.Connection;


public interface TicketDAO {
    void insertTicket(Connection connection, int ticketId, String customerName, String issueDescription, String status, String priority, int agentId) throws DatabaseOperationException;

    void getTicketDetails(Connection connection, int ticketId) throws DatabaseOperationException, EntityNotFoundException;

    void updateTicketStatus(Connection connection, int ticketId, String newStatus) throws DatabaseOperationException;
     void logTicketHistory(Connection connection, int ticketId, String updateDescription) throws DatabaseOperationException;
    void deleteTicket(Connection connection, int ticketId) throws DatabaseOperationException;

    void getTicketHistory(Connection connection, int ticketId) throws DatabaseOperationException;
}
