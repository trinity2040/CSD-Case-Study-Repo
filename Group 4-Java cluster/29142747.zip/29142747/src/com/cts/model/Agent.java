package customersupport;

public class Agent {

    // Fields representing the properties of an agent
    private int agentId; // Unique identifier for the agent
    private String agentName; // Name of the agent
    private String skillset; // The skillset of the agent (e.g., Networking, Software Support)
    private String availability; // Availability status of the agent (e.g., Available, Unavailable)

    // Constructor that initializes all the fields
    public Agent(int agentId, String agentName, String skillset, String availability) {
        this.agentId = agentId;
        this.agentName = agentName;
        this.skillset = skillset;
        this.availability = availability;
    }

    // Default constructor
    public Agent() {}

    // Getter and Setter methods for each field

    public int getAgentId() {
        return agentId;
    }

    public void setAgentId(int agentId) {
        this.agentId = agentId;
    }

    public String getAgentName() {
        return agentName;
    }

    public void setAgentName(String agentName) {
        this.agentName = agentName;
    }

    public String getSkillset() {
        return skillset;
    }

    public void setSkillset(String skillset) {
        this.skillset = skillset;
    }

    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }
}
