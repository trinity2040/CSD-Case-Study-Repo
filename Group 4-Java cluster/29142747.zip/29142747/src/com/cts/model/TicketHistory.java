package com.cts.model;



import java.sql.Timestamp;

public class TicketHistory {

    private int historyId;
    private int ticketId;
    private Timestamp updateDate;
    private String updateDescription;

    // Constructor with all fields except historyId, assuming it's auto-generated
    public TicketHistory(int ticketId, Timestamp updateDate, String updateDescription) {
        this.ticketId = ticketId;
        this.updateDate = updateDate;
        this.updateDescription = updateDescription;
    }

    // Constructor with historyId (if not auto-generated)
    public TicketHistory(int historyId, int ticketId, Timestamp updateDate, String updateDescription) {
        this.historyId = historyId;
        this.ticketId = ticketId;
        this.updateDate = updateDate;
        this.updateDescription = updateDescription;
    }

    // Default constructor
    public TicketHistory() {}

    // Getters and setters

    public int getHistoryId() {
        return historyId;
    }

    public void setHistoryId(int historyId) {
        this.historyId = historyId;
    }

    public int getTicketId() {
        return ticketId;
    }

    public void setTicketId(int ticketId) {
        this.ticketId = ticketId;
    }

    public Timestamp getUpdateDate() {
        return updateDate;
    }

    public void setUpdateDate(Timestamp updateDate) {
        this.updateDate = updateDate;
    }

    public String getUpdateDescription() {
        return updateDescription;
    }

    public void setUpdateDescription(String updateDescription) {
        this.updateDescription = updateDescription;
    }
}

