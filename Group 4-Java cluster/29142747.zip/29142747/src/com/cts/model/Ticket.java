package customersupport;

public class Ticket {

    // Fields representing the properties of a ticket
    private int ticketId; // Unique identifier for the ticket
    private String customerName; // Name of the customer who reported the issue
    private String issueDescription; // Description of the issue the customer is facing
    private String status; // Current status of the ticket (e.g., Open, Closed)
    private String priority; // Priority level of the ticket (e.g., Low, Medium, High)
    private int assignedAgentId; // ID of the agent assigned to handle the ticket

    // Constructor that initializes all the fields
    public Ticket(int ticketId, String customerName, String issueDescription, String status, String priority, int assignedAgentId) {
        this.ticketId = ticketId;
        this.customerName = customerName;
        this.issueDescription = issueDescription;
        this.status = status;
        this.priority = priority;
        this.assignedAgentId = assignedAgentId;
    }

    // Default constructor
    public Ticket() {}

    // Getter and Setter methods for each field

    public int getTicketId() {
        return ticketId;
    }

    public void setTicketId(int ticketId) {
        this.ticketId = ticketId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getIssueDescription() {
        return issueDescription;
    }

    public void setIssueDescription(String issueDescription) {
        this.issueDescription = issueDescription;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public int getAssignedAgentId() {
        return assignedAgentId;
    }

    public void setAssignedAgentId(int assignedAgentId) {
        this.assignedAgentId = assignedAgentId;
    }
}
