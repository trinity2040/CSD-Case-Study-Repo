package com.cts.client;

import com.cts.dao.AgentDAO;
import com.cts.dao.TicketDAO;
import com.cts.dao.iml.AgentDAOIML;
import com.cts.dao.iml.TicketDAOIML;
import com.cts.exception.DatabaseOperationException;
import com.cts.exception.EntityNotFoundException;
import com.cts.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class App {

    // Scanner to read user input
    private static final Scanner scanner = new Scanner(System.in);

    // DAO instances to interact with the database
    private static final TicketDAO ticketDAO = new TicketDAOIML();
    private static final AgentDAO agentDAO = new AgentDAOIML();

    public static void main(String[] args) {
        // Establish a connection to the database
        Connection connection = DatabaseConnection.getConnection();

        // Check if the connection was successful
        if (connection != null) {
            while (true) { // Infinite loop to keep the program running until the user decides to exit
                showMainMenu(); // Display the main menu options
                int choice = Integer.parseInt(scanner.nextLine()); // Get the user's menu choice

                // Handle the user's menu choice
                switch (choice) {
                    case 1:
                        handleTicketManagement(connection); // Ticket management operations
                        break;
                    case 2:
                        handleAgentAssignment(connection); // Agent assignment operations
                        break;
                    case 3:
                        handleTicketResolution(connection); // Ticket resolution operations
                        break;
                    case 4:
                        System.out.println("Exiting the program. Goodbye!");
                        closeConnection(connection); // Close the database connection
                        return; // Exit the program
                    default:
                        System.out.println("Invalid choice. Please choose a number between 1 and 4.");
                }
            }
        }
    }

    // Display the main menu options
    private static void showMainMenu() {
        System.out.println("\n--- Main Menu ---");
        System.out.println("1. Ticket Management");
        System.out.println("2. Agent Assignment");
        System.out.println("3. Ticket Resolution");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    // Handle ticket management operations
    private static void handleTicketManagement(Connection connection) {
        while (true) { // Loop to keep the ticket management menu running
            showTicketManagementMenu(); // Display the ticket management menu
            int choice = Integer.parseInt(scanner.nextLine()); // Get the user's menu choice

            // Handle the user's choice for ticket management
            switch (choice) {
                case 1:
                    createTicket(connection); // Create a new ticket
                    break;
                case 2:
                    viewTicketDetails(connection); // View details of an existing ticket
                    break;
                case 3:
                    updateTicketInformation(connection); // Update ticket information
                    break;
                case 4:
                    deleteTicket(connection); // Delete a ticket
                    break;
                case 5:
                    return; // Go back to the main menu
                default:
                    System.out.println("Invalid choice. Please choose a number between 1 and 5.");
            }
        }
    }

    // Display the ticket management menu options
    private static void showTicketManagementMenu() {
        System.out.println("\n--- Ticket Management ---");
        System.out.println("1. Create New Ticket");
        System.out.println("2. View Ticket Details");
        System.out.println("3. Update Ticket Information");
        System.out.println("4. Delete Ticket");
        System.out.println("5. Back to Main Menu");
        System.out.print("Enter your choice: ");
    }

    // Create a new ticket in the database
    private static void createTicket(Connection connection) {
        try {
            // Prompt the user for ticket details
            System.out.print("Enter ticket ID: ");
            int ticketId = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter customer name: ");
            String customerName = scanner.nextLine();
            System.out.print("Enter issue description: ");
            String issueDescription = scanner.nextLine();
            System.out.print("Enter status (Open/In Progress/Closed): ");
            String status = scanner.nextLine();
            System.out.print("Enter priority (Low/Medium/High): ");
            String priority = scanner.nextLine();
            System.out.print("Enter assigned agent ID: ");
            int agentId = Integer.parseInt(scanner.nextLine());

            // Create a Ticket object with the provided details
            customersupport.Ticket ticket = new customersupport.Ticket(ticketId, customerName, issueDescription, status, priority, agentId);

            // Insert the ticket into the database using the DAO
            ticketDAO.insertTicket(connection, ticket.getTicketId(), ticket.getCustomerName(),
                    ticket.getIssueDescription(), ticket.getStatus(),
                    ticket.getPriority(), ticket.getAssignedAgentId());
        } catch (DatabaseOperationException e) {
            // Handle any database operation exceptions
            System.err.println("Error creating ticket: " + e.getMessage());
        }
    }

    // View details of a specific ticket
    private static void viewTicketDetails(Connection connection) {
        try {
            System.out.print("Enter ticket ID: ");
            int ticketId = Integer.parseInt(scanner.nextLine());

            // Retrieve and display the details of the ticket
            ticketDAO.getTicketDetails(connection, ticketId);
        } catch (DatabaseOperationException | EntityNotFoundException e) {
            System.err.println("Error viewing ticket details: " + e.getMessage());
        }
    }

    // Update the status of an existing ticket
    private static void updateTicketInformation(Connection connection) {
        try {
            System.out.print("Enter ticket ID: ");
            int ticketId = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter new status (Open/In Progress/Closed): ");
            String newStatus = scanner.nextLine();

            // Update the ticket's status in the database using the DAO
            ticketDAO.updateTicketStatus(connection, ticketId, newStatus);
        } catch (DatabaseOperationException e) {
            System.err.println("Error updating ticket: " + e.getMessage());
        }
    }

    // Delete a specific ticket from the database
    private static void deleteTicket(Connection connection) {
        try {
            System.out.print("Enter ticket ID: ");
            int ticketId = Integer.parseInt(scanner.nextLine());

            // Delete the ticket from the database using the DAO
            ticketDAO.deleteTicket(connection, ticketId);
        } catch (DatabaseOperationException e) {
            System.err.println("Error deleting ticket: " + e.getMessage());
        }
    }

    // Handle agent assignment operations
    private static void handleAgentAssignment(Connection connection) {
        while (true) {
            showAgentAssignmentMenu(); // Display the agent assignment menu
            int choice = Integer.parseInt(scanner.nextLine());

            // Handle the user's choice for agent assignment
            switch (choice) {
                case 1:
                    createAgent(connection); // Create a new agent
                    break;
                case 2:
                    viewAgentDetails(connection); // View details of an existing agent
                    break;
                case 3:
                    updateAgentInformation(connection); // Update agent information
                    break;
                case 4:
                    return; // Go back to the main menu
                default:
                    System.out.println("Invalid choice. Please choose a number between 1 and 4.");
            }
        }
    }

    // Display the agent assignment menu options
    private static void showAgentAssignmentMenu() {
        System.out.println("\n--- Agent Assignment ---");
        System.out.println("1. Create New Agent");
        System.out.println("2. View Agent Details");
        System.out.println("3. Update Agent Information");
        System.out.println("4. Back to Main Menu");
        System.out.print("Enter your choice: ");
    }

    // Create a new agent in the database
    private static void createAgent(Connection connection) {
        try {
            System.out.print("Enter agent ID: ");
            int agentId = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter agent name: ");
            String agentName = scanner.nextLine();
            System.out.print("Enter skillset: ");
            String skillset = scanner.nextLine();
            System.out.print("Enter availability (Available/Unavailable): ");
            String availability = scanner.nextLine();

            // Create an Agent object with the provided details
            customersupport.Agent agent = new customersupport.Agent(agentId, agentName, skillset, availability);

            // Insert the agent into the database using the DAO
            agentDAO.insertAgent(connection, agent.getAgentId(), agent.getAgentName(),
                    agent.getSkillset(), agent.getAvailability());
        } catch (DatabaseOperationException e) {
            System.err.println("Error creating agent: " + e.getMessage());
        }
    }

    // View details of a specific agent
    private static void viewAgentDetails(Connection connection) {
        try {
            System.out.print("Enter agent ID: ");
            int agentId = Integer.parseInt(scanner.nextLine());

            // Retrieve and display the details of the agent
            agentDAO.getAgentDetails(connection, agentId);
        } catch (DatabaseOperationException | EntityNotFoundException e) {
            System.err.println("Error viewing agent details: " + e.getMessage());
        }
    }

    // Update the availability status of an existing agent
    private static void updateAgentInformation(Connection connection) {
        try {
            System.out.print("Enter agent ID: ");
            int agentId = Integer.parseInt(scanner.nextLine());
            System.out.print("Enter new availability (Available/Unavailable): ");
            String newAvailability = scanner.nextLine();

            // Update the agent's availability in the database using the DAO
            agentDAO.updateAgentAvailability(connection, agentId, newAvailability);
        } catch (DatabaseOperationException e) {
            System.err.println("Error updating agent: " + e.getMessage());
        }
    }

    // Handle ticket resolution operations
    private static void handleTicketResolution(Connection connection) {
        while (true) {
            showTicketResolutionMenu(); // Display the ticket resolution menu
            int choice = Integer.parseInt(scanner.nextLine());

            // Handle the user's choice for ticket resolution
            switch (choice) {
                case 1:
                    trackTicketResolutionStatus(connection); // Track the resolution status of a ticket
                    break;
                case 2:
                    closeTicket(connection); // Close a ticket
                    break;
                case 3:
                    viewTicketHistory(connection); // View the history of a ticket
                    break;
                case 4:
                    return; // Go back to the main menu
                default:
                    System.out.println("Invalid choice. Please choose a number between 1 and 4.");
            }
        }
    }

    // Display the ticket resolution menu options
    private static void showTicketResolutionMenu() {
        System.out.println("\n--- Ticket Resolution ---");
        System.out.println("1. Track Ticket Resolution Status");
        System.out.println("2. Close Ticket");
        System.out.println("3. View Ticket History");
        System.out.println("4. Back to Main Menu");
        System.out.print("Enter your choice: ");
    }

    // Track the resolution status of a specific ticket
    private static void trackTicketResolutionStatus(Connection connection) {
        try {
            System.out.print("Enter ticket ID: ");
            int ticketId = Integer.parseInt(scanner.nextLine());

            // Retrieve and display the current status of the ticket
            ticketDAO.getTicketDetails(connection, ticketId);
        } catch (DatabaseOperationException | EntityNotFoundException e) {
            System.err.println("Error tracking ticket resolution: " + e.getMessage());
        }
    }

    // Close a specific ticket by updating its status to "Closed"
    private static void closeTicket(Connection connection) {
        try {
            System.out.print("Enter ticket ID: ");
            int ticketId = Integer.parseInt(scanner.nextLine());
            String newStatus = "Closed";

            // Update the ticket's status to "Closed" using the DAO
            ticketDAO.updateTicketStatus(connection, ticketId, newStatus);
        } catch (DatabaseOperationException e) {
            System.err.println("Error closing ticket: " + e.getMessage());
        }
    }

    // View the history of a specific ticket
    private static void viewTicketHistory(Connection connection) {
        try {
            System.out.print("Enter ticket ID: ");
            int ticketId = Integer.parseInt(scanner.nextLine());

            // Retrieve and display the history of the ticket
            ticketDAO.getTicketHistory(connection, ticketId);
        } catch (DatabaseOperationException e) {
            System.err.println("Error viewing ticket history: " + e.getMessage());
        }
    }

    // Close the database connection when exiting the program
    private static void closeConnection(Connection connection) {
        try {
            connection.close(); // Close the connection
            System.out.println("Connection closed.");
        } catch (SQLException e) {
            System.err.println("Failed to close connection: " + e.getMessage());
        }
    }
}
