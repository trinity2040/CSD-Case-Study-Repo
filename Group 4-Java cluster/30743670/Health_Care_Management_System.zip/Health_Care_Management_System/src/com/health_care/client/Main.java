//package com.health_care.client;
//
//public class Main {
//    public static void main(String[] args) {
//
//    }
//}

package com.health_care.client;

import com.health_care.dao.PatientDao;
import com.health_care.dao.DoctorDao;
import com.health_care.dao.AppointmentDao;
import com.health_care.dao.impl.PatientDaoImpl;
import com.health_care.dao.impl.DoctorDaoImpl;
import com.health_care.dao.impl.AppointmentDaoImpl;
import com.health_care.exception.AppointmentNotFoundException;
import com.health_care.exception.DoctorNotFoundException;
import com.health_care.exception.PatientNotFoundException;
import com.health_care.model.Patient;
import com.health_care.model.Doctor;
import com.health_care.exception.CustomException;
import com.health_care.model.Appointment;

import java.util.List;
import java.util.Scanner;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;



public class Main {
    public static void main(String[] args) throws CustomException {
        Scanner scanner = new Scanner(System.in);
        PatientDao patientDao = new PatientDaoImpl();
        DoctorDao doctorDao = new DoctorDaoImpl();
        AppointmentDao appointmentDao = new AppointmentDaoImpl();
        int choice;

        do {
            System.out.println("====================================");
            System.out.println(" Health Care Management System ");
            System.out.println("====================================");
            System.out.println("1. Patient Management");
            System.out.println("2. Doctor Management");
            System.out.println("3. Appointment Management");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    managePatients(scanner, patientDao);
                    break;
                case 2:
                    manageDoctors(scanner, doctorDao);
                    break;
                case 3:
                    manageAppointments(scanner, appointmentDao);
                    break;
                case 4:
                    System.out.println("Exiting the system. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 4);
    }

    private static void managePatients(Scanner scanner, PatientDao patientDao) throws CustomException {
        int choice;
        do {
            System.out.println("---- Patient Management ----");
            System.out.println("1. Add Patient");
            System.out.println("2. View Patient by ID");
            System.out.println("3. View All Patients");
            System.out.println("4. Update Patient");
            System.out.println("5. Delete Patient");
            System.out.println("6. Back to Main Menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addPatient(scanner, patientDao);
                    break;
                case 2:
                    viewPatientById(scanner, patientDao);
                    break;
                case 3:
                    viewAllPatients(patientDao);
                    break;
                case 4:
                    updatePatient(scanner, patientDao);
                    break;
                case 5:
                    deletePatient(scanner, patientDao);
                    break;
                case 6:
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 6);
    }

    private static void manageDoctors(Scanner scanner, DoctorDao doctorDao) {
        int choice;
        do {
            System.out.println("---- Doctor Management ----");
            System.out.println("1. Add Doctor");
            System.out.println("2. View Doctor by ID");
            System.out.println("3. View All Doctors");
            System.out.println("4. Update Doctor");
            System.out.println("5. Delete Doctor");
            System.out.println("6. Back to Main Menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addDoctor(scanner, doctorDao);
                    break;
                case 2:
                    viewDoctorById(scanner, doctorDao);
                    break;
                case 3:
                    viewAllDoctors(doctorDao);
                    break;
                case 4:
                    updateDoctor(scanner, doctorDao);
                    break;
                case 5:
                    deleteDoctor(scanner, doctorDao);
                    break;
                case 6:
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 6);
    }

    private static void manageAppointments(Scanner scanner, AppointmentDao appointmentDao) throws CustomException {
        int choice;
        do {
            System.out.println("---- Appointment Management ----");
            System.out.println("1. Add Appointment");
            System.out.println("2. View Appointment by ID");
            System.out.println("3. View All Appointments");
            System.out.println("4. Update Appointment");
            System.out.println("5. Delete Appointment");
            System.out.println("6. Back to Main Menu");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    addAppointment(scanner, appointmentDao);
                    break;
                case 2:
                    viewAppointmentById(scanner, appointmentDao);
                    break;
                case 3:
                    viewAllAppointments(appointmentDao);
                    break;
                case 4:
                    updateAppointment(scanner, appointmentDao);
                    break;
                case 5:
                    deleteAppointment(scanner, appointmentDao);
                    break;
                case 6:
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 6);
    }

    // CRUD operations for Patients
    private static void addPatient(Scanner scanner, PatientDao patientDao) throws CustomException{
        System.out.println("Enter patient details:");
        System.out.print("ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Date of Birth (YYYY-MM-DD): ");
        String dob = scanner.nextLine();
        System.out.print("Gender: ");
        String gender = scanner.nextLine();
        System.out.print("Address: ");
        String address = scanner.nextLine();

        Patient patient = new Patient(id, name, dob, gender, address);
        patientDao.createPatient(patient);
        System.out.println("Patient added successfully.");
    }

    private static void viewPatientById(Scanner scanner, PatientDao patientDao) throws CustomException {
        System.out.print("Enter patient ID: ");
        int id = scanner.nextInt();
        Patient p1 = patientDao.getPatientById(id);
        if (p1 != null) {
//            System.out.println("Patient Details: " + patient);
            // Display patient information
            System.out.println("+------------+--------------------+--------------+------------+--------------------+");
            System.out.println("| Patient Id | Name               | Date of Birth | Gender     | Address            |");
            System.out.println("+------------+--------------------+--------------+------------+--------------------+");
            int pid = p1.getPatientId();
            String name = p1.getName();
            String dob = p1.getDateOfBirth().toString();  // Assuming Date of Birth is a Date object
            String gender = p1.getGender();
            String address = p1.getAddress();

            System.out.printf("| %-10s | %-18s | %-12s | %-10s | %-18s |\n", pid, name, dob, gender, address);
            System.out.println("+------------+--------------------+--------------+------------+--------------------+");
        } else {
            System.out.println("Patient not found.");
        }
    }

    private static void viewAllPatients(PatientDao patientDao) throws CustomException {
        List<Patient> patients = patientDao.getAllPatients();
        if (patients.isEmpty()) {
            System.out.println("No patients found.");
        } else {
            System.out.println("List of all patients:");
            System.out.println("+------------+--------------------+--------------+------------+--------------------+");
            System.out.println("| Patient Id | Name               | Date of Birth | Gender     | Address            |");
            System.out.println("+------------+--------------------+--------------+------------+--------------------+");

            for (Patient p1 : patients) {
                int id = p1.getPatientId();
                String name = p1.getName();
                String dob = p1.getDateOfBirth().toString();  // Assuming Date of Birth is a Date object
                String gender = p1.getGender();
                String address = p1.getAddress();

                System.out.printf("| %-10s | %-18s | %-12s | %-10s | %-18s |\n", id, name, dob, gender, address);
                System.out.println("+------------+--------------------+--------------+------------+--------------------+");
            }

        }
    }

    private static void updatePatient(Scanner scanner, PatientDao patientDao) throws CustomException {
        System.out.print("Enter patient ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // consume newline
        Patient existingPatient = patientDao.getPatientById(id);
        if (existingPatient != null) {
            System.out.print("Enter new name (or press Enter to skip): ");
            String name = scanner.nextLine();
            if (!name.isEmpty()) {
                existingPatient.setName(name);
            }
            System.out.print("Enter new Date of Birth (YYYY-MM-DD) (or press Enter to skip): ");
            String dob = scanner.nextLine();
            if (!dob.isEmpty()) {
                existingPatient.setDateOfBirth(dob);
            }
            System.out.print("Enter new Gender (or press Enter to skip): ");
            String gender = scanner.nextLine();
            if (!gender.isEmpty()) {
                existingPatient.setGender(gender);
            }
            System.out.print("Enter new Address (or press Enter to skip): ");
            String address = scanner.nextLine();
            if (!address.isEmpty()) {
                existingPatient.setAddress(address);
            }
            patientDao.updatePatient(existingPatient);
            System.out.println("Patient updated successfully.");
        } else {
            System.out.println("Patient not found.");
        }
    }

    private static void deletePatient(Scanner scanner, PatientDao patientDao) {
        System.out.print("Enter patient ID to delete: ");
        int id = scanner.nextInt();

        try {
            boolean exists = patientDao.patientExists(id);
            if (!exists) {
                throw new PatientNotFoundException("Patient ID " + id + " does not exist.");
            }
            patientDao.deletePatient(id);
            System.out.println("Patient deleted successfully.");
        } catch (PatientNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }

    }

    // CRUD operations for Doctors
    private static void addDoctor(Scanner scanner, DoctorDao doctorDao) {
        System.out.println("Enter doctor details:");
        System.out.print("ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Name: ");
        String name = scanner.nextLine();
        System.out.print("Specialization: ");
        String specialization = scanner.nextLine();
        System.out.print("Contact Number: ");
        String contactNumber = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();

        Doctor doctor = new Doctor(id, name, specialization, contactNumber, email);
        doctorDao.createDoctor(doctor);
        System.out.println("Doctor added successfully.");
    }

    private static void viewDoctorById(Scanner scanner, DoctorDao doctorDao) {
        System.out.print("Enter doctor ID: ");
        int id = scanner.nextInt();
        Doctor d1 = doctorDao.getDoctorById(id);
        if (d1 != null) {
//            System.out.println("Doctor Details: " + doctor);
            System.out.println("+------------+--------------------+--------------+------------+--------------------+");
            System.out.println("| Doctor Id | Name               | Specialization  | Contact Num     | Email       |");
            System.out.println("+------------+--------------------+--------------+------------+--------------------+");
            int did = d1.getDoctorId();
            String name = d1.getName();
            String specialization = d1.getSpecialization();
            String contactNum  = d1.getContactNumber();
            String email = d1.getEmail();

            System.out.printf("| %-10s | %-18s | %-12s | %-10s | %-18s |\n", did, name, specialization, contactNum, email);
            System.out.println("+------------+--------------------+--------------+------------+--------------------+");
        } else {
            System.out.println("Doctor not found.");
        }
    }

    private static void viewAllDoctors(DoctorDao doctorDao) {
        List<Doctor> doctors = doctorDao.getAllDoctors();
        if (doctors.isEmpty()) {
            System.out.println("No doctors found.");
        } else {
            System.out.println("List of all Doctors:");
            System.out.println("+------------+--------------------+--------------+------------+--------------------+");
            System.out.println("| Doctor Id | Name               | Specialization  | Contact Num     | Email       |");
            System.out.println("+------------+--------------------+--------------+------------+--------------------+");

            for (Doctor d1 : doctors) {
                int id = d1.getDoctorId();
                String name = d1.getName();
                String specialization = d1.getSpecialization();  // Assuming Date of Birth is a Date object
                String contactNum  = d1.getContactNumber();
                String email = d1.getEmail();

                System.out.printf("| %-10s | %-18s | %-12s | %-10s | %-18s |\n", id, name, specialization, contactNum, email);
                System.out.println("+------------+--------------------+--------------+------------+--------------------+");
            }

        }
    }

    private static void updateDoctor(Scanner scanner, DoctorDao doctorDao) {
        System.out.print("Enter doctor ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // consume newline
        Doctor existingDoctor = doctorDao.getDoctorById(id);
        if (existingDoctor != null) {
            System.out.print("Enter new name (or press Enter to skip): ");
            String name = scanner.nextLine();
            if (!name.isEmpty()) {
                existingDoctor.setName(name);
            }
            System.out.print("Enter new Specialization (or press Enter to skip): ");
            String specialization = scanner.nextLine();
            if (!specialization.isEmpty()) {
                existingDoctor.setSpecialization(specialization);
            }
            System.out.print("Enter new Contact Number (or press Enter to skip): ");
            String contactNumber = scanner.nextLine();
            if (!contactNumber.isEmpty()) {
                existingDoctor.setContactNumber(contactNumber);
            }
            System.out.print("Enter new Email (or press Enter to skip): ");
            String email = scanner.nextLine();
            if (!email.isEmpty()) {
                existingDoctor.setEmail(email);
            }
            doctorDao.updateDoctor(existingDoctor);
            System.out.println("Doctor updated successfully.");
        } else {
            System.out.println("Doctor not found.");
        }
    }

    private static void deleteDoctor(Scanner scanner, DoctorDao doctorDao) {
        System.out.print("Enter doctor ID to delete: ");
        int id = scanner.nextInt();

        try {
            boolean exists = doctorDao.doctorExists(id);
            if (!exists) {
                throw new DoctorNotFoundException("Doctor ID " + id + " does not exist.");
            }
            doctorDao.deleteDoctor(id);
            System.out.println("Doctor deleted successfully.");
        } catch (DoctorNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }

    }

    // CRUD operations for Appointments
    private static void addAppointment(Scanner scanner, AppointmentDao appointmentDao) throws CustomException{
        System.out.println("Enter appointment details:");
        System.out.print("ID: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Patient ID: ");
        int patientId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Doctor ID: ");
        int doctorId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Date (YYYY-MM-DD): ");
        String date = scanner.nextLine();
        System.out.print("Time (HH:MM): ");
        String time = scanner.nextLine();
        // Convert date string to LocalDate
        LocalDate appointmentDate = null;
        try {
            appointmentDate = LocalDate.parse(date, DateTimeFormatter.ISO_LOCAL_DATE);
        } catch (DateTimeParseException e) {
            System.out.println("Invalid date format. Please use YYYY-MM-DD.");
            return;
        }

        Appointment appointment = new Appointment(id, patientId, doctorId, appointmentDate, time);
        appointmentDao.createAppointment(appointment);
        System.out.println("Appointment added successfully.");

    }

    private static void viewAppointmentById(Scanner scanner, AppointmentDao appointmentDao) {
        System.out.print("Enter appointment ID: ");
        int id = scanner.nextInt();
        Appointment appointment = appointmentDao.getAppointmentById(id);
        if (appointment != null) {

            System.out.println("+----------------+------------+------------+------------------+----------------+---------");
            System.out.println("| Appointment Id | Patient Id | Doctor Id  | Appointment Date |Appointment time| Status |");
            System.out.println("+----------------+------------+------------+------------------+----------------+---------");
            int a_id = appointment.getAppointment_id();
            int p_id = appointment.getPatient_id();
            int d_id = appointment.getDoctor_id();  // Assuming Date of Birth is a Date object
            String date  = appointment.getAppointment_date().toString();
            String time = appointment.getAppointment_time().toString();
            String status = appointment.getStatus(); // New field

            System.out.printf("| %-10s | %-18s | %-12s | %-10s | %-18s |\n", a_id, p_id, d_id, date, time,status);
            System.out.println("+------------+--------------------+--------------+------------+--------------------+");
        } else {
            System.out.println("Appointment not found.");
        }
    }

    private static void viewAllAppointments(AppointmentDao appointmentDao) {
        List<Appointment> appointments = appointmentDao.getAllAppointments();
        if (appointments.isEmpty()) {
            System.out.println("No appointments found.");
        } else {
            System.out.println("List of all Appointments:");
            System.out.println("+----------------+------------+------------+------------------+----------------+---------+");
            System.out.println("| Appointment Id | Patient Id | Doctor Id  | Appointment Date | Appointment Time | Status  |");
            System.out.println("+----------------+------------+------------+------------------+----------------+---------+");

            for (Appointment d1 : appointments) {
                int a_id = d1.getAppointment_id();
                int p_id = d1.getPatient_id();
                int d_id = d1.getDoctor_id();
                String date = d1.getAppointment_date().toString();
                String time = d1.getAppointment_time().toString();
                String status = d1.getStatus();

                System.out.printf("| %-14d | %-10d | %-10d | %-16s | %-14s | %-8s |\n", a_id, p_id, d_id, date, time, status);
                System.out.println("+----------------+------------+------------+------------------+----------------+---------+");
            }
        }
    }

    private static void updateAppointment(Scanner scanner, AppointmentDao appointmentDao) {
        System.out.print("Enter appointment ID to update: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // consume newline
        Appointment existingAppointment = appointmentDao.getAppointmentById(id);
        if (existingAppointment != null) {
            System.out.print("Enter new Patient ID (or press Enter to skip): ");
            String patientIdStr = scanner.nextLine();
            if (!patientIdStr.isEmpty()) {
                existingAppointment.setPatient_id(Integer.parseInt(patientIdStr));
            }
            System.out.print("Enter new Doctor ID (or press Enter to skip): ");
            String doctorIdStr = scanner.nextLine();
            if (!doctorIdStr.isEmpty()) {
                existingAppointment.setDoctor_id(Integer.parseInt(doctorIdStr));
            }
            System.out.print("Enter new Date (YYYY-MM-DD) (or press Enter to skip): ");
            String date = scanner.nextLine();
            if (!date.isEmpty()) {
                try {
                    LocalDate appointmentDate = LocalDate.parse(date, DateTimeFormatter.ISO_LOCAL_DATE);
                    existingAppointment.setAppointment_date(appointmentDate);
                } catch (DateTimeParseException e) {
                    System.out.println("Invalid date format. Please use YYYY-MM-DD.");
                    return;
                }
            }
            System.out.print("Enter new Time (HH:MM) (or press Enter to skip): ");
            String time = scanner.nextLine();
            if (!time.isEmpty()) {
                existingAppointment.setAppointment_time(time);
            }

            System.out.print("Enter new Status (or press Enter to skip): ");
            String status = scanner.nextLine();
            if (!status.isEmpty()) {
                existingAppointment.setStatus(status);
            }


            appointmentDao.updateAppointment(existingAppointment);
            System.out.println("Appointment updated successfully.");
        } else {
            System.out.println("Appointment not found.");
        }
    }

    private static void deleteAppointment(Scanner scanner, AppointmentDao appointmentDao) {
        System.out.print("Enter appointment ID to delete: ");
        int id = scanner.nextInt();
        try {
            boolean exists = appointmentDao.appointmentExists(id);
            if (!exists) {
                throw new AppointmentNotFoundException("Appointment ID " + id + " does not exist.");
            }
            appointmentDao.deleteAppointment(id);
            System.out.println("Appointment deleted successfully.");
        } catch (AppointmentNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }

    }
}
