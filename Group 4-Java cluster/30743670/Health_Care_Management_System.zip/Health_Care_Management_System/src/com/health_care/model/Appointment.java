package com.health_care.model;

import java.time.LocalDate;

public class Appointment {
    private int appointment_id;
    private int patient_id;
    private int doctor_id;
    private LocalDate appointment_date;
    private String appointment_time;
    private String status;

    public Appointment() {}

    public Appointment(int appointment_id, int patient_id, int doctor_id, LocalDate appointment_date, String appointment_time, String status) {
        this.appointment_id = appointment_id;
        this.patient_id = patient_id;
        this.doctor_id = doctor_id;
        this.appointment_date = appointment_date;
        this.appointment_time = appointment_time;
        this.status = status;
    }

    public Appointment(int id, int patientId, int doctorId, LocalDate appointmentDate, String appointment_time) {
        this.appointment_id = id;
        this.patient_id = patientId;
        this.doctor_id = doctorId;
        this.appointment_date = appointmentDate;
        this.appointment_time = appointment_time;
    }

    public int getAppointment_id() {
        return appointment_id;
    }

    public void setAppointment_id(int appointment_id) {
        this.appointment_id = appointment_id;
    }

    public int getPatient_id() {
        return patient_id;
    }

    public void setPatient_id(int patient_id) {
        this.patient_id = patient_id;
    }

    public int getDoctor_id() {
        return doctor_id;
    }

    public void setDoctor_id(int doctor_id) {
        this.doctor_id = doctor_id;
    }

    public LocalDate getAppointment_date() {
        return appointment_date;
    }

    public void setAppointment_date(LocalDate appointment_date) {
        this.appointment_date = appointment_date;
    }

    public String getAppointment_time() {
        return appointment_time;
    }

    public void setAppointment_time(String appointment_time) {
        this.appointment_time = appointment_time;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
