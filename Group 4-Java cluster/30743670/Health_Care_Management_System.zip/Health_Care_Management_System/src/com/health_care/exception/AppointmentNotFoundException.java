package com.health_care.exception;

public class AppointmentNotFoundException extends Exception{
    public AppointmentNotFoundException(String message) {
        super(message);
    }
}

