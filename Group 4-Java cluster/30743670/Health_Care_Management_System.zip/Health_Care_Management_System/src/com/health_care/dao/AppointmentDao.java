package com.health_care.dao;

import com.health_care.model.Appointment;
import com.health_care.exception.CustomException;
import com.health_care.exception.AppointmentNotFoundException;
import java.util.List;

public interface AppointmentDao {
    void createAppointment(Appointment appointment) throws CustomException;
    Appointment getAppointmentById(int id);
    List<Appointment> getAllAppointments();
    void updateAppointment(Appointment appointment);
    void deleteAppointment(int id) throws  AppointmentNotFoundException;
    boolean appointmentExists(int id);
}