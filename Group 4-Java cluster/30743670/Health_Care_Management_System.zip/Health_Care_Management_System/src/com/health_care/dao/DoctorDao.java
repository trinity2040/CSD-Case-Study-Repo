package com.health_care.dao;

import com.health_care.exception.DoctorNotFoundException;
import com.health_care.model.Doctor;
import java.util.List;

public interface DoctorDao {
    void createDoctor(Doctor doctor);
    Doctor getDoctorById(int id);
    List<Doctor> getAllDoctors();
    void updateDoctor(Doctor doctor);
    void deleteDoctor(int id) throws DoctorNotFoundException;

    //  method to check if a doctor exists
    boolean doctorExists(int id);
}