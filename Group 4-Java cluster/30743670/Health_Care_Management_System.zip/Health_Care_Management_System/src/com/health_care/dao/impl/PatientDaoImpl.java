package com.health_care.dao.impl;

import com.health_care.dao.PatientDao;
import com.health_care.db_connect.DBConnection;
import com.health_care.exception.CustomException;
import com.health_care.exception.PatientNotFoundException;
import com.health_care.model.Patient;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PatientDaoImpl implements PatientDao {

    @Override
    public void createPatient(Patient patient) throws CustomException {
        String sql = "INSERT INTO patient (patient_id, name, date_of_birth, gender, address) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, patient.getPatientId());
            pstmt.setString(2, patient.getName());
            pstmt.setString(3, patient.getDateOfBirth());
            pstmt.setString(4, patient.getGender());
            pstmt.setString(5, patient.getAddress());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new CustomException("Database operation failed", e);
//            e.printStackTrace();
        }
    }

    @Override
    public Patient getPatientById(int patientId) throws CustomException {
        String sql = "SELECT * FROM patient WHERE patient_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, patientId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Patient(
                        rs.getInt("patient_id"),
                        rs.getString("name"),
                        rs.getString("date_of_birth"),
                        rs.getString("gender"),
                        rs.getString("address")
                );
            }
        } catch (SQLException e) {
            throw new CustomException("Database operation failed", e);
//            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Patient> getAllPatients() throws CustomException{
        List<Patient> patients = new ArrayList<>();
        String sql = "SELECT * FROM patient";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                patients.add(new Patient(
                        rs.getInt("patient_id"),
                        rs.getString("name"),
                        rs.getString("date_of_birth"),
                        rs.getString("gender"),
                        rs.getString("address")
                ));
            }
        } catch (SQLException e) {
            throw new CustomException("Database operation failed", e);
//            e.printStackTrace();
        }
        return patients;
    }

    @Override
    public void updatePatient(Patient patient) throws CustomException {
        String sql = "UPDATE patient SET name = ?, date_of_birth = ?, gender = ?, address = ? WHERE patient_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, patient.getName());
            pstmt.setString(2, patient.getDateOfBirth());
            pstmt.setString(3, patient.getGender());
            pstmt.setString(4, patient.getAddress());
            pstmt.setInt(5, patient.getPatientId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new CustomException("Database operation failed", e);
        }
    }

    @Override
    public boolean patientExists(int id) {
        String sql = "SELECT COUNT(*) FROM patient WHERE patient_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public void deletePatient(int id) throws PatientNotFoundException {
        if (!patientExists(id)) {
            throw new PatientNotFoundException("Patient ID " + id + " does not exist.");
        }

        String sql = "DELETE FROM patient WHERE patient_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
