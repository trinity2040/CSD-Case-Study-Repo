package com.health_care.dao;

import com.health_care.exception.PatientNotFoundException;
import com.health_care.model.Patient;
import com.health_care.exception.CustomException;
import java.util.List;

public interface PatientDao {
    void createPatient(Patient patient) throws CustomException;
    Patient getPatientById(int id) throws CustomException;
    List<Patient> getAllPatients() throws CustomException;
    void updatePatient(Patient patient) throws CustomException;
    void deletePatient(int id) throws PatientNotFoundException;

    //  method to check if a patient exists
    boolean patientExists(int id) ;
}