package com.health_care.dao.impl;

import com.health_care.dao.AppointmentDao;
import com.health_care.db_connect.DBConnection;
import com.health_care.exception.AppointmentNotFoundException;
import com.health_care.exception.CustomException;
import com.health_care.model.Appointment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class AppointmentDaoImpl implements AppointmentDao {

    @Override
    public void createAppointment(Appointment appointment) throws CustomException  {
        String sql = "INSERT INTO appointment (appointment_id, patient_id, doctor_id, appointment_date, appointment_time,status) VALUES (?, ?, ?, ?, ?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, appointment.getAppointment_id());
            pstmt.setInt(2, appointment.getPatient_id());
            pstmt.setInt(3, appointment.getDoctor_id());
            pstmt.setDate(4, java.sql.Date.valueOf(appointment.getAppointment_date()));
            pstmt.setString(5, appointment.getAppointment_time());
            pstmt.setString(6, "Scheduled");
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new CustomException("Failed to create appointment", e);
        }
    }


    @Override
    public Appointment getAppointmentById(int id) {
        String sql = "SELECT * FROM appointment WHERE appointment_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Appointment(
                        rs.getInt("appointment_id"),
                        rs.getInt("patient_id"),
                        rs.getInt("doctor_id"),
                        rs.getDate("appointment_date").toLocalDate(),
                        rs.getString("appointment_time"),
                        rs.getString("status")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Appointment> getAllAppointments() {
        List<Appointment> appointments = new ArrayList<>();
        String sql = "SELECT * FROM appointment";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            while (rs.next()) {
                appointments.add(new Appointment(
                        rs.getInt("appointment_id"),
                        rs.getInt("patient_id"),
                        rs.getInt("doctor_id"),
                        rs.getDate("appointment_date").toLocalDate(),
                        rs.getString("appointment_time"),
                        rs.getString("status")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return appointments;
    }

    @Override
    public void updateAppointment(Appointment appointment) {
        String sql = "UPDATE appointment SET patient_id = ?, doctor_id = ?, appointment_date = ?, appointment_time = ? , status=? WHERE appointment_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, appointment.getPatient_id());
            pstmt.setInt(2, appointment.getDoctor_id());
            pstmt.setDate(3, java.sql.Date.valueOf(appointment.getAppointment_date()));
            pstmt.setString(4, appointment.getAppointment_time());
            pstmt.setString(5, appointment.getStatus());
            pstmt.setInt(6, appointment.getAppointment_id());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteAppointment(int id) throws AppointmentNotFoundException {
        if (!appointmentExists(id)) {
            throw new AppointmentNotFoundException("Appointment ID " + id + " does not exist.");
        }

        String sql = "DELETE FROM appointment WHERE appointment_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();

        }
    }

    // Method to check if the appointment exists
    public boolean appointmentExists(int id) {
        String sql = "SELECT COUNT(*) FROM appointment WHERE appointment_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

}
