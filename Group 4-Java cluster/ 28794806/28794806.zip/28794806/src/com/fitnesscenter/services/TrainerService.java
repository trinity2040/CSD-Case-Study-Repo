package com.fitnesscenter.services;

import com.fitnesscenter.models.Trainer;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TrainerService {
    private Connection connection;

    public TrainerService(Connection connection) {
        this.connection = connection;
    }

    public void addTrainer(Trainer trainer) {
        String sql = "INSERT INTO trainer (name, email, phone_number, specialization) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, trainer.getName());
            stmt.setString(2, trainer.getEmail());
            stmt.setString(3, trainer.getPhoneNumber());
            stmt.setString(4, trainer.getSpecialization());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while adding trainer: " + e.getMessage());
        }
    }

    public void viewTrainer(int trainerId) {
        String sql = "SELECT * FROM trainer WHERE trainer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, trainerId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    System.out.println("Trainer Details:");
                    System.out.println("Trainer ID: " + rs.getInt("trainer_id"));
                    System.out.println("Name: " + rs.getString("name"));
                    System.out.println("Email: " + rs.getString("email"));
                    System.out.println("Phone Number: " + rs.getString("phone_number"));
                    System.out.println("Specialization: " + rs.getString("specialization"));
                } else {
                    System.out.println("No trainer found with ID: " + trainerId);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while viewing trainer: " + e.getMessage());
        }
    }

    public void updateTrainer(Trainer trainer) {
        String sql = "UPDATE trainer SET name = ?, email = ?, phone_number = ?, specialization = ? WHERE trainer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, trainer.getName());
            stmt.setString(2, trainer.getEmail());
            stmt.setString(3, trainer.getPhoneNumber());
            stmt.setString(4, trainer.getSpecialization());
            stmt.setInt(5, trainer.getTrainerId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while updating trainer: " + e.getMessage());
        }
    }

    public void deleteTrainer(int trainerId) {
        String sql = "DELETE FROM trainer WHERE trainer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, trainerId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while deleting trainer: " + e.getMessage());
        }
    }
}
