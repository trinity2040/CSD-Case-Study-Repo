package com.fitnesscenter.services;

import com.fitnesscenter.models.Member;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MemberService {
    private Connection connection;

    public MemberService(Connection connection) {
        this.connection = connection;
    }

    public void registerMember(Member member) {
        String sql = "INSERT INTO member (name, email, phone_number, membership_type) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, member.getName());
            stmt.setString(2, member.getEmail());
            stmt.setString(3, member.getPhoneNumber());
            stmt.setString(4, member.getMembershipType());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while registering member: " + e.getMessage());
        }
    }

    public void viewMember(int memberId) {
        String sql = "SELECT * FROM member WHERE member_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, memberId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    System.out.println("Member Details:");
                    System.out.println("Member ID: " + rs.getInt("member_id"));
                    System.out.println("Name: " + rs.getString("name"));
                    System.out.println("Email: " + rs.getString("email"));
                    System.out.println("Phone Number: " + rs.getString("phone_number"));
                    System.out.println("Membership Type: " + rs.getString("membership_type"));
                } else {
                    System.out.println("No member found with ID: " + memberId);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while viewing member: " + e.getMessage());
        }
    }

    public void updateMember(Member member) {
        String sql = "UPDATE member SET name = ?, email = ?, phone_number = ?, membership_type = ? WHERE member_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, member.getName());
            stmt.setString(2, member.getEmail());
            stmt.setString(3, member.getPhoneNumber());
            stmt.setString(4, member.getMembershipType());
            stmt.setInt(5, member.getMemberId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while updating member: " + e.getMessage());
        }
    }

    public void deleteMember(int memberId) {
        String sql = "DELETE FROM member WHERE member_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, memberId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            System.out.println("Error while deleting member: " + e.getMessage());
        }
    }
}
