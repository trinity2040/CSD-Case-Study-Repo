package com.fitnesscenter.dao;

import com.fitnesscenter.models.Trainer;
import java.sql.*;

public class TrainerDAO {
    private Connection connection;

    public TrainerDAO(Connection connection) {
        this.connection = connection;
    }

    public void addTrainer(Trainer trainer) throws SQLException {
        String query = "INSERT INTO Trainer (name, email, phone_number, specialization) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, trainer.getName());
            stmt.setString(2, trainer.getEmail());
            stmt.setString(3, trainer.getPhoneNumber());
            stmt.setString(4, trainer.getSpecialization());
            stmt.executeUpdate();
        }
    }

    public Trainer getTrainer(int trainerId) throws SQLException {
        String query = "SELECT * FROM Trainer WHERE trainer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, trainerId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Trainer(rs.getInt("trainer_id"), rs.getString("name"), rs.getString("email"),
                        rs.getString("phone_number"), rs.getString("specialization"));
            }
            return null;
        }
    }

    public void updateTrainer(Trainer trainer) throws SQLException {
        String query = "UPDATE Trainer SET name = ?, email = ?, phone_number = ?, specialization = ? WHERE trainer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, trainer.getName());
            stmt.setString(2, trainer.getEmail());
            stmt.setString(3, trainer.getPhoneNumber());
            stmt.setString(4, trainer.getSpecialization());
            stmt.setInt(5, trainer.getTrainerId());
            stmt.executeUpdate();
        }
    }

    public void deleteTrainer(int trainerId) throws SQLException {
        String query = "DELETE FROM Trainer WHERE trainer_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, trainerId);
            stmt.executeUpdate();
        }
    }
}
