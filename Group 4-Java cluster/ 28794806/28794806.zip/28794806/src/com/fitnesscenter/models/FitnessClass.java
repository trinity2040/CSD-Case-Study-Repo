package com.fitnesscenter.models;

import java.time.LocalDateTime;

public class FitnessClass {
    private int classId;
    private int trainerId;
    private String className;
    private LocalDateTime schedule;
    private int capacity;
    private String status;

    public FitnessClass(int classId, int trainerId, String className, LocalDateTime schedule, int capacity, String status) {
        this.classId = classId;
        this.trainerId = trainerId;
        this.className = className;
        this.schedule = schedule;
        this.capacity = capacity;
        this.status = status;
    }

    // Getters and Setters

    public int getClassId() {
        return classId;
    }

    public void setClassId(int classId) {
        this.classId = classId;
    }

    public int getTrainerId() {
        return trainerId;
    }

    public void setTrainerId(int trainerId) {
        this.trainerId = trainerId;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public LocalDateTime getSchedule() {
        return schedule;
    }

    public void setSchedule(LocalDateTime schedule) {
        this.schedule = schedule;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "FitnessClass{" +
                "classId=" + classId +
                ", trainerId=" + trainerId +
                ", className='" + className + '\'' +
                ", schedule=" + schedule +
                ", capacity=" + capacity +
                ", status='" + status + '\'' +
                '}';
    }
}

