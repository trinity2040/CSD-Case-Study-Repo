package com.cts.sme.exceptions;

public class ShowTimeNotFoundException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ShowTimeNotFoundException(String message) {
		super(message);
		
	}

}
