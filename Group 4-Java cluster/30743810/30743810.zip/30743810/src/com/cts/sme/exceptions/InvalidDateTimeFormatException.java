package com.cts.sme.exceptions;

public class InvalidDateTimeFormatException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidDateTimeFormatException(String message) {
		super(message);
		
	}

}
