package com.bankingSystem.util;

import java.sql.*;

public class DatabaseConnection {
	
private static final String URL = "jdbc:mysql://localhost:3306/BankingSystem";
    
//     username to connect to the database
    private static final String USER = "root";
    
//    password for the database user
    private static final String PASSWORD = "phoenix";

//     Gets a connection to the database using JDBC.
//     this method throws SQLException if a database access error occurs
    public static Connection getConnection() throws SQLException{
//         Connect to the database and return the connection
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

}
