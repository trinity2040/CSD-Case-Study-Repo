package com.bankingSystem.main;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.bankingSystem.dao.impl.AccountDaoImpl;
import com.bankingSystem.dao.impl.TransactionDaoImpl;



public class Main {
	
	public static void main(String[] args) {
		
		Scanner scanner = new Scanner(System.in);

        // Create instances of Account Interface Implementation and Transaction Interface Implementation
        AccountDaoImpl accountManagement = new AccountDaoImpl();
        TransactionDaoImpl transactionManagement = new TransactionDaoImpl();

        // Infinite loop to keep the menu running until the user chooses to exit
        while (true) {
            // Display the banking system menu
            System.out.println("Banking System Menu:");
            System.out.println("1. Add Account");
            System.out.println("2. View Account");
            System.out.println("3. Update Account");
            System.out.println("4. Close Account");
            System.out.println("5. Deposit Funds");
            System.out.println("6. Withdraw Funds");
            System.out.println("7. Transfer Funds");
            System.out.println("8. View Transaction History");
            System.out.println("9. Exit");
            System.out.print("Enter your choice: ");

            // Read the user input from the console
            int choice = scanner.nextInt();

            // Execute the appropriate action based on the user input
            switch (choice) {
                case 1:
                    // To Add a new account
                	try {
                		System.out.println("Enter Customer ID:");
                        int customerId = scanner.nextInt();
                        scanner.nextLine(); // bring input to a newline after sc.nextInt()
                        System.out.println("Enter Account Type (Savings/Checking):");
                        String accountType = scanner.nextLine();
                        System.out.println("Enter Initial Balance:");
                        double balance = scanner.nextDouble();
                        accountManagement.addAccount(customerId, accountType, balance);
                        break;
                	}catch(InputMismatchException e) {
                		System.err.println("Please Provide a proper input");
                	}catch(Exception e) {
                		e.printStackTrace();
                	}
                    
                case 2:
                    // View details of an existing account
                    System.out.println("Enter Account ID:");
                    try {
                        int accountId = scanner.nextInt();
                        accountManagement.viewAccountDetails(accountId);
                        break;
                    }catch(InputMismatchException e) {
                		System.err.println("Please Provide a proper input");
                	}catch(Exception e) {
                		e.printStackTrace();
                	}
                    
                case 3:
                    // Update details of an existing account
                	try {
                		System.out.print("Enter Account ID: ");
                        int accountId = scanner.nextInt();
                        scanner.nextLine(); // bring input to a newline after sc.nextInt()
                        System.out.print("Enter New Account Type (Savings/Checking): ");
                        String newAccountType = scanner.nextLine();
                        System.out.print("Enter New Balance: ");
                        double newBalance = scanner.nextDouble();
                        accountManagement.updateAccount(accountId, newAccountType, newBalance);
                        break;
                	}catch(InputMismatchException e) {
                		System.err.println("Please Provide a proper input");
                	}catch(Exception e) {
                		e.printStackTrace();
                	}
                    
                case 4:
                    // Close an existing account
                	try {
                		System.out.print("Enter Account ID to Close: ");
                        int accountId = scanner.nextInt();
                        accountManagement.closeAccount(accountId);
                        break;
                	}catch(InputMismatchException e) {
                		System.err.println("Please Provide a proper input");
                	}catch(Exception e) {
                		e.printStackTrace();
                	}
                    
                case 5:
                    // Deposit amount into an account
                	try {
                		System.out.println("Enter Account ID:");
                        int accountId = scanner.nextInt();
                        System.out.println("Enter Amount to Deposit:");
                        double depositAmount = scanner.nextDouble();
                        transactionManagement.deposit(accountId, depositAmount);
                        break;
                	}catch(InputMismatchException e) {
                		System.err.println("Please Provide a proper input");
                	}catch(Exception e) {
                		e.printStackTrace();
                	}
                    
                case 6:
                    // Withdraw amount from an account
                	try {
                		System.out.println("Enter Account ID:");
                        int accountId = scanner.nextInt();
                        System.out.println("Enter Amount to Withdraw:");
                        double withdrawalAmount = scanner.nextDouble();
                        transactionManagement.withdraw(accountId, withdrawalAmount);
                        break;
                	}catch(InputMismatchException e) {
                		System.err.println("Please Provide a proper input");
                	}catch(Exception e) {
                		e.printStackTrace();
                	}
                    
                case 7:
                    // Transfer amount between two accounts
                	try {
                		System.out.print("Enter Source Account ID: ");
                        int fromAccountId = scanner.nextInt();
                        System.out.print("Enter Destination Account ID: ");
                        int toAccountId = scanner.nextInt();
                        System.out.print("Enter Amount to Transfer: ");
                        double transferAmount = scanner.nextDouble();
                        transactionManagement.transferFunds(fromAccountId, toAccountId, transferAmount);
                        break;
                	}catch(InputMismatchException e) {
                		System.err.println("Please Provide a proper input");
                	}catch(Exception e) {
                		e.printStackTrace();
                	}
                    
                case 8:
                    // View transaction history for an account
                	try {
                		System.out.print("Enter Account ID to View Transaction History: ");
                        int accountId = scanner.nextInt();
                        transactionManagement.viewTransactionHistory(accountId);
                        break;
                	}catch(InputMismatchException e) {
                		System.err.println("Please Provide a proper input");
                	}catch(Exception e) {
                		e.printStackTrace();
                	}
                    
                case 9:
                    // Exit the application
                    System.out.println("Exiting...");
                    scanner.close(); // Close the scanner
                    return; // Exit the loop and end the program
                default:
                    // Handle invalid user input
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

}
