package com.bankingSystem.dao;

public interface TransactionDao {
	
	// Abstract methods of the TransactionDao interface
	public abstract void deposit(int accountId, double amount);
	public abstract void withdraw(int accountId, double amount);
	public abstract void transferFunds(int fromAccountId, int toAccountId, double amount);
	public void viewTransactionHistory(int accountId);

}
