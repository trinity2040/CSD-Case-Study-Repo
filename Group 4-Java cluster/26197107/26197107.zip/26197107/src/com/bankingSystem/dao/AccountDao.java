package com.bankingSystem.dao;

public interface AccountDao {
	
	// abstract methods of the AccountDao interface
	public abstract void addAccount(int customerId, String accountType, double initialBalance);
	public void viewAccountDetails(int accountId);
	public void updateAccount(int accountId, String newAccountType, double newBalance);
	public void closeAccount(int accountId);
	
}
