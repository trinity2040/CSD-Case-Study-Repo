package com.bankingSystem.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.bankingSystem.util.DatabaseConnection;
import com.bankingSystem.dao.AccountDao;

public class AccountDaoImpl implements AccountDao{
	
	
//    To Add a new account to the database.
//    @param customerId the ID of the customer who owns the account
//    @param accountType the type of the account (e.g., Savings, Checking)
//    @param initialBalance the initial balance of the account
	
	public void addAccount(int customerId, String accountType, double initialBalance) {
		
	    String query = "INSERT INTO Account (customer_id, account_type, balance) VALUES (?, ?, ?)";
	    try {
	    	Connection connection = DatabaseConnection.getConnection();
	        PreparedStatement statement = connection.prepareStatement(query);
	        statement.setInt(1, customerId);
	        statement.setString(2, accountType);
	        statement.setDouble(3, initialBalance);
	        statement.executeUpdate();
	        System.out.println("Account successfully added.");
	    } catch (SQLException e) {
	        System.err.println("Error adding account: " + e.getMessage());
	    }
	}
	
//	 To View the details of a specific account.
//    @param accountId the ID of the account to view
    
	public void viewAccountDetails(int accountId) {
        String query = "SELECT * FROM Account WHERE account_id = ?";
        try {
        	Connection connection = DatabaseConnection.getConnection();
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, accountId);
            ResultSet rs = statement.executeQuery();
            System.out.println("|  Account ID   |  Customer ID  |  Account Type  |  Balance  |");
            if (rs.next()) {
                System.out.print(" 	" + rs.getInt("account_id"));
                System.out.print("		" + rs.getInt("customer_id"));
                System.out.print("	   " + rs.getString("account_type"));
                System.out.print("	   " + rs.getDouble("balance")+"\n");
            } else {
                System.out.println("No account found with ID: " + accountId);
            }
        } catch (SQLException e) {
            System.err.println("Error viewing account details: " + e.getMessage());
        }
    }
	
//	  To Update the details of an existing account.
//    @param accountId the ID of the account to update
//    @param newAccountType the new type of the account (e.g., Savings, Checking)
//    @param newBalance the new balance of the account
	
	public void updateAccount(int accountId, String newAccountType, double newBalance) {
        String query = "UPDATE Account SET account_type = ?, balance = ? WHERE account_id = ?";
        try {
        	Connection connection = DatabaseConnection.getConnection();
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setString(1, newAccountType);
            statement.setDouble(2, newBalance);
            statement.setInt(3, accountId);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Account successfully updated.");
            } else {
                System.out.println("No account found with ID: " + accountId);
            }
        } catch (SQLException e) {
            System.err.println("Error updating account: " + e.getMessage());
        }
    }
	
	
//	  To Close an account / to delete it from the database
//    @param accountId the ID of the account to close
	public void closeAccount(int accountId) {
        // First, we need to delete related transactions
        deleteTransactions(accountId);

        // Then, we can delete the account
        String query = "DELETE FROM Account WHERE account_id = ?";
        try {
        	Connection connection = DatabaseConnection.getConnection();
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, accountId);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Account successfully closed.");
            } else {
                System.out.println("No account found with ID: " + accountId);
            }
        } catch (SQLException e) {
            System.err.println("Error closing account: " + e.getMessage());
        }
	}
	
	// To delete the related transactions from the transactions table before deleting account
	
	public void deleteTransactions(int accountId) {
        String query = "DELETE FROM Transaction WHERE account_id = ?";
        try {
        	Connection connection = DatabaseConnection.getConnection();
            PreparedStatement statement = connection.prepareStatement(query);
            statement.setInt(1, accountId);
            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Transactions successfully deleted.");
            } else {
                System.out.println("No transactions found for Account ID: " + accountId);
            }
        } catch (SQLException e) {
            System.err.println("Error deleting transactions: " + e.getMessage());
        }
    }
	

}
