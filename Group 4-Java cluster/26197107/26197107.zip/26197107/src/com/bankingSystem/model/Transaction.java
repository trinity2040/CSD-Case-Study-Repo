package com.bankingSystem.model;

public class Transaction {
	
	private int transactionId;
	private int accountId;
	private String transactionType;
	private double amount;
	private String transactionDate;
	
	//getter and setter methods for the attributes
	public int getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public String getTransactionDate() {
		return transactionDate;
	}
	public void setTransactionDate(String transactionDate) {
		this.transactionDate = transactionDate;
	}
	
	//parameterized constructor
	public Transaction(int transactionId, int accountId, String transactionType, double amount,
			String transactionDate) {
		super();
		this.transactionId = transactionId;
		this.accountId = accountId;
		this.transactionType = transactionType;
		this.amount = amount;
		this.transactionDate = transactionDate;
	}
	
	//default constructor
	public Transaction() {
		
	}
	
	//to string method to print the values of the attributes
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", accountId=" + accountId + ", transactionType="
				+ transactionType + ", amount=" + amount + ", transactionDate=" + transactionDate + "]";
	}
	
	
	

}
