package com.cts.exception;

public class DuplicateAttendanceException extends Exception {
    public DuplicateAttendanceException(String message) {
        super(message);
    }
}
