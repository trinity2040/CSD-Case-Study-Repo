package cog;

import java.util.Scanner;

public class Exe {
	
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println();
            System.out.println("--- Welcome to Car Insurance Management System --- \n Choose the below options to continue");
            System.out.println();
            System.out.println("1. Policy Management");
            System.out.println("2. Customer Management");
            System.out.println("3. Claim Management");
            System.out.println("4. Exit");
            System.out.println();
            System.out.print("Enter your choice: ");
            
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    PolicyManagment.managePolicies();
                    break;
                case 2:
                    CustomerManagment.manageCustomers();
                    break;
                case 3:
                    ClaimManagment.manageClaims();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

}
