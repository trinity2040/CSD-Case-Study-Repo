package cognizant_30743502.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import cognizant_30743502.dto.Claim;

public class ClaimDao {

	public void createTable() {
//		Class.forName("com.mysql.cj.jdbc.Driver");
//		Connection connection=DriverManager.getConnection("jdbc:mysql://localhost:3307/Car_Insurance_Management_System","root","root");

		try (Connection connection = DbConn.getConnection()) {
			Statement statement = connection.createStatement();
			statement.execute(
					"create table Claim(claimId int primary key,claimDate date,claimStatus varchar(45),policyId int ,foreign key(policyId) references Policy(policyId),customerId int ,foreign key(customerId) references Customer(customerId))");
			connection.close();
		} catch (SQLException sqlException) {
			System.out.println("connection failed! please try again after some time...");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	public Claim addANewClaim(Claim claim) {
		try (Connection connection = DbConn.getConnection()) {
			PreparedStatement preparedStatement = connection.prepareStatement("insert into Claim values(?,?,?,?,?)");
			preparedStatement.setInt(1, claim.getClaimId());
			preparedStatement.setString(2, claim.getClaimDate());
			preparedStatement.setString(3, claim.getClaimStatus());
			preparedStatement.setInt(4, claim.getPolicyId());
			preparedStatement.setInt(5, claim.getCustomerId());

			preparedStatement.execute();
//			connection.close();

			return claim;
		} catch (SQLException sqlException) {
			System.out.println("connection failed! please try again after some time...");
			return null;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}

	}

	public Claim fetchAClaimById(int id) {
		try (Connection connection = DbConn.getConnection()) {
			Claim claim = new Claim();
			PreparedStatement preparedStatement = connection.prepareStatement("select * from Claim where claimId=?");
			preparedStatement.setInt(1, id);

			ResultSet resultSet = preparedStatement.executeQuery();
			while (resultSet.next()) {

				claim.setClaimId(resultSet.getInt(1));
				claim.setClaimDate(resultSet.getString(2));
				claim.setClaimStatus(resultSet.getString(3));
				claim.setPolicyId(id);
				claim.setCustomerId(resultSet.getInt(5));
			}
//			connection.close();

			return claim;
		} catch (SQLException sqlException) {
			System.out.println("connection failed! please try again after some time...");
			return null;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}

	}

	public Claim updateClaim(Claim claim,int id) {
		try (Connection connection = DbConn.getConnection()) {
			PreparedStatement preparedStatement = connection.prepareStatement(
					"update Claim set claimDate=?,ClaimStatus=?,policyId=?,customerId=? where claimId=?");

			preparedStatement.setString(1, claim.getClaimDate());
			preparedStatement.setString(2, claim.getClaimStatus());
			preparedStatement.setInt(3, claim.getPolicyId());
			preparedStatement.setInt(4, claim.getCustomerId());
			preparedStatement.setInt(5, id);

			preparedStatement.execute();
//			connection.close();

			return claim;
		} catch (SQLException sqlException) {
			System.out.println("connection failed! please try again after some time...");
			return null;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}
	}

	public Claim deleteClaim(int id) {
		Claim claim = fetchAClaimById(id);
		try (Connection connection = DbConn.getConnection()) {
			PreparedStatement preparedStatement = connection.prepareStatement("delete from Claim where claimId=?");
			preparedStatement.setInt(1, id);
			preparedStatement.execute();
//			connection.close();
		} catch (SQLException sqlException) {
			System.out.println("connection failed! please try again after some time...");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return claim;
	}

}
