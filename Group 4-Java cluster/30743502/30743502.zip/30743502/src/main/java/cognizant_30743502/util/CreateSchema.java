package cognizant_30743502.util;

public class CreateSchema {
	
	public static void main(String[] args) {
		
		cognizant_30743502.dao.CreateSchema.createSchema();
		
	}

}
