package cognizant_30743502.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import cognizant_30743502.dto.Customer;

public class CustomerDao {
	
	public void createTable() 
	{
		
		try(Connection connection=DbConn.getConnection())
		{
			Statement statement = connection.createStatement();
			statement.execute(
					"CREATE TABLE Customer (customerId INT PRIMARY KEY AUTO_INCREMENT,customerName VARCHAR(100) NOT NULL,customerEmail VARCHAR(100) NOT NULL UNIQUE,customerPhone Long NOT NULL,customerAddress VARCHAR(15) NOT NULL)");
			connection.close();
			System.out.println("table created sucessfully");
		}
		catch (SQLException sqlException) 
		{
			System.out.println("connection failed! please try again after some time...");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}
	public Customer addANewCustomer(Customer customer)
	{
		try(Connection connection=DbConn.getConnection())
		{
			PreparedStatement preparedStatement=connection.prepareStatement("insert into Customer values(?,?,?,?,?)");
			preparedStatement.setInt(1, customer.getCustomerId());
			preparedStatement.setString(2, customer.getCustomerName());
			preparedStatement.setString(3, customer.getCustomerEmail());
			preparedStatement.setLong(4, customer.getCustomerPhone());
			preparedStatement.setString(5, customer.getCustomerAddress());
			
			preparedStatement.execute();
//			connection.close();
			
			return customer;
		}
		catch (SQLException sqlException) 
		{
			System.out.println("connection failed! please try again after some time...");
			return null;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		
	}
	public Customer fetchACustomerById(int id)
	{
		try(Connection connection=DbConn.getConnection())
		{
			Customer customer=new Customer();
			PreparedStatement preparedStatement=connection.prepareStatement("select * from Customer where customerId=?");
			preparedStatement.setInt(1, id);
			
			ResultSet  resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				
				customer.setCustomerId(resultSet.getInt(1));
				customer.setCustomerName(resultSet.getString(2));
				customer.setCustomerEmail(resultSet.getString(3));
				customer.setCustomerPhone(resultSet.getLong(4));
				customer.setCustomerAddress(resultSet.getString(5));
			}
//			connection.close();
			
			return customer;
		}
		catch (SQLException sqlException) 
		{
			System.out.println("connection failed! please try again after some time...");
			return null;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		
	}
	public Customer updateCustomer(Customer customer,int id)
	{
		try(Connection connection=DbConn.getConnection())
		{
			PreparedStatement preparedStatement=connection.prepareStatement("update Customer set customerName=?,customerEmail=?,customerPhone=?,customerAddress=? where customerId=?");
			
			preparedStatement.setString(1, customer.getCustomerName());
			preparedStatement.setString(2, customer.getCustomerEmail());
			preparedStatement.setLong(3, customer.getCustomerPhone());
			preparedStatement.setString(4, customer.getCustomerAddress());
			preparedStatement.setInt(5, id);
			
			preparedStatement.execute();
			
			customer.setCustomerId(id);
			
			return customer;
		}
		catch (SQLException sqlException) 
		{
			System.out.println("connection failed! please try again after some time...");
			return null;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}
	}
	public Customer deleteCustomer(int id)
	{
		Customer customer=fetchACustomerById(id);
		try(Connection connection=DbConn.getConnection())
		{
			PreparedStatement preparedStatement=connection.prepareStatement("delete from Customer where customerId=?");
			preparedStatement.setInt(1, id);
			preparedStatement.execute();
		}
		catch (SQLException sqlException) 
		{
			System.out.println("connection failed! please try again after some time...");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return customer;
	}

}
