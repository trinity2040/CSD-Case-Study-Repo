package cognizant_30743502.service;

import cognizant_30743502.dao.CustomerDao;
import cognizant_30743502.dto.Customer;
import cognizant_30743502.exception.AlreadyExists;
import cognizant_30743502.exception.NoOneExists;

public class CustomerService {

	CustomerDao dao = new CustomerDao();

	public void createTable() {
		dao.createTable();

	}

	public Customer addANewCustomer(Customer customer) {
		
		return dao.addANewCustomer(customer);
	}

	public Customer fetchACustomerById(int id) {
		return dao.fetchACustomerById(id);

	}

	public Customer updateCustomer(Customer customer, int id) {

		Customer customer2 = dao.fetchACustomerById(id);
		if (customer2 == null) {
			throw new NoOneExists();
		} else {
			return dao.updateCustomer(customer, id);

		}

	}

	public Customer deleteCustomer(int id) {

		Customer customer2 = dao.fetchACustomerById(id);
		if (customer2 == null) {
			throw new NoOneExists();
		} else {
			return dao.deleteCustomer(id);

		}

	}

}
