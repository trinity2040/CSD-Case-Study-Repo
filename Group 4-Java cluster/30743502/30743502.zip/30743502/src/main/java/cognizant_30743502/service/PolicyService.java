package cognizant_30743502.service;

import cognizant_30743502.dao.PolicyDao;
import cognizant_30743502.dto.Policy;
import cognizant_30743502.exception.NoOneExists;

public class PolicyService {
	PolicyDao dao = new PolicyDao();

	public void createTable() {
		dao.createTable();

	}

	public Policy addANewPolicy(Policy policy) {
		
		return dao.addANewPolicy(policy);

	}

	public Policy fetchAPolicyById(int id) {
		return dao.fetchAPolicyById(id);

	}

	public Policy updatePolicy(Policy policy, int id) {
		Policy policy2 = dao.fetchAPolicyById(id);
		if (policy2 == null) {
			throw new NoOneExists();
		} else {
			return dao.updatePolicy(policy, id);
		}

	}

	public Policy deletePolicy(int id) {
		Policy policy = fetchAPolicyById(id);
		if (policy == null) {
			throw new NoOneExists();
		} else {
			return dao.deletePolicy(id);

		}
	}

}
