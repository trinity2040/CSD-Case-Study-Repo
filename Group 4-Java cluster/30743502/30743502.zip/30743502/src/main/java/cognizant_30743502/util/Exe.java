package cognizant_30743502.util;

import java.util.Scanner;

import cognizant_30743502.dto.Claim;
import cognizant_30743502.dto.Customer;
import cognizant_30743502.dto.Policy;
import cognizant_30743502.service.ClaimService;
import cognizant_30743502.service.CustomerService;
import cognizant_30743502.service.PolicyService;

public class Exe {
	
	public static void main(String[] args) {
		PolicyService policyService=new PolicyService();
		ClaimService claimService=new ClaimService();
		CustomerService customerService=new CustomerService();
		
		
		System.out.println("Welcome to car insurance managment system!!");
	while(true)
	{
		
		System.out.println("Choose Options \n1.Policy Management \n2.Customer Managment \n3.Claim Managment\n4.Exit");
		
		Scanner scanner=new Scanner(System.in);
		int option=scanner.nextInt();
		
		switch(option)
		{
		case 1:
			System.out.println("Choose Options \n1.add a new POLICY \n2.view a POLICY \n3.update a POLICY \n4.delete a POLICY ");
			int op=scanner.nextInt();
			if(op==1)
			{
				Policy policy=new Policy();
				System.out.println("Enter Policy Id");
				policy.setPolicyId(scanner.nextInt());
				System.out.println("enter policy number");
				policy.setPolicyNumber( scanner.nextInt());
				System.out.println("enter type of policy");
				policy.setPolicyType(scanner.nextLine());
             	scanner.nextLine();
				System.out.println("enter coverage amount");
				policy.setPolicyCoverageAmount(scanner.nextDouble());
				System.out.println("Enter premium amount");
				policy.setPolicyPremiumAmount(scanner.nextDouble());
				
				
				Policy  policy2=policyService.addANewPolicy(policy);
				
				if(policy2==null)
				{
					System.out.println("adding failed!!");
				}
			}
			else if(op==2)
			{
				System.out.println("Enter policy id");
				int id=scanner.nextInt();
				System.out.println(policyService.fetchAPolicyById(id));
			}
			else if(op==3)
			{
				Policy policy=new Policy();
				System.out.println("Enter Policy Id to update");
				int id=scanner.nextInt();
				System.out.println("enter policy number");
				policy.setPolicyNumber( scanner.nextInt());
				System.out.println("enter type of policy");
				policy.setPolicyType(scanner.nextLine());
				scanner.nextLine();
				System.out.println("enter coverage amount");
				policy.setPolicyCoverageAmount(scanner.nextDouble());
				System.out.println("Enter premium amount");
				policy.setPolicyPremiumAmount(scanner.nextDouble());
				
				System.out.println(policyService.updatePolicy(policy, id));
				
				
			}
			else if(op==4)
			{
				System.out.println("Enter Policy Id to delete");
				int id=scanner.nextInt();
				policyService.deletePolicy(id);
				System.out.println("deleted sucessfully");
			}
			break;
		case 3:
			System.out.println("Choose Options \n1.add a new CLAIM \n2.view a CLAIM \n3.update a CLAIM \n4.delete a CLAIM ");
			int op1=scanner.nextInt();
			if(op1==1)
			{
				Claim claim=new Claim();
				System.out.println("Enter CLAIM Id");
				claim.setClaimId(scanner.nextInt());
				System.out.println("enter policy Id");
				claim.setClaimId(scanner.nextInt());
				System.out.println("enter customer id");
				claim.setCustomerId(scanner.nextInt());
				System.out.println("enter claim date");
				claim.setClaimDate(scanner.nextLine());
				scanner.nextLine();
				System.out.println("Enter claim status ");
				claim.setClaimStatus(scanner.nextLine());
				
				
				Claim claim2=claimService.addANewClaim(claim);
				
				if(claim2==null)
				{
					System.out.println("adding failed!!");
				}
			}
			else if(op1==2)
			{
				System.out.println("Enter claim id");
				int id=scanner.nextInt();
				System.out.println(claimService.fetchAClaimById(id));
			}
			else if(op1==3)
			{

				Claim claim=new Claim();
				System.out.println("Enter CLAIM Id to update");
				int id=scanner.nextInt();
				System.out.println("enter policy Id");
				claim.setClaimId(scanner.nextInt());
				System.out.println("enter customer id");
				claim.setCustomerId(scanner.nextInt());
				System.out.println("enter claim date");
				claim.setClaimDate(scanner.nextLine());
				scanner.nextLine();
				System.out.println("Enter claim status ");
				claim.setClaimStatus(scanner.nextLine());
				
				
				System.out.println(claimService.updateClaim(claim, id));
				
				
			}
			else if(op1==4)
			{
				System.out.println("Enter claim Id to delete");
				int id=scanner.nextInt();
				claimService.deleteClaim(id);
				System.out.println("deleted sucessfully");
			}
			break;
		case 2:
			System.out.println("Choose Options \n1.add a new Customer \n2.view a Customer \n3.update a Customer \n4.delete a Customer ");
			int op2=scanner.nextInt();
			if(op2==1)
			{
				Customer customer=new Customer();
				System.out.println("Enter Customer Id");
				customer.setCustomerId(scanner.nextInt());
				System.out.println("enter customer name");
				customer.setCustomerName(scanner.nextLine());
				scanner.nextLine();
				System.out.println("enter customer email");
				customer.setCustomerEmail(scanner.nextLine());
				scanner.nextLine();
				System.out.println("enter customer phone");
				customer.setCustomerPhone(scanner.nextLong());
				scanner.nextLine();
				System.out.println("Enter customer address ");
				customer.setCustomerAddress(scanner.nextLine());
				scanner.nextLine();
				
				Customer customer2=customerService.addANewCustomer(customer);
				
				if(customer2==null)
				{
					System.out.println("adding failed!!");
				}
			}
			else if(op2==2)
			{
				System.out.println("Enter customer id");
				int id=scanner.nextInt();
				System.out.println(customerService.fetchACustomerById(id));
			}
			else if(op2==3)
			{

				Claim claim=new Claim();
				System.out.println("Enter CLAIM Id to update");
				int id=scanner.nextInt();
				System.out.println("enter policy Id");
				claim.setClaimId(scanner.nextInt());
				System.out.println("enter customer id");
				claim.setCustomerId(scanner.nextInt());
				System.out.println("enter claim date");
				claim.setClaimDate(scanner.nextLine());
				scanner.nextLine();
				System.out.println("Enter claim status ");
				claim.setClaimStatus(scanner.nextLine());
				scanner.nextLine();
				
				
				System.out.println(claimService.updateClaim(claim, id));
				
				
			}
			else if(op2==4)
			{
				System.out.println("Enter claim Id to delete");
				int id=scanner.nextInt();
				customerService.deleteCustomer(id);
				System.out.println("deleted sucessfully");
			}
			break;
			
		case 4:
			System.exit(0);
			break;
			
			default:
				System.out.println("choose correct option");
		}
		
	}	
		
		
	}

}
