package cognizant_30743502.dto;

public class Policy {

	private int policyId;
	private int policyNumber;
	private String policyType;
	private double policyCoverageAmount;
	private double policyPremiumAmount;

	public int getPolicyId() {
		return policyId;
	}

	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}

	@Override
	public String toString() {
		return "Policy [policyId=" + policyId + ", policyNumber=" + policyNumber + ", policyType=" + policyType
				+ ", policyCoverageAmount=" + policyCoverageAmount + ", policyPremiumAmount=" + policyPremiumAmount
				+ "]";
	}

	public int getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(int policyNumber) {
		this.policyNumber = policyNumber;
	}

	public String getPolicyType() {
		return policyType;
	}

	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}

	public double getPolicyCoverageAmount() {
		return policyCoverageAmount;
	}

	public void setPolicyCoverageAmount(double policyCoverageAmount) {
		this.policyCoverageAmount = policyCoverageAmount;
	}

	public double getPolicyPremiumAmount() {
		return policyPremiumAmount;
	}

	public void setPolicyPremiumAmount(double policyPremiumAmount) {
		this.policyPremiumAmount = policyPremiumAmount;
	}

}
