package cognizant_30743502.exception;

public class AlreadyExists extends RuntimeException{

	@Override
	public String getMessage() {
		// TODO Auto-generated method stub
		return "already user exists kindly update";
	}
}
