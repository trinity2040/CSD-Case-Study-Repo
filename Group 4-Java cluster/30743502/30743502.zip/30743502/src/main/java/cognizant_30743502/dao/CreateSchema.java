package cognizant_30743502.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateSchema {
	
	public static void createSchema()
	{
		try(Connection connection=DbConn.getConnection())
		{
			Statement statement=connection.createStatement();
			statement.execute("create schema Car_Insurance_Management_System");
			connection.close();
			System.out.println("schema created sucessfully!!");
		}
		catch (SQLException sqlException) 
		{
			System.out.println("connection failed! please try again after some time...");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}

}
