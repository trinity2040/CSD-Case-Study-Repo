package cognizant_30743502.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import cognizant_30743502.dto.Policy;

public class PolicyDao {
	
	public void createTable() 
	{
		
		try(Connection connection=DbConn.getConnection())
		{
			Statement statement = connection.createStatement();
			statement.execute(
					"CREATE TABLE Policy (policyId INT PRIMARY KEY AUTO_INCREMENT,policyNumber int NOT NULL UNIQUE,policyType VARCHAR(50) NOT NULL,policyCoverageAmount double NOT NULL,policyPremiumAmount double NOT NULL)");
			connection.close();
		}
		catch (SQLException sqlException) 
		{
			System.out.println("connection failed! please try again after some time...");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		
	}
	public Policy addANewPolicy(Policy policy)
	{
		try(Connection connection=DbConn.getConnection())
		{
			PreparedStatement preparedStatement=connection.prepareStatement("insert into Policy values(?,?,?,?,?)");
			preparedStatement.setInt(1, policy.getPolicyId());
			preparedStatement.setInt(2, policy.getPolicyNumber());
			preparedStatement.setString(3, policy.getPolicyType());
			preparedStatement.setDouble(4, policy.getPolicyCoverageAmount());
			preparedStatement.setDouble(5, policy.getPolicyPremiumAmount());
			
			preparedStatement.execute();
//			connection.close();
			
			return policy;
		}
		catch (SQLException sqlException) 
		{
			System.out.println("connection failed! please try again after some time...");
			return null;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		
	}
	public Policy fetchAPolicyById(int id)
	{
		try(Connection connection=DbConn.getConnection())
		{
			Policy policy=new Policy();
			PreparedStatement preparedStatement=connection.prepareStatement("select * from Policy where policyId=?");
			preparedStatement.setInt(1, id);
			
			ResultSet  resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				
				policy.setPolicyId(resultSet.getInt(1));;
				policy.setPolicyNumber(resultSet.getInt(2));
				policy.setPolicyType(resultSet.getString(3));
				policy.setPolicyCoverageAmount(resultSet.getDouble(4));
				policy.setPolicyPremiumAmount(resultSet.getDouble(5));
			}
//			connection.close();
			
			return policy;
		}
		catch (SQLException sqlException) 
		{
			System.out.println("connection failed! please try again after some time...");
			return null;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		
	}
	public Policy updatePolicy(Policy policy,int oldId)
	{
		try(Connection connection=DbConn.getConnection())
		{
			PreparedStatement preparedStatement=connection.prepareStatement("update Policy set policyNumber=?,policyType=?,policyCoverageAmount=?,policyPremiumAmount=? where policyId=?");
			
			preparedStatement.setInt(1, policy.getPolicyNumber());
			preparedStatement.setString(2, policy.getPolicyType());
			preparedStatement.setDouble(3, policy.getPolicyCoverageAmount());
			preparedStatement.setDouble(4, policy.getPolicyPremiumAmount());
			preparedStatement.setInt(5, oldId);
			preparedStatement.execute();
//			connection.close();
			policy.setPolicyId(oldId);
			return policy;
		}
		catch (SQLException sqlException) 
		{
			System.out.println("connection failed! please try again after some time...");
			return null;
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}
	}
	public Policy deletePolicy(int id)
	{
		Policy policy=fetchAPolicyById(id);
		try(Connection connection=DbConn.getConnection())
		{
			PreparedStatement preparedStatement=connection.prepareStatement("delete from Policy where policyId=?");
			preparedStatement.setInt(1, id);
			preparedStatement.execute();
//			connection.close();
		}
		catch (SQLException sqlException) 
		{
			System.out.println("connection failed! please try again after some time...");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return policy;
	}


}
