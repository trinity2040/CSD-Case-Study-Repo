package cognizant_30743502.exception;

public class NoOneExists extends RuntimeException{
	
	@Override
	public String getMessage() {
		
		return "No One exists in specified record id";
	}

}
