package cognizant_30743502.dto;

import java.sql.Date;

public class Claim {

	private int claimId;
	private int policyId;
	private int customerId;
	private String claimDate;
	private String claimStatus;

	public int getClaimId() {
		return claimId;
	}

	public void setClaimId(int claimId) {
		this.claimId = claimId;
	}

	@Override
	public String toString() {
		return "Claim [claimId=" + claimId + ", policyId=" + policyId + ", customerId=" + customerId + ", claimDate="
				+ claimDate + ", claimStatus=" + claimStatus + "]";
	}

	public int getPolicyId() {
		return policyId;
	}

	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public String getClaimDate() {
		return claimDate;
	}

	public void setClaimDate(String claimDate) {
		this.claimDate = claimDate;
	}

	public String getClaimStatus() {
		return claimStatus;
	}

	public void setClaimStatus(String claimStatus) {
		this.claimStatus = claimStatus;
	}

}
