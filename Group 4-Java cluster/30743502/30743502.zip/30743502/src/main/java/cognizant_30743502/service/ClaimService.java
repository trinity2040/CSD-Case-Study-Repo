package cognizant_30743502.service;

import cognizant_30743502.dao.ClaimDao;
import cognizant_30743502.dto.Claim;
import cognizant_30743502.exception.NoOneExists;

public class ClaimService {

	ClaimDao dao = new ClaimDao();

	public void createTable() {

		dao.createTable();
	}

	public Claim addANewClaim(Claim claim) {
		
			return dao.addANewClaim(claim);

		
	}

	public Claim fetchAClaimById(int id) {
		return dao.fetchAClaimById(id);

	}

	public Claim updateClaim(Claim claim, int id) {

		Claim claim2 = dao.fetchAClaimById(id);
		if (claim2 == null) {
			throw new NoOneExists();
		} else {
			return dao.updateClaim(claim, id);

		}

	}

	public Claim deleteClaim(int id) {

		Claim claim2 = dao.fetchAClaimById(id);
		if (claim2 == null) {
			throw new NoOneExists();
		} else {
			return dao.deleteClaim(id);

		}

	}

}
