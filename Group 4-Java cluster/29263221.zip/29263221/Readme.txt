# Blood Bank Management System


## Introduction

The Blood Bank Management System is a console-based application built using Core Java, MySQL, and JDBC. It simulates the operations of a blood bank, allowing users to manage donors, blood inventory, and blood requests effectively. This project is designed to demonstrate proficiency in Java programming, database connectivity using JDBC, and basic CRUD operations.

## Features

- **Donor Management**:
  - Add new donors
  - View donor details
  - Update donor information
  - Delete donor records

- **Inventory Management**:
  - Add blood donations to the inventory
  - View blood inventory details
  - Update inventory information
  - Delete blood inventory records

- **Request Management**:
  - Register blood requests
  - View request details
  - Update request status
  - Delete requests

## Technologies Used

- **Java**: Core Java for application logic and console interaction.
- **MySQL**: For database management and storage.
- **JDBC**: Java Database Connectivity for interacting with the MySQL database.

## Project Structure
src/ │ 
	├── BloodBankManagementApp.java # Main application class 
	├── DatabaseConnector.java # Database connection handler 
	├── DonorManager.java # Donor-related operations 
	├── InventoryManager.java # Inventory-related operations 
	|── RequestManager.java # Request-related operations



## Database Schema

The project uses a MySQL database with the following schema:

CREATE DATABASE bloodbank;

USE bloodbank;

CREATE TABLE Donor (
    donor_id INT AUTO_INCREMENT PRIMARY KEY,
    donor_name VARCHAR(100),
    blood_group VARCHAR(10),
    contact_number VARCHAR(15),
    email VARCHAR(100),
    last_donation_date DATE
);

CREATE TABLE Inventory (
    donation_id INT AUTO_INCREMENT PRIMARY KEY,
    donor_id INT,
    donation_date DATE,
    blood_group VARCHAR(10),
    quantity INT,
    expiry_date DATE,
    FOREIGN KEY (donor_id) REFERENCES Donor(donor_id)
);

CREATE TABLE Request (
    request_id INT AUTO_INCREMENT PRIMARY KEY,
    requester_name VARCHAR(100),
    blood_group_requested VARCHAR(10),
    request_date DATE,
    request_status VARCHAR(20)
);





Setup Instructions

Clone the Repository:

git clone https://github.com/your-username/blood-bank-management-system.git
cd blood-bank-management-system
Create the Database:

Open MySQL and run the provided SQL script to create the necessary database and tables.
Configure Database Connection:

Update the DatabaseConnector.java file with your MySQL username and password.
Compile the Java Classes:

javac src/*.java
Run the Application:

java src/BloodBankManagementApp
Usage
Run the application and follow the on-screen menu to manage donors, blood inventory, and requests.
Choose the appropriate menu option by entering the corresponding number.
