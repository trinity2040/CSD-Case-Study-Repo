package bloodBankManagement;

import java.util.Scanner;

public class BloodBankManagementApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DonorManager donorManager = new DonorManager();
        InventoryManager inventoryManager = new InventoryManager();
        RequestManager requestManager = new RequestManager();

        while (true) {
            System.out.println("Blood Bank Management System Menu:");
            System.out.println("1. Add Donor");
            System.out.println("2. View Donor");
            System.out.println("3. Update Donor");
            System.out.println("4. Delete Donor");
            System.out.println("5. Add Blood Donation");
            System.out.println("6. View Blood Inventory");
            System.out.println("7. Update Blood Inventory");
            System.out.println("8. Delete Blood Inventory");
            System.out.println("9. Register Blood Request");
            System.out.println("10. View Request Details");
            System.out.println("11. Update Request Status");
            System.out.println("12. Delete Request");
            System.out.println("0. Exit");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    donorManager.addDonor(scanner);
                    break;
                case 2:
                    donorManager.viewDonorDetails(scanner);
                    break;
                case 3:
                    donorManager.updateDonorInfo(scanner);
                    break;
                case 4:
                    donorManager.deleteDonor(scanner);
                    break;
                case 5:
                    inventoryManager.addDonation(scanner);
                    break;
                case 6:
                    inventoryManager.viewInventory(scanner);
                    break;
                case 7:
                    inventoryManager.updateInventory(scanner);
                    break;
                case 8:
                    inventoryManager.deleteInventory(scanner);
                    break;
                case 9:
                    requestManager.registerRequest(scanner);
                    break;
                case 10:
                    requestManager.viewRequestDetails(scanner);
                    break;
                case 11:
                    requestManager.updateRequestStatus(scanner);
                    break;
                case 12:
                    requestManager.deleteRequest(scanner);
                    break;
                case 0:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
