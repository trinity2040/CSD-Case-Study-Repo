package bloodBankManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class DonorManager {

    public void addDonor(Scanner scanner) {
        System.out.println("Enter donor name:");
        String donorName = scanner.nextLine();
        System.out.println("Enter blood group:");
        String bloodGroup = scanner.nextLine();
        System.out.println("Enter contact number:");
        String contactNumber = scanner.nextLine();
        System.out.println("Enter email:");
        String email = scanner.nextLine();
        System.out.println("Enter last donation date (YYYY-MM-DD):");
        String lastDonationDate = scanner.nextLine();

        String query = "INSERT INTO Donor (donor_name, blood_group, contact_number, email, last_donation_date) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, donorName);
            stmt.setString(2, bloodGroup);
            stmt.setString(3, contactNumber);
            stmt.setString(4, email);
            stmt.setString(5, lastDonationDate);
            stmt.executeUpdate();
            System.out.println("Donor added successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewDonorDetails(Scanner scanner) {
        System.out.println("Enter donor ID:");
        int donorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query = "SELECT * FROM Donor WHERE donor_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, donorId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Donor Name: " + rs.getString("donor_name"));
                System.out.println("Blood Group: " + rs.getString("blood_group"));
                System.out.println("Contact Number: " + rs.getString("contact_number"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Last Donation Date: " + rs.getString("last_donation_date"));
            } else {
                System.out.println("Donor not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateDonorInfo(Scanner scanner) {
        System.out.println("Enter donor ID to update:");
        int donorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.println("Enter new donor name:");
        String donorName = scanner.nextLine();
        System.out.println("Enter new blood group:");
        String bloodGroup = scanner.nextLine();
        System.out.println("Enter new contact number:");
        String contactNumber = scanner.nextLine();
        System.out.println("Enter new email:");
        String email = scanner.nextLine();
        System.out.println("Enter new last donation date (YYYY-MM-DD):");
        String lastDonationDate = scanner.nextLine();

        String query = "UPDATE Donor SET donor_name = ?, blood_group = ?, contact_number = ?, email = ?, last_donation_date = ? WHERE donor_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, donorName);
            stmt.setString(2, bloodGroup);
            stmt.setString(3, contactNumber);
            stmt.setString(4, email);
            stmt.setString(5, lastDonationDate);
            stmt.setInt(6, donorId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Donor information updated successfully.");
            } else {
                System.out.println("Donor not found.");
            }
} catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteDonor(Scanner scanner) {
        System.out.println("Enter donor ID to delete:");
        int donorId = scanner.nextInt();

        String query = "DELETE FROM Donor WHERE donor_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, donorId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Donor deleted successfully.");
            } else {
                System.out.println("Donor not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
