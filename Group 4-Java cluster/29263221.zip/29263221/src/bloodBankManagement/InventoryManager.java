package bloodBankManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class InventoryManager {

    public void addDonation(Scanner scanner) {
        System.out.println("Enter donor ID:");
        int donorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.println("Enter donation date (YYYY-MM-DD):");
        String donationDate = scanner.nextLine();
        System.out.println("Enter blood group:");
        String bloodGroup = scanner.nextLine();
        System.out.println("Enter quantity (in ml):");
        int quantity = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.println("Enter expiry date (YYYY-MM-DD):");
        String expiryDate = scanner.nextLine();

        String query = "INSERT INTO Inventory (donor_id, donation_date, blood_group, quantity, expiry_date) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, donorId);
            stmt.setString(2, donationDate);
            stmt.setString(3, bloodGroup);
            stmt.setInt(4, quantity);
            stmt.setString(5, expiryDate);
            stmt.executeUpdate();
            System.out.println("Donation added successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewInventory(Scanner scanner) {
        System.out.println("Enter blood group to view inventory:");
        String bloodGroup = scanner.nextLine();

        String query = "SELECT * FROM Inventory WHERE blood_group = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, bloodGroup);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                System.out.println("Donation ID: " + rs.getInt("donation_id"));
                System.out.println("Donor ID: " + rs.getInt("donor_id"));
                System.out.println("Donation Date: " + rs.getDate("donation_date"));
                System.out.println("Quantity: " + rs.getInt("quantity") + " ml");
                System.out.println("Expiry Date: " + rs.getDate("expiry_date"));
                System.out.println("----------");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateInventory(Scanner scanner) {
        System.out.println("Enter donation ID to update:");
        int donationId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.println("Enter new donor ID:");
        int donorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.println("Enter new donation date (YYYY-MM-DD):");
        String donationDate = scanner.nextLine();
        System.out.println("Enter new blood group:");
        String bloodGroup = scanner.nextLine();
        System.out.println("Enter new quantity (in ml):");
        int quantity = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.println("Enter new expiry date (YYYY-MM-DD):");
        String expiryDate = scanner.nextLine();

        String query = "UPDATE Inventory SET donor_id = ?, donation_date = ?, blood_group = ?, quantity = ?, expiry_date = ? WHERE donation_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
stmt.setInt(1, donorId);
            stmt.setString(2, donationDate);
            stmt.setString(3, bloodGroup);
            stmt.setInt(4, quantity);
            stmt.setString(5, expiryDate);
            stmt.setInt(6, donationId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Inventory record updated successfully.");
            } else {
                System.out.println("Inventory record not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteInventory(Scanner scanner) {
        System.out.println("Enter donation ID to delete:");
        int donationId = scanner.nextInt();

        String query = "DELETE FROM Inventory WHERE donation_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, donationId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Inventory record deleted successfully.");
            } else {
                System.out.println("Inventory record not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}