package bloodBankManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class RequestManager {

    public void registerRequest(Scanner scanner) {
        System.out.println("Enter requester name:");
        String requesterName = scanner.nextLine();
        System.out.println("Enter blood group requested:");
        String bloodGroupRequested = scanner.nextLine();
        System.out.println("Enter request date (YYYY-MM-DD):");
        String requestDate = scanner.nextLine();
        System.out.println("Enter request status (Pending, Fulfilled, Cancelled):");
        String requestStatus = scanner.nextLine();

        String query = "INSERT INTO Request (requester_name, blood_group_requested, request_date, request_status) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, requesterName);
            stmt.setString(2, bloodGroupRequested);
            stmt.setString(3, requestDate);
            stmt.setString(4, requestStatus);
            stmt.executeUpdate();
            System.out.println("Request registered successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewRequestDetails(Scanner scanner) {
        System.out.println("Enter request ID:");
        int requestId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query = "SELECT * FROM Request WHERE request_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, requestId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Requester Name: " + rs.getString("requester_name"));
                System.out.println("Blood Group Requested: " + rs.getString("blood_group_requested"));
                System.out.println("Request Date: " + rs.getDate("request_date"));
                System.out.println("Request Status: " + rs.getString("request_status"));
            } else {
                System.out.println("Request not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateRequestStatus(Scanner scanner) {
        System.out.println("Enter request ID to update:");
        int requestId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.println("Enter new request status (Pending, Fulfilled, Cancelled):");
        String requestStatus = scanner.nextLine();

        String query = "UPDATE Request SET request_status = ? WHERE request_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, requestStatus);
            stmt.setInt(2, requestId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Request status updated successfully.");
            } else {
                System.out.println("Request not found.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteRequest(Scanner scanner) {
        System.out.println("Enter request ID to delete:");
        int requestId = scanner.nextInt();

        String query = "DELETE FROM Request WHERE request_id = ?";
        try (Connection conn = DatabaseConnector.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, requestId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Request deleted successfully.");
            } else {
                System.out.println("Request not found.");
            }
} catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
