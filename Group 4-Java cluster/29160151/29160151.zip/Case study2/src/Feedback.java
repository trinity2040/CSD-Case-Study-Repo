// public class Feedback {
//     private int feedbackId;        // feedback_id column
//     private int customerId;        // customer_id column (Foreign Key)
//     private String feedbackDate;   // feedback_date column
//     private String feedbackText;   // feedback_text column
//     private int rating;            // rating column

//     // Constructors
//     public Feedback() {}

//     public Feedback(int feedbackId, int customerId, String feedbackDate, String feedbackText, int rating) {
//         this.feedbackId = feedbackId;
//         this.customerId = customerId;
//         this.feedbackDate = feedbackDate;
//         this.feedbackText = feedbackText;
//         this.rating = rating;
//     }

//     // Getters and setters
//     public int getFeedbackId() {
//         return feedbackId;
//     }

//     public void setFeedbackId(int feedbackId) {
//         this.feedbackId = feedbackId;
//     }

//     public int getCustomerId() {
//         return customerId;
//     }

//     public void setCustomerId(int customerId) {
//         this.customerId = customerId;
//     }

//     public String getFeedbackDate() {
//         return feedbackDate;
//     }

//     public void setFeedbackDate(String feedbackDate) {
//         this.feedbackDate = feedbackDate;
//     }

//     public String getFeedbackText() {
//         return feedbackText;
//     }

//     public void setFeedbackText(String feedbackText) {
//         this.feedbackText = feedbackText;
//     }

//     public int getRating() {
//         return rating;
//     }

//     public void setRating(int rating) {
//         this.rating = rating;
//     }
// }

public class Feedback {
    private int feedbackId;
    private int customerId;
    private String feedbackDate;
    private String feedbackText;
    private int rating;

    // Constructor
    public Feedback(int feedbackId, int customerId, String feedbackDate, String feedbackText, int rating) {
        this.feedbackId = feedbackId;
        this.customerId = customerId;
        this.feedbackDate = feedbackDate;
        this.feedbackText = feedbackText;
        this.rating = rating;
    }

    // Getters and Setters
    public int getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(int feedbackId) {
        this.feedbackId = feedbackId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getFeedbackDate() {
        return feedbackDate;
    }

    public void setFeedbackDate(String feedbackDate) {
        this.feedbackDate = feedbackDate;
    }

    public String getFeedbackText() {
        return feedbackText;
    }

    public void setFeedbackText(String feedbackText) {
        this.feedbackText = feedbackText;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    // toString method for easy display of feedback information
    @Override
    public String toString() {
        return "Feedback{" +
                "feedbackId=" + feedbackId +
                ", customerId=" + customerId +
                ", feedbackDate='" + feedbackDate + '\'' +
                ", feedbackText='" + feedbackText + '\'' +
                ", rating=" + rating +
                '}';
    }
}