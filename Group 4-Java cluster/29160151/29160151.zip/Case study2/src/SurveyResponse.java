// public class SurveyResponse {
//     private int responseId;       // response_id column
//     private int surveyId;         // survey_id column (Foreign Key)
//     private int customerId;       // customer_id column (Foreign Key)
//     private String responseDate;  // response_date column
//     private String responseText;  // response_text column

//     // Constructors
//     public SurveyResponse() {}

//     public SurveyResponse(int responseId, int surveyId, int customerId, String responseDate, String responseText) {
//         this.responseId = responseId;
//         this.surveyId = surveyId;
//         this.customerId = customerId;
//         this.responseDate = responseDate;
//         this.responseText = responseText;
//     }

//     // Getters and setters
//     public int getResponseId() {
//         return responseId;
//     }

//     public void setResponseId(int responseId) {
//         this.responseId = responseId;
//     }

//     public int getSurveyId() {
//         return surveyId;
//     }

//     public void setSurveyId(int surveyId) {
//         this.surveyId = surveyId;
//     }

//     public int getCustomerId() {
//         return customerId;
//     }

//     public void setCustomerId(int customerId) {
//         this.customerId = customerId;
//     }

//     public String getResponseDate() {
//         return responseDate;
//     }

//     public void setResponseDate(String responseDate) {
//         this.responseDate = responseDate;
//     }

//     public String getResponseText() {
//         return responseText;
//     }

//     public void setResponseText(String responseText) {
//         this.responseText = responseText;
//     }
// }

public class SurveyResponse {
    private int responseId;
    private int surveyId;
    private int customerId;
    private String responseDate;
    private String responseText;

    // Constructor
    public SurveyResponse() {
    }

    public SurveyResponse(int responseId, int surveyId, int customerId, String responseDate, String responseText) {
        this.responseId = responseId;
        this.surveyId = surveyId;
        this.customerId = customerId;
        this.responseDate = responseDate;
        this.responseText = responseText;
    }

    // Getters and Setters
    public int getResponseId() {
        return responseId;
    }

    public void setResponseId(int responseId) {
        this.responseId = responseId;
    }

    public int getSurveyId() {
        return surveyId;
    }

    public void setSurveyId(int surveyId) {
        this.surveyId = surveyId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getResponseDate() {
        return responseDate;
    }

    public void setResponseDate(String responseDate) {
        this.responseDate = responseDate;
    }

    public String getResponseText() {
        return responseText;
    }

    public void setResponseText(String responseText) {
        this.responseText = responseText;
    }

    // toString method for easy display of survey response information
    @Override
    public String toString() {
        return "SurveyResponse{" +
                "responseId=" + responseId +
                ", surveyId=" + surveyId +
                ", customerId=" + customerId +
                ", responseDate='" + responseDate + '\'' +
                ", responseText='" + responseText + '\'' +
                '}';
    }
}