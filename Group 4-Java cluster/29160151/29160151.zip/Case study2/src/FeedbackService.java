import java.util.List;
import java.util.Scanner;

public class FeedbackService {
    private FeedbackDAO feedbackDAO;

    public FeedbackService() {
        this.feedbackDAO = new FeedbackDAO();
    }

    public void manageFeedback() {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("1. Submit Feedback");
            System.out.println("2. View All Feedback");
            System.out.println("3. Update Feedback");
            System.out.println("4. Delete Feedback");
            System.out.println("5. Exit");

            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    submitFeedback();
                    break;
                case 2:
                    viewAllFeedback();
                    break;
                case 3:
                    updateFeedback();
                    break;
                case 4:
                    deleteFeedback();
                    break;
                case 5:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice");
            }
        }
    }

    private void submitFeedback() {
        try (Scanner sc = new Scanner(System.in)) {
            Feedback feedback = new Feedback();
            System.out.print("Enter Customer ID: ");
            feedback.setCustomerId(sc.nextInt());
            sc.nextLine();  // Consume newline
            System.out.print("Enter Feedback: ");
            feedback.setFeedbackText(sc.nextLine());
            System.out.print("Enter Rating (1-5): ");
            feedback.setRating(sc.nextInt());

            // Set feedback date
            feedback.setFeedbackDate(java.time.LocalDate.now().toString());

            feedbackDAO.addFeedback(feedback);
        }
        System.out.println("Feedback submitted successfully.");
    }

    private void viewAllFeedback() {
        List<Feedback> feedbackList = feedbackDAO.getAllFeedback();

        if (feedbackList.isEmpty()) {
            System.out.println("No feedback available.");
        } else {
            System.out.println("Feedback List:");
            for (Feedback feedback : feedbackList) {
                System.out.println("ID: " + feedback.getFeedbackId());
                System.out.println("Customer ID: " + feedback.getCustomerId());
                System.out.println("Feedback: " + feedback.getFeedbackText());
                System.out.println("Rating: " + feedback.getRating());
                System.out.println("Date: " + feedback.getFeedbackDate());
                System.out.println("--------------------------------");
            }
        }
    }

    private void updateFeedback() {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Enter Feedback ID to update: ");
            int feedbackId = sc.nextInt();
            sc.nextLine();  // Consume newline

            Feedback feedback = feedbackDAO.getFeedbackById(feedbackId);

            if (feedback != null) {
                System.out.print("Enter new Feedback: ");
                feedback.setFeedbackText(sc.nextLine());
                System.out.print("Enter new Rating (1-5): ");
                feedback.setRating(sc.nextInt());

                feedbackDAO.updateFeedback(feedback);
                System.out.println("Feedback updated successfully.");
            } else {
                System.out.println("Feedback with ID " + feedbackId + " not found.");
            }
        }
    }

    private void deleteFeedback() {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.print("Enter Feedback ID to delete: ");
            int feedbackId = sc.nextInt();

            Feedback feedback = feedbackDAO.getFeedbackById(feedbackId);

            if (feedback != null) {
                feedbackDAO.deleteFeedback(feedbackId);
                System.out.println("Feedback deleted successfully.");
            } else {
                System.out.println("Feedback with ID " + feedbackId + " not found.");
            }
        }
    }
}

class FeedbackDAO {

    public void addFeedback(Feedback feedback) {
        throw new UnsupportedOperationException("Unimplemented method 'addFeedback'");
    }
    // Implementation of FeedbackDAO

    public void deleteFeedback(int feedbackId) {
        throw new UnsupportedOperationException("Unimplemented method 'deleteFeedback'");
    }

    public void updateFeedback(Feedback feedback) {
        throw new UnsupportedOperationException("Unimplemented method 'updateFeedback'");
    }

    public Feedback getFeedbackById(int feedbackId) {
        throw new UnsupportedOperationException("Unimplemented method 'getFeedbackById'");
    }

    public List<Feedback> getAllFeedback() {
        throw new UnsupportedOperationException("Unimplemented method 'getAllFeedback'");
    }
}

class Feedback {
    private int feedbackId;
    private int customerId;
    private String feedbackText;
    private int rating;
    private String feedbackDate;

    // Getters and setters
    public int getFeedbackId() {
        return feedbackId;
    }

    public void setFeedbackId(int feedbackId) {
        this.feedbackId = feedbackId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public String getFeedbackText() {
        return feedbackText;
    }

    public void setFeedbackText(String feedbackText) {
        this.feedbackText = feedbackText;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getFeedbackDate() {
        return feedbackDate;
    }

    public void setFeedbackDate(String feedbackDate) {
        this.feedbackDate = feedbackDate;
    }
}