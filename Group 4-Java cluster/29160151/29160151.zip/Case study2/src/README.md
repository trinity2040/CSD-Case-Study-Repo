# Customer Feedback and Survey System

## Description
The Customer Feedback and Survey System is a console-based Java application designed to manage customer feedback and surveys. Built using Core Java with MySQL as the backend database and JDBC (Java Database Connectivity) for database operations, this system features a menu-driven interface for performing CRUD (Create, Read, Update, Delete) operations on feedback and survey data.

## Features
- **Feedback Management**: Add, view, update, and delete feedback submissions.
- **Survey Management**: Create, view, update, and delete surveys.
- **Analysis**: Generate basic analysis reports based on feedback.

## System Requirements
- Java Development Kit (JDK) 8 or later
- MySQL Server
- MySQL Connector/J (JDBC Driver)
- Integrated Development Environment (IDE): IntelliJ IDEA, Eclipse, or any other Java IDE

## Setup Instructions
1. **Database Setup**:
   - Create a MySQL database named `customer_feedback_db`.
   - Create the following tables:

     ```sql
     CREATE TABLE Feedback (
        feedback_id INT AUTO_INCREMENT PRIMARY KEY,
        customer_name VARCHAR(100) NOT NULL,
        feedback_text TEXT NOT NULL,
        feedback_date DATE NOT NULL
     );

     CREATE TABLE Survey (
        survey_id INT AUTO_INCREMENT PRIMARY KEY,
        survey_title VARCHAR(100) NOT NULL,
        survey_description TEXT,
        creation_date DATE NOT NULL
     );

     CREATE TABLE SurveyResponse (
        response_id INT AUTO_INCREMENT PRIMARY KEY,
        survey_id INT,
        customer_name VARCHAR(100) NOT NULL,
        response_text TEXT NOT NULL,
        response_date DATE NOT NULL,
        FOREIGN KEY (survey_id) REFERENCES Survey(survey_id)
     );
     ```

2. **Configure the Application**:
   - Open the `DBconnection.java` file located in the `src/database` directory and update it with your MySQL database credentials:

   ```java
   private static final String URL = "jdbc:mysql://localhost:3306/customer_feedback_db";
   private static final String USER = "your_username";
   private static final String PASSWORD = "your_password";
   ```

3. **Run the Application**:
   - Compile and run the `DBconnection.java` class.
   - Follow the on-screen menu to manage feedback submissions, surveys, and analyze data.

## Usage
- Use the menu options to add, view, update, or delete records for feedback and surveys.
- Generate analysis reports to review feedback trends and survey results.

## Notes
- Ensure that your MySQL server is running and accessible.
- Modify the database credentials in the `DBconnection.java` file as needed.

---