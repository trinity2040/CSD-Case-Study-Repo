// import java.sql.Connection;
// import java.sql.DriverManager;
// import java.sql.SQLException;

// public class DBConnection {
//     private static final String URL = "jdbc:mysql://localhost:3306/demodb";
//     private static final String USERNAME = "root";
//     private static final String PASSWORD = "Srihitha@123";

//     public static Connection getConnection() throws SQLException {
//         return DriverManager.getConnection(URL, USERNAME, PASSWORD);
//     }
// }

// import java.sql.Connection;
// import java.sql.DriverManager;
// import java.sql.Statement;
// import javax.swing.JOptionPane;

// public class DBConnection {

//     public static void main(String[] args) throws Exception {
//         try {
//             String url = "jdbc:mysql://localhost:3306/";

//             String databaseName = "firstdemo";

//             String userName = "root";
//             String password = "Srihitha@123";

//             Connection connection = DriverManager.getConnection(url, userName, password);

//             String sql = "CREATE DATABASE " + databaseName;

//             Statement statement = connection.createStatement();
//             statement.executeUpdate(sql);
//             statement.close();
//             JOptionPane.showMessageDialog(null, databaseName + " Database has been created successfully",
//                     "System Message", JOptionPane.INFORMATION_MESSAGE);

//         } catch (Exception e) {
//             e.printStackTrace();
//         }
//     }

//     public static Connection getConnection() {
//         throw new UnsupportedOperationException("Unimplemented method 'getConnection'");
//     }
// } 

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class DBConnection {

    public static void main(String[] args) throws Exception {
        try {
            String url = "jdbc:mysql://localhost:3306/";

            String databaseName = "siri";

            String userName = "root";
            String password = "Srihitha@123";

            Connection connection = DriverManager.getConnection(url, userName, password);

            String sql = "CREATE DATABASE " + databaseName;

            Statement statement = connection.createStatement();
            statement.executeUpdate(sql);
            statement.close();
            JOptionPane.showMessageDialog(null, databaseName + " Database has been created successfully",
                    "System Message", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Connection getConnection() throws Exception {
        String url = "jdbc:mysql://localhost:3306/siri";
        String userName = "root";
        String password = "Srihitha@123";
        return DriverManager.getConnection(url, userName, password);
    }
}