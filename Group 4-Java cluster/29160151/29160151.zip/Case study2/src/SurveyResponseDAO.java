import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SurveyResponseDAO {
    public void addResponse(SurveyResponse response) throws Exception {
        String sql = "INSERT INTO SurveyResponse (survey_id, customer_id, response_date, response_text) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, response.getSurveyId());
            stmt.setInt(2, response.getCustomerId());
            stmt.setString(3, response.getResponseDate());
            stmt.setString(4, response.getResponseText());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Read: Retrieve survey response by ID
    public SurveyResponse getResponseById(int responseId) throws Exception {
        SurveyResponse response = null;
        String sql = "SELECT * FROM SurveyResponse WHERE response_id = ?";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, responseId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                response = new SurveyResponse();
                response.setResponseId(rs.getInt("response_id"));
                response.setSurveyId(rs.getInt("survey_id"));
                response.setCustomerId(rs.getInt("customer_id"));
                response.setResponseDate(rs.getString("response_date"));
                response.setResponseText(rs.getString("response_text"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return response;
    }

    // Read: Retrieve all responses for a specific survey
    public List<SurveyResponse> getResponsesBySurveyId(int surveyId) throws Exception {
        List<SurveyResponse> responses = new ArrayList<>();
        String sql = "SELECT * FROM SurveyResponse WHERE survey_id = ?";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, surveyId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                SurveyResponse response = new SurveyResponse();
                response.setResponseId(rs.getInt("response_id"));
                response.setSurveyId(rs.getInt("survey_id"));
                response.setCustomerId(rs.getInt("customer_id"));
                response.setResponseDate(rs.getString("response_date"));
                response.setResponseText(rs.getString("response_text"));
                responses.add(response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return responses;
    }

    // Update: Update an existing survey response
    public void updateResponse(SurveyResponse response) throws Exception {
        String sql = "UPDATE SurveyResponse SET survey_id = ?, customer_id = ?, response_date = ?, response_text = ? WHERE response_id = ?";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, response.getSurveyId());
            stmt.setInt(2, response.getCustomerId());
            stmt.setString(3, response.getResponseDate());
            stmt.setString(4, response.getResponseText());
            stmt.setInt(5, response.getResponseId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete: Remove a survey response by ID
    public void deleteResponse(int responseId) throws Exception {
        String sql = "DELETE FROM SurveyResponse WHERE response_id = ?";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, responseId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}