import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class FeedbackDAO {

    public FeedbackDAO(Connection connection) {
    }

    public void addFeedback(Feedback feedback) throws Exception {
        String sql = "INSERT INTO Feedback (customer_id, feedback_date, feedback_text, rating) VALUES (?, ?, ?, ?)";
        try (Connection connection = DBConnection.getConnection();
                PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, feedback.getCustomerId());
            stmt.setString(2, feedback.getFeedbackDate());
            stmt.setString(3, feedback.getFeedbackText());
            stmt.setInt(4, feedback.getRating());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Read: Retrieve feedback by ID
    public Feedback getFeedbackById(int feedbackId) throws Exception {
        Feedback feedback = null;
        String sql = "SELECT * FROM Feedback WHERE feedback_id = ?";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, feedbackId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                feedback = new Feedback();
                feedback.setFeedbackId(rs.getInt("feedback_id"));
                feedback.setCustomerId(rs.getInt("customer_id"));
                feedback.setFeedbackDate(rs.getString("feedback_date"));
                feedback.setFeedbackText(rs.getString("feedback_text"));
                feedback.setRating(rs.getInt("rating"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return feedback;
    }

    // Read: Retrieve all feedback
    public List<Feedback> getAllFeedback() throws Exception {
        List<Feedback> feedbackList = new ArrayList<>();
        String sql = "SELECT * FROM Feedback";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Feedback feedback = new Feedback();
                feedback.setFeedbackId(rs.getInt("feedback_id"));
                feedback.setCustomerId(rs.getInt("customer_id"));
                feedback.setFeedbackDate(rs.getString("feedback_date"));
                feedback.setFeedbackText(rs.getString("feedback_text"));
                feedback.setRating(rs.getInt("rating"));
                feedbackList.add(feedback);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return feedbackList;
    }

    // Update: Update existing feedback
    public void updateFeedback(Feedback feedback) throws Exception {
        String sql = "UPDATE Feedback SET customer_id = ?, feedback_date = ?, feedback_text = ?, rating = ? WHERE feedback_id = ?";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, feedback.getCustomerId());
            stmt.setString(2, feedback.getFeedbackDate());
            stmt.setString(3, feedback.getFeedbackText());
            stmt.setInt(4, feedback.getRating());
            stmt.setInt(5, feedback.getFeedbackId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete: Remove feedback by ID
    public void deleteFeedback(int feedbackId) throws Exception {
        String sql = "DELETE FROM Feedback WHERE feedback_id = ?";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, feedbackId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
