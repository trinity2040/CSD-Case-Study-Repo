package com.cts.model;

import java.sql.Connection;

// public class DBConnection {

//     public static Connection getConnection() {
//         throw new UnsupportedOperationException("Unimplemented method 'getConnection'");
//     }
// import java.sql.DriverManager;
// import java.sql.Statement;
// import javax.swing.JOptionPane;

// public class DBConnection {

//     public static void main(String[] args) throws Exception {
//         try {
//             String url = "jdbc:mysql://localhost:3306/";

//             String databaseName = "seven";

//             String userName = "root";
//             String password = "Srihitha@123";

//             Connection connection = DriverManager.getConnection(url, userName, password);

//             String sql = "CREATE DATABASE " + databaseName;

//             Statement statement = connection.createStatement();
//             statement.executeUpdate(sql);
//             statement.close();
//             JOptionPane.showMessageDialog(null, databaseName + " Database has been created successfully",
//                     "System Message", JOptionPane.INFORMATION_MESSAGE);

//         } catch (Exception e) {
//             e.printStackTrace();
//         }
//     }

//     public static Connection getConnection() {
//         throw new UnsupportedOperationException("Unimplemented method 'getConnection'");
//     }
// }

// import java.sql.DriverManager;
// import java.sql.SQLException;

// public class DBConnection {

//     private static final String URL = "jdbc:mysql://localhost:3306/chandhu";
//     private static final String USERNAME = "root";
//     private static final String PASSWORD = "Srihitha@123";

//     public static Connection getConnection() {
//         try {
//             return DriverManager.getConnection(URL, USERNAME, PASSWORD);
//         } catch (SQLException e) {
//             System.out.println("Error connecting to database: " + e.getMessage());
//             return null;
//         }
//     }

//     public static void main(String[] args) {
//         // This main method is not needed, remove it
//     }
// }

import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

public class DBConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/";
    private static final String DATABASE_NAME = "siri";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "Srihitha@123";

    public static Connection getConnection() {
        try {
            String url = URL + DATABASE_NAME;
            return DriverManager.getConnection(url, USERNAME, PASSWORD);
        } catch (SQLException e) {
            System.out.println("Error connecting to database: " + e.getMessage());
            return null;
        }
    }

    public static void createDatabase() {
        try {
            String url = URL;
            Connection connection = DriverManager.getConnection(url, USERNAME, PASSWORD);

            String sql = "CREATE DATABASE " + DATABASE_NAME;

            Statement statement = connection.createStatement();
            statement.executeUpdate(sql);
            statement.close();
            JOptionPane.showMessageDialog(null, DATABASE_NAME + " Database has been created successfully",
                    "System Message", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        createDatabase();
    }
}