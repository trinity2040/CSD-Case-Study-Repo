package com.cts.model;
// public class Survey {

//     private int surveyId;             // survey_id column
//     private String surveyName;        // survey_name column
//     private String surveyDescription; // survey_description column
//     private String status;            // status column

//     // Constructors
//     public Survey() {}

//     public Survey(int surveyId, String surveyName, String surveyDescription, String status) {
//         this.surveyId = surveyId;
//         this.surveyName = surveyName;
//         this.surveyDescription = surveyDescription;
//         this.status = status;
//     }

//     // Getters and setters
//     public int getSurveyId() {
//         return surveyId;
//     }

//     public void setSurveyId(int surveyId) {
//         this.surveyId = surveyId;
//     }

//     public String getSurveyName() {
//         return surveyName;
//     }

//     public void setSurveyName(String surveyName) {
//         this.surveyName = surveyName;
//     }

//     public String getSurveyDescription() {
//         return surveyDescription;
//     }

//     public void setSurveyDescription(String surveyDescription) {
//         this.surveyDescription = surveyDescription;
//     }

//     public String getStatus() {
//         return status;
//     }

//     public void setStatus(String status) {
//         this.status = status;
//     }
// }

public class Survey {
    private int surveyId;
    private String surveyName;
    private String surveyDescription;
    private String status;

    // Constructor
    // Default constructor
    public Survey() {
    }

    public Survey(int surveyId, String surveyName, String surveyDescription, String status) {
        this.surveyId = surveyId;
        this.surveyName = surveyName;
        this.surveyDescription = surveyDescription;
        this.status = status;
    }

    // Getters and Setters
    public int getSurveyId() {
        return surveyId;
    }

    public void setSurveyId(int surveyId) {
        this.surveyId = surveyId;
    }

    public String getSurveyName() {
        return surveyName;
    }

    public void setSurveyName(String surveyName) {
        this.surveyName = surveyName;
    }

    public String getSurveyDescription() {
        return surveyDescription;
    }

    public void setSurveyDescription(String surveyDescription) {
        this.surveyDescription = surveyDescription;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // toString method for easy display of survey information
    @Override
    public String toString() {
        return "Survey{" +
                "surveyId=" + surveyId +
                ", surveyName='" + surveyName + '\'' +
                ", surveyDescription='" + surveyDescription + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}