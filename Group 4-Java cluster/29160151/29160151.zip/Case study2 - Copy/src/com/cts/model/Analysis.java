package com.cts.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Analysis {

    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu() throws Exception {
        while (true) {
            System.out.println("\n--- Analysis and Reporting ---");
            System.out.println("1. Average Feedback Rating");
            System.out.println("2. Feedback Count by Rating");
            System.out.println("3. Survey Response Count");
            System.out.println("4. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    analyzeFeedback();
                    break;
                case 2:
                    reportFeedbackCountByRating();
                    break;
                case 3:
                    reportSurveyResponseCount();
                    break;
                case 4:
                    return; // Go back to the main menu
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void analyzeFeedback() throws Exception {
        String sql = "SELECT AVG(rating) AS average_rating FROM Feedback";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

            if (rs.next()) {
                double averageRating = rs.getDouble("average_rating");
                System.out.println("Average Rating: " + averageRating);
            } else {
                System.out.println("No feedback data available.");
            }
        } catch (SQLException e) {
            System.out.println("Error analyzing feedback: " + e.getMessage());
        }
    }

    private void reportFeedbackCountByRating() throws Exception {
        String sql = "SELECT rating, COUNT(*) AS count FROM Feedback GROUP BY rating";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int rating = rs.getInt("rating");
                int count = rs.getInt("count");
                System.out.println("Rating " + rating + ": " + count + " feedback(s)");
            }
        } catch (SQLException e) {
            System.out.println("Error reporting feedback count by rating: " + e.getMessage());
        }
    }

    private void reportSurveyResponseCount() throws Exception {
        String sql = "SELECT survey_id, COUNT(*) AS response_count FROM SurveyResponse GROUP BY survey_id";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int surveyId = rs.getInt("survey_id");
                int responseCount = rs.getInt("response_count");
                System.out.println("Survey ID " + surveyId + ": " + responseCount + " response(s)");
            }
        } catch (SQLException e) {
            System.out.println("Error reporting survey response count: " + e.getMessage());
        }
    }

    public static void main(String[] args) throws Exception {
        Analysis analysis = new Analysis();
        analysis.displayMenu();
    }
}
