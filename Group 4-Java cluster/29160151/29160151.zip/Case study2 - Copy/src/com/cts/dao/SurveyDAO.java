package com.cts.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cts.model.DBConnection;
import com.cts.model.Survey;

public class SurveyDAO {

    public interface Surveydao {
        void createSurvey(Survey survey);

        Survey getSurveyById(int surveyId);

        List<Survey> getAllSurveys();

        void updateSurvey(Survey survey);

        void deleteSurvey(int surveyId);
    }

    // Create: Add a new survey
    public void createSurvey(Survey survey) throws Exception {
        String sql = "INSERT INTO Survey (survey_name, survey_description, status) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, survey.getSurveyName());
            stmt.setString(2, survey.getSurveyDescription());
            stmt.setString(3, survey.getStatus());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Read: Retrieve a survey by ID
    public Survey getSurveyById(int surveyId) throws Exception {
        Survey survey = null;
        String sql = "SELECT * FROM Survey WHERE survey_id = ?";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, surveyId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                survey = new Survey(surveyId, sql, sql, sql);
                survey.setSurveyId(rs.getInt("survey_id"));
                survey.setSurveyName(rs.getString("survey_name"));
                survey.setSurveyDescription(rs.getString("survey_description"));
                survey.setStatus(rs.getString("status"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return survey;
    }

    // Read: Retrieve all surveys
    public List<Survey> getAllSurveys() throws Exception {
        List<Survey> surveys = new ArrayList<>();
        String sql = "SELECT * FROM Survey";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Survey survey = new Survey();
                survey.setSurveyId(rs.getInt("survey_id"));
                survey.setSurveyName(rs.getString("survey_name"));
                survey.setSurveyDescription(rs.getString("survey_description"));
                survey.setStatus(rs.getString("status"));
                surveys.add(survey);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return surveys;
    }

    // Update: Update an existing survey
    public void updateSurvey(Survey survey) throws Exception {
        String sql = "UPDATE Survey SET survey_name = ?, survey_description = ?, status = ? WHERE survey_id = ?";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, survey.getSurveyName());
            stmt.setString(2, survey.getSurveyDescription());
            stmt.setString(3, survey.getStatus());
            stmt.setInt(4, survey.getSurveyId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete: Remove a survey by ID
    public void deleteSurvey(int surveyId) throws Exception {
        String sql = "DELETE FROM Survey WHERE survey_id = ?";
        try (Connection conn = DBConnection.getConnection();
                PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, surveyId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}