package com.cts.dao;

import java.util.ArrayList;
import java.util.List;

import com.cts.dao.SurveyDAO.Surveydao;
import com.cts.model.Survey;

public class SurveydaoImpl implements Surveydao {
    private List<Survey> surveys = new ArrayList<>();

    @Override
    public void createSurvey(Survey survey) {
        surveys.add(survey);
    }

    @Override
    public Survey getSurveyById(int surveyId) {
        for (Survey survey : surveys) {
            if (survey.getSurveyId() == surveyId) {
                return survey;
            }
        }
        return null;
    }

    @Override
    public List<Survey> getAllSurveys() {
        return surveys;
    }

    @Override
    public void updateSurvey(Survey survey) {
        for (int i = 0; i < surveys.size(); i++) {
            if (surveys.get(i).getSurveyId() == survey.getSurveyId()) {
                surveys.set(i, survey);
                return;
            }
        }
    }

    @Override
    public void deleteSurvey(int surveyId) {
        throw new UnsupportedOperationException("Unimplemented method 'deleteSurvey'");
    }
}