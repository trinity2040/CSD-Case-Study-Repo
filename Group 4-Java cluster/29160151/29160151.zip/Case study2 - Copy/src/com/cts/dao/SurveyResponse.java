package com.cts.dao;

public class SurveyResponse {

    public void setResponseId(int int1) {
        throw new UnsupportedOperationException("Unimplemented method 'setResponseId'");
    }

    public void setSurveyId(int int1) {
        throw new UnsupportedOperationException("Unimplemented method 'setSurveyId'");
    }

    public void setCustomerId(int int1) {
        throw new UnsupportedOperationException("Unimplemented method 'setCustomerId'");
    }

    public void setResponseDate(String string) {
        throw new UnsupportedOperationException("Unimplemented method 'setResponseDate'");
    }

    public void setResponseText(String string) {
        throw new UnsupportedOperationException("Unimplemented method 'setResponseText'");
    }

    public int getSurveyId() {
        throw new UnsupportedOperationException("Unimplemented method 'getSurveyId'");
    }

    public int getCustomerId() {
        throw new UnsupportedOperationException("Unimplemented method 'getCustomerId'");
    }

    public String getResponseDate() {
        throw new UnsupportedOperationException("Unimplemented method 'getResponseDate'");
    }

    public String getResponseText() {
        throw new UnsupportedOperationException("Unimplemented method 'getResponseText'");
    }

    public int getResponseId() {
        throw new UnsupportedOperationException("Unimplemented method 'getResponseId'");
    }

}
