// package com.cts.services;

// import java.util.Scanner;

// import com.cts.dao.Surveydao;
// import com.cts.dao.SurveydaoImpl;
// import com.cts.model.Survey;

// public class SurveyService {
//     public Surveydao surveyDAO = new SurveydaoImpl(); // Use the SurveydaoImpl here

//     public void manageSurveys() {
//         try (Scanner scanner = new Scanner(System.in)) {
//             // Display options to the user
//             System.out.println("1. Create Survey");
//             System.out.println("2. View Survey");
//             System.out.println("3. Update Survey");
//             System.out.println("4. Delete Survey");
//             int choice = scanner.nextInt();

//             switch (choice) {
//                 case 1:
//                     createSurvey();
//                     break;
//                 case 2:
//                     viewSurvey();
//                     break;
//                 case 3:
//                     updateSurvey();
//                     break;
//                 case 4:
//                     deleteSurvey();
//                     break;
//                 default:
//                     System.out.println("Invalid choice");
//             }
//         }
//     }

//     private void createSurvey() {
//         try (Scanner scanner = new Scanner(System.in)) {
//             Survey survey = new Survey();
//             // Survey survey = new Survey(surveyName, surveyDescription, status);
//             // Prompt user for survey details
//             System.out.print("Enter Survey Name: ");
//             survey.setSurveyName(scanner.nextLine());

//             System.out.print("Enter Survey Description: ");
//             survey.setSurveyDescription(scanner.nextLine());

//             System.out.print("Enter Status: ");
//             survey.setStatus(scanner.nextLine());

//             // Save the survey using Surveydao
//             surveyDAO.createSurvey(survey);
//         }
//         // Confirm survey creation
//         System.out.println("Survey created successfully.");
//     }

//     private void viewSurvey() {
//         try (Scanner scanner = new Scanner(System.in)) {
//             System.out.print("Enter Survey ID to view: ");
//             int surveyId = scanner.nextInt();

//             // Retrieve the survey using Surveydao
//             Survey survey = surveyDAO.getSurveyById(surveyId);

//             if (survey != null) {
//                 // Display survey details
//                 System.out.println("Survey Name: " + survey.getSurveyName());
//                 System.out.println("Survey Description: " + survey.getSurveyDescription());
//                 System.out.println("Status: " + survey.getStatus());
//             } else {
//                 System.out.println("Survey not found.");
//             }
//         }
//     }

//     private void updateSurvey() {
//         try (Scanner scanner = new Scanner(System.in)) {
//             System.out.print("Enter Survey ID to update: ");
//             int surveyId = scanner.nextInt();
//             scanner.nextLine(); // Consume newline

//             // Retrieve the survey using Surveydao
//             Survey survey = surveyDAO.getSurveyById(surveyId);

//             if (survey != null) {
//                 // Prompt user for new survey details
//                 System.out.print("Enter new Survey Name (current: " + survey.getSurveyName() + "): ");
//                 survey.setSurveyName(scanner.nextLine());

//                 System.out.print("Enter new Survey Description (current: " + survey.getSurveyDescription() + "): ");
//                 survey.setSurveyDescription(scanner.nextLine());

//                 System.out.print("Enter new Status (current: " + survey.getStatus() + "): ");
//                 survey.setStatus(scanner.nextLine());

//                 // Update the survey using Surveydao
//                 surveyDAO.updateSurvey(survey);

//                 // Confirm survey update
//                 System.out.println("Survey updated successfully.");
//             } else {
//                 System.out.println("Survey not found.");
//             }
//         }
//     }

//     // Method to delete an existing survey
//     private void deleteSurvey() {
//         try (Scanner scanner = new Scanner(System.in)) {
//             System.out.print("Enter Survey ID to delete: ");
//             int surveyId = scanner.nextInt();

//             // Retrieve the survey using Surveydao
//             Survey survey = surveyDAO.getSurveyById(surveyId);

//             if (survey != null) {
//                 // Confirm and delete the survey
//                 surveyDAO.deleteSurvey(surveyId);
//                 System.out.println("Survey deleted successfully.");
//             } else {
//                 System.out.println("Survey not found.");
//             }
//         }
//     }
// }

package com.cts.services;

import java.util.Scanner;
//import com.cts.dao.SurveyDAO;
import com.cts.dao.SurveydaoImpl;
import com.cts.model.Survey;

public class SurveyService {
    public SurveydaoImpl surveyDAO = new SurveydaoImpl(); // Use the SurveyDAOImpl here

    public void manageSurveys() {
        try (Scanner scanner = new Scanner(System.in)) {
            // Display options to the user
            System.out.println("1. Create Survey");
            System.out.println("2. View Survey");
            System.out.println("3. Update Survey");
            System.out.println("4. Delete Survey");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    createSurvey(scanner);
                    break;
                case 2:
                    viewSurvey(scanner);
                    break;
                case 3:
                    updateSurvey(scanner);
                    break;
                case 4:
                    deleteSurvey(scanner);
                    break;
                default:
                    System.out.println("Invalid choice");
            }
        }
    }

    private void createSurvey(Scanner scanner) {
        Survey survey = new Survey();
        // Prompt user for survey details
        System.out.print("Enter Survey Name: ");
        survey.setSurveyName(scanner.nextLine());

        System.out.print("Enter Survey Description: ");
        survey.setSurveyDescription(scanner.nextLine());

        System.out.print("Enter Status: ");
        survey.setStatus(scanner.nextLine());

        // Save the survey using SurveyDAO
        surveyDAO.createSurvey(survey);
        // Confirm survey creation
        System.out.println("Survey created successfully.");
    }

    private void viewSurvey(Scanner scanner) {
        System.out.print("Enter Survey ID to view: ");
        int surveyId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        // Retrieve the survey using SurveyDAO
        Survey survey = surveyDAO.getSurveyById(surveyId);

        if (survey != null) {
            // Display survey details
            System.out.println("Survey Name: " + survey.getSurveyName());
            System.out.println("Survey Description: " + survey.getSurveyDescription());
            System.out.println("Status: " + survey.getStatus());
        } else {
            System.out.println("Survey not found.");
        }
    }

    private void updateSurvey(Scanner scanner) {
        System.out.print("Enter Survey ID to update: ");
        int surveyId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        // Retrieve the survey using SurveyDAO
        Survey survey = surveyDAO.getSurveyById(surveyId);

        if (survey != null) {
            // Prompt user for new survey details
            System.out.print("Enter new Survey Name (current: " + survey.getSurveyName() + "): ");
            survey.setSurveyName(scanner.nextLine());

            System.out.print("Enter new Survey Description (current: " + survey.getSurveyDescription() + "): ");
            survey.setSurveyDescription(scanner.nextLine());

            System.out.print("Enter new Status (current: " + survey.getStatus() + "): ");
            survey.setStatus(scanner.nextLine());

            // Update the survey using SurveyDAO
            surveyDAO.updateSurvey(survey);

            // Confirm survey update
            System.out.println("Survey updated successfully.");
        } else {
            System.out.println("Survey not found.");
        }
    }

    // Method to delete an existing survey
    private void deleteSurvey(Scanner scanner) {
        System.out.print("Enter Survey ID to delete: ");
        int surveyId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        // Retrieve the survey using SurveyDAO
        Survey survey = surveyDAO.getSurveyById(surveyId);

        if (survey != null) {
            // Confirm and delete the survey
            surveyDAO.deleteSurvey(surveyId);
            System.out.println("Survey deleted successfully.");
        } else {
            System.out.println("Survey not found.");
        }
    }
}