package com.cts.client;

public class SurveySystemException extends Exception {
    public SurveySystemException(String message) {
        super(message);
    }
}
