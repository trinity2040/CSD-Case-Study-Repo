// package com.cts.client;

// import java.sql.Connection;
// import java.sql.PreparedStatement;
// import java.sql.ResultSet;
// import java.sql.SQLException;
// import java.util.Scanner;

// import com.cts.model.DBConnection;

// public class MainMenu {

//     private final Scanner scanner = new Scanner(System.in);

//     public void displayMenu() throws Exception {
//         while (true) {
//             System.out.println("\n--- Customer Feedback and Survey System ---");
//             System.out.println("1. Submit Feedback");
//             System.out.println("2. Manage Surveys");
//             System.out.println("3. Analysis and Reporting");
//             System.out.println("4. Exit");
//             System.out.print("Choose an option: ");
//             int choice = scanner.nextInt();
//             scanner.nextLine(); // Consume newline

//             switch (choice) {
//                 case 1:
//                     submitFeedback();
//                     break;
//                 case 2:
//                     manageSurveys();
//                     break;
//                 case 3:
//                     analyzeAndReport();
//                     break;
//                 case 4:
//                     System.out.println("Exiting...");
//                     System.exit(0);
//                 default:
//                     System.out.println("Invalid choice. Please try again.");
//             }
//         }
//     }

//     private void submitFeedback() throws Exception {
//         try (Connection conn = DBConnection.getConnection()) {
//             System.out.print("Enter Customer ID: ");
//             String customerId = scanner.nextLine(); // Changed to String to accept alphanumeric ID
//             System.out.print("Enter Feedback: ");
//             String feedbackText = scanner.nextLine();
//             System.out.print("Enter Rating (1-5): ");
//             int rating = scanner.nextInt();

//             String sql = "INSERT INTO Feedback (customer_id, feedback_date, feedback_text, rating) VALUES (?, CURDATE(), ?, ?)";
//             PreparedStatement stmt = conn.prepareStatement(sql);
//             stmt.setString(1, customerId); // Updated to setString for customer_id
//             stmt.setString(2, feedbackText);
//             stmt.setInt(3, rating);
//             stmt.executeUpdate();

//             System.out.println("Feedback submitted successfully!");
//         } catch (SQLException e) {
//             System.out.println("Error submitting feedback: " + e.getMessage());
//         }
//     }

//     private void manageSurveys() throws Exception {
//         while (true) {
//             System.out.println("\n--- Manage Surveys ---");
//             System.out.println("1. Create Survey");
//             System.out.println("2. View Survey");
//             System.out.println("3. Update Survey");
//             System.out.println("4. Delete Survey");
//             System.out.println("5. Back to Main Menu");
//             System.out.print("Choose an option: ");
//             int choice = scanner.nextInt();
//             scanner.nextLine(); // Consume newline

//             switch (choice) {
//                 case 1:
//                     createSurvey();
//                     break;
//                 case 2:
//                     viewSurvey();
//                     break;
//                 case 3:
//                     updateSurvey();
//                     break;
//                 case 4:
//                     deleteSurvey();
//                     break;
//                 case 5:
//                     return;
//                 default:
//                     System.out.println("Invalid choice. Please try again.");
//             }
//         }
//     }

//     private void createSurvey() throws Exception {
//         try (Connection conn = DBConnection.getConnection()) {
//             System.out.print("Enter Survey Name: ");
//             String surveyName = scanner.nextLine();
//             System.out.print("Enter Survey Description: ");
//             String surveyDescription = scanner.nextLine();
//             System.out.print("Enter Status (Active/Inactive): ");
//             String status = scanner.nextLine();

//             String sql = "INSERT INTO Survey (survey_name, survey_description, status) VALUES (?, ?, ?)";
//             // var stmt = conn.prepareStatement(sql);
//             PreparedStatement stmt = conn.prepareStatement(sql);
//             stmt.setString(1, surveyName);
//             stmt.setString(2, surveyDescription);
//             stmt.setString(3, status);
//             stmt.executeUpdate();

//             System.out.println("Survey created successfully!");
//         } catch (SQLException e) {
//             System.out.println("Error creating survey: " + e.getMessage());
//         }
//     }

//     private void viewSurvey() throws Exception {
//         try (Connection conn = DBConnection.getConnection()) {
//             System.out.print("Enter Survey ID: ");
//             int surveyId = scanner.nextInt();
//             scanner.nextLine(); // Consume newline

//             String sql = "SELECT * FROM Survey WHERE survey_id = ?";
//             // var stmt = conn.prepareStatement(sql);
//             PreparedStatement stmt = conn.prepareStatement(sql);
//             stmt.setInt(1, surveyId);
//             // var rs = stmt.executeQuery();
//             ResultSet rs = stmt.executeQuery();

//             if (rs.next()) {
//                 System.out.println("Survey ID: " + rs.getInt("survey_id"));
//                 System.out.println("Survey Name: " + rs.getString("survey_name"));
//                 System.out.println("Survey Description: " + rs.getString("survey_description"));
//                 System.out.println("Status: " + rs.getString("status"));
//             } else {
//                 System.out.println("Survey not found.");
//             }
//         } catch (SQLException e) {
//             System.out.println("Error viewing survey: " + e.getMessage());
//         }
//     }

//     private void updateSurvey() throws Exception {
//         try (Connection conn = DBConnection.getConnection()) {
//             System.out.print("Enter Survey ID: ");
//             int surveyId = scanner.nextInt();
//             scanner.nextLine(); // Consume newline
//             System.out.print("Enter New Survey Name: ");
//             String surveyName = scanner.nextLine();
//             System.out.print("Enter New Survey Description: ");
//             String surveyDescription = scanner.nextLine();
//             System.out.print("Enter New Status (Active/Inactive): ");
//             String status = scanner.nextLine();

//             String sql = "UPDATE Survey SET survey_name = ?, survey_description = ?, status = ? WHERE survey_id = ?";
//             // var stmt = conn.prepareStatement(sql);
//             PreparedStatement stmt = conn.prepareStatement(sql);
//             stmt.setString(1, surveyName);
//             stmt.setString(2, surveyDescription);
//             stmt.setString(3, status);
//             stmt.setInt(4, surveyId);
//             int rowsAffected = stmt.executeUpdate();

//             if (rowsAffected > 0) {
//                 System.out.println("Survey updated successfully!");
//             } else {
//                 System.out.println("Survey not found.");
//             }
//         } catch (SQLException e) {
//             System.out.println("Error updating survey: " + e.getMessage());
//         }
//     }

//     private void deleteSurvey() throws Exception {
//         try (Connection conn = DBConnection.getConnection()) {
//             System.out.print("Enter Survey ID: ");
//             int surveyId = scanner.nextInt();
//             scanner.nextLine(); // Consume newline

//             String sql = "DELETE FROM Survey WHERE survey_id = ?";
//             // var stmt = conn.prepareStatement(sql);
//             PreparedStatement stmt = conn.prepareStatement(sql);
//             stmt.setInt(1, surveyId);
//             int rowsAffected = stmt.executeUpdate();

//             if (rowsAffected > 0) {
//                 System.out.println("Survey deleted successfully!");
//             } else {
//                 System.out.println("Survey not found.");
//             }
//         } catch (SQLException e) {
//             System.out.println("Error deleting survey: " + e.getMessage());
//         }
//     }

//     private void analyzeAndReport() {
//         System.out.println("\n--- Analysis and Reporting ---");
//         // System.out.println("Analysis and reporting functionality is not yet
//         // implemented.");
//     }

//     public static void main(String[] args) throws Exception {
//         MainMenu menu = new MainMenu();
//         menu.displayMenu();
//     }
// }

package com.cts.client;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.cts.model.DBConnection;

public class MainMenu {

    private final Scanner scanner = new Scanner(System.in);

    public void displayMenu() throws Exception {
        while (true) {
            System.out.println("\n--- Customer Feedback and Survey System ---");
            System.out.println("1. Submit Feedback");
            System.out.println("2. Manage Surveys");
            System.out.println("3. Analysis and Reporting");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    submitFeedback();
                    break;
                case 2:
                    manageSurveys();
                    break;
                case 3:
                    try {
                        analyzeAndReport();
                    } catch (SurveySystemException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void analyzeAndReport() throws SurveySystemException {
        throw new SurveySystemException("Analysis and reporting feature is not implemented yet.");
    }

    private void submitFeedback() throws Exception {
        try (Connection conn = DBConnection.getConnection()) {
            System.out.print("Enter Customer ID: ");
            String customerId = scanner.nextLine(); // Changed to String to accept alphanumeric ID
            System.out.print("Enter Feedback: ");
            String feedbackText = scanner.nextLine();
            System.out.print("Enter Rating (1-5): ");
            int rating = scanner.nextInt();

            String sql = "INSERT INTO Feedback (customer_id, feedback_date, feedback_text, rating) VALUES (?, CURDATE(), ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, customerId); // Updated to setString for customer_id
            stmt.setString(2, feedbackText);
            stmt.setInt(3, rating);
            stmt.executeUpdate();

            System.out.println("Feedback submitted successfully!");
        } catch (SQLException e) {
            System.out.println("Error submitting feedback: " + e.getMessage());
        }
    }

    private void manageSurveys() throws Exception {
        while (true) {
            System.out.println("\n--- Manage Surveys ---");
            System.out.println("1. Create Survey");
            System.out.println("2. View Survey");
            System.out.println("3. Update Survey");
            System.out.println("4. Delete Survey");
            System.out.println("5. Back to Main Menu");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    createSurvey();
                    break;
                case 2:
                    viewSurvey();
                    break;
                case 3:
                    updateSurvey();
                    break;
                case 4:
                    deleteSurvey();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void createSurvey() throws Exception {
        try (Connection conn = DBConnection.getConnection()) {
            System.out.print("Enter Survey Name: ");
            String surveyName = scanner.nextLine();
            System.out.print("Enter Survey Description: ");
            String surveyDescription = scanner.nextLine();
            System.out.print("Enter Status (Active/Inactive): ");
            String status = scanner.nextLine();

            String sql = "INSERT INTO Survey (survey_name, survey_description, status) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, surveyName);
            stmt.setString(2, surveyDescription);
            stmt.setString(3, status);
            stmt.executeUpdate();

            System.out.println("Survey created successfully!");
        } catch (SQLException e) {
            System.out.println("Error creating survey: " + e.getMessage());
        }
    }

    private void viewSurvey() throws Exception {
        try (Connection conn = DBConnection.getConnection()) {
            System.out.print("Enter Survey ID: ");
            int surveyId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            String sql = "SELECT * FROM Survey WHERE survey_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, surveyId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                System.out.println("Survey ID: " + rs.getInt("survey_id"));
                System.out.println("Survey Name: " + rs.getString("survey_name"));
                System.out.println("Survey Description: " + rs.getString("survey_description"));
                System.out.println("Status: " + rs.getString("status"));
            }
        }
    }

    private void updateSurvey() throws Exception {
        try (Connection conn = DBConnection.getConnection()) {
            System.out.print("Enter Survey ID: ");
            int surveyId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter New Survey Name: ");
            String surveyName = scanner.nextLine();
            System.out.print("Enter New Survey Description: ");
            String surveyDescription = scanner.nextLine();
            System.out.print("Enter New Status (Active/Inactive): ");
            String status = scanner.nextLine();

            String sql = "UPDATE Survey SET survey_name = ?, survey_description = ?, status = ? WHERE survey_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, surveyName);
            stmt.setString(2, surveyDescription);
            stmt.setString(3, status);
            stmt.setInt(4, surveyId);
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Survey updated successfully!");
            } else {
                System.out.println("Survey not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating survey: " + e.getMessage());
        }
    }

    private void deleteSurvey() throws Exception {
        try (Connection conn = DBConnection.getConnection()) {
            System.out.print("Enter Survey ID: ");
            int surveyId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            String sql = "DELETE FROM Survey WHERE survey_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, surveyId);
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Survey deleted successfully!");
            } else {
                System.out.println("Survey not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting survey: " + e.getMessage());
        }
    }

    public static void main(String[] args) throws Exception {
        MainMenu menu = new MainMenu();
        menu.displayMenu();
    }
}