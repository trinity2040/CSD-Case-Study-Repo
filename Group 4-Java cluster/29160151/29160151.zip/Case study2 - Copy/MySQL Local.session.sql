CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(255) NOT NULL UNIQUE,
    email VARCHAR(255) NOT NULL UNIQUE,
    feedback VARCHAR(255)
);

DESCRIBE users;

ALTER TABLE users
ADD COLUMN feedback VARCHAR(255);


    INSERT INTO users (username, email, feedback) VALUES
    ('john_date','john@example.com','good'),
    ('jane_smith','jane@example.com','bad'),
    ('bob_jones','bob@example.com','satisfied')
ON DUPLICATE KEY UPDATE
    email = VALUES(email),
    feedback = VALUES(feedback);

SELECT * FROM users

CREATE DATABASE NewFeedbackSurveyDB;

USE NewFeedbackSurveyDB;

CREATE TABLE Customer1 (
    customer_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_name VARCHAR(255) NOT NULL,
    customer_email VARCHAR(255) NOT NULL UNIQUE
);
CREATE TABLE Customer (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(255),
    email VARCHAR(255) UNIQUE
);

INSERT INTO Customer (customer_name, email)
VALUES ('John Doe', 'johndoe@example.com');

INSERT INTO Customer1 (customer_name, customer_email) VALUES ('Siri', 'siri@example.com');

SELECT customer_id FROM Customer1 WHERE customer_email = 'siri@example.com';

INSERT INTO Feedback (customer_id, feedback_date, feedback_text, rating) 
VALUES (1, CURDATE(), 'good', 5);

SELECT * FROM Customer1;

SELECT * FROM Customer;

CREATE TABLE Feedback (
    feedback_id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    feedback_date DATE,
    feedback_text TEXT,
    rating INT,
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
);

CREATE TABLE Feedback1 (
    feedback_id INT PRIMARY KEY AUTO_INCREMENT,
    customer_id INT,
    feedback_date DATE,
    feedback_text TEXT,
    rating INT,
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
);

INSERT INTO Feedback (customer_id, feedback_date, feedback_text, rating)
VALUES (1, '2022-01-01', 'good', 4);

SELECT * FROM feedback;



CREATE TABLE Survey (
    survey_id INT AUTO_INCREMENT PRIMARY KEY,
    survey_name VARCHAR(255),
    survey_description TEXT
);

CREATE TABLE Survey2 (
    survey_id INT PRIMARY KEY AUTO_INCREMENT,
    survey_name VARCHAR(255) NOT NULL,
    survey_description TEXT,
    status VARCHAR(50)
);

INSERT INTO Survey (survey_name, survey_description)
VALUES ('Sample Survey', 'This is a sample survey to collect feedback from customers');

ALTER TABLE Survey2 MODIFY status ENUM('Active', 'Inactive') NOT NULL;




SELECT * FROM Survey;


CREATE TABLE SurveyResponse (
    response_id INT AUTO_INCREMENT PRIMARY KEY,
    survey_id INT,
    customer_id INT,
    response_date DATE,
    response_text TEXT,
    FOREIGN KEY (survey_id) REFERENCES Survey(survey_id),
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
);

CREATE TABLE SurveyResponse2 (
    response_id INT PRIMARY KEY AUTO_INCREMENT,
    survey_id INT,
    customer_id INT,
    response_date DATE,
    response_text TEXT,
    FOREIGN KEY (survey_id) REFERENCES Survey(survey_id),
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
);

INSERT INTO SurveyResponse (survey_id, customer_id, response_date, response_text)
VALUES (1, 1, '2022-01-01', 'This is a sample response to the survey');

SELECT * FROM SurveyResponse;

CREATE DATABASE CustomerFeedbackSurveyDB;

SELECT AVG(rating) AS average_rating FROM Feedback;

SELECT rating, COUNT(*) AS count FROM Feedback GROUP BY rating;

SELECT survey_id, COUNT(*) AS response_count FROM SurveyResponse GROUP BY survey_id;

show databases;
