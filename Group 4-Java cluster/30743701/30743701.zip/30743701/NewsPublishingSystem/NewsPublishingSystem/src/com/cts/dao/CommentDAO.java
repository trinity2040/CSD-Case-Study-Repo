package com.cts.dao;

import com.cts.model.Comment;
import java.util.List;

public interface CommentDAO {
    void addComment(Comment comment);
    Comment getCommentById(int id);
    List<Comment> getAllComments();
    void updateComment(Comment comment);
    void deleteComment(int id);
    List<Comment> getCommentsByArticleId(int articleId);
}
