package com.cts.dao;

import com.cts.model.Category;
import java.util.List;

public interface CategoryDAO {
    void addCategory(Category category);
    Category getCategoryById(int id);
    List<Category> getAllCategories();
    void updateCategory(Category category);
    boolean deleteCategory(int categoryId, ArticleDAO articleDAO);
}

