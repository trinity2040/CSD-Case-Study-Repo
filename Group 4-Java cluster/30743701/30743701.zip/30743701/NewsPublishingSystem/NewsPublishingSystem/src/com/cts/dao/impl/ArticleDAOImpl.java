package com.cts.dao.impl;

import com.cts.dao.ArticleDAO;
import com.cts.model.Article;
import com.cts.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ArticleDAOImpl implements ArticleDAO {

	@Override
	public void addArticle(Article article) {
	    try (Connection connection = DatabaseConnection.getConnection()) {
	        String query = "INSERT INTO Article (category_id, title, content, author, publish_date) VALUES (?, ?, ?, ?, ?)";
	        PreparedStatement preparedStatement = connection.prepareStatement(query);
	        preparedStatement.setInt(1, article.getCategoryId());
	        preparedStatement.setString(2, article.getTitle());
	        preparedStatement.setString(3, article.getContent());
	        preparedStatement.setString(4, article.getAuthor());
	        
	        // Check if publishDate is null and handle accordingly
	        java.sql.Date sqlPublishDate = (article.getPublishDate() != null) 
	                                        ? new java.sql.Date(article.getPublishDate().getTime()) 
	                                        : null;
	        preparedStatement.setDate(5, sqlPublishDate);

	        preparedStatement.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}


    @Override
    public Article getArticleById(int id) {
        Article article = null;
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM Article WHERE article_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                article = new Article();
                article.setArticleId(resultSet.getInt("article_id"));
                article.setCategoryId(resultSet.getInt("category_id"));
                article.setTitle(resultSet.getString("title"));
                article.setContent(resultSet.getString("content"));
                article.setAuthor(resultSet.getString("author"));
                article.setPublishDate(resultSet.getDate("publish_date"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return article;
    }

    @Override
    public List<Article> getAllArticles() {
        List<Article> articles = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM Article";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Article article = new Article();
                article.setArticleId(resultSet.getInt("article_id"));
                article.setCategoryId(resultSet.getInt("category_id"));
                article.setTitle(resultSet.getString("title"));
                article.setContent(resultSet.getString("content"));
                article.setAuthor(resultSet.getString("author"));
                article.setPublishDate(resultSet.getDate("publish_date"));
                articles.add(article);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return articles;
    }

    @Override
    public void updateArticle(Article article) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "UPDATE Article SET category_id = ?, title = ?, content = ?, author = ?, publish_date = ? WHERE article_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, article.getCategoryId());
            preparedStatement.setString(2, article.getTitle());
            preparedStatement.setString(3, article.getContent());
            preparedStatement.setString(4, article.getAuthor());
            preparedStatement.setDate(5, new java.sql.Date(article.getPublishDate().getTime()));
            preparedStatement.setInt(6, article.getArticleId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean deleteArticle(int articleId) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        try {
            connection = DatabaseConnection.getConnection();
            String query = "DELETE FROM article WHERE article_id = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, articleId);
            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0; // Return true if at least one row was affected
        } catch (SQLException e) {
            e.printStackTrace();
            return false; // Return false in case of an error
        } finally {
            // Close resources
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    @Override
    public List<Article> getArticlesByCategoryId(int categoryId) {
        List<Article> articles = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM Article WHERE category_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, categoryId);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        Article article = new Article();
                        article.setArticleId(resultSet.getInt("article_id"));
                        article.setCategoryId(resultSet.getInt("category_id"));
                        article.setTitle(resultSet.getString("title"));
                        article.setContent(resultSet.getString("content"));
                        article.setAuthor(resultSet.getString("author"));
                        article.setPublishDate(resultSet.getDate("publish_date"));
                        articles.add(article);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return articles;
    }

}

