package com.cts.exception;

public class CommentNotFoundException extends Exception {
    private static final long serialVersionUID = 1L; // Adding serialVersionUID

    public CommentNotFoundException(String message) {
        super(message);
    }
}
