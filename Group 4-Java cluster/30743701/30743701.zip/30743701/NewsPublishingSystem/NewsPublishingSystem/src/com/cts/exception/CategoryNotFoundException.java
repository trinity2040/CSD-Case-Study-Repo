package com.cts.exception;

public class CategoryNotFoundException extends Exception {
    private static final long serialVersionUID = 1L; // Adding serialVersionUID

    public CategoryNotFoundException(String message) {
        super(message);
    }
}

