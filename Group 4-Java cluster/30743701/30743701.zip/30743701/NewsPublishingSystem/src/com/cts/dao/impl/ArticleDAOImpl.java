package com.cts.dao.impl;

import com.cts.dao.ArticleDAO;
import com.cts.model.Article;
import com.cts.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ArticleDAOImpl implements ArticleDAO {

    @Override
    public void addArticle(Article article) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "INSERT INTO Article (category_id, title, content, author, publish_date) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, article.getCategoryId());
            preparedStatement.setString(2, article.getTitle());
            preparedStatement.setString(3, article.getContent());
            preparedStatement.setString(4, article.getAuthor());
            preparedStatement.setDate(5, new java.sql.Date(article.getPublishDate().getTime()));
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Article getArticleById(int id) {
        Article article = null;
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM Article WHERE article_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                article = new Article();
                article.setArticleId(resultSet.getInt("article_id"));
                article.setCategoryId(resultSet.getInt("category_id"));
                article.setTitle(resultSet.getString("title"));
                article.setContent(resultSet.getString("content"));
                article.setAuthor(resultSet.getString("author"));
                article.setPublishDate(resultSet.getDate("publish_date"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return article;
    }

    @Override
    public List<Article> getAllArticles() {
        List<Article> articles = new ArrayList<>();
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "SELECT * FROM Article";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                Article article = new Article();
                article.setArticleId(resultSet.getInt("article_id"));
                article.setCategoryId(resultSet.getInt("category_id"));
                article.setTitle(resultSet.getString("title"));
                article.setContent(resultSet.getString("content"));
                article.setAuthor(resultSet.getString("author"));
                article.setPublishDate(resultSet.getDate("publish_date"));
                articles.add(article);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return articles;
    }

    @Override
    public void updateArticle(Article article) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "UPDATE Article SET category_id = ?, title = ?, content = ?, author = ?, publish_date = ? WHERE article_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, article.getCategoryId());
            preparedStatement.setString(2, article.getTitle());
            preparedStatement.setString(3, article.getContent());
            preparedStatement.setString(4, article.getAuthor());
            preparedStatement.setDate(5, new java.sql.Date(article.getPublishDate().getTime()));
            preparedStatement.setInt(6, article.getArticleId());
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteArticle(int id) {
        try (Connection connection = DatabaseConnection.getConnection()) {
            String query = "DELETE FROM Article WHERE article_id = ?";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

