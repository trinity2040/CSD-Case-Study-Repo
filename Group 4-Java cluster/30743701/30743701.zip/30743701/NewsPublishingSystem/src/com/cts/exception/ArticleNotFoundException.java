package com.cts.exception;

public class ArticleNotFoundException extends Exception {
    private static final long serialVersionUID = 1L; // Adding serialVersionUID

    public ArticleNotFoundException(String message) {
        super(message);
    }
}

