package com.cts.dao;

import com.cts.model.Article;
import java.util.List;

public interface ArticleDAO {
    void addArticle(Article article);
    Article getArticleById(int id);
    List<Article> getAllArticles();
    void updateArticle(Article article);
    void deleteArticle(int id);
}
