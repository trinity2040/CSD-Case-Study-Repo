package com.cts.client;

import com.cts.dao.CategoryDAO;
import com.cts.dao.ArticleDAO;
import com.cts.dao.CommentDAO;
import com.cts.dao.UserDAO;
import com.cts.dao.impl.CategoryDAOImpl;
import com.cts.dao.impl.ArticleDAOImpl;
import com.cts.dao.impl.CommentDAOImpl;
import com.cts.dao.impl.UserDAOImpl;
import com.cts.model.Category;
import com.cts.model.Article;
import com.cts.model.Comment;
import com.cts.model.User;

import java.util.List;
import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        CategoryDAO categoryDAO = new CategoryDAOImpl();
        ArticleDAO articleDAO = new ArticleDAOImpl();
        CommentDAO commentDAO = new CommentDAOImpl();
        UserDAO userDAO = new UserDAOImpl();

        while (true) {
            System.out.println("===== News Publishing System =====");
            System.out.println("1. Manage Categories");
            System.out.println("2. Manage Articles");
            System.out.println("3. Manage Comments");
            System.out.println("4. Manage Users");
            System.out.println("5. Exit");
            System.out.print("Select an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    manageCategories(categoryDAO);
                    break;
                case 2:
                    manageArticles(articleDAO);
                    break;
                case 3:
                    manageComments(commentDAO);
                    break;
                case 4:
                    manageUsers(userDAO);
                    break;
                case 5:
                    System.out.println("Exiting the application...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void manageCategories(CategoryDAO categoryDAO) {
        System.out.println("===== Manage Categories =====");
        System.out.println("1. Add Category");
        System.out.println("2. View All Categories");
        System.out.println("3. Update Category");
        System.out.println("4. Delete Category");
        System.out.print("Select an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter Category Name: ");
                String name = scanner.nextLine();
                System.out.print("Enter Category Description: ");
                String description = scanner.nextLine();
                Category category = new Category();
                category.setName(name);
                category.setDescription(description);
                categoryDAO.addCategory(category);
                System.out.println("Category added successfully!");
                break;
            case 2:
                List<Category> categories = categoryDAO.getAllCategories();
                for (Category cat : categories) {
                    System.out.println(cat);
                }
                break;
            case 3:
                System.out.print("Enter Category ID to Update: ");
                int categoryId = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                Category catToUpdate = categoryDAO.getCategoryById(categoryId);
                if (catToUpdate != null) {
                    System.out.print("Enter New Category Name: ");
                    catToUpdate.setName(scanner.nextLine());
                    System.out.print("Enter New Category Description: ");
                    catToUpdate.setDescription(scanner.nextLine());
                    categoryDAO.updateCategory(catToUpdate);
                    System.out.println("Category updated successfully!");
                } else {
                    System.out.println("Category not found.");
                }
                break;
            case 4:
                System.out.print("Enter Category ID to Delete: ");
                int categoryIdToDelete = scanner.nextInt();
                categoryDAO.deleteCategory(categoryIdToDelete);
                System.out.println("Category deleted successfully!");
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void manageArticles(ArticleDAO articleDAO) {
        System.out.println("===== Manage Articles =====");
        System.out.println("1. Add Article");
        System.out.println("2. View All Articles");
        System.out.println("3. Update Article");
        System.out.println("4. Delete Article");
        System.out.print("Select an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter Article Title: ");
                String title = scanner.nextLine();
                System.out.print("Enter Article Content: ");
                String content = scanner.nextLine();
                System.out.print("Enter Article Author: ");
                String author = scanner.nextLine();
                System.out.print("Enter Category ID: ");
                int categoryId = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                Article article = new Article();
                article.setTitle(title);
                article.setContent(content);
                article.setAuthor(author);
                article.setCategoryId(categoryId);
                articleDAO.addArticle(article);
                System.out.println("Article added successfully!");
                break;
            case 2:
                List<Article> articles = articleDAO.getAllArticles();
                for (Article art : articles) {
                    System.out.println(art);
                }
                break;
            case 3:
                System.out.print("Enter Article ID to Update: ");
                int articleId = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                Article artToUpdate = articleDAO.getArticleById(articleId);
                if (artToUpdate != null) {
                    System.out.print("Enter New Article Title: ");
                    artToUpdate.setTitle(scanner.nextLine());
                    System.out.print("Enter New Article Content: ");
                    artToUpdate.setContent(scanner.nextLine());
                    System.out.print("Enter New Article Author: ");
                    artToUpdate.setAuthor(scanner.nextLine());
                    articleDAO.updateArticle(artToUpdate);
                    System.out.println("Article updated successfully!");
                } else {
                    System.out.println("Article not found.");
                }
                break;
            case 4:
                System.out.print("Enter Article ID to Delete: ");
                int articleIdToDelete = scanner.nextInt();
                articleDAO.deleteArticle(articleIdToDelete);
                System.out.println("Article deleted successfully!");
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void manageComments(CommentDAO commentDAO) {
        System.out.println("===== Manage Comments =====");
        System.out.println("1. Add Comment");
        System.out.println("2. View All Comments for an Article");
        System.out.println("3. Update Comment");
        System.out.println("4. Delete Comment");
        System.out.print("Select an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter Comment Content: ");
                String content = scanner.nextLine();
                System.out.print("Enter Article ID: ");
                int articleId = scanner.nextInt();
                System.out.print("Enter User ID: ");
                int userId = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                Comment comment = new Comment();
                comment.setContent(content);
                comment.setArticleId(articleId);
                comment.setUserId(userId);
                commentDAO.addComment(comment);
                System.out.println("Comment added successfully!");
                break;
            case 2:
                System.out.print("Enter Article ID to View Comments: ");
                int articleIdForComments = scanner.nextInt();
                List<Comment> comments = commentDAO.getCommentsByArticleId(articleIdForComments);
                for (Comment com : comments) {
                    System.out.println(com);
                }
                break;
            case 3:
                System.out.print("Enter Comment ID to Update: ");
                int commentId = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                Comment comToUpdate = commentDAO.getCommentById(commentId);
                if (comToUpdate != null) {
                    System.out.print("Enter New Comment Content: ");
                    comToUpdate.setContent(scanner.nextLine());
                    commentDAO.updateComment(comToUpdate);
                    System.out.println("Comment updated successfully!");
                } else {
                    System.out.println("Comment not found.");
                }
                break;
            case 4:
                System.out.print("Enter Comment ID to Delete: ");
                int commentIdToDelete = scanner.nextInt();
                commentDAO.deleteComment(commentIdToDelete);
                System.out.println("Comment deleted successfully!");
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void manageUsers(UserDAO userDAO) {
        System.out.println("===== Manage Users =====");
        System.out.println("1. Add User");
        System.out.println("2. View All Users");
        System.out.println("3. Update User");
        System.out.println("4. Delete User");
        System.out.print("Select an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter Username: ");
                String username = scanner.nextLine();
                System.out.print("Enter Email: ");
                String email = scanner.nextLine();
                System.out.print("Enter Date of Birth (YYYY-MM-DD): ");
                String dob = scanner.nextLine();
                User user = new User();
                user.setUsername(username);
                user.setEmail(email);
                user.setDateOfBirth(java.sql.Date.valueOf(dob));
                userDAO.addUser(user);
                System.out.println("User added successfully!");
                break;
            case 2:
                List<User> users = userDAO.getAllUsers();
                for (User usr : users) {
                    System.out.println(usr);
                }
                break;
            case 3:
                System.out.print("Enter User ID to Update: ");
                int userId = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                User usrToUpdate = userDAO.getUserById(userId);
                if (usrToUpdate != null) {
                    System.out.print("Enter New Username: ");
                    usrToUpdate.setUsername(scanner.nextLine());
                    System.out.print("Enter New Email: ");
                    usrToUpdate.setEmail(scanner.nextLine());
                    userDAO.updateUser(usrToUpdate);
                    System.out.println("User updated successfully!");
                } else {
                    System.out.println("User not found.");
                }
                break;
            case 4:
                System.out.print("Enter User ID to Delete: ");
                int userIdToDelete = scanner.nextInt();
                userDAO.deleteUser(userIdToDelete);
                System.out.println("User deleted successfully!");
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }
}



