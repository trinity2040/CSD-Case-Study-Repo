package com.cts.model;

import java.util.Date;

public class Article {
    private int articleId;
    private int categoryId;
    private String title;
    private String content;
    private String author;
    private Date publishDate;

    // Getters and Setters
    public int getArticleId() {
        return articleId;
    }

    public void setArticleId(int articleId) {
        this.articleId = articleId;
    }

    public int getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(int categoryId) {
        this.categoryId = categoryId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Date getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(Date publishDate) {
        this.publishDate = publishDate;
    }

    @Override
    public String toString() {
        return "Article [articleId=" + articleId + ", categoryId=" + categoryId + ", title=" + title + 
               ", content=" + content + ", author=" + author + ", publishDate=" + publishDate + "]";
    }
}
