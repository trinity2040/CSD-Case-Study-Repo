package com.library.service;

import com.library.dao.AuthorDAO;
import com.library.dao.EbookDAO;
import com.library.dao.UserDAO;
import com.library.model.Author;
import com.library.model.Ebook;
import com.library.model.User;

import java.util.List;

public class LibraryService {
    private EbookDAO ebookDAO = new EbookDAO();
    private AuthorDAO authorDAO = new AuthorDAO();
    private UserDAO userDAO = new UserDAO();

    public void addEbook(Ebook ebook) {
        ebookDAO.addEbook(ebook);
    }

    public Ebook getEbook(int ebookId) {
        return ebookDAO.getEbook(ebookId);
    }

    public void updateEbook(Ebook ebook) {
        ebookDAO.updateEbook(ebook);
    }

    public void deleteEbook(int ebookId) {
        ebookDAO.deleteEbook(ebookId);
    }

    public List<Ebook> getAllEbooks() {
        return ebookDAO.getAllEbooks();
    }

    public void addAuthor(Author author) {
        authorDAO.addAuthor(author);
    }

    public Author getAuthor(int authorId) {
        return authorDAO.getAuthor(authorId);
    }

    public void updateAuthor(Author author) {
        authorDAO.updateAuthor(author);
    }

    public void deleteAuthor(int authorId) {
        authorDAO.deleteAuthor(authorId);
    }

    public List<Author> getAllAuthors() {
        return authorDAO.getAllAuthors();
    }

    public void addUser(User user) {
        userDAO.addUser(user);
    }

    public User getUser(int userId) {
        return userDAO.getUser(userId);
    }

    public void updateUser(User user) {
        userDAO.updateUser(user);
    }

    public void deleteUser(int userId) {
        userDAO.deleteUser(userId);
    }

    public List<User> getAllUsers() {
        return userDAO.getAllUsers();
    }
}
