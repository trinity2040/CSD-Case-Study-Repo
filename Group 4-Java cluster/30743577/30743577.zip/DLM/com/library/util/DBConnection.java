package com.library.util;

import java.sql.*;
import java.util.*;

public class DBConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/library_db?characterEncoding=latin1&useConfigs=maxPerformance";
    private static final String USER = "root";
    private static final String PASSWORD = "Fifilove#18";

    private static final String Driver = "com.mysql.jdbc.Driver";

    public static Connection getConnection() throws SQLException {
        try{
            Class.forName(Driver);
        }
        catch (Exception e){
            System.out.println(e);
        }
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
