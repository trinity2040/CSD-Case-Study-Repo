package com.library.dao;

import com.library.model.Author;
import com.library.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AuthorDAO {
    public void addAuthor(Author author) {
        String sql = "INSERT INTO Author (name, bio, nationality, birth_date) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, author.getName());
            stmt.setString(2, author.getBio());
            stmt.setString(3, author.getNationality());
            stmt.setString(4, author.getBirthDate());

            stmt.executeUpdate();
            System.out.println("Author added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Author getAuthor(int authorId) {
        String sql = "SELECT * FROM Author WHERE author_id = ?";
        Author author = null;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, authorId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                author = new Author();
                author.setAuthorId(rs.getInt("author_id"));
                author.setName(rs.getString("name"));
                author.setBio(rs.getString("bio"));
                author.setNationality(rs.getString("nationality"));
                author.setBirthDate(rs.getString("birth_date"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return author;
    }

    public void updateAuthor(Author author) {
        String sql = "UPDATE Author SET name = ?, bio = ?, nationality = ?, birth_date = ? WHERE author_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, author.getName());
            stmt.setString(2, author.getBio());
            stmt.setString(3, author.getNationality());
            stmt.setString(4, author.getBirthDate());
            stmt.setInt(5, author.getAuthorId());

            stmt.executeUpdate();
            System.out.println("Author updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteAuthor(int authorId) {
        String sql = "DELETE FROM Author WHERE author_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, authorId);
            stmt.executeUpdate();
            System.out.println("Author deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Author> getAllAuthors() {
        String sql = "SELECT * FROM Author";
        List<Author> authors = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Author author = new Author();
                author.setAuthorId(rs.getInt("author_id"));
                author.setName(rs.getString("name"));
                author.setBio(rs.getString("bio"));
                author.setNationality(rs.getString("nationality"));
                author.setBirthDate(rs.getString("birth_date"));

                authors.add(author);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return authors;
    }
}
