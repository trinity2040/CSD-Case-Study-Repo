package com.cts.exception;

public class EbookDoesnotExistException extends Exception {
    public EbookDoesnotExistException(){
        super("Book does not exist");
    }
}
