package com.cts.exception;

public class AuthorDoesnotExistException extends Exception{
    public AuthorDoesnotExistException(){
        super("Author does not exist");
    }
}
