package com.cts.main;

import com.cts.model.Author;
import com.cts.model.Ebook;
import com.cts.model.User;
import com.cts.service.LibraryService;

import java.util.List;
import java.util.Scanner;

public class LibraryManagementSystem {
    private static LibraryService libraryService = new LibraryService();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n--- Digital Library Management System ---");
            System.out.println("1. E-Book Management");
            System.out.println("2. Author Management");
            System.out.println("3. Membership Management");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    manageEbooks();
                    break;
                case 2:
                    manageAuthors();
                    break;
                case 3:
                    manageUsers();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageEbooks() {
        System.out.println("\n--- E-Book Management ---");
        System.out.println("1. Add E-Book");
        System.out.println("2. View E-Book");
        System.out.println("3. Update E-Book");
        System.out.println("4. Delete E-Book");
        System.out.println("5. View All E-Books");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                addEbook();
                break;
            case 2:
                viewEbook();
                break;
            case 3:
                updateEbook();
                break;
            case 4:
                deleteEbook();
                break;
            case 5:
                viewAllEbooks();
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }

    private static void addEbook() {
        Ebook ebook = new Ebook();
        System.out.print("Enter title: ");
        ebook.setTitle(scanner.nextLine());
        System.out.print("Enter genre: ");
        ebook.setGenre(scanner.nextLine());
        System.out.print("Enter publication date (YYYY-MM-DD): ");
        ebook.setPublicationDate(scanner.nextLine());
        System.out.print("Enter author ID: ");
        ebook.setAuthorId(scanner.nextInt());
        System.out.print("Enter available copies: ");
        ebook.setAvailableCopies(scanner.nextInt());
        scanner.nextLine(); // Consume newline

        libraryService.addEbook(ebook);
    }

    private static void viewEbook() {
        System.out.print("Enter e-book ID: ");
        int ebookId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Ebook ebook = libraryService.getEbook(ebookId);
        if (ebook != null) {
            System.out.println("E-Book Details:");
            System.out.println("ID: " + ebook.getEbookId());
            System.out.println("Title: " + ebook.getTitle());
            System.out.println("Genre: " + ebook.getGenre());
            System.out.println("Publication Date: " + ebook.getPublicationDate());
            System.out.println("Author ID: " + ebook.getAuthorId());
            System.out.println("Available Copies: " + ebook.getAvailableCopies());
        } else {
            System.out.println("E-Book not found.");
        }
    }

    private static void updateEbook() {
        System.out.print("Enter e-book ID: ");
        int ebookId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Ebook ebook = libraryService.getEbook(ebookId);
        if (ebook != null) {
            System.out.print("Enter new title: ");
            ebook.setTitle(scanner.nextLine());
            System.out.print("Enter new genre: ");
            ebook.setGenre(scanner.nextLine());
            System.out.print("Enter new publication date (YYYY-MM-DD): ");
            ebook.setPublicationDate(scanner.nextLine());
            System.out.print("Enter new author ID: ");
            ebook.setAuthorId(scanner.nextInt());
            System.out.print("Enter new available copies: ");
            ebook.setAvailableCopies(scanner.nextInt());
            scanner.nextLine(); // Consume newline

            libraryService.updateEbook(ebook);
        } else {
            System.out.println("E-Book not found.");
        }
    }

    private static void deleteEbook() {
        System.out.print("Enter e-book ID: ");
        int ebookId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        libraryService.deleteEbook(ebookId);
    }

    private static void viewAllEbooks() {
        List<Ebook> ebooks = libraryService.getAllEbooks();
        System.out.println("\n--- All E-Books ---");
        for (Ebook ebook : ebooks) {
            System.out.println("ID: " + ebook.getEbookId() + ", Title: " + ebook.getTitle());
        }
    }

    private static void manageAuthors() {
        System.out.println("\n--- Author Management ---");
        System.out.println("1. Add Author");
        System.out.println("2. View Author");
        System.out.println("3. Update Author");
        System.out.println("4. Delete Author");
        System.out.println("5. View All Authors");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                addAuthor();
                break;
            case 2:
                viewAuthor();
                break;
            case 3:
                updateAuthor();
                break;
            case 4:
                deleteAuthor();
                break;
            case 5:
                viewAllAuthors();
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }

    private static void addAuthor() {
        Author author = new Author();
        System.out.print("Enter name: ");
        author.setName(scanner.nextLine());
        System.out.print("Enter bio: ");
        author.setBio(scanner.nextLine());
        System.out.print("Enter nationality: ");
        author.setNationality(scanner.nextLine());
        System.out.print("Enter birth date (YYYY-MM-DD): ");
        author.setBirthDate(scanner.nextLine());

        libraryService.addAuthor(author);
    }

    private static void viewAuthor() {
        System.out.print("Enter author ID: ");
        int authorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Author author = libraryService.getAuthor(authorId);
        if (author != null) {
            System.out.println("Author Details:");
            System.out.println("ID: " + author.getAuthorId());
            System.out.println("Name: " + author.getName());
            System.out.println("Bio: " + author.getBio());
            System.out.println("Nationality: " + author.getNationality());
            System.out.println("Birth Date: " + author.getBirthDate());
        } else {
            System.out.println("Author not found.");
        }
    }

    private static void updateAuthor() {
        System.out.print("Enter author ID: ");
        int authorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Author author = libraryService.getAuthor(authorId);
        if (author != null) {
            System.out.print("Enter new name: ");
            author.setName(scanner.nextLine());
            System.out.print("Enter new bio: ");
            author.setBio(scanner.nextLine());
            System.out.print("Enter new nationality: ");
            author.setNationality(scanner.nextLine());
            System.out.print("Enter new birth date (YYYY-MM-DD): ");
            author.setBirthDate(scanner.nextLine());

            libraryService.updateAuthor(author);
        } else {
            System.out.println("Author not found.");
        }
    }

    private static void deleteAuthor() {
        System.out.print("Enter author ID: ");
        int authorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        libraryService.deleteAuthor(authorId);
    }

    private static void viewAllAuthors() {
        List<Author> authors = libraryService.getAllAuthors();
        System.out.println("\n--- All Authors ---");
        for (Author author : authors) {
            System.out.println("ID: " + author.getAuthorId() + ", Name: " + author.getName());
        }
    }

    private static void manageUsers() {
        System.out.println("\n--- Membership Management ---");
        System.out.println("1. Register User");
        System.out.println("2. View User");
        System.out.println("3. Update User");
        System.out.println("4. Cancel Membership");
        System.out.println("5. View All Users");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                addUser();
                break;
            case 2:
                viewUser();
                break;
            case 3:
                updateUser();
                break;
            case 4:
                deleteUser();
                break;
            case 5:
                viewAllUsers();
                break;
            default:
                System.out.println("Invalid choice.");
        }
    }

    private static void addUser() {
        User user = new User();
        System.out.print("Enter username: ");
        user.setUsername(scanner.nextLine());
        System.out.print("Enter email: ");
        user.setEmail(scanner.nextLine());
        System.out.print("Enter date of birth (YYYY-MM-DD): ");
        user.setDateOfBirth(scanner.nextLine());
        System.out.print("Enter membership date (YYYY-MM-DD): ");
        user.setMembershipDate(scanner.nextLine());
        System.out.print("Enter membership status: ");
        user.setMembershipStatus(scanner.nextLine());

        libraryService.addUser(user);
    }

    private static void viewUser() {
        System.out.print("Enter user ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        User user = libraryService.getUser(userId);
        if (user != null) {
            System.out.println("User Details:");
            System.out.println("ID: " + user.getUserId());
            System.out.println("Username: " + user.getUsername());
            System.out.println("Email: " + user.getEmail());
            System.out.println("Date of Birth: " + user.getDateOfBirth());
            System.out.println("Membership Date: " + user.getMembershipDate());
            System.out.println("Membership Status: " + user.getMembershipStatus());
        } else {
            System.out.println("User not found.");
        }
    }

    private static void updateUser() {
        System.out.print("Enter user ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        User user = libraryService.getUser(userId);
        if (user != null) {
            System.out.print("Enter new username: ");
            user.setUsername(scanner.nextLine());
            System.out.print("Enter new email: ");
            user.setEmail(scanner.nextLine());
            System.out.print("Enter new date of birth (YYYY-MM-DD): ");
            user.setDateOfBirth(scanner.nextLine());
            System.out.print("Enter new membership date (YYYY-MM-DD): ");
            user.setMembershipDate(scanner.nextLine());
            System.out.print("Enter new membership status: ");
            user.setMembershipStatus(scanner.nextLine());

            libraryService.updateUser(user);
        } else {
            System.out.println("User not found.");
        }
    }

    private static void deleteUser() {
        System.out.print("Enter user ID: ");
        int userId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        libraryService.deleteUser(userId);
    }

    private static void viewAllUsers() {
        List<User> users = libraryService.getAllUsers();
        System.out.println("\n--- All Users ---");
        for (User user : users) {
            System.out.println("ID: " + user.getUserId() + ", Username: " + user.getUsername());
        }
    }
}

