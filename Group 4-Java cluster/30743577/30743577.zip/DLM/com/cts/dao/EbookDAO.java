package com.cts.dao;

import com.cts.exception.EbookDoesnotExistException;
import com.cts.model.Ebook;
import com.cts.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EbookDAO {
    public void addEbook(Ebook ebook) {
        String sql = "INSERT INTO Ebook (title, genre, publication_date, author_id, available_copies) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, ebook.getTitle());
            stmt.setString(2, ebook.getGenre());
            stmt.setString(3, ebook.getPublicationDate());
            stmt.setInt(4, ebook.getAuthorId());
            stmt.setInt(5, ebook.getAvailableCopies());

            stmt.executeUpdate();
            System.out.println("E-book added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Ebook getEbook(int ebookId) {
        String sql = "SELECT * FROM Ebook WHERE ebook_id = ?";
        Ebook ebook = null;

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, ebookId);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                ebook = new Ebook();
                ebook.setEbookId(rs.getInt("ebook_id"));
                ebook.setTitle(rs.getString("title"));
                ebook.setGenre(rs.getString("genre"));
                ebook.setPublicationDate(rs.getString("publication_date"));
                ebook.setAuthorId(rs.getInt("author_id"));
                ebook.setAvailableCopies(rs.getInt("available_copies"));
            } else if (!rs.next()) {
                throw new EbookDoesnotExistException();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return ebook;
    }

    public void updateEbook(Ebook ebook) {
        String sql = "UPDATE Ebook SET title = ?, genre = ?, publication_date = ?, author_id = ?, available_copies = ? WHERE ebook_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, ebook.getTitle());
            stmt.setString(2, ebook.getGenre());
            stmt.setString(3, ebook.getPublicationDate());
            stmt.setInt(4, ebook.getAuthorId());
            stmt.setInt(5, ebook.getAvailableCopies());
            stmt.setInt(6, ebook.getEbookId());

            stmt.executeUpdate();
            System.out.println("E-book updated successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteEbook(int ebookId) {
        String sql = "DELETE FROM Ebook WHERE ebook_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, ebookId);
            stmt.executeUpdate();
            System.out.println("E-book deleted successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Ebook> getAllEbooks() {
        String sql = "SELECT * FROM Ebook";
        List<Ebook> ebooks = new ArrayList<>();

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                Ebook ebook = new Ebook();
                ebook.setEbookId(rs.getInt("ebook_id"));
                ebook.setTitle(rs.getString("title"));
                ebook.setGenre(rs.getString("genre"));
                ebook.setPublicationDate(rs.getString("publication_date"));
                ebook.setAuthorId(rs.getInt("author_id"));
                ebook.setAvailableCopies(rs.getInt("available_copies"));

                ebooks.add(ebook);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ebooks;
    }
}
