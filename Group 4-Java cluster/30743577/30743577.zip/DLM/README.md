
# Digital Library Management System

This project is a Digital Library Management System implemented in Core Java using MySQL and JDBC. The application provides functionalities to manage e-books, authors, and user memberships.


## Prerequisites

Before running the project, ensure you have the following installed on your machine:

- Java Development Kit (JDK) 8 or above
- MySQL Server
- IntelliJ IDEA

## Setup Instructions

### 1. Clone the Repository

Clone the repository to your local machine:


### 2. Import the Project in IntelliJ IDEA

1. Open IntelliJ IDEA.
2. Click on `File` > `Open` and select the root directory of the cloned repository.
3. IntelliJ will automatically detect the project as a Java project. Wait for the IDE to finish indexing and building the project.

### 3. Configure the Database Connection

1. Create a MySQL database with the following command:

    ```sql
    CREATE DATABASE library_db;
    ```

2. Update the database credentials in the `LibraryManagementSystem.java` or a configuration file:

    ```java
    String url = "jdbc:mysql://localhost:3306/library_db";
    String username = "your_mysql_username";
    String password = "your_mysql_password";
    ```

3. Execute the SQL scripts to create the necessary tables:

    ```sql
    -- Author table
    CREATE TABLE author (
        author_id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(255) NOT NULL,
        bio TEXT,
        nationality VARCHAR(100),
        birth_date DATE
    );

    -- Ebook table
    CREATE TABLE ebook (
        ebook_id INT PRIMARY KEY AUTO_INCREMENT,
        title VARCHAR(255) NOT NULL,
        genre VARCHAR(100),
        publication_date DATE,
        author_id INT,
        available_copies INT DEFAULT 0,
        FOREIGN KEY (author_id) REFERENCES author(author_id)
    );

    -- User table
    CREATE TABLE user (
        user_id INT PRIMARY KEY AUTO_INCREMENT,
        username VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        date_of_birth DATE,
        membership_date DATE,
        membership_status VARCHAR(50)
    );
    ```

### 4. Run the Application

1. In IntelliJ IDEA, navigate to the `LibraryManagementSystem` class under the `com.library` package.
2. Right-click on the `LibraryManagementSystem.java` file and select `Run 'LibraryManagementSystem.main()'`.
3. The console application will start, and you can interact with the menu to manage e-books, authors, and users.

### 5. Building the Project

To build the project, you can use the following steps:

1. Go to `Build` > `Build Project` in the IntelliJ menu.
2. The compiled `.class` files will be available under the `out/production/<project_name>` directory.

