package com.cts.insurancemanagement.daoimpl;

import com.cts.insurancemanagement.dao.ClientDao;
import com.cts.insurancemanagement.exception.DatabaseException;
import com.cts.insurancemanagement.exception.ClientNotFoundException;
import com.cts.insurancemanagement.model.ClientModel;
import com.cts.insurancemanagement.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClientDaoImpl implements ClientDao {

    private final Connection connection;

    public ClientDaoImpl() throws SQLException {
        connection = DatabaseConnection.getConnection();
    }

    @Override
    public void addClient(ClientModel client) throws DatabaseException {
        String sql = "INSERT INTO Client (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, client.getName());
            stmt.setString(2, client.getEmail());
            stmt.setInt(3, client.getPhoneNumber());
            stmt.setString(4, client.getAddress());
            stmt.executeUpdate();
            System.out.println("Client added successfully.");
        } catch (SQLException e) {
            throw new DatabaseException("Failed to add client.", e);
        }
    }

    @Override
    public List<ClientModel> getAllClients() throws DatabaseException {
        List<ClientModel> clients = new ArrayList<>();
        String sql = "SELECT * FROM Client";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                ClientModel client = new ClientModel(
                        rs.getInt("client_id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getInt("phone_number"),
                        rs.getString("address")
                );
                clients.add(client);
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to get all clients.", e);
        }
        return clients;
    }

    @Override
    public void updateClient(ClientModel client) throws ClientNotFoundException,DatabaseException {
        // First, check if the client exists
        String checkSql = "SELECT COUNT(*) FROM Client WHERE client_id = ?";
        try (PreparedStatement checkStmt = connection.prepareStatement(checkSql)) {
            checkStmt.setInt(1, client.getClientId());
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next() && rs.getInt(1) == 0) {
                throw new ClientNotFoundException("Client with ID " + client.getClientId() + " does not exist.");
            }
        } catch (SQLException e) {
            throw new ClientNotFoundException("Failed to check client existence.", e);
        }

        // Now update the client
        String updateSql = "UPDATE Client SET name = ?, email = ?, phone_number = ?, address = ? WHERE client_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(updateSql)) {
            stmt.setString(1, client.getName());
            stmt.setString(2, client.getEmail());
            stmt.setInt(3, client.getPhoneNumber());
            stmt.setString(4, client.getAddress());
            stmt.setInt(5, client.getClientId());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new ClientNotFoundException("Client with ID " + client.getClientId() + " does not exist.");
            }
            System.out.println("Client updated successfully.");
        } catch (SQLException e) {
            throw new DatabaseException("Failed to update client.", e);
        }
    }

    @Override
    public void deleteClient(int clientId) throws ClientNotFoundException,DatabaseException {
        // First, check if the client exists
        String checkSql = "SELECT COUNT(*) FROM Client WHERE client_id = ?";
        try (PreparedStatement checkStmt = connection.prepareStatement(checkSql)) {
            checkStmt.setInt(1, clientId);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next() && rs.getInt(1) == 0) {
                throw new ClientNotFoundException("Client with ID " + clientId + " does not exist.");
            }
        } catch (SQLException e) {
            throw new ClientNotFoundException("Failed to check client existence.", e);
        }

        // Now delete the client
        String deleteSql = "DELETE FROM Client WHERE client_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(deleteSql)) {
            stmt.setInt(1, clientId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new ClientNotFoundException("Client with ID " + clientId + " does not exist.");
            }
            System.out.println("Client deleted successfully.");
        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete client.", e);
        }
    }
}
