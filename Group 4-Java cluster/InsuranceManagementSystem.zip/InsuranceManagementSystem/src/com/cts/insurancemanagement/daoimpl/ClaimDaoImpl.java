package com.cts.insurancemanagement.daoimpl;

import com.cts.insurancemanagement.dao.ClaimDao;
import com.cts.insurancemanagement.exception.DatabaseException;
import com.cts.insurancemanagement.exception.ClaimNotFoundException;
import com.cts.insurancemanagement.model.ClaimModel;
import com.cts.insurancemanagement.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClaimDaoImpl implements ClaimDao {

    private final Connection connection;

    public ClaimDaoImpl() throws SQLException {
        connection = DatabaseConnection.getConnection();
    }

    @Override
    public void addClaim(ClaimModel claim) throws DatabaseException {
        String sql = "INSERT INTO Claim (policy_id, client_id, claim_date, status) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, claim.getPolicyId());
            stmt.setInt(2, claim.getClientId());
            stmt.setString(3, claim.getClaimDate());
            stmt.setString(4, claim.getStatus());
            stmt.executeUpdate();
            System.out.println("Claim added successfully.");
        } catch (SQLException e) {
            throw new DatabaseException("Failed to add claim.", e);
        }
    }

    @Override
    public List<ClaimModel> getAllClaims() throws DatabaseException {
        List<ClaimModel> claims = new ArrayList<>();
        String sql = "SELECT * FROM Claim";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                ClaimModel claim = new ClaimModel(
                        rs.getInt("claim_id"),
                        rs.getInt("policy_id"),
                        rs.getInt("client_id"),
                        rs.getString("claim_date"),
                        rs.getString("status")
                );
                claims.add(claim);
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to get all claims.", e);
        }
        return claims;
    }

    @Override
    public void updateClaim(ClaimModel claim) throws ClaimNotFoundException, DatabaseException {
        // First, check if the claim exists
        String checkSql = "SELECT COUNT(*) FROM Claim WHERE claim_id = ?";
        try (PreparedStatement checkStmt = connection.prepareStatement(checkSql)) {
            checkStmt.setInt(1, claim.getClaimId());
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next() && rs.getInt(1) == 0) {
                throw new ClaimNotFoundException("Claim with ID " + claim.getClaimId() + " does not exist.");
            }
        } catch (SQLException e) {
            throw new ClaimNotFoundException("Failed to check claim existence.", e);
        }

        // Now update the claim
        String updateSql = "UPDATE Claim SET policy_id = ?, client_id = ?, claim_date = ?, status = ? WHERE claim_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(updateSql)) {
            stmt.setInt(1, claim.getPolicyId());
            stmt.setInt(2, claim.getClientId());
            stmt.setString(3, claim.getClaimDate());
            stmt.setString(4, claim.getStatus());
            stmt.setInt(5, claim.getClaimId());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new ClaimNotFoundException("Claim with ID " + claim.getClaimId() + " does not exist.");
            }
            System.out.println("Claim updated successfully.");
        } catch (SQLException e) {
            throw new DatabaseException("Failed to update claim.", e);
        }
    }

    @Override
    public void deleteClaim(int claimId) throws ClaimNotFoundException,DatabaseException {
        // First, check if the claim exists
        String checkSql = "SELECT COUNT(*) FROM Claim WHERE claim_id = ?";
        try (PreparedStatement checkStmt = connection.prepareStatement(checkSql)) {
            checkStmt.setInt(1, claimId);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next() && rs.getInt(1) == 0) {
                throw new ClaimNotFoundException("Claim with ID " + claimId + " does not exist.");
            }
        } catch (SQLException e) {
            throw new ClaimNotFoundException("Failed to check claim existence.", e);
        }

        // Now delete the claim
        String deleteSql = "DELETE FROM Claim WHERE claim_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(deleteSql)) {
            stmt.setInt(1, claimId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new ClaimNotFoundException("Claim with ID " + claimId + " does not exist.");
            }
            System.out.println("Claim deleted successfully.");
        } catch (SQLException e) {
            throw new DatabaseException("Failed to delete claim.", e);
        }
    }
}

