package com.cts.insurancemanagement.daoimpl;

import com.cts.insurancemanagement.dao.PolicyDao;
import com.cts.insurancemanagement.exception.DatabaseException;
import com.cts.insurancemanagement.exception.PolicyNotFoundException;
import com.cts.insurancemanagement.model.PolicyModel;
import com.cts.insurancemanagement.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PolicyDaoImpl implements PolicyDao {
    private final Connection connection;

    public PolicyDaoImpl() throws SQLException {
        connection = DatabaseConnection.getConnection();
    }

    @Override
    public void addPolicy(PolicyModel policy) throws DatabaseException {
        String sql = "INSERT INTO Policy (policy_number, type, coverage_amount, premium_amount) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, policy.getPolicyNumber());
            stmt.setString(2, policy.getType());
            stmt.setFloat(3, policy.getCoverageAmount());
            stmt.setFloat(4, policy.getPremiumAmount());
            stmt.executeUpdate();
            System.out.println("Policy added successfully.");
        } catch (SQLException e) {
            throw new DatabaseException("Failed to add policy.", e);
        }
    }

    @Override
    public List<PolicyModel> getAllPolicies() throws DatabaseException {
        List<PolicyModel> policies = new ArrayList<>();
        String sql = "SELECT * FROM Policy";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                PolicyModel policy = new PolicyModel(
                        rs.getInt("policy_id"),
                        rs.getInt("policy_number"),
                        rs.getString("type"),
                        rs.getFloat("coverage_amount"),
                        rs.getFloat("premium_amount")
                );
                policies.add(policy);
            }
        } catch (SQLException e) {
            throw new DatabaseException("Failed to get all policies.", e);
        }
        return policies;
    }

    @Override
    public void updatePolicy(PolicyModel policy) throws PolicyNotFoundException,DatabaseException {
        // First, check if the policy exists
        String checkSql = "SELECT COUNT(*) FROM Policy WHERE policy_id = ?";
        try (PreparedStatement checkStmt = connection.prepareStatement(checkSql)) {
            checkStmt.setInt(1, policy.getPolicyId());
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next() && rs.getInt(1) == 0) {
                throw new PolicyNotFoundException("Policy with ID " + policy.getPolicyId() + " does not exist.");
            }
        } catch (SQLException e) {
            throw new PolicyNotFoundException("Failed to check policy existence.", e);
        }

        // Now update the policy
        String updateSql = "UPDATE Policy SET policy_number = ?, type = ?, coverage_amount = ?, premium_amount = ? WHERE policy_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(updateSql)) {
            stmt.setInt(1, policy.getPolicyNumber());
            stmt.setString(2, policy.getType());
            stmt.setFloat(3, policy.getCoverageAmount());
            stmt.setFloat(4, policy.getPremiumAmount());
            stmt.setInt(5, policy.getPolicyId());
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new PolicyNotFoundException("Policy with ID " + policy.getPolicyId() + " does not exist.");
            }
            System.out.println("Policy details updated successfully.");
        } catch (SQLException e) {
            throw new DatabaseException("Failed to update policy.", e);
        }
    }

        @Override
        public void deletePolicy(int policyId) throws PolicyNotFoundException, DatabaseException {
            // First, check if the policy exists
            String checkSql = "SELECT COUNT(*) FROM Policy WHERE policy_id = ?";
            try (PreparedStatement checkStmt = connection.prepareStatement(checkSql)) {
                checkStmt.setInt(1, policyId);
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next() && rs.getInt(1) == 0) {
                    throw new PolicyNotFoundException("Policy with ID " + policyId + " does not exist.");
                }
            } catch (SQLException e) {
                throw new PolicyNotFoundException("Failed to check policy existence.", e);
            }

            // Now delete the policy
            String deleteSql = "DELETE FROM Policy WHERE policy_id = ?";
            try (PreparedStatement stmt = connection.prepareStatement(deleteSql)) {
                stmt.setInt(1, policyId);
                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected == 0) {
                    throw new PolicyNotFoundException("Policy with ID " + policyId + " does not exist.");
                }
                System.out.println("Policy deleted successfully.");
            } catch (SQLException e) {
                throw new DatabaseException("Failed to delete policy.", e);
            }
    }
}
