package com.cts.insurancemanagement.model;

public class PolicyModel {
    private int policyId;
    private int policyNumber;
    private String type;
    private float coverageAmount;
    private float premiumAmount;

    // Constructor for creating a new policy without an ID (useful before insertion in DB)
    public PolicyModel(int policyNumber, String type, float coverageAmount, float premiumAmount) {
        this.policyNumber = policyNumber;
        this.type = type;
        this.coverageAmount = coverageAmount;
        this.premiumAmount = premiumAmount;
    }

    // Constructor for fetching or updating an existing policy with an ID
    public PolicyModel(int policyId, int policyNumber, String type, float coverageAmount, float premiumAmount) {
        this.policyId = policyId;
        this.policyNumber = policyNumber;
        this.type = type;
        this.coverageAmount = coverageAmount;
        this.premiumAmount = premiumAmount;
    }

    // Getters and Setters
    public int getPolicyId() {
        return policyId;
    }

    public void setPolicyId(int policyId) {
        this.policyId = policyId;
    }

    public int getPolicyNumber() {
        return policyNumber;
    }

    public void setPolicyNumber(int policyNumber) {
        this.policyNumber = policyNumber;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public float getCoverageAmount() {
        return coverageAmount;
    }

    public void setCoverageAmount(float coverageAmount) {
        this.coverageAmount = coverageAmount;
    }

    public float getPremiumAmount() {
        return premiumAmount;
    }

    public void setPremiumAmount(float premiumAmount) {
        this.premiumAmount = premiumAmount;
    }
}
