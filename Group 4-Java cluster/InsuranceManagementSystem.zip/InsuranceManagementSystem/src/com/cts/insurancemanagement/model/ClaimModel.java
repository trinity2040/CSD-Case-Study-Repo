package com.cts.insurancemanagement.model;

public class ClaimModel {


    private int claimId;
    private int policyId;
    private int clientId;
    private String claimDate;
    private String status;

    // Constructor for adding a new claim
    public ClaimModel(int policyId, int clientId, String claimDate, String status) {
        this.policyId = policyId;
        this.clientId = clientId;
        this.claimDate = claimDate;
        this.status = status;
    }

    // Constructor for updating an existing claim
    public ClaimModel(int claimId, int policyId, int clientId, String claimDate, String status) {
        this.claimId = claimId;
        this.policyId = policyId;
        this.clientId = clientId;
        this.claimDate = claimDate;
        this.status = status;
    }

    public int getClaimId() {
        return claimId;
    }

    public void setClaimId(int claimId) {
        this.claimId = claimId;
    }

    public int getPolicyId() {
        return policyId;
    }

    public void setPolicyId(int policyId) {
        this.policyId = policyId;
    }

    public int getClientId() {
        return clientId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public String getClaimDate() {
        return claimDate;
    }

    public void setClaimDate(String claimDate) {
        this.claimDate = claimDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
