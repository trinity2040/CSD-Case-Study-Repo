package com.cts.insurancemanagement.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3306/insurancedb";
    private static final String USER = "root";
    private static final String PASSWORD = "2020";

    public static Connection getConnection() throws SQLException {
        Connection connection = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL Driver not found: " + e.getMessage());
            e.fillInStackTrace();
        } catch (SQLException e) {
            System.out.println("SQL Error: " + e.getMessage());
            e.fillInStackTrace();
            throw e;
        }

        return connection;
    }

    public static void main(String[] args) {
        try {
            Connection connection = getConnection();
            // Do something with the connection
            if (connection != null) {
                connection.close();  // Close the connection when done
            }
        } catch (SQLException e) {
            System.out.println("Failed to connect to the database");
        }
    }
}
