package com.cts.insurancemanagement.client;

import com.cts.insurancemanagement.daoimpl.PolicyDaoImpl;
import com.cts.insurancemanagement.daoimpl.ClaimDaoImpl;
import com.cts.insurancemanagement.daoimpl.ClientDaoImpl;
import com.cts.insurancemanagement.exception.ClaimNotFoundException;
import com.cts.insurancemanagement.exception.ClientNotFoundException;
import com.cts.insurancemanagement.exception.DatabaseException;
import com.cts.insurancemanagement.exception.PolicyNotFoundException;
import com.cts.insurancemanagement.model.PolicyModel;
import com.cts.insurancemanagement.model.ClaimModel;
import com.cts.insurancemanagement.model.ClientModel;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;
public class Main {
    private static final Scanner scanner = new Scanner(System.in);

    // This class will manage policy operations
    private static final PolicyDaoImpl policyDaoImpl;

    static {
        try {
            policyDaoImpl = new PolicyDaoImpl();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // This class will manage claim operations
    private static final ClaimDaoImpl claimDaoImpl;

    static {
        try {
            claimDaoImpl = new ClaimDaoImpl();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // This class will manage client operations
    private static final ClientDaoImpl clientDaoImpl;

    static {
        try {
            clientDaoImpl = new ClientDaoImpl();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // Program Execution will start from this method.
    public static void main(String[] args) throws DatabaseException {
        while (true) {
            System.out.println("\nInsurance Management System");
            System.out.println("1. Manage Policies");
            System.out.println("2. Manage Claims");
            System.out.println("3. Manage Clients");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    managePolicies();
                    break;
                case 2:
                    manageClaims();
                    break;
                case 3:
                    manageClients();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    // Menu for Policy management
    private static void managePolicies() throws DatabaseException {
        System.out.println("\n1. Add Policy");
        System.out.println("2. View Policies");
        System.out.println("3. Update Policy");
        System.out.println("4. Delete Policy");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                scanner.nextLine();
                System.out.print("Enter policy number: ");
                int policyNumber = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                System.out.print("Enter policy type: ");
                String type = scanner.nextLine();
                System.out.print("Enter coverage amount: ");
                float coverageAmount = scanner.nextFloat();
                System.out.print("Enter premium amount: ");
                float premiumAmount = scanner.nextFloat();
                PolicyModel policy = new PolicyModel(policyNumber, type, coverageAmount, premiumAmount);
                policyDaoImpl.addPolicy(policy);
                break;
            case 2:
                List<PolicyModel> policies = policyDaoImpl.getAllPolicies();
                for (PolicyModel policyItem : policies) {
                    System.out.println();
                    System.out.println("Policy ID: " + policyItem.getPolicyId());
                    System.out.println("Policy Number: " + policyItem.getPolicyNumber());
                    System.out.println("Policy Type: " + policyItem.getType());
                    System.out.println("Coverage Amount: " + policyItem.getCoverageAmount());
                    System.out.println("Premium Amount: " + policyItem.getPremiumAmount());
                    System.out.println("---------------------------------------");
                }
                break;
            case 3:
                System.out.print("Enter Policy ID to update: ");
                int policyId = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Enter new policy number: ");
                int newPolicyNumber = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                System.out.print("Enter new policy type: ");
                String newType = scanner.nextLine();
                System.out.print("Enter new coverage amount: ");
                float newCoverageAmount = scanner.nextFloat();
                System.out.print("Enter new premium amount: ");
                float newPremiumAmount = scanner.nextFloat();
                PolicyModel updatedPolicy = new PolicyModel(policyId, newPolicyNumber, newType, newCoverageAmount, newPremiumAmount);
                try {
                    policyDaoImpl.updatePolicy(updatedPolicy);
                }catch (DatabaseException e) {
                    System.out.println("An error occurred while deleting the policy: " + e.getMessage());
                }  catch (PolicyNotFoundException e) {
                    System.out.println(e.getMessage());
                }
                break;
            case 4:
                System.out.print("Enter Policy ID to delete: ");
                int deletePolicyId = scanner.nextInt();
                try {
                    policyDaoImpl.deletePolicy(deletePolicyId);
                }catch (DatabaseException e) {
                    System.out.println("An error occurred while deleting the policy: " + e.getMessage());
                } catch (PolicyNotFoundException e) {
                    System.out.println(e.getMessage());
                }
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    // Menu for Claim management
    private static void manageClaims() throws DatabaseException {
        System.out.println("\n1. Add Claim");
        System.out.println("2. View Claims");
        System.out.println("3. Update Claim");
        System.out.println("4. Delete Claim");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                System.out.print("Enter Policy ID: ");
                int policyId = scanner.nextInt();
                System.out.print("Enter Client ID: ");
                int clientId = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                System.out.print("Enter claim date (YYYY-MM-DD): ");
                String claimDate = scanner.nextLine();
                System.out.print("Enter status (approved/rejected/pending): ");
                String status = scanner.nextLine();
                ClaimModel claim = new ClaimModel(policyId, clientId, claimDate, status);
                try {
                    claimDaoImpl.addClaim(claim);
                    System.out.println("Claim added successfully.");
                } catch (DatabaseException e) {
                    System.out.println("An error occurred while adding the claim: " + e.getMessage());
                }
                break;
            case 2:
                List<ClaimModel> claims = claimDaoImpl.getAllClaims();
                for (ClaimModel claimItem : claims) {
                    System.out.println();
                    System.out.println("Claim ID: " + claimItem.getClaimId());
                    System.out.println("Policy ID: " + claimItem.getPolicyId());
                    System.out.println("Client ID: " + claimItem.getClientId());
                    System.out.println("Claim Date: " + claimItem.getClaimDate());
                    System.out.println("Claim Status: " + claimItem.getStatus());
                    System.out.println("---------------------------------------");
                }
                break;
            case 3:
                System.out.print("Enter Claim ID to update: ");
                int claimId = scanner.nextInt();
                System.out.print("Enter new Policy ID: ");
                int newPolicyId = scanner.nextInt();
                System.out.print("Enter new Client ID: ");
                int newClientId = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                System.out.print("Enter new Claim Date (YYYY-MM-DD): ");
                String newClaimDate = scanner.nextLine();
                System.out.print("Enter new status (approved/rejected/pending): ");
                String newStatus = scanner.nextLine();
                ClaimModel updatedClaim = new ClaimModel(claimId, newPolicyId, newClientId, newClaimDate, newStatus);
                try {
                    claimDaoImpl.updateClaim(updatedClaim);
                    System.out.println("Claim updated successfully.");
                }catch (DatabaseException e) {
                    System.out.println("An error occurred while deleting the claim: " + e.getMessage());
                } catch (ClaimNotFoundException e) {
                    System.out.println(e.getMessage());
                }
                break;
            case 4:
                System.out.print("Enter Claim ID to delete: ");
                int deleteClaimId = scanner.nextInt();
                try {
                    claimDaoImpl.deleteClaim(deleteClaimId);
                    System.out.println("Claim deleted successfully.");
                }catch (DatabaseException e) {
                    System.out.println("An error occurred while deleting the claim: " + e.getMessage());
                }catch (ClaimNotFoundException e) {
                    System.out.println(e.getMessage());
                }
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }


    // Menu for Client management
    private static void manageClients() throws DatabaseException {
        System.out.println("\n1. Add Client");
        System.out.println("2. View Clients");
        System.out.println("3. Update Client");
        System.out.println("4. Delete Client");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                scanner.nextLine(); // Consume newline
                System.out.print("Enter client name: ");
                String clientName = scanner.nextLine();
                System.out.print("Enter client email: ");
                String clientEmail = scanner.nextLine();
                System.out.print("Enter client phone number: ");
                int clientPhoneNumber = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                System.out.print("Enter client address: ");
                String clientAddress = scanner.nextLine();
                ClientModel client = new ClientModel(clientName, clientEmail, clientPhoneNumber, clientAddress);
                try {
                    clientDaoImpl.addClient(client);
                    System.out.println("Client added successfully.");
                } catch (DatabaseException e) {
                    System.out.println("An error occurred while adding the client: " + e.getMessage());
                }
                break;
            case 2:
                List<ClientModel> clients = clientDaoImpl.getAllClients();
                for (ClientModel clientItem : clients) {
                    System.out.println();
                    System.out.println("Client ID: " + clientItem.getClientId());
                    System.out.println("Client Name: " + clientItem.getName());
                    System.out.println("Client Email: " + clientItem.getEmail());
                    System.out.println("Client Phone Number: " + clientItem.getPhoneNumber());
                    System.out.println("Client Address: " + clientItem.getAddress());
                    System.out.println("---------------------------------------");
                }
                break;
            case 3:
                System.out.print("Enter Client ID to update: ");
                int clientId = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                System.out.print("Enter new client name: ");
                String newClientName = scanner.nextLine();
                System.out.print("Enter new client email: ");
                String newClientEmail = scanner.nextLine();
                System.out.print("Enter new client phone number: ");
                int newClientPhoneNumber = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                System.out.print("Enter new client address: ");
                String newClientAddress = scanner.nextLine();
                ClientModel updatedClient = new ClientModel(clientId, newClientName, newClientEmail, newClientPhoneNumber, newClientAddress);
                try {
                    clientDaoImpl.updateClient(updatedClient);
                    System.out.println("Client updated successfully.");
                } catch (DatabaseException e) {
                    System.out.println("An error occurred while deleting the client: " + e.getMessage());
                } catch (ClientNotFoundException e) {
                    System.out.println(e.getMessage());
                }
                break;
            case 4:
                System.out.print("Enter Client ID to delete: ");
                int deleteClientId = scanner.nextInt();
                try {
                    clientDaoImpl.deleteClient(deleteClientId);
                    System.out.println("Client deleted successfully.");
                } catch (DatabaseException e) {
                    System.out.println("An error occurred while deleting the client: " + e.getMessage());
                } catch (ClientNotFoundException e) {
                    System.out.println(e.getMessage());
                }
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

}