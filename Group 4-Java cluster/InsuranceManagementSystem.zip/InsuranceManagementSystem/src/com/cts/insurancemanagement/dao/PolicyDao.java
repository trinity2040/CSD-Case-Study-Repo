package com.cts.insurancemanagement.dao;

import com.cts.insurancemanagement.exception.DatabaseException;
import com.cts.insurancemanagement.exception.PolicyNotFoundException;
import com.cts.insurancemanagement.model.PolicyModel;
import java.util.List;

public interface PolicyDao {
    void addPolicy(PolicyModel policy) throws DatabaseException;
    List<PolicyModel> getAllPolicies() throws DatabaseException;
    void updatePolicy(PolicyModel policy) throws PolicyNotFoundException, DatabaseException;
    void deletePolicy(int policyId) throws PolicyNotFoundException, DatabaseException;
}
