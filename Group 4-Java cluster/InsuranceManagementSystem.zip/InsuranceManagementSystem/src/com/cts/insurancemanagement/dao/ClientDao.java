package com.cts.insurancemanagement.dao;
import com.cts.insurancemanagement.exception.ClaimNotFoundException;
import com.cts.insurancemanagement.exception.ClientNotFoundException;
import com.cts.insurancemanagement.exception.DatabaseException;
import com.cts.insurancemanagement.model.ClientModel;
import java.util.List;
public interface ClientDao {
        void addClient(ClientModel client) throws DatabaseException;
        List<ClientModel> getAllClients() throws DatabaseException;
        void updateClient(ClientModel client) throws ClientNotFoundException,DatabaseException;
        void deleteClient(int clientId) throws ClientNotFoundException,DatabaseException;
}
