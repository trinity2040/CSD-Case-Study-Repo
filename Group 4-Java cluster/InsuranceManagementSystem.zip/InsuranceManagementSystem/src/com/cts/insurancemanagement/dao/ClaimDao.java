package com.cts.insurancemanagement.dao;

import com.cts.insurancemanagement.exception.ClaimNotFoundException;
import com.cts.insurancemanagement.exception.DatabaseException;
import com.cts.insurancemanagement.model.ClaimModel;

import java.util.List;

public interface ClaimDao {
    void addClaim(ClaimModel claim) throws DatabaseException;
    List<ClaimModel> getAllClaims() throws DatabaseException;
    void updateClaim(ClaimModel claim) throws ClaimNotFoundException, DatabaseException;
    void deleteClaim(int claimId) throws ClaimNotFoundException,DatabaseException;
}
