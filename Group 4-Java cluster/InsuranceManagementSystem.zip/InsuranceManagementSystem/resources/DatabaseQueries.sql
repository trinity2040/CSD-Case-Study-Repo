CREATE DATABASE InsuranceDB;
USE InsuranceDB;
CREATE TABLE Policy(
    policy_id INT AUTO_INCREMENT PRIMARY KEY,
    policy_number INT NOT NULL,
    type VARCHAR(255),
    coverage_amount FLOAT NOT NULL,
    premium_amount FLOAT NOT NULL
    );
  
CREATE TABLE Client(
    client_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    phone_number INT NOT NULL,
    address VARCHAR(255) NOT NULL
    );
    
CREATE TABLE Claim(
    claim_id INT AUTO_INCREMENT PRIMARY KEY,
    policy_id INT,
    client_id INT,
    claim_date DATE NOT NULL,
    status VARCHAR(10),
    FOREIGN KEY(policy_id) REFERENCES Policy(policy_id),
    FOREIGN KEY(client_id) REFERENCES Client(client_id)
    );
 SELECT * FROM Policy;
 SELECT * FROM Client;
  SELECT * FROM Claim;
  
INSERT INTO Policy (policy_number, type, coverage_amount, premium_amount)
VALUES (123456, 'Auto', 50000.00, 1500.00);

INSERT INTO Client (name, email, phone_number, address)
VALUES ('Raj Shah', 'raj@gmail.com', 1234567890, '123 Main St, Mumbai');

INSERT INTO Claim (policy_id, client_id, claim_date, status)
VALUES (1, 1, '2024-09-04', 'Pending');

  