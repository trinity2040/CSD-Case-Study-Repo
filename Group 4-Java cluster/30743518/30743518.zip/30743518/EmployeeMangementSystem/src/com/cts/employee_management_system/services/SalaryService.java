package com.cts.employee_management_system.services;

import com.cts.employee_management_system.dao.SalaryDAO;
import com.cts.employee_management_system.dao.EmployeeDAO;
import com.cts.employee_management_system.exception.*;
import com.cts.employee_management_system.models.Salary;

import java.util.Scanner;

public class SalaryService {
    static Scanner sc = new Scanner(System.in);

    private static void processSalary(double salary) {
        if (salary < 10000) {
            throw new InsufficientSalaryException("Salary must be greater than 10000");
        }
    }
    private static void checkEmployeeExists(int employeeId) throws EmployeeNotFoundException {
        if (!EmployeeDAO.employeeExists(employeeId)) {
            throw new EmployeeNotFoundException("Employee with ID " + employeeId + " not found");
        }
    }
    private static void validateEmployeeId(String employeeId) throws InvalidEmployeeIdException {
        if (employeeId == null || employeeId.isEmpty()) {
            throw new InvalidEmployeeIdException("Employee ID cannot be null or empty");
        }
    }

    private static void validateSalaryId(String salaryId) throws InvalidSalaryIdException {
        if (salaryId == null || salaryId.isEmpty()) {
            throw new InvalidSalaryIdException("Salary ID cannot be null or empty");
        }
    }

    private static void validatePaymentDate(int paymentDate) throws InvalidPaymentDateException {
        if (paymentDate < 1 || paymentDate > 31) {
            throw new InvalidPaymentDateException("Payment date must be between 1 and 31");
        }
    }

    public static void addSalary() {
        int payment_date;
        String emp_id;
        double salary;
        System.out.print("Enter employee_id: ");
        emp_id = sc.nextLine();
        System.out.print("Enter salary_amount: ");
        salary = sc.nextDouble();
        System.out.print("Enter payment_date: ");
        payment_date = sc.nextInt();
        sc.nextLine();

        try {
            processSalary(salary);
            validateEmployeeId(emp_id);
            checkEmployeeExists(Integer.parseInt(emp_id));
            validatePaymentDate(payment_date);
            SalaryDAO.addSalary(new Salary(Integer.parseInt(emp_id), salary, payment_date));
        } catch (IllegalArgumentException | InvalidEmployeeIdException | InvalidPaymentDateException | EmployeeNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void viewSalary() {
        SalaryDAO.viewSalary();
    }

    public static void updateSalary() {
        System.out.print("Enter salary Id for update: ");
        String id = sc.nextLine();
        int payment_date;
        int emp_id;
        double salary;
        System.out.print("Enter employee_id: ");
        emp_id = sc.nextInt();
        System.out.print("Enter salary_amount: ");
        salary = sc.nextDouble();
        System.out.print("Enter payment_date: ");
        payment_date = sc.nextInt();
        sc.nextLine();

        try {
            validateSalaryId(id);
            processSalary(salary);
            validateEmployeeId(String.valueOf(emp_id));
            checkEmployeeExists(emp_id);
            validatePaymentDate(payment_date);
            SalaryDAO.updateSalary(new Salary(emp_id, salary, payment_date), Integer.parseInt(id));
        } catch (EmployeeNotFoundException | IllegalArgumentException | InvalidEmployeeIdException | InvalidSalaryIdException | InvalidPaymentDateException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void deleteSalary() {
        System.out.print("Enter Salary Id to delete: ");
        int id = sc.nextInt();
        sc.nextLine();

        try {
            validateSalaryId(String.valueOf(id));
            SalaryDAO.deleteSalary(id);
        } catch (InvalidSalaryIdException e) {
            System.out.println(e.getMessage());
        }
    }
}
