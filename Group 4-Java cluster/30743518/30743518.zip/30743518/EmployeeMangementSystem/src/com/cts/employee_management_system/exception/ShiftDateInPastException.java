package com.cts.employee_management_system.exception;

public class ShiftDateInPastException extends Exception {
    public ShiftDateInPastException(String message) {
        super(message);
    }
}
