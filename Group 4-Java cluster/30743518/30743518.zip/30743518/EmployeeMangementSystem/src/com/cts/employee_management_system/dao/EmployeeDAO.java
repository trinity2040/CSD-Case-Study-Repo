package com.cts.employee_management_system.dao;

import com.cts.employee_management_system.models.Employee;
import com.cts.employee_management_system.util.DatabaseConnection;

import java.sql.*;

public class EmployeeDAO {
    public static boolean employeeExists(int id){
        String sql="SELECT * FROM Employee WHERE employee_id=?;";
        try(Connection conn= DatabaseConnection.connect();
            PreparedStatement st = conn.prepareStatement(sql)) {
            st.setInt(1, id);
            ResultSet result = st.executeQuery();
            return result.next();
        }catch(SQLException ex){
            System.out.println("Invalid Sql Query");
        }
        return false;
    }
    public static void addEmployee(Employee e){
        String sql="INSERT INTO Employee (name,email,phone,position) VALUES (?,?,?,?);";
        try(Connection conn= DatabaseConnection.connect();
            PreparedStatement st = conn.prepareStatement(sql)){
            st.setString(1,e.getName());
            st.setString(2, e.getEmail());
            st.setString(3,e.getPhone());
            st.setString(4,e.getPosition());
            int result= st.executeUpdate();
            System.out.println("Rows affected: "+result);
        }catch(SQLIntegrityConstraintViolationException er){
            System.out.println("Violating Constraint: "+er.getMessage());
        }catch(SQLException ex){
            System.out.println("Invalid Sql Query");
        }
    }
    public static void viewEmployeeDetails() {
        String sql = "SELECT * FROM Employee;";
        try (Connection conn = DatabaseConnection.connect();
             PreparedStatement st = conn.prepareStatement(sql)) {
            ResultSet rs = st.executeQuery();

            // Print the table header
            System.out.printf("%-15s %-20s %-25s %-15s %-20s%n",
                    "Employee Id", "Name", "Email", "Phone", "Position");
            System.out.println("----------------------------------------------------------------------------");

            // Print the table rows
            while (rs.next()) {
                int id = rs.getInt("employee_id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                String phone = rs.getString("phone");
                String position = rs.getString("position");

                System.out.printf("%-15d %-20s %-25s %-15s %-20s%n",
                        id, name, email, phone == null ? "" : phone, position == null ? "" : position);
            }

            System.out.println("----------------------------------------------------------------------------");

        } catch (SQLException e) {
            System.out.println("Cannot fetch data");
        }
    }

    public static void updateEmployeeInfo(Employee emp,int id){
        String sql="UPDATE Employee SET name = ?, email = ?, phone = ?, position = ? WHERE employee_id = ?;";
        try(Connection conn = DatabaseConnection.connect();
            PreparedStatement st = conn.prepareStatement(sql)){
            st.setString(1,emp.getName());
            st.setString(2,emp.getEmail());
            st.setString(3,emp.getPhone());
            st.setString(4,emp.getPosition());
            st.setInt(5,id);
            int result= st.executeUpdate();
            System.out.println("Rows affected: "+result);
        }catch(SQLIntegrityConstraintViolationException e){
            System.out.println("Violating Constraint: "+e.getMessage());
        }catch (SQLException e){
            System.out.println("Invalid Sql Query");
        }
    }
    public static void deleteEmployee(int id){
        String sql = "DELETE FROM Employee where employee_id=?;";
        try(Connection conn= DatabaseConnection.connect();
            PreparedStatement st = conn.prepareStatement(sql)){
            st.setInt(1,id);
            int result= st.executeUpdate();
            System.out.println("Rows affected: "+result);
        }catch (SQLException e){
            System.out.println("Invalid Sql Query");
        }
    }
}
