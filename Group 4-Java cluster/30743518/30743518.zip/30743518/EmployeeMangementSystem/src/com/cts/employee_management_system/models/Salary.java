package com.cts.employee_management_system.models;

public class Salary {

    private final int employee_id;
    private final double salary_amount;
    private final int payment_date;

    public Salary( int employee_id, double salary_amount, int payment_date) {
        this.employee_id = employee_id;
        this.salary_amount = salary_amount;
        this.payment_date = payment_date;
    }


    public int getEmployee_id() {
        return employee_id;
    }

    public double getSalary_amount() {
        return salary_amount;
    }

    public int getPayment_date() {
        return payment_date;
    }
}
