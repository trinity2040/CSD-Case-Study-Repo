package com.cts.employee_management_system.exception;

public class InvalidPaymentDateException extends Exception{

    public InvalidPaymentDateException(String message) {
        super(message);
    }
}
