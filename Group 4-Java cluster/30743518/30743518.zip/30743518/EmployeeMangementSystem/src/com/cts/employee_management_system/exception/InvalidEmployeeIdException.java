package com.cts.employee_management_system.exception;

public class InvalidEmployeeIdException extends Exception{

    public InvalidEmployeeIdException(String message) {
        super(message);
    }
}
