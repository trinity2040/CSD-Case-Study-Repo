package com.cts.employee_management_system.services;


import com.cts.employee_management_system.dao.EmployeeDAO;
import com.cts.employee_management_system.exception.*;
import com.cts.employee_management_system.models.Employee;

import java.util.Scanner;

public class EmployeeService {
    static Scanner sc= new Scanner(System.in);
    private static void validateEmployeeId(String employeeId) throws InvalidEmployeeIdException {
        if (employeeId == null || employeeId.isEmpty()) {
            throw new InvalidEmployeeIdException("Employee ID cannot be null or empty");
        }
    }
    private static void validateEmail(String email) throws InvalidEmailFormatException {
        if (!email.contains("@") || !email.contains(".")) {
            throw new InvalidEmailFormatException("Enter a valid email address");
        }
    }

    private static void validatePhoneNumber(String phone) throws InvalidPhoneNumberException {
        if (phone.length() != 10) {
            throw new InvalidPhoneNumberException("Phone number should be 10 digits long");
        }
    }

    private static void validatePosition(String position) throws InvalidPositionException {
        if (!position.toLowerCase().matches("manager|developer|tester|hr")) { // example positions
            throw new InvalidPositionException("Invalid position title: " + position);
        }
    }

    private static void checkEmployeeExists(int employeeId) throws EmployeeNotFoundException {
        if (!EmployeeDAO.employeeExists(employeeId)) {
            throw new EmployeeNotFoundException("Employee with ID " + employeeId + " not found");
        }
    }

    public static void addEmployee(){
        String name, email, phone, position;
        System.out.print("Enter Name: ");
        name = sc.nextLine();
        System.out.print("Enter Email: ");
        email = sc.nextLine();
        System.out.print("Enter Phone: ");
        phone = sc.nextLine();
        System.out.print("Enter Position: ");
        position = sc.nextLine();

        try {

            validateEmail(email);
            validatePosition(position);

            EmployeeDAO.addEmployee(new Employee(name, email, phone, position.toLowerCase()));
        } catch (IllegalArgumentException | InvalidEmailFormatException | InvalidPositionException e) {
            System.out.println(e.getMessage());
        }
    }
    public static void viewEmployeeDetails(){
        EmployeeDAO.viewEmployeeDetails();
    }
    public static void updateEmployeeInfo() {
        System.out.print("Enter employee ID for update: ");
        String id = sc.nextLine();

        String name, email, phone, position;
        System.out.print("Enter Name: ");
        name = sc.nextLine();
        System.out.print("Enter Email: ");
        email = sc.nextLine();
        System.out.print("Enter Phone: ");
        phone = sc.nextLine();
        System.out.print("Enter Position: ");
        position = sc.nextLine();

        try {
            validateEmployeeId(id);
            validateEmail(email);
            validatePhoneNumber(phone);
            validatePosition(position);
            checkEmployeeExists(Integer.parseInt(id));

            EmployeeDAO.updateEmployeeInfo(new Employee(name, email, phone, position.toLowerCase()), Integer.parseInt(id));
        } catch (IllegalArgumentException | InvalidEmployeeIdException | InvalidEmailFormatException |
                 InvalidPhoneNumberException | InvalidPositionException | EmployeeNotFoundException e) {
            System.out.println(e.getMessage());
        }
    }
    public static void deleteEmployee(){
        System.out.print("Enter employee Id for delete: ");
        int id= sc.nextInt();
        sc.nextLine();
        EmployeeDAO.deleteEmployee(id);
    }
}
