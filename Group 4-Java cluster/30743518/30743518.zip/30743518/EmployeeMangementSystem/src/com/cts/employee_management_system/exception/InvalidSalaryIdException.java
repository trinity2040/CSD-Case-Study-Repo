package com.cts.employee_management_system.exception;

public class InvalidSalaryIdException extends Exception {
    public InvalidSalaryIdException(String message) {
        super(message);
    }
}
