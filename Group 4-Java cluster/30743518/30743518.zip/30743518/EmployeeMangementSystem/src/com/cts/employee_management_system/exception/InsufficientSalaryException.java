package com.cts.employee_management_system.exception;

public class InsufficientSalaryException extends RuntimeException {

    public InsufficientSalaryException(String message) {
        super(message);
    }
}
