# Employee Management System

## Overview

This repository includes the source code and documentation for the Employee Management System—a console-based Java application for managing employee records, shifts, and salaries in a retail business environment. The application is built using Core Java, MySQL, and JDBC.

## Features

### 1. Employee Management

- Add, view, update, and delete employee records.

### 2. Shift Management

- Assign, view, update, and delete employee shifts.

### 3. Salary Management

- Set, view, update, and delete salary records.

## Project Structure

- **`InventorySystem`**: Contains the full source code of the project.
- **`InventorySystem.jar`**: Contains a pre-built version of the application for reference.
- **`src/com/cts/employee_management_system/resources/db/credentials.txt`**: File to configure your database URL, username, and password for MySQL connection (for `InventorySystem`).

- **`database_step.sql`**: Script that automatically sets up the required tables during the first run.

## Setup Instructions

### 1. Database Configuration

- Update the database credentials in `src/resources/db/credentials.txt` int the order (don't remove the comma(",")):
  - Database URL
  - Username
  - Password

### 2. Running the Application

- Open the project in IntelliJ or your preferred IDE.
- Navigate to the main file located at `EmployeeMangementSystem/`.
- Open IDE(InteliJ Prefered).
- Run the Main.java file located in "src/com/cts/employee_management_system".
- Ensure that MySQL is installed and running on your local machine.
- You can also run the "EmployeeManagementSystem.jar" file located in the artifacts folder.

## External Libraries

The project requires the following external libraries:

- **JDK**: Version 22 (recommended) or later.
- **MySQL Connector**: Version 9 (recommended).

## Notes

- The application is designed to handle exceptions gracefully and provide user-friendly error messages.
- The code adheres to standard coding conventions and is thoroughly documented for clarity.

## Submission Details

This project has been uploaded to a public GitHub repository. The repository link is provided below:

**https://github.com/RajG98/CSD-Case-Study-Repo**
