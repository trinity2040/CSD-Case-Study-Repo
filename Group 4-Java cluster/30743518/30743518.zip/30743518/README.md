# Employee Management System

## Overview

This repository includes the source code and documentation for the Employee Management System—a console-based Java application for managing employee records, shifts, and salaries in a retail business environment. The application is built using Core Java, MySQL, and JDBC.

## Features

### 1. Employee Management

- Add, view, update, and delete employee records.

### 2. Shift Management

- Assign, view, update, and delete employee shifts.

### 3. Salary Management

- Set, view, update, and delete salary records.

## Project Structure

- **`InventorySystem`**: Contains the full source code of the project.
- **`InventorySystem_jar`**: Contains a pre-built version of the application for reference (`InventorySystem.jar`).
- **`src/resources/db/credentials.txt`**: File to configure your database URL, username, and password for MySQL connection (for `InventorySystem`).
- **`resources/db/credentials.txt`**: File to configure your database URL, username, and password for MySQL connection (for `InventorySystem_jar`).
- **`database_step.sql`**: Script that automatically sets up the required tables during the first run.

## Setup Instructions

### 1. Database Configuration

- Update the database credentials in `src/resources/db/credentials.txt` (for the source code) or `resources/db/credentials.txt` (for the pre-built application):
  - Database URL
  - Username
  - Password

### 2. Running the Application

- Open the project in IntelliJ or your preferred IDE.
- Navigate to the main file located at `InventorySystem/src/Main`.
- Run the application.
- Ensure that MySQL is installed and running on your local machine.

### 3. Running the Pre-built Application

- Go to the `InventorySystem_jar` folder.
- Execute the `InventorySystem.jar` file in console using command "java -jar .\InventorySystem.jar" to run the pre-built application.

## External Libraries

The project requires the following external libraries:

- **JDK**: Version 22 (recommended) or later.
- **MySQL Connector**: Version 9 (recommended).

## Notes

- The application is designed to handle exceptions gracefully and provide user-friendly error messages.
- The code adheres to standard coding conventions and is thoroughly documented for clarity.

## Submission Details

This project has been uploaded to a public GitHub repository. The repository link is provided below:

**https://github.com/RajG98/CSD-Case-Study-Repo**
