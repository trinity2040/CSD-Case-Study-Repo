CREATE DATABASE IF NOT EXISTS EmployeeManagementDB;


USE EmployeeManagementDB;


CREATE TABLE IF NOT EXISTS Employee (
    employee_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    phone VARCHAR(10),
    position VARCHAR(50)
);


CREATE TABLE IF NOT EXISTS Shift (
    shift_id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL UNIQUE,
    shift_date DATE,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    FOREIGN KEY (employee_id) REFERENCES Employee(employee_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);


CREATE TABLE IF NOT EXISTS Salary (
    salary_id INT AUTO_INCREMENT PRIMARY KEY,
    employee_id INT NOT NULL UNIQUE,
    salary_amount DOUBLE NOT NULL,
    payment_date INT NOT NULL,
    CHECK (payment_date > 0 AND payment_date <= 31),
    FOREIGN KEY (employee_id) REFERENCES Employee(employee_id)
    ON DELETE CASCADE
    ON UPDATE CASCADE
);
