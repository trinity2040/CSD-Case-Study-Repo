package salary;


import util.DatabaseConnection;

import java.sql.*;
/*
* employee_id
* salary_amount
* payment_date
* */

public class SalaryDAO {
    public static void addSalary(Salary s){
        String sql="INSERT INTO Salary (employee_id,salary_amount,payment_date) VALUES (?,?,?);";

        try(Connection conn= DatabaseConnection.connect();

            PreparedStatement st = conn.prepareStatement(sql)){
            st.setInt(1,s.getEmployee_id());
            st.setDouble(2, s.getSalary_amount());
            st.setInt(3,s.getPayment_date());
            int result= st.executeUpdate();
            System.out.println("Rows affected: "+result);
        }catch(SQLIntegrityConstraintViolationException e){
            System.out.println("Violating Constraint: "+e.getMessage());
        }catch(SQLException ex){
            System.out.println("Invalid Sql Query");
        }
    }
    public static void viewSalary(){
        String sql="SELECT * FROM Salary;";
        try(Connection conn= DatabaseConnection.connect();
            PreparedStatement st = conn.prepareStatement(sql)){
            ResultSet rs= st.executeQuery();
            while(rs.next()){
                int salary_id=rs.getInt("salary_id");

                int emp_id=rs.getInt("employee_id");
                double salary_amount = rs.getDouble("salary_amount");
                String payment_date = rs.getString("payment_date");
                System.out.println("-----------------------");
                System.out.println("Salary Id: "+salary_id);
                System.out.println("Employee Id: "+emp_id);
                System.out.println("Salary Amount: "+salary_amount);
                System.out.println("Payment Date: "+payment_date);
                System.out.println("-----------------------");
            }
        }catch (SQLException e){
            System.out.println("Cannot fetch data");
        }
    }
    public static void updateSalary(Salary s,int id){

        String sql="UPDATE Salary SET employee_id = ?, salary_amount = ?, payment_date = ? WHERE salary_id = ?;";
        try(Connection conn = DatabaseConnection.connect();
            PreparedStatement st = conn.prepareStatement(sql)){
            st.setInt(1,s.getEmployee_id());
            st.setDouble(2,s.getSalary_amount());
            st.setInt(3,s.getPayment_date());
            st.setInt(4,id);
            int result= st.executeUpdate();
            System.out.println("Rows affected: "+result);
        }catch(SQLIntegrityConstraintViolationException e){
            System.out.println("Violating Constraint: "+e.getMessage());
        }
        catch (SQLException e){
            System.out.println("Invalid Sql Query");
        }
    }
    public static void deleteSalary(int id){
        String sql = "DELETE FROM Salary where salary_id=?;";
        try(Connection conn= DatabaseConnection.connect();
            PreparedStatement st = conn.prepareStatement(sql)){
            st.setInt(1,id);
            int result= st.executeUpdate();
            System.out.println("Rows affected: "+result);
        }catch (SQLException e){
            System.out.println("Invalid Sql Query");
        }
    }
}
