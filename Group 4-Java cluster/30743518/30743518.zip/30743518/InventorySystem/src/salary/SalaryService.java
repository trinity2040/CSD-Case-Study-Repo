package salary;


import java.util.Scanner;
/*
 * employee_id
 * salary_amount
 * payment_date
 * */

public class SalaryService {
    static Scanner sc= new Scanner(System.in);
    public static void addSalary() {
        int payment_date;
        int emp_id;
        double salary;
        System.out.print("Enter employee_id:");
        emp_id = sc.nextInt();
        System.out.print("Enter salary_amount:");
        salary = sc.nextDouble();
        System.out.print("Enter payment_date:");
        payment_date = sc.nextInt();
        sc.nextLine();
        try{
            if (emp_id == 0 || salary == 0) {
                throw new IllegalArgumentException("Employee_id or Salary cannot be zero!");

            }
            SalaryDAO.addSalary(new Salary(emp_id, salary, payment_date));
        }catch (IllegalArgumentException e){
            System.out.println(e.getMessage());
        }
    }
    public static void viewSalary(){
        SalaryDAO.viewSalary();
    }
    public static void updateSalary(){
        System.out.print("Enter salary Id for update: ");
        int id= sc.nextInt();
        int payment_date;
        int emp_id;
        double salary;
        System.out.print("Enter employee_id:");
        emp_id=sc.nextInt();
        System.out.print("Enter salary_amount:");
        salary=sc.nextDouble();
        System.out.print("Enter payment_date:");
        payment_date= sc.nextInt();
        sc.nextLine();
        try{
            if (emp_id == 0 || salary == 0) {
                throw new IllegalArgumentException("Employee_id or Salary cannot be zero!");

            }
            SalaryDAO.updateSalary(new Salary(emp_id,salary,payment_date),id);
        }catch (IllegalArgumentException e){
            System.out.println(e.getMessage());
        }
    }
    public static void deleteSalary(){
        System.out.print("Enter Salary Id to delete: ");
        int id= sc.nextInt();
        sc.nextLine();
        SalaryDAO.deleteSalary(id);
    }
}
