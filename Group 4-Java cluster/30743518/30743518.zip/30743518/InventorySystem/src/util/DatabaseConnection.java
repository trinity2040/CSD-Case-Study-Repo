package util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DatabaseConnection {
    private static String URL ;
    private static final String DB_NAME = "EmployeeManagementDB";
    private static String USER ;
    private static String PASSWORD ;
    private static final String SQL_FILEPATH = "src/resources/db/database_setup.sql";
    private static final String CRED_FILEPATH = "src/resources/db/credentials.txt";



    // JDBC driver name and database URL
    private static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    public static Connection connect(){
        Connection conn= null;
        try{
            Class.forName(JDBC_DRIVER);
            checkIfExistsElseCreateDB();
            conn= DriverManager.getConnection(URL+DB_NAME,USER,PASSWORD);
        }catch(ClassNotFoundException e){
            System.out.println("Driver Class not Found");
        }catch (SQLException e){
            System.out.println("Sql Error");
        }
        return conn;
    }
    private static void checkIfExistsElseCreateDB()  {
        Connection conn=null;
        Statement st = null;
        try{
            BufferedReader br= new BufferedReader(new FileReader(CRED_FILEPATH));
            String[] cred= br.readLine().split(",");
            URL=cred[0].trim();
            USER=cred[1].trim();
            PASSWORD=cred[2].trim();
            conn= DriverManager.getConnection(URL,USER,PASSWORD);
            st=conn.createStatement();
            String sql=getSqlQuery();
            for(String subcommand: sql.split(";")){
                if(!subcommand.trim().isEmpty()) {
                    st.execute(subcommand.trim() + ";");
                }
            }
        }catch (SQLException e){
            System.out.println("Sql Error: "+e.getMessage());
        }catch (IOException e){
            System.out.println("File not found: "+e.getMessage());
        }finally {
            // Close resources
            closeConnection(conn);
            if (st != null) {
                try {
                    st.close();
                } catch (SQLException e) {
                    System.err.println("Failed to close the statement: "+e.getMessage());
                }
            }
        }
    }
    private static String getSqlQuery() throws IOException{
        StringBuilder sb = new StringBuilder();
        BufferedReader br = new BufferedReader(new FileReader(DatabaseConnection.SQL_FILEPATH));
        String line;
        while((line=br.readLine())!=null){
            sb.append(line).append("\n");
        }
        return sb.toString();
    }
    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                System.err.println("Failed to close the connection: "+e.getMessage());
            }
        }
    }

}
