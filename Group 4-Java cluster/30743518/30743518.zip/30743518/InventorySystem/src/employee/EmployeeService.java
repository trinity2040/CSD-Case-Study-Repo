package employee;


import java.util.Scanner;

public class EmployeeService {
    static Scanner sc= new Scanner(System.in);
    public static void addEmployee(){
        String name,email,position,phone;
        System.out.print("Enter name:");
        name=sc.nextLine();
        System.out.print("Enter email:");
        email=sc.nextLine();
        System.out.print("Enter phone:");
        phone= sc.nextLine();
        System.out.print("Enter position:");
        position=sc.nextLine();
        try{
            if(name.isEmpty() || email.isEmpty()){
                throw new IllegalArgumentException("Name or Email cannot be blank!");

            }
            if(!phone.isEmpty() && phone.length()!=10){
                throw new IllegalArgumentException("Phone number should be 10 digits long");
            }
            if(!email.contains("@") || !email.contains(".")){
                throw new IllegalArgumentException("Enter valid mail");
            }
            EmployeeDAO.addEmployee(new Employee(name,email,phone,position));
        }catch (IllegalArgumentException e){
            System.out.println(e.getMessage());
        }

    }
    public static void viewEmployeeDetails(){
        EmployeeDAO.viewEmployeeDetails();
    }
    public static void updateEmployeeInfo() {
        System.out.print("Enter employee Id for update: ");
        int id = sc.nextInt();
        String name, email, phone, position;
        sc.nextLine();
        System.out.print("Enter Name: ");
        name = sc.nextLine();
        System.out.print("Enter Email: ");
        email = sc.nextLine();
        System.out.print("Enter Phone: ");
        phone = sc.nextLine();
        System.out.print("Enter Position: ");
        position = sc.nextLine();
        try{
            if (name.isEmpty() || email.isEmpty()) {
                throw new IllegalArgumentException("Name or Email cannot be blank!");

            }
            if (!phone.isEmpty() && phone.length() != 10) {
                throw new IllegalArgumentException("Phone number should be 10 digits long");
            }
            if (!email.contains("@") || !email.contains(".")) {
                throw new IllegalArgumentException("Enter valid mail");
            }
            EmployeeDAO.updateEmployeeInfo(new Employee(name,email,phone,position),id);
        }catch (IllegalArgumentException e){
            System.out.println(e.getMessage());
        }
    }
    public static void deleteEmployee(){
        System.out.print("Enter employee Id for delete: ");
        int id= sc.nextInt();
        sc.nextLine();
        EmployeeDAO.deleteEmployee(id);
    }
}
