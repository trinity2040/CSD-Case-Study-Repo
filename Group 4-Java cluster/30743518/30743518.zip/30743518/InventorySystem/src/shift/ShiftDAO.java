package shift;

import util.DatabaseConnection;

import java.sql.*;
/*
    employee_id
    shift_date
    start_time
    end_date
 */
public class ShiftDAO {
    public static void addShift(Shift s){
        String sql="INSERT INTO Shift (employee_id,shift_date,start_time,end_time) VALUES (?,?,?,?);";

        try(Connection conn= DatabaseConnection.connect();

            PreparedStatement st = conn.prepareStatement(sql)){
            st.setInt(1,s.getEmployee_id());
            st.setDate(2, s.getShift_date());
            st.setTime(3,s.getStart_time());
            st.setTime(4,s.getEnd_time());
            int result= st.executeUpdate();
            System.out.println("Rows affected: "+result);
        }catch(SQLIntegrityConstraintViolationException e){
            System.out.println("Violating Constraint: "+e.getMessage());
        }catch(SQLException ex){
            System.out.println("Invalid Sql Query");
        }
    }
    public static void getShiftDetails(){
        String sql="SELECT * FROM Shift;";
        try(Connection conn= DatabaseConnection.connect();
            PreparedStatement st = conn.prepareStatement(sql)){
            ResultSet rs= st.executeQuery();
            while(rs.next()){
                int shift_id=rs.getInt("shift_id");

                int emp_id=rs.getInt("employee_id");
                String shift_date = rs.getString("shift_date");
                String start_time = rs.getString("start_time");
                String end_time = rs.getString("end_time");

                System.out.println("-----------------------");
                System.out.println("Shift Id: "+shift_id);
                System.out.println("Employee Id: "+emp_id);
                System.out.println("Shift Date: "+(shift_date==null?"":shift_date));
                System.out.println("Start Time: "+start_time);
                System.out.println("End Time: "+end_time);

                System.out.println("-----------------------");
            }
        }catch (SQLException e){
            System.out.println("Cannot fetch data");
        }
    }
    public static void updateShift(Shift s, int id){

        String sql="UPDATE Shift SET employee_id = ?, shift_date = ?, start_time = ?, end_time=? WHERE shift_id = ?;";
        try(Connection conn = DatabaseConnection.connect();
            PreparedStatement st = conn.prepareStatement(sql)){
            st.setInt(1,s.getEmployee_id());
            st.setDate(2, s.getShift_date());
            st.setTime(3,s.getStart_time());
            st.setTime(4,s.getEnd_time());
            st.setInt(5,id);
            int result= st.executeUpdate();
            System.out.println("Rows affected: "+result);
        }catch(SQLIntegrityConstraintViolationException e){
            System.out.println("Violating Constraint: "+e.getMessage());
        }
        catch (SQLException e){
            System.out.println("Invalid Sql Query");
        }
    }
    public static void deleteShift(int id){
        String sql = "DELETE FROM Shift where shift_id=?;";
        try(Connection conn= DatabaseConnection.connect();
            PreparedStatement st = conn.prepareStatement(sql)){
            st.setInt(1,id);
            int result= st.executeUpdate();
            System.out.println("Rows affected: "+result);
        }catch (SQLException e){
            System.out.println("Invalid Sql Query: "+e.getMessage());
        }
    }
}
