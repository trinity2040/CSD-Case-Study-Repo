package shift;

import java.sql.Date;
import java.sql.Time;

public class Shift {

    private final int employee_id;
    private final Date shift_date;
    private final Time start_time;
    private final Time end_time;


    public int getEmployee_id() {
        return employee_id;
    }

    public Date getShift_date() {
        return shift_date;
    }

    public Time getStart_time() {
        return start_time;
    }

    public Time getEnd_time() {
        return end_time;
    }


    public Shift(int employee_id, Date shift_date, Time start_time, Time end_time) {
        this.employee_id = employee_id;
        this.shift_date = shift_date;
        this.start_time = start_time;
        this.end_time = end_time;
    }
}
