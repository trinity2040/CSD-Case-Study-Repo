package shift;


import java.sql.Time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.sql.Date;
import java.util.Scanner;
/*
    employee_id
    shift_date
    start_time
    end_date
 */
public class ShiftService {
    static Scanner sc= new Scanner(System.in);
    public static void addShift(){
        int employee_id;
        String shift_date,start_time,end_time;
        System.out.print("Enter employee_id:");
        employee_id=sc.nextInt();
        sc.nextLine();
        System.out.print("Enter shift_date in format (dd-MM-yyyy):");
        shift_date=sc.nextLine();
        System.out.print("Enter start_time in 24 hrs format (HH:mm):");
        start_time= sc.nextLine();
        System.out.print("Enter end_time in 24 hrs format (HH:mm):");
        end_time= sc.nextLine();

        DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("HH:mm");
        SimpleDateFormat formatter2 = new SimpleDateFormat("dd-MM-yyyy");

        try{
            Time startTime= Time.valueOf(LocalTime.parse(start_time,formatter1));
            Time endTime= Time.valueOf(LocalTime.parse(end_time,formatter1));
            Date shiftDate=!shift_date.isEmpty()?new Date(formatter2.parse(shift_date).getTime()):null;
            if(startTime.compareTo(endTime)>=0)
                throw new IllegalArgumentException("Start Time should be before end time");
            ShiftDAO.addShift(new Shift(employee_id,shiftDate,startTime,endTime));

        }catch (IllegalArgumentException e){
            System.out.println(e.getMessage());
        }
        catch(DateTimeParseException e){
            System.out.println("Incorrect Time Format");
        }
        catch (ParseException e){
            System.out.println("Incorrect Date Format");
        }
    }
    public static void getShiftDetails(){
        ShiftDAO.getShiftDetails();
    }
    public static void updateShift(){
        System.out.print("Enter Shift Id for update: ");
        int id= sc.nextInt();
        int employee_id;
        String shift_date,start_time,end_time;
        System.out.print("Enter employee_id:");
        employee_id=sc.nextInt();
        sc.nextLine();
        System.out.print("Enter shift_date in format (dd-MM-yyyy):");
        shift_date=sc.nextLine();
        System.out.print("Enter start_time in 24 hrs format (HH:mm):");
        start_time= sc.nextLine();
        System.out.print("Enter end_time in 24 hrs format (HH:mm):");
        end_time= sc.nextLine();
        DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("HH:mm");
        SimpleDateFormat formatter2 = new SimpleDateFormat("dd-MM-yyyy");

        try{
            Time startTime= Time.valueOf(LocalTime.parse(start_time,formatter1));
            Time endTime= Time.valueOf(LocalTime.parse(end_time,formatter1));
            if(startTime.compareTo(endTime)>=0)
                throw new IllegalArgumentException("Start Time should be before end time");
            Date shiftDate=!shift_date.isEmpty()?new Date(formatter2.parse(shift_date).getTime()):null;
            ShiftDAO.updateShift(new Shift(employee_id,shiftDate,startTime,endTime),id);

        }catch (IllegalArgumentException e){
            System.out.println(e.getMessage());
        }
        catch(DateTimeParseException e){
            System.out.println("Incorrect Time Format");
        }
        catch (ParseException e){
            System.out.println("Incorrect Date Format");
        }
    }
    public static void deleteShift(){
        System.out.print("Enter Shift Id to delete: ");
        int id= sc.nextInt();
        sc.nextLine();
        ShiftDAO.deleteShift(id);
    }
}
