Setup Instructions

1. Clone the Repository
2. Set up the Database
	i.Open the insurance_management_system.sql file located in the project directory.

	ii.Execute the SQL script to create the insurancedb database and the required tables.
3. Configure the Database
	i.Open the DatabaseUtility.java file located in the src directory.
	ii.Update the database connection details:

private static final String URL = "jdbc:mysql://localhost:3306/insurancedb";
private static final String USER = "root";       // Your MySQL username
private static final String PASSWORD = "password"; // Your MySQL password

4. Compile and Run the Application
Using IntelliJ IDEA:
	i.Open the project in IntelliJ IDEA.
	ii.Navigate to InsuranceApp.java and run the application.
Using Command Line:
	i.Navigate to the src directory:
	cd src
	ii.Compile the project:
	javac *.java
	iii.Run the java
	java Main




Usage
Once the application is running, a menu will be displayed with options for managing policies, customers, and claims. Use the numeric keys to select an option, and follow the prompts to perform operations.

Example Operations:
Add a New Policy:

Select 1 for Policy Management.
Follow the prompts to enter policy details.
Register a New Customer:

Select 2 for Customer Management.
Follow the prompts to enter customer details.
Submit a New Claim:

Select 3 for Claim Management.
Follow the prompts to enter claim details.
Exit:

Select 4 to exit the application.
Exception Handling
The application includes basic exception handling to ensure smooth operation. Error messages are displayed for common issues such as database connection failures or invalid input.