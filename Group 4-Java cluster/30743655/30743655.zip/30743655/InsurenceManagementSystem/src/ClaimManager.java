import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ClaimManager {

    public void submitClaim(int policyId, int customerId, Date claimDate) {
        String query = "INSERT INTO Claim (policy_id, customer_id, claim_date) VALUES (?, ?, ?)";
        try (Connection conn = DatabaseUtility.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, policyId);
            stmt.setInt(2, customerId);
            stmt.setDate(3, claimDate);
            stmt.executeUpdate();
            System.out.println("Claim submitted successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewClaim(int claimId) {
        String query = "SELECT * FROM Claim WHERE claim_id = ?";
        try (Connection conn = DatabaseUtility.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, claimId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Claim ID: " + rs.getInt("claim_id"));
                System.out.println("Policy ID: " + rs.getInt("policy_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Claim Date: " + rs.getDate("claim_date"));
                System.out.println("Status: " + rs.getString("status"));
            } else {
                System.out.println("Claim not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updateClaim(int claimId, int policyId, int customerId, Date claimDate, String status) {
        String query = "UPDATE Claim SET policy_id = ?, customer_id = ?, claim_date = ?, status = ? WHERE claim_id = ?";
        try (Connection conn = DatabaseUtility.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, policyId);
            stmt.setInt(2, customerId);
            stmt.setDate(3, claimDate);
            stmt.setString(4, status);
            stmt.setInt(5, claimId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Claim information updated successfully!");
            } else {
                System.out.println("Claim not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteClaim(int claimId) {
        String query = "DELETE FROM Claim WHERE claim_id = ?";
        try (Connection conn = DatabaseUtility.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, claimId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Claim deleted successfully!");
            } else {
                System.out.println("Claim not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
