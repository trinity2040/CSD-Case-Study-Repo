import java.util.Scanner;
import java.sql.Date;//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        PolicyManager policyManager = new PolicyManager();
        CustomerManager customerManager = new CustomerManager();
        ClaimManager claimManager = new ClaimManager();

        while (true) {
            System.out.println("1. Policy Management");
            System.out.println("2. Customer Management");
            System.out.println("3. Claim Management");
            System.out.println("4. Exit");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    // Policy management operations
                    System.out.println("1. Add a new policy");
                    System.out.println("2. View policy details");
                    System.out.println("3. Update policy information");
                    System.out.println("4. Delete a policy");
                    System.out.println("5. Exit");
                    int choice1 = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    switch (choice1) {
                        case 1:
                            System.out.println("Enter Policy Number:");
                            String policyNumber = scanner.nextLine();
                            System.out.println("Enter Policy Type:");
                            String type = scanner.nextLine();
                            System.out.println("Enter Coverage Amount:");
                            double coverageAmount = scanner.nextDouble();
                            System.out.println("Enter Premium Amount:");
                            double premiumAmount = scanner.nextDouble();
                            policyManager.addPolicy(policyNumber, type, coverageAmount, premiumAmount);
                            break;
                        case 2:
                            System.out.println("Enter Policy ID:");
                            int policyId = scanner.nextInt();
                            policyManager.viewPolicy(policyId);
                            break;
                        case 3:
                            System.out.println("Enter Policy ID:");
                            int policyIdUpdate = scanner.nextInt();
                            scanner.nextLine(); // Consume newline
                            System.out.println("Enter New Policy Number:");
                            String newPolicyNumber = scanner.nextLine();
                            System.out.println("Enter New Policy Type:");
                            String newType = scanner.nextLine();
                            System.out.println("Enter New Coverage Amount:");
                            double newCoverageAmount = scanner.nextDouble();
                            System.out.println("Enter New Premium Amount:");
                            double newPremiumAmount = scanner.nextDouble();
                            policyManager.updatePolicy(policyIdUpdate, newPolicyNumber, newType, newCoverageAmount, newPremiumAmount);
                            break;
                        case 4:
                            System.out.println("Enter Policy ID:");
                            int policyIdDelete = scanner.nextInt();
                            policyManager.deletePolicy(policyIdDelete);
                            break;
                        case 5:
                            System.exit(0);
                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }
                    break;
                case 2:
                    // Customer management operations
                    System.out.println("1. Register a new customer");
                    System.out.println("2. View customer details");
                    System.out.println("3. Update customer information");
                    System.out.println("4. Delete a customer");
                    System.out.println("5. Exit");
                    int choice2 = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    switch (choice2) {
                        case 1:
                            System.out.println("Enter Name:");
                            String name = scanner.nextLine();
                            System.out.println("Enter Email:");
                            String email = scanner.nextLine();
                            System.out.println("Enter Phone Number:");
                            String phoneNumber = scanner.nextLine();
                            System.out.println("Enter Address:");
                            String address = scanner.nextLine();
                            customerManager.registerCustomer(name, email, phoneNumber, address);
                            break;
                        case 2:
                            System.out.println("Enter Customer ID:");
                            int customerId = scanner.nextInt();
                            customerManager.viewCustomer(customerId);
                            break;
                        case 3:
                            System.out.println("Enter Customer ID:");
                            int customerIdUpdate = scanner.nextInt();
                            scanner.nextLine(); // Consume newline
                            System.out.println("Enter New Name:");
                            String newName = scanner.nextLine();
                            System.out.println("Enter New Email:");
                            String newEmail = scanner.nextLine();
                            System.out.println("Enter New Phone Number:");
                            String newPhoneNumber = scanner.nextLine();
                            System.out.println("Enter New Address:");
                            String newAddress = scanner.nextLine();
                            customerManager.updateCustomer(customerIdUpdate, newName, newEmail, newPhoneNumber, newAddress);
                            break;
                        case 4:
                            System.out.println("Enter Customer ID:");
                            int customerIdDelete = scanner.nextInt();
                            customerManager.deleteCustomer(customerIdDelete);
                            break;
                        case 5:
                            System.exit(0);
                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }
                    break;
                case 3:
                    // Claim management operations
                    System.out.println("1. Submit a new claim");
                    System.out.println("2. View claim details");
                    System.out.println("3. Update claim information");
                    System.out.println("4. Delete a claim");
                    System.out.println("5. Exit");
                    int choice3 = scanner.nextInt();
                    scanner.nextLine(); // Consume newline

                    switch (choice3) {
                        case 1:
                            System.out.println("Enter Policy ID:");
                            int policyId = scanner.nextInt();
                            System.out.println("Enter Customer ID:");
                            int customerId = scanner.nextInt();
                            System.out.println("Enter Claim Date (YYYY-MM-DD):");
                            String claimDateStr = scanner.next();
                            Date claimDate = Date.valueOf(claimDateStr);
                            claimManager.submitClaim(policyId, customerId, claimDate);
                            break;
                        case 2:
                            System.out.println("Enter Claim ID:");
                            int claimId = scanner.nextInt();
                            claimManager.viewClaim(claimId);
                            break;
                        case 3:
                            System.out.println("Enter Claim ID:");
                            int claimIdUpdate = scanner.nextInt();
                            System.out.println("Enter New Policy ID:");
                            int newPolicyId = scanner.nextInt();
                            System.out.println("Enter New Customer ID:");
                            int newCustomerId = scanner.nextInt();
                            System.out.println("Enter New Claim Date (YYYY-MM-DD):");
                            String newClaimDateStr = scanner.next();
                            Date newClaimDate = Date.valueOf(newClaimDateStr);
                            System.out.println("Enter New Status (submitted/processed):");
                            String newStatus = scanner.next();
                            claimManager.updateClaim(claimIdUpdate, newPolicyId, newCustomerId, newClaimDate, newStatus);
                            break;
                        case 4:
                            System.out.println("Enter Claim ID:");
                            int claimIdDelete = scanner.nextInt();
                            claimManager.deleteClaim(claimIdDelete);
                            break;
                        case 5:
                            System.exit(0);
                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }
                    break;
                case 4:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}