import java.sql.*;

public class PolicyManager {
    public void addPolicy(String policyNumber, String type, double coverageAmount, double premiumAmount) {
        String query = "INSERT INTO Policy (policy_number, type, coverage_amount, premium_amount) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseUtility.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, policyNumber);
            stmt.setString(2, type);
            stmt.setDouble(3, coverageAmount);
            stmt.setDouble(4, premiumAmount);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void viewPolicy(int policyId) {
        String query = "SELECT * FROM Policy WHERE policy_id = ?";
        try (Connection conn = DatabaseUtility.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, policyId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Policy ID: " + rs.getInt("policy_id"));
                System.out.println("Policy Number: " + rs.getString("policy_number"));
                System.out.println("Type: " + rs.getString("type"));
                System.out.println("Coverage Amount: " + rs.getDouble("coverage_amount"));
                System.out.println("Premium Amount: " + rs.getDouble("premium_amount"));
            } else {
                System.out.println("Policy not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void updatePolicy(int policyId, String policyNumber, String type, double coverageAmount, double premiumAmount) {
        String query = "UPDATE Policy SET policy_number = ?, type = ?, coverage_amount = ?, premium_amount = ? WHERE policy_id = ?";
        try (Connection conn = DatabaseUtility.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, policyNumber);
            stmt.setString(2, type);
            stmt.setDouble(3, coverageAmount);
            stmt.setDouble(4, premiumAmount);
            stmt.setInt(5, policyId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Policy updated successfully!");
            } else {
                System.out.println("Policy not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletePolicy(int policyId) {
        String query = "DELETE FROM Policy WHERE policy_id = ?";
        try (Connection conn = DatabaseUtility.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, policyId);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Policy deleted successfully!");
            } else {
                System.out.println("Policy not found!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    // Add similar methods for view, update, and delete
}
