
-- Create the database
create database insurancedb;

-- use the database
use insurancedb

-- create policy table

CREATE TABLE Policy (
    policy_id INT AUTO_INCREMENT PRIMARY KEY,
    policy_number VARCHAR(255) NOT NULL,
    type VARCHAR(255) NOT NULL,
    coverage_amount DECIMAL(10, 2) NOT NULL,
    premium_amount DECIMAL(10, 2) NOT NULL
);


-- create customer table

CREATE TABLE Customer (
    customer_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    phone_number VARCHAR(20),
    address TEXT
);


-- create claim table

CREATE TABLE Claim (
    claim_id INT AUTO_INCREMENT PRIMARY KEY,
    policy_id INT,
    customer_id INT,
    claim_date DATE NOT NULL,
    status ENUM('submitted', 'processed') DEFAULT 'submitted',
    FOREIGN KEY (policy_id) REFERENCES Policy(policy_id),
    FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
);
