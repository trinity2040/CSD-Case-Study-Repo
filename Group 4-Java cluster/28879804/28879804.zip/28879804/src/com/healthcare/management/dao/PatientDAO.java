
package com.healthcare.management.dao;

import com.healthcare.management.model.Patient;
import com.healthcare.management.util.DBConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PatientDAO {

    public void registerPatient(Patient patient) {
        try (Connection connection = DBConnectionUtil.getConnection()) {
            String query = "INSERT INTO patients (name, date_of_birth, gender, address) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setString(1, patient.getName());
            pstmt.setString(2, patient.getDateOfBirth());
            pstmt.setString(3, patient.getGender());
            pstmt.setString(4, patient.getAddress());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Patient viewPatientDetails(int patientId) {
        Patient patient = null;
        try (Connection connection = DBConnectionUtil.getConnection()) {
            String query = "SELECT * FROM patients WHERE patient_id = ?";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setInt(1, patientId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                patient = new Patient();
                patient.setPatientId(rs.getInt("patient_id"));
                patient.setName(rs.getString("name"));
                patient.setDateOfBirth(rs.getString("date_of_birth"));
                patient.setGender(rs.getString("gender"));
                patient.setAddress(rs.getString("address"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return patient;
    }

    public void updatePatientInfo(Patient patient) {
        try (Connection connection = DBConnectionUtil.getConnection()) {
            String query = "UPDATE patients SET name = ?, date_of_birth = ?, gender = ?, address = ? WHERE patient_id = ?";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setString(1, patient.getName());
            pstmt.setString(2, patient.getDateOfBirth());
            pstmt.setString(3, patient.getGender());
            pstmt.setString(4, patient.getAddress());
            pstmt.setInt(5, patient.getPatientId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deletePatient(int patientId) {
        try (Connection connection = DBConnectionUtil.getConnection()) {
            String query = "DELETE FROM patients WHERE patient_id = ?";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setInt(1, patientId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
 }
}
}
