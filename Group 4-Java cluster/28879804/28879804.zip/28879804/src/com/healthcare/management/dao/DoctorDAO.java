
package com.healthcare.management.dao;

import com.healthcare.management.model.Doctor;
import com.healthcare.management.util.DBConnectionUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DoctorDAO {

    public void addDoctor(Doctor doctor) {
        try (Connection connection = DBConnectionUtil.getConnection()) {
            String query = "INSERT INTO doctors (name, specialization, contact_number, email) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setString(1, doctor.getName());
            pstmt.setString(2, doctor.getSpecialization());
            pstmt.setString(3, doctor.getContactNumber());
            pstmt.setString(4, doctor.getEmail());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Doctor viewDoctorDetails(int doctorId) {
        Doctor doctor = null;
        try (Connection connection = DBConnectionUtil.getConnection()) {
            String query = "SELECT * FROM doctors WHERE doctor_id = ?";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setInt(1, doctorId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                doctor = new Doctor();
                doctor.setDoctorId(rs.getInt("doctor_id"));
                doctor.setName(rs.getString("name"));
                doctor.setSpecialization(rs.getString("specialization"));
                doctor.setContactNumber(rs.getString("contact_number"));
                doctor.setEmail(rs.getString("email"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return doctor;
    }

    public void updateDoctorInfo(Doctor doctor) {
        try (Connection connection = DBConnectionUtil.getConnection()) {
            String query = "UPDATE doctors SET name = ?, specialization = ?, contact_number = ?, email = ? WHERE doctor_id = ?";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setString(1, doctor.getName());
            pstmt.setString(2, doctor.getSpecialization());
            pstmt.setString(3, doctor.getContactNumber());
            pstmt.setString(4, doctor.getEmail());
            pstmt.setInt(5, doctor.getDoctorId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteDoctor(int doctorId) {
        try (Connection connection = DBConnectionUtil.getConnection()) {
            String query = "DELETE FROM doctors WHERE doctor_id = ?";
            PreparedStatement pstmt = connection.prepareStatement(query);
            pstmt.setInt(1, doctorId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
 }
}
}