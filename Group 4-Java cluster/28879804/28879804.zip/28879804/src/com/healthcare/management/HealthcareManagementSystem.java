
package com.healthcare.management;

import com.healthcare.management.dao.AppointmentDAO;
import com.healthcare.management.dao.DoctorDAO;
import com.healthcare.management.dao.PatientDAO;
import com.healthcare.management.exception.DatabaseConnectionException;
import com.healthcare.management.exception.PatientNotFoundException;
import com.healthcare.management.model.Appointment;
import com.healthcare.management.model.Doctor;
import com.healthcare.management.model.Patient;

import java.util.Scanner;

public class HealthcareManagementSystem {

    public static void main(String[] args) throws DatabaseConnectionException, PatientNotFoundException {
        Scanner scanner = new Scanner(System.in);
        PatientDAO patientDAO = new PatientDAO();
        DoctorDAO doctorDAO = new DoctorDAO();
        AppointmentDAO appointmentDAO = new AppointmentDAO();

        while (true) {
            System.out.println("\nHealthcare Management System");
            System.out.println("1. Manage Patients");
            System.out.println("2. Manage Doctors");
            System.out.println("3. Manage Appointments");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    managePatients(scanner, patientDAO);
                    break;
                case 2:
                    manageDoctors(scanner, doctorDAO);
                    break;
                case 3:
                    manageAppointments(scanner, appointmentDAO);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void managePatients(Scanner scanner, PatientDAO patientDAO) throws DatabaseConnectionException, PatientNotFoundException {
        System.out.println("\nManage Patients");
        System.out.println("1. Register Patient");
        System.out.println("2. View Patient Details");
        System.out.println("3. Update Patient Information");
        System.out.println("4. Delete Patient");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                Patient newPatient = new Patient();
                System.out.print("Enter name: ");
                newPatient.setName(scanner.next());
                System.out.print("Enter date of birth (YYYY-MM-DD): ");
                newPatient.setDateOfBirth(scanner.next());
                System.out.print("Enter gender: ");
                newPatient.setGender(scanner.next());
                System.out.print("Enter address: ");
                newPatient.setAddress(scanner.next());

                patientDAO.registerPatient(newPatient);
                System.out.println("Patient registered successfully.");
                break;

            case 2:
                System.out.print("Enter patient ID: ");
                int patientId = scanner.nextInt();
                Patient patient = patientDAO.viewPatientDetails(patientId);
                if (patient != null) {
                    System.out.println("Patient ID: " + patient.getPatientId());
                    System.out.println("Name: " + patient.getName());
                    System.out.println("Date of Birth: " + patient.getDateOfBirth());
                    System.out.println("Gender: " + patient.getGender());
                    System.out.println("Address: " + patient.getAddress());
                } else {
                    System.out.println("Patient not found.");
                }
                break;

            case 3:
                Patient updatePatient = new Patient();
                System.out.print("Enter patient ID: ");
                updatePatient.setPatientId(scanner.nextInt());
                System.out.print("Enter new name: ");
                updatePatient.setName(scanner.next());
                System.out.print("Enter new date of birth (YYYY-MM-DD): ");
                updatePatient.setDateOfBirth(scanner.next());
                System.out.print("Enter new gender: ");
                updatePatient.setGender(scanner.next());
                System.out.print("Enter new address: ");
                updatePatient.setAddress(scanner.next());

                patientDAO.updatePatientInfo(updatePatient);
                System.out.println("Patient information updated successfully.");
                break;

            case 4:
                System.out.print("Enter patient ID to delete: ");
                int deletePatientId = scanner.nextInt();
                patientDAO.deletePatient(deletePatientId);
                System.out.println("Patient deleted successfully.");
                break;

            default:
                System.out.println("Invalid choice. Try again.");
        }
    }

    private static void manageDoctors(Scanner scanner, DoctorDAO doctorDAO) {
        System.out.println("\nManage Doctors");
        System.out.println("1. Add Doctor");
        System.out.println("2. View Doctor Details");
        System.out.println("3. Update Doctor Information");
        System.out.println("4. Delete Doctor");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                Doctor newDoctor = new Doctor();
                System.out.print("Enter name: ");
                newDoctor.setName(scanner.next());
                System.out.print("Enter specialization: ");
                newDoctor.setSpecialization(scanner.next());
                System.out.print("Enter contact number: ");
                newDoctor.setContactNumber(scanner.next());
                System.out.print("Enter email: ");
                newDoctor.setEmail(scanner.next());

                doctorDAO.addDoctor(newDoctor);
                System.out.println("Doctor added successfully.");
                break;

            case 2:
                System.out.print("Enter doctor ID: ");
                int doctorId = scanner.nextInt();
                Doctor doctor = doctorDAO.viewDoctorDetails(doctorId);
                if (doctor != null) {
                    System.out.println("Doctor ID: " + doctor.getDoctorId());
                    System.out.println("Name: " + doctor.getName());
                    System.out.println("Specialization: " + doctor.getSpecialization());
                    System.out.println("Contact Number: " + doctor.getContactNumber());
                    System.out.println("Email: " + doctor.getEmail());
                } else {
                    System.out.println("Doctor not found.");
                }
                break;

            case 3:
                Doctor updateDoctor = new Doctor();
                System.out.print("Enter doctor ID: ");
                updateDoctor.setDoctorId(scanner.nextInt());
                System.out.print("Enter new name: ");
                updateDoctor.setName(scanner.next());
                System.out.print("Enter new specialization: ");
                updateDoctor.setSpecialization(scanner.next());
                System.out.print("Enter new contact number: ");
                updateDoctor.setContactNumber(scanner.next());
                System.out.print("Enter new email: ");
                updateDoctor.setEmail(scanner.next());

                doctorDAO.updateDoctorInfo(updateDoctor);
                System.out.println("Doctor information updated successfully.");
                break;

            case 4:
                System.out.print("Enter doctor ID to delete: ");
                int deleteDoctorId = scanner.nextInt();
                doctorDAO.deleteDoctor(deleteDoctorId);
                System.out.println("Doctor deleted successfully.");
                break;

            default:
                System.out.println("Invalid choice. Try again.");
        }
    }

    private static void manageAppointments(Scanner scanner, AppointmentDAO appointmentDAO) {
        System.out.println("\nManage Appointments");
        System.out.println("1. Schedule Appointment");
        System.out.println("2. View Appointment Details");
        System.out.println("3. Update Appointment Information");
        System.out.println("4. Cancel Appointment");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                Appointment newAppointment = new Appointment();
                System.out.print("Enter patient ID: ");
                newAppointment.setPatientId(scanner.nextInt());
                System.out.print("Enter doctor ID: ");
                newAppointment.setDoctorId(scanner.nextInt());
                System.out.print("Enter appointment date (YYYY-MM-DD): ");
                newAppointment.setAppointmentDate(scanner.next());
                System.out.print("Enter appointment time (HH:MM:SS): ");
                newAppointment.setAppointmentTime(scanner.next());

                appointmentDAO.scheduleAppointment(newAppointment);
                System.out.println("Appointment scheduled successfully.");
                break;

            case 2:
                System.out.print("Enter appointment ID: ");
                int appointmentId = scanner.nextInt();
                Appointment appointment = appointmentDAO.viewAppointmentDetails(appointmentId);
                if (appointment != null) {
                    System.out.println("Appointment ID: " + appointment.getAppointmentId());
                    System.out.println("Patient ID: " + appointment.getPatientId());
                    System.out.println("Doctor ID: " + appointment.getDoctorId());
                    System.out.println("Appointment Date: " + appointment.getAppointmentDate());
                    System.out.println("Appointment Time: " + appointment.getAppointmentTime());
                    System.out.println("Status: " + appointment.getStatus());
                } else {
                    System.out.println("Appointment not found.");
                }
                break;

            case 3:
                Appointment updateAppointment = new Appointment();
                System.out.print("Enter appointment ID: ");
                updateAppointment.setAppointmentId(scanner.nextInt());
                System.out.print("Enter new patient ID: ");
                updateAppointment.setPatientId(scanner.nextInt());
                System.out.print("Enter new doctor ID: ");
                updateAppointment.setDoctorId(scanner.nextInt());
                System.out.print("Enter new appointment date (YYYY-MM-DD): ");
                updateAppointment.setAppointmentDate(scanner.next());
                System.out.print("Enter new appointment time (HH:MM:SS): ");
                updateAppointment.setAppointmentTime(scanner.next());
                System.out.print("Enter new status: ");
                updateAppointment.setStatus(scanner.next());

                appointmentDAO.updateAppointmentInfo(updateAppointment);
                System.out.println("Appointment information updated successfully.");
                break;

            case 4:
                System.out.print("Enter appointment ID to cancel: ");
                int cancelAppointmentId = scanner.nextInt();
                appointmentDAO.cancelAppointment(cancelAppointmentId);
                System.out.println("Appointment canceled successfully.");
                break;

            default:
                System.out.println("Invalid choice. Try again.");
 }
}
}