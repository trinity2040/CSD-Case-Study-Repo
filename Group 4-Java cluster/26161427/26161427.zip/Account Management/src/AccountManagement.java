import java.sql.*;
import java.util.Scanner;

public class AccountManagement {
    private static final String url = "jdbc:mysql://localhost:3306/banking_system";
    private static final String username = "root";
    private static final String password = "suraj";

    public static void main(String[] args){
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println(e.getMessage());
        }

        try {
            Connection connection = DriverManager.getConnection(url, username, password);

            while (true) {
                System.out.println();
                System.out.println("=== Account Management ===");
                Scanner scanner = new Scanner(System.in);
                System.out.println("1. Create Account");
                System.out.println("2. View Account");
                System.out.println("3. Update Account");
                System.out.println("4. Close Account");
                System.out.println("5. Deposit Funds");
                System.out.println("6. Withdraw Funds");
                System.out.println("7. Transfer Funds");
                System.out.println("8. Show Transaction History");
                System.out.println("9. Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        createAccount(connection, scanner);
                        break;
                    case 2:
                        viewAccount(connection, scanner);
                        break;
                    case 3:
                        updateAccount(connection, scanner);
                        break;
                    case 4:
                        closeAccount(connection, scanner);
                        break;
                    case 5:
                        depositFunds(connection, scanner);
                        break;
                    case 6:
                        withdrawFunds(connection, scanner);
                        break;
                    case 7:
                        transferFunds(connection, scanner);
                        break;
                    case 8:
                        showTransactionHistory(connection, scanner);
                        break;
                    case 9:
                        exit();
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } catch (InterruptedException e) {
            System.out.println(e.getMessage());
        }
    }

    private static void createAccount(Connection connection, Scanner scanner) {
        try {
            System.out.println("Enter Account holder name: ");
            String name = scanner.next();
            scanner.nextLine();
            System.out.println("Enter Initial Deposit: ");
            double balance = scanner.nextDouble();

            String sql = "insert into account (account_holder_name, balance) values (?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, name);
            statement.setDouble(2, balance);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                ResultSet generatedKeys = statement.getGeneratedKeys();
                if (generatedKeys.next()) {
                    int accountId = generatedKeys.getInt(1);
                    recordTransaction(connection, accountId, "Initial Deposit", balance);
                    System.out.println("Account created successfully!");
                }
            }

        } catch (SQLException e) {
            System.out.println("Error creating account: " + e.getMessage());
        }
    }

    private static void viewAccount(Connection connection, Scanner scanner) {
        try {
            System.out.println("Enter Account ID to view: ");
            int accountId = scanner.nextInt();

            String sql = "select * from account where account_number = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, accountId);

            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                System.out.println("+----------------+---------------------+--------------+");
                System.out.println("| Account ID     | Account Holder Name | Balance      |");
                System.out.println("+----------------+---------------------+--------------+");
                System.out.printf("| %-14d | %-19s | %-12.2f |\n",
                        resultSet.getInt("account_number"),
                        resultSet.getString("account_holder_name"),
                        resultSet.getDouble("balance"));
                System.out.println("+----------------+---------------------+--------------+");
            } else {
                System.out.println("Account not found.");
            }

        } catch (SQLException e) {
            System.out.println("Error viewing account: " + e.getMessage());
        }
    }

    private static void updateAccount(Connection connection, Scanner scanner) {
        try {
            System.out.println("Enter Account ID to update: ");
            int accountId = scanner.nextInt();
            scanner.nextLine(); 
            System.out.println("Enter new Account holder name: ");
            String newName = scanner.nextLine();

            String sql = "UPDATE account SET account_holder_name = ? WHERE account_number = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, newName);
            statement.setInt(2, accountId);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Account updated successfully!");
            } else {
                System.out.println("Account not found.");
            }

        } catch (SQLException e) {
            System.out.println("Error updating account: " + e.getMessage());
        }
    }

    private static void closeAccount(Connection connection, Scanner scanner) {
        try {
            System.out.println("Enter Account ID to close: ");
            int accountId = scanner.nextInt();

            String sql = "DELETE FROM account WHERE account_number = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, accountId);

            int rowsDeleted = statement.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Account closed successfully!");
            } else {
                System.out.println("Account not found.");
            }

        } catch (SQLException e) {
            System.out.println("Error closing account: " + e.getMessage());
        }
    }

    private static void depositFunds(Connection connection, Scanner scanner) {
        try {
            System.out.println("Enter Account ID to deposit to: ");
            int accountId = scanner.nextInt();
            System.out.println("Enter amount to deposit: ");
            double amount = scanner.nextDouble();

            String sql = "update account set balance = balance + ? where account_number = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setDouble(1, amount);
            statement.setInt(2, accountId);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                recordTransaction(connection, accountId, "Deposit", amount);
                System.out.println("Funds deposited successfully!");
            } else {
                System.out.println("Account not found.");
            }

        } catch (SQLException e) {
            System.out.println("Error depositing funds: " + e.getMessage());
        }
    }

    private static void withdrawFunds(Connection connection, Scanner scanner) {
        try {
            System.out.println("Enter Account ID to withdraw from: ");
            int accountId = scanner.nextInt();
            System.out.println("Enter amount to withdraw: ");
            double amount = scanner.nextDouble();

            String sql = "update account set balance = balance - ? where account_number = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setDouble(1, amount);
            statement.setInt(2, accountId);

            int rowsUpdated = statement.executeUpdate();
            if (rowsUpdated > 0) {
                recordTransaction(connection, accountId, "Withdrawal", amount);
                System.out.println("Funds withdrawn successfully!");
            } else {
                System.out.println("Account not found or insufficient funds.");
            }

        } catch (SQLException e) {
            System.out.println("Error withdrawing funds: " + e.getMessage());
        }
    }

    private static void transferFunds(Connection connection, Scanner scanner) {
        try {
            System.out.println("Enter source Account ID: ");
            int sourceAccountId = scanner.nextInt();
            System.out.println("Enter target Account ID: ");
            int targetAccountId = scanner.nextInt();
            System.out.println("Enter amount to transfer: ");
            double amount = scanner.nextDouble();

            connection.setAutoCommit(false);

            try {
                String withdrawSQL = "update account set balance = balance - ? where account_number = ?";
                PreparedStatement withdrawStatement = connection.prepareStatement(withdrawSQL);
                withdrawStatement.setDouble(1, amount);
                withdrawStatement.setInt(2, sourceAccountId);

                int rowsWithdrawn = withdrawStatement.executeUpdate();

                if (rowsWithdrawn > 0) {
                    String depositSQL = "update account set balance = balance + ? where account_number = ?";
                    PreparedStatement depositStatement = connection.prepareStatement(depositSQL);
                    depositStatement.setDouble(1, amount);
                    depositStatement.setInt(2, targetAccountId);

                    int rowsDeposited = depositStatement.executeUpdate();

                    if (rowsDeposited > 0) {
                        connection.commit();
                        recordTransaction(connection, sourceAccountId, "Transfer Out", amount);
                        recordTransaction(connection, targetAccountId, "Transfer In", amount);
                        System.out.println("Funds transferred successfully!");
                    } else {
                        connection.rollback();
                        System.out.println("Target account not found. Transaction rolled back.");
                    }
                } else {
                    connection.rollback();
                    System.out.println("Source account not found or insufficient funds. Transaction rolled back.");
                }

            } catch (SQLException e) {
                connection.rollback();
                System.out.println("Error transferring funds: " + e.getMessage());
            } finally {
                connection.setAutoCommit(true);
            }

        } catch (SQLException e) {
            System.out.println("Error transferring funds: " + e.getMessage());
        }
    }

    private static void showTransactionHistory(Connection connection, Scanner scanner) {
        try {
            System.out.println("Enter Account ID to view transaction history: ");
            int accountId = scanner.nextInt();

            String sql = "select * from transaction where account_number = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, accountId);

            ResultSet resultSet = statement.executeQuery();
            System.out.println("+----------------+----------------+---------------------+--------------+----------------------+");
            System.out.println("| Transaction ID | Account Number | Transaction Type    | Amount       | Transaction Date     |");
            System.out.println("+----------------+----------------+---------------------+--------------+----------------------+");
            while (resultSet.next()) {
                System.out.printf("| %-14d | %-14d | %-19s | %-12.2f | %-20s |\n",
                        resultSet.getInt("transaction_id"),
                        resultSet.getInt("account_number"),
                        resultSet.getString("transaction_type"),
                        resultSet.getDouble("amount"),
                        resultSet.getTimestamp("transaction_date").toString());
            }
            System.out.println("+----------------+----------------+---------------------+--------------+----------------------+");

        } catch (SQLException e) {
            System.out.println("Error viewing transaction history: " + e.getMessage());
        }
    }

    private static void recordTransaction(Connection connection, int accountId, String transactionType, double amount) {
        try {
            String sql = "insert into transaction (account_number, transaction_type, amount) values (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, accountId);
            statement.setString(2, transactionType);
            statement.setDouble(3, amount);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error recording transaction: " + e.getMessage());
        }
    }

        public static void exit() throws InterruptedException {
            System.out.println("Existing system");
            int i =3;
            while(i>0){
                System.out.print(".");
                Thread.sleep(500);
                i--;
            }
            System.out.println();
            System.out.println("Thank you for using Account Management!!!");
        }
}
