package com.CaseStudy_2;

import java.sql.*;

public class TransactionManagement {

    public void depositFunds(Connection conn, int accountNumber, double amount) throws SQLException {
        try {
            String updateBalance = "UPDATE Account SET balance = balance + ? WHERE account_number = ?";
            PreparedStatement pstmt1 = conn.prepareStatement(updateBalance);
            pstmt1.setDouble(1, amount);
            pstmt1.setInt(2, accountNumber);
            pstmt1.executeUpdate();

            String insertTransaction = "INSERT INTO Transaction (account_number, transaction_type, amount) VALUES (?, 'Deposit', ?)";
            PreparedStatement pstmt2 = conn.prepareStatement(insertTransaction);
            pstmt2.setInt(1, accountNumber);
            pstmt2.setDouble(2, amount);
            pstmt2.executeUpdate();

            System.out.println("Deposit successful!");
        } catch (SQLException e) {
            throw e; // Re-throwing the exception so it can be handled by the caller
        }
    }

    public void withdrawFunds(Connection conn, int accountNumber, double amount) throws SQLException {
        try {
            String checkBalance = "SELECT balance FROM Account WHERE account_number = ?";
            PreparedStatement pstmt1 = conn.prepareStatement(checkBalance);
            pstmt1.setInt(1, accountNumber);
            ResultSet rs = pstmt1.executeQuery();
            if (rs.next()) {
                double balance = rs.getDouble("balance");
                if (balance >= amount) {
                    String updateBalance = "UPDATE Account SET balance = balance - ? WHERE account_number = ?";
                    PreparedStatement pstmt2 = conn.prepareStatement(updateBalance);
                    pstmt2.setDouble(1, amount);
                    pstmt2.setInt(2, accountNumber);
                    pstmt2.executeUpdate();

                    String insertTransaction = "INSERT INTO Transaction (account_number, transaction_type, amount) VALUES (?, 'Withdrawal', ?)";
                    PreparedStatement pstmt3 = conn.prepareStatement(insertTransaction);
                    pstmt3.setInt(1, accountNumber);
                    pstmt3.setDouble(2, amount);
                    pstmt3.executeUpdate();

                    System.out.println("Withdrawal successful!");
                } else {
                    System.out.println("Insufficient balance!");
                    throw new SQLException("Insufficient balance for withdrawal.");
                }
            } else {
                System.out.println("Account not found!");
                throw new SQLException("Account not found.");
            }
        } catch (SQLException e) {
        	
            throw e; // Re-throwing the exception so it can be handled by the caller
        }
    }

    public void transferFunds(Connection conn, int fromAccount, int toAccount, double amount) throws SQLException {
    	conn.setAutoCommit(false); // Start transaction
        try {
        	if (!accountExists(conn, fromAccount) || !accountExists(conn, toAccount)) {
                throw new SQLException("One or both accounts do not exist.");
            }

            // First, withdraw from the sender's account
            withdrawFunds(conn, fromAccount, amount);

            // If withdrawal is successful, deposit into the recipient's account
            depositFunds(conn, toAccount, amount);

            // Commit the transaction
            conn.commit();
            System.out.println("Transfer successful!");
        } catch (SQLException e) {
            conn.rollback(); // Rollback the transaction on error
            System.out.println("Transfer failed! Rolling back the transaction.");
//            e.printStackTrace();
            throw e; // Re-throw the exception so it can be handled by the caller
        } finally {
            conn.setAutoCommit(true); // Restore auto-commit mode
        }
    }
    private boolean accountExists(Connection conn, int accountNumber) throws SQLException {
        String query = "SELECT 1 FROM Account WHERE account_number = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, accountNumber);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }
}
