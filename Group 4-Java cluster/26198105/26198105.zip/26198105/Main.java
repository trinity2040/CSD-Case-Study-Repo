package com.CaseStudy_2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String jdbcURL = "jdbc:mysql://localhost:3306/BankingSystem";
        String dbUser = "root";
        String dbPassword = "Password";  // Replace with your MySQL password

        try (Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
             Scanner scanner = new Scanner(System.in)) {

            AccountManagement accountMgmt = new AccountManagement();
            TransactionManagement transactionMgmt = new TransactionManagement();

            while (true) {
                System.out.println("\nBanking System Menu:");
                System.out.println("1. Create a new account");
                System.out.println("2. View account details");
                System.out.println("3. Update account information");
                System.out.println("4. Close an account");
                System.out.println("5. Deposit funds");
                System.out.println("6. Withdraw funds");
                System.out.println("7. Transfer funds");
                System.out.println("8. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1:
                        System.out.print("Enter account holder name: ");
                        scanner.nextLine();  // Consume newline
                        String name = scanner.nextLine();
                        accountMgmt.createAccount(conn, name);
                        break;
                    case 2:
                        System.out.print("Enter account number: ");
                        int accountNumber = scanner.nextInt();
                        accountMgmt.viewAccountDetails(conn, accountNumber);
                        break;
                    case 3:
                        System.out.print("Enter account number: ");
                        accountNumber = scanner.nextInt();
                        System.out.print("Enter new account holder name: ");
                        scanner.nextLine();  // Consume newline
                        String newName = scanner.nextLine();
                        accountMgmt.updateAccountInformation(conn, accountNumber, newName);
                        break;
                    case 4:
                        System.out.print("Enter account number: ");
                        accountNumber = scanner.nextInt();
                        accountMgmt.closeAccount(conn, accountNumber);
                        break;
                    case 5:
                        System.out.print("Enter account number: ");
                        accountNumber = scanner.nextInt();
                        System.out.print("Enter amount to deposit: ");
                        double depositAmount = scanner.nextDouble();
                        try {
                        	transactionMgmt.depositFunds(conn, accountNumber, depositAmount);
                        } catch (SQLException e) {
                            System.out.println("Error during deposit: " + e.getMessage());
                        }
                        break;
                    case 6:
                        System.out.print("Enter account number: ");
                        accountNumber = scanner.nextInt();
                        System.out.print("Enter amount to withdraw: ");
                        double withdrawAmount = scanner.nextDouble();
                        try {
                        	transactionMgmt.withdrawFunds(conn, accountNumber, withdrawAmount);
                        } catch (SQLException e) {
                            if (e.getMessage().contains("Insufficient balance")) {
                                System.out.println("Withdrawal failed: Insufficient balance.");
                            } else {
                                System.out.println("Error during withdrawal: " + e.getMessage());
                            }
                        }
                        break;
                    case 7:
                        System.out.print("Enter sender's account number: ");
                        int fromAccount = scanner.nextInt();
                        System.out.print("Enter recipient's account number: ");
                        int toAccount = scanner.nextInt();
                        System.out.print("Enter amount to transfer: ");
                        double transferAmount = scanner.nextDouble();
                        try {
                        	transactionMgmt.transferFunds(conn, fromAccount, toAccount, transferAmount);
                        } catch (SQLException e) {
                            System.out.println("Error during transfer: " + e.getMessage());
                        }
                        break;
                    case 8:
                        System.out.println("Exiting...");
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice! Please try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
