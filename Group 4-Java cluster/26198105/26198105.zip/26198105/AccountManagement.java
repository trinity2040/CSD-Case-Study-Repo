package com.CaseStudy_2;

import java.sql.*;

public class AccountManagement {
    
    public void createAccount(Connection conn, String accountHolderName) throws SQLException {
        String query = "INSERT INTO Account (account_holder_name, balance) VALUES (?, ?)";
        PreparedStatement pstmt = conn.prepareStatement(query);
        pstmt.setString(1, accountHolderName);
        pstmt.setDouble(2, 0.0);
        pstmt.executeUpdate();
        String newQuery = "SELECT * FROM Account WHERE account_holder_name = ?";
        PreparedStatement newPstmt = conn.prepareStatement(newQuery);
        newPstmt.setString(1,accountHolderName);
        ResultSet rs = newPstmt.executeQuery();
        if (rs.next()) {
            System.out.println("Your Personal Account Number: " + rs.getInt("account_number"));
        }
        
        System.out.println("Account created successfully!");
    }

    public void viewAccountDetails(Connection conn, int accountNumber) throws SQLException {
        String query = "SELECT * FROM Account WHERE account_number = ?";
        PreparedStatement pstmt = conn.prepareStatement(query);
        pstmt.setInt(1, accountNumber);
        ResultSet rs = pstmt.executeQuery();
        if (rs.next()) {
            System.out.println("Account Number: " + rs.getInt("account_number"));
            System.out.println("Account Holder Name: " + rs.getString("account_holder_name"));
            System.out.println("Balance: " + rs.getDouble("balance"));
        } else {
            System.out.println("Account not found!");
        }
    }

    public void updateAccountInformation(Connection conn, int accountNumber, String newAccountHolderName) throws SQLException {
        String query = "UPDATE Account SET account_holder_name = ? WHERE account_number = ?";
        PreparedStatement pstmt = conn.prepareStatement(query);
        pstmt.setString(1, newAccountHolderName);
        pstmt.setInt(2, accountNumber);
        int rowsAffected = pstmt.executeUpdate();
        if (rowsAffected > 0) {
            System.out.println("Account information updated successfully!");
        } else {
            System.out.println("Account not found!");
        }
    }

    public void closeAccount(Connection conn, int accountNumber) throws SQLException {
        conn.setAutoCommit(false);
        try {
            // First delete all related transactions
            String deleteTransactions = "DELETE FROM Transaction WHERE account_number = ?";
            PreparedStatement pstmt1 = conn.prepareStatement(deleteTransactions);
            pstmt1.setInt(1, accountNumber);
            pstmt1.executeUpdate();

            // Now delete the account
            String deleteAccount = "DELETE FROM Account WHERE account_number = ?";
            PreparedStatement pstmt2 = conn.prepareStatement(deleteAccount);
            pstmt2.setInt(1, accountNumber);
            int rowsAffected = pstmt2.executeUpdate();

            if (rowsAffected > 0) {
                conn.commit();
                System.out.println("Account closed successfully!");
            } else {
                System.out.println("Account not found!");
            }
        } catch (SQLException e) {
            conn.rollback();
            throw e;
        } finally {
            conn.setAutoCommit(true);
        }
    }
}

