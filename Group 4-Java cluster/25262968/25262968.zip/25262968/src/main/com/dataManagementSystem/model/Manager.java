package main.com.dataManagementSystem.model;

// Define main.com.dataManagementSystem.model.Manager Interface to remove redundancy
public interface Manager {
    void add();
    void viewAll();
    void viewDetails();
    void update();
    void delete();
    void deleteAll();
}
