package main.com.dataManagementSystem.model;

import main.com.dataManagementSystem.service.DatabaseConnection;

import java.sql.*;
import java.util.Scanner;

public class ExperimentManager implements Manager {
    // Scanner object to take user inputs
    Scanner scanner = new Scanner(System.in);

    // Method to add a new experiment to the database
    @Override
    public void add() {
        // Taking input from the user about the details of the Experiment
        System.out.println("Add the details of the new Experiment: ");
        System.out.println("Enter name of the experiment: ");
        String name = scanner.nextLine();
        System.out.println("Enter description of the experiment: ");
        String description = scanner.nextLine();
        System.out.println("Enter start date (yyyy-mm-dd) of the experiment: ");
        String startDate = scanner.nextLine();
        System.out.println("Enter end date (yyyy-mm-dd) of the experiment: ");
        String endDate = scanner.nextLine();

        // SQL query to insert a new experiment to the experiments table
        String query = "INSERT INTO experiment (name, description, start_date, end_date) VALUES (?, ?, ?, ?)";
        try {
            // Establishing connection with database
            PreparedStatement preparedStatement = getPreparedStatement(query);

            // setting the values of the parameters of the query string
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, description);
            preparedStatement.setDate(3, Date.valueOf(startDate));
            preparedStatement.setDate(4, Date.valueOf(endDate));

            // execute the query
            preparedStatement.executeUpdate();
            preparedStatement.close();

            System.out.println("Experiment added successfully.");
        } catch (SQLException e) {
            System.out.println("Error while adding new experiment to the database: " + e.getMessage());
        }
    }

    // Method to view all experiments in the database
    @Override
    public void viewAll() {
        // SQL query to view all the experiments in the experiments table
        String fetchQuery = "SELECT * FROM experiment";
        try {
            // establishing connection with the database
            PreparedStatement preparedStatement = getPreparedStatement(fetchQuery);
            // execute the query
            ResultSet resultSet = preparedStatement.executeQuery();
            // printing the result generated if any
            if (resultSet.next()) {
                System.out.println("ExperimentId | Name | \tDescription\t | Start Date | End Date");
                // Iterate through the result set to display all experiments
                while (resultSet.next()) {
                    printExperiment(resultSet);
                }
            } else {
                System.out.println("No experiments found.");
            }
        } catch (SQLException e) {
            System.out.println("Error while retrieving the experiments: " + e.getMessage());
        }
    }

    // Method to view details of a specific experiment based on ID
    @Override
    public void viewDetails() {
        // taking experiment_id as input from user to fetch the experiment
        System.out.println("Enter the id of the experiment: ");
        int id = scanner.nextInt();
        // SQL query to fetch the experiment using its id
        String query = "SELECT * FROM experiment WHERE experiment_id = ?";
        try {
            // establishing connection with database
            PreparedStatement preparedStatement = getPreparedStatement(query);
            // setting values for query parameters
            preparedStatement.setInt(1, id);
            // executing query
            ResultSet resultSet = preparedStatement.executeQuery();
            // If experiment is found, display the details
            if (resultSet.next()) {
                System.out.println("ExperimentId | Name | \tDescription\t | Start Date | End Date");
                printExperiment(resultSet);
            } else {
                System.out.println("No experiment with id:" + id + " found.");
            }
        } catch (SQLException e) {
            System.out.println("Error while retrieving the details of the Experiment: " + e.getMessage());
        }
    }

    // Method to update details of an existing experiment
    @Override
    public void update() {
        // taking experiment_id as input from user to fetch the experiment
        System.out.println("Enter the id of the experiment to be updated: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume the leftover newline

        // Variables to store updated values, initially empty
        String name = "";
        String description = "";
        String startDate = "";
        String endDate = "";

        boolean exit = false; // Control flag for the update menu

        while (!exit) {
            System.out.println("Select the option to update existing information: ");
            System.out.println("1. Name \n2. Description \n3. Start Date \n4. End Date \n5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume the leftover newline

            switch (choice) {
                case 1:
                    System.out.println("Enter the new name of the experiment: ");
                    name = scanner.nextLine();
                    break;
                case 2:
                    System.out.println("Enter the new description of the experiment: ");
                    description = scanner.nextLine();
                    break;
                case 3:
                    System.out.println("Enter the new start date of the experiment: ");
                    startDate = scanner.nextLine();
                    break;
                case 4:
                    System.out.println("Enter the new end date of the experiment: ");
                    endDate = scanner.nextLine();
                    break;
                case 5:
                    System.out.println("Exiting the update process.");
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        // query to fetch existing experiment details to retain unchanged fields
        String fetchQuery = "SELECT * FROM experiment WHERE experiment_id = ?";
        // query to update the experiment details
        String updateQuery = "UPDATE experiment SET name = ?, description = ?, start_date = ?, end_date = ? WHERE experiment_id = ?";

        try {
            // establish connection with database
            PreparedStatement fetchStmt = getPreparedStatement(fetchQuery);
            PreparedStatement updateStmt = getPreparedStatement(updateQuery);
            // set values to query parameters for fetch
            fetchStmt.setInt(1, id);
            // execute query
            ResultSet resultSet = fetchStmt.executeQuery();

            if (resultSet.next()) {
                if (name.isEmpty()) name = resultSet.getString("name");
                if (description.isEmpty()) description = resultSet.getString("description");
                if (startDate.isEmpty()) startDate = String.valueOf(resultSet.getDate("start_date"));
                if (endDate.isEmpty()) endDate = String.valueOf(resultSet.getDate("end_date"));

                // set parameters of the query for update
                updateStmt.setString(1, name);
                updateStmt.setString(2, description);
                updateStmt.setDate(3, Date.valueOf(startDate));
                updateStmt.setDate(4, Date.valueOf(endDate));
                updateStmt.setInt(5, id);


                // execute the update query
                int rows = updateStmt.executeUpdate();
                if (rows > 0) {
                    System.out.println("Experiment updated! ");

                    // optionally update associated samples based on experiment details
                    System.out.println("Do you want to update samples associated with this experiment? (y/n)");
                    String updateSamples = scanner.nextLine();
                    if ("y".equalsIgnoreCase(updateSamples)) {
                        updateSamplesForExperiment(id); // a separate method to handle this
                    }
                } else {
                    System.out.println("Experiment update failed. Please check the id and try again.");
                }
            }else {
                System.out.println("No experiment with id:" + id + " found.");
            }
        } catch (SQLException e) {
            System.out.println("Error while updating the experiment: " + e.getMessage());
        }
    }

    // Method to delete a specific experiment based on ID
    @Override
    public void delete() {
        // taking experiment_id as input from user to fetch the experiment
        System.out.println("Enter the id of the experiment to be deleted: ");
        int id = scanner.nextInt();
        // SQL query to fetch the experiment using its id
        String query = "DELETE FROM experiment WHERE experiment_id = ?";
        try {
            // establishing connection with database
            PreparedStatement preparedStatement = getPreparedStatement(query);
            // setting values for query parameters
            preparedStatement.setInt(1, id);
            // executing query
            int rows = preparedStatement.executeUpdate();
            if (rows > 0) System.out.println("Experiment deleted and associated sample set to null! ");
            else System.out.println("No experiment with id:" + id + " found.");
        } catch (SQLException e) {
            System.out.println("Error while deleting the experiment: " + e.getMessage());
        }
    }

    // Method to delete all Experiments
    @Override
    public void deleteAll() {
        // SQL query to delete all experiments in the table
        String query = "DELETE FROM experiment";
        try {
            // establishing connection with database
            PreparedStatement preparedStatement = getPreparedStatement(query);
            // executing query
            int rows = preparedStatement.executeUpdate();
            if (rows > 0) {
                System.out.println(rows + " Experiments deleted successfully.");
            }
            else {
                System.out.println("Experiments not found or Table Empty");
            }
        } catch (SQLException e) {
            System.out.println("Error while deleting the experiments: " + e.getMessage());
        }
    }

    // Method to update associated samples
    public void updateSamplesForExperiment(int experimentId) {
        // fetch the sample associated with it
        String fetchQuery = "SELECT * FROM Sample WHERE experiment_id = ?";
        String updateQuery = "UPDATE Sample SET quantity = ? WHERE sample_id = ?";

        int sample_quantity, sample_id = 0;
        try{
            // establishing connection
            PreparedStatement fetchStmt = getPreparedStatement(fetchQuery);
            // setting values to the parameter
            fetchStmt.setInt(1, experimentId);
            // executing the query
            ResultSet resultSet = fetchStmt.executeQuery();
            if (resultSet.next()) {
                sample_id = resultSet.getInt("sample_id");
                String sample_name = resultSet.getString("name");
                String sample_type = resultSet.getString("type");
                int quantity = resultSet.getInt("quantity");
                int experiment_id = resultSet.getInt("experiment_id");
                System.out.println("Associated Sample Details are: ");
                System.out.println("Sample ID: " + sample_id);
                System.out.println("Sample Name: " + sample_name);
                System.out.println("Sample Type: " + sample_type);
                System.out.println("Sample Quantity: " + quantity);
                System.out.println("Experiment ID: " + experiment_id);
            }else{
                System.out.println("No Sample associated with this experiment.");
            }
            System.out.println("Enter the updated quantity of the sample");
            sample_quantity = scanner.nextInt();
            scanner.nextLine(); // consume extra line
            PreparedStatement updateStmt = getPreparedStatement(updateQuery);
            updateStmt.setInt(1, sample_quantity);
            updateStmt.setInt(2, sample_id);
            // execute the query
            int rows = updateStmt.executeUpdate();
            if(rows > 0){
                System.out.println("Sample updated successfully.");
            }else{
                System.out.println("Sample update failed. Please check the id and try again.");
            }
        }catch (SQLException e){
            System.out.println("Error while retrieving the samples associated with this experiment: " + e.getMessage());
        }
    }
    // helper-functions
    private static PreparedStatement getPreparedStatement(String query) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        return connection.prepareStatement(query);
    }

    private void printExperiment(ResultSet resultSet) throws SQLException {
        int experimentId = resultSet.getInt("experiment_id");
        String name = resultSet.getString("name");
        String description = resultSet.getString("description");
        String startDate = resultSet.getString("start_date");
        String endDate = resultSet.getString("end_date");
        System.out.println(experimentId + " | " + name + " | " + description + " | " + startDate + " | " + endDate);
    }

}
