package main.com.dataManagementSystem.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

//  declaring the database configuration information used for locating the database and for authenticating it
    private static final String db_url = "jdbc:mysql://localhost:3306/data_management_system";
    private static final String db_user = "root";
    private static final String db_pass = "Ankita#@2101";

// this method returns a connection object that tries to connect to the sql database using jdbc and provided credentials
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(db_url, db_user, db_pass);
    }

}
