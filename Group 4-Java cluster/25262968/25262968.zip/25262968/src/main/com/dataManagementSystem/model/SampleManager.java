package main.com.dataManagementSystem.model;

import main.com.dataManagementSystem.service.DatabaseConnection;

import java.sql.*;
import java.util.Scanner;

public class SampleManager implements Manager {
    // Scanner object to take user inputs
    Scanner scanner = new Scanner(System.in);

    // Method to add a new Sample to the database
    @Override
    public void add() {
        // Taking input from the user about the details of the Sample
        System.out.println("Add the details of the new sample: ");
        System.out.println("Enter name of the sample: ");
        String name = scanner.nextLine();
        System.out.println("Enter type of the sample: ");
        String type = scanner.nextLine();
        System.out.println("Enter quantity of the sample: ");
        int quantity = scanner.nextInt();
        System.out.println("Enter experiment id related to the sample: ");
        int experiment_id = scanner.nextInt();

        // SQL syntax to insert a new sample to the samples table
        String query = "INSERT INTO sample (experiment_id, name, type, quantity) VALUES (?, ?, ?, ?)";
        try {
            // Establishing connection by using driver manager instance
            PreparedStatement preparedStatement = getpreparedStatement(query);
            // setting the values of the parameters of the query string
            preparedStatement.setInt(1, experiment_id);
            preparedStatement.setString(2, name);
            preparedStatement.setString(3, type);
            preparedStatement.setInt(4, quantity);
            // execute the query
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error while adding new sample to the database: " + e.getMessage());
        }
    }

    // Method to view all Samples
    @Override
    public void viewAll() {
        // SQL query to view all the samples
        String query = "SELECT s.sample_id, e.experiment_id, s.name, e.name as experiment_name, s.type, s.quantity  FROM sample s, experiment e WHERE s.experiment_id = e.experiment_id";
        try {
            // establishing connection with the database
            PreparedStatement preparedStatement = getpreparedStatement(query);
            // execute the query
            ResultSet resultSet = preparedStatement.executeQuery();
            // printing the result generated if any
            if (resultSet.next()) {
                System.out.println("Sample_ID | Experiment ID | Name | Experiment Name | Type | Quantity");
                while (resultSet.next()) {
                    printSample(resultSet);
                }
            } else {
                System.out.println("No samples in the Database found");
            }
        } catch (SQLException e) {
            System.out.println("Error while viewing all samples: " + e.getMessage());
        }
    }

    // Method to view Sample based on ID
    @Override
    public void viewDetails() {
        // taking sample id as input from user to fetch the sample
        System.out.println("Enter the id of the required sample: ");
        int id = scanner.nextInt();
        String query = "SELECT s.sample_id, e.experiment_id, s.name, e.name as experiment_name, s.type, s.quantity  FROM sample s, experiment e WHERE s.sample_id = ? and s.experiment_id = e.experiment_id";
        try {
            // establishing connection with database
            PreparedStatement preparedStatement = getpreparedStatement(query);
            // setting values for query parameters
            preparedStatement.setInt(1, id);
            // executing query
            ResultSet resultSet = preparedStatement.executeQuery();
            // If sample is found, display the details
            if (resultSet.next()) {
                System.out.println("Sample_ID | Experiment ID | Sample Name | Experiment Name | Type | Quantity");
                printSample(resultSet);
            } else {
                System.out.println("Sample with id: " + id + " not found");
            }
        } catch (SQLException e) {
            System.out.println("Error while viewing sample: " + e.getMessage());
        }
    }

    // Method to update details of an existing sample
    @Override
    public void update() {
        // taking id as input from user to fetch the experiment
        System.out.println("Enter the id of the sample to be updated: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume the leftover newline

        // Variables to store updated values, initially empty
        String name = "";
        String type = "";
        int quantity = 0;
        int experiment_id = 0;

        boolean exit = false; // Control flag for the update menu

        while (!exit) {
            System.out.println("Select the option to update existing information: ");
            System.out.println("1. Name \n2. Type \n3. Experiment number \n4. Quantity \n5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume the leftover newline

            switch (choice) {
                case 1:
                    System.out.println("Enter name of the sample: ");
                    name = scanner.nextLine();
                    break;
                case 2:
                    System.out.println("Enter type of the sample: ");
                    type = scanner.nextLine();
                    break;
                case 3:
                    System.out.println("Enter experiment id related to the sample: ");
                    experiment_id = scanner.nextInt();
                    break;
                case 4:
                    System.out.println("Enter quantity of the sample: ");
                    quantity = scanner.nextInt();
                    break;
                case 5:
                    System.out.println("Exiting the update process.");
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }

        // query to fetch existing sample details to retain unchanged fields
        String fetchQuery = "SELECT name, type, experiment_id, quantity FROM sample WHERE sample_id = ?";
        // query to update the sample details
        String updateQuery = "UPDATE sample SET name = ?, type = ?, experiment_id = ?, quantity = ? WHERE sample_id = ?";

        try {
            // establish connection with database
            PreparedStatement fetchStmt = getpreparedStatement(fetchQuery);
            PreparedStatement updateStmt = getpreparedStatement(updateQuery);
            // set values to query parameters
            fetchStmt.setInt(1, id);
            // execute query
            ResultSet rs = fetchStmt.executeQuery();

            if (rs.next()) {
                if (name.isEmpty()) name = rs.getString("name");
                if (type.isEmpty()) type = rs.getString("type");
                if (experiment_id == 0) experiment_id = rs.getInt("experiment_id");
                if (quantity == 0) quantity = rs.getInt("quantity");

                // Setting the values for the update query
                updateStmt.setString(1, name);
                updateStmt.setString(2, type);
                updateStmt.setInt(3, experiment_id);
                updateStmt.setInt(4, quantity);
                updateStmt.setInt(5, id);
                // execute the update query
                int rows = updateStmt.executeUpdate();
                if (rows > 0) {
                    System.out.println("Sample updated successfully.");
                } else {
                    System.out.println("Sample update failed. Please check the id and try again.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error while updating sample: " + e.getMessage());
        }
    }

    // Method to delete a specific sample based on ID
    @Override
    public void delete() {
        //taking id as input from user to fetch the sample
        System.out.println("Enter the id of the sample to be deleted: ");
        int id = scanner.nextInt();
        // SQL query to fetch the sample using its id
        String query = "DELETE FROM sample WHERE sample_id = ?";
        try {
            // establishing connection with database
            PreparedStatement preparedStatement = getpreparedStatement(query);
            // setting values for query parameters
            preparedStatement.setInt(1, id);
            // executing query
            int rows = preparedStatement.executeUpdate();
            if (rows > 0) {
                System.out.println("Sample deleted successfully.");
            } else {
                System.out.println("Sample delete failed. Please check the id and try again.");
            }
        } catch (SQLException e) {
            System.out.println("Error while deleting sample: " + e.getMessage());
        }
    }

    // Method to delete all samples
    @Override
    public void deleteAll() {
        try {
            String query = "DELETE FROM sample";
            PreparedStatement preparedStatement = getpreparedStatement(query);
            int rows = preparedStatement.executeUpdate();
            if (rows > 0) {
                System.out.println("Successfully deleted the samples");
            } else System.out.println("Something went wrong while deleting the samples");
        } catch (SQLException e) {
            System.out.println("Error while deleting all samples: " + e.getMessage());
        }
    }

    // helper functions

    private static PreparedStatement getpreparedStatement(String query) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        return connection.prepareStatement(query);
    }

    private void printSample(ResultSet resultSet) throws SQLException {

        int sample_ID = resultSet.getInt("sample_id");
        int experiment_ID = resultSet.getInt("experiment_id");
        String name = resultSet.getString("name");
        String experimentName = resultSet.getString("experiment_name");
        String type = resultSet.getString("type");
        int quantity = resultSet.getInt("quantity");
        System.out.println(sample_ID + " | " + experiment_ID + " | " + name + " | " + experimentName + " | " + type + " | " + quantity);
    }
}
