package main.com.dataManagementSystem.model;

import main.com.dataManagementSystem.service.DatabaseConnection;

import java.sql.*;
import java.util.Scanner;

public class ResearcherManager implements Manager {
    // Scanner object to take user inputs
    private final Scanner scanner = new Scanner(System.in);

    // Method to add a new researcher to the database
    @Override
    public void add() {
        System.out.println("Add the details of the new Researcher: ");

        // Taking input from the user about the details of the Researcher
        System.out.print("Enter name of the researcher: ");
        String name = scanner.nextLine();
        System.out.print("Enter email of the researcher: ");
        String email = scanner.nextLine();
        System.out.print("Enter phone number of the researcher: ");
        String phone_number = scanner.nextLine();
        System.out.print("Enter specialization of the researcher: ");
        String specialization = scanner.nextLine();

        // SQL query to insert a new researcher into the researchers table
        String query = "INSERT INTO researcher (name, email, phone_number, specialization) VALUES (?, ?, ?, ?)";

        try {
            // Establishing connection with database
            PreparedStatement preparedStatement = getPreparedStatement(query);

            // Setting the values of the parameters of the query string
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, phone_number);
            preparedStatement.setString(4, specialization);

            // Execute the query
            preparedStatement.executeUpdate();
            preparedStatement.close();

            System.out.println("Researcher added successfully.");
        } catch (SQLException e) {
            System.out.println("Error while adding new researcher to the database: " + e.getMessage());
        }
    }

    // Method to view all researchers in the database
    @Override
    public void viewAll() {
        // SQL query to view all the researcher in the researchers table
        String query = "SELECT * FROM researcher";
        try {
            // establishing connection with the database
            PreparedStatement preparedStatement = getPreparedStatement(query);
            // execute the query
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                System.out.println("ResearcherId | Name | Email | Phone | Specialization");
                // Iterate through the result set to display all researchers
                while (resultSet.next()) {
                    printResearcher(resultSet);
                }
            }else{
                System.out.println("No researcher found.");
            }
        } catch (SQLException e) {
            System.out.println("Error while viewing all researchers: " + e.getMessage());
        }
    }

    // Method to view details of a specific researcher based on ID
    @Override
    public void viewDetails() {
        // taking id as input from user to fetch the researcher
        System.out.print("Enter the ID of the researcher: ");
        int id = scanner.nextInt();
        // SQL query to fetch the researcher using id
        String query = "SELECT * FROM researcher WHERE researcher_id = ?";
        try {
            //establishing connection with database
            PreparedStatement preparedStatement = getPreparedStatement(query);
            // setting values for query parameters
            preparedStatement.setInt(1, id);
            // executing query
            ResultSet resultSet = preparedStatement.executeQuery();

            // If researcher is found, display the details
            if (resultSet.next()) {
                printResearcher(resultSet);
            } else {
                System.out.println("Researcher not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error while viewing details: " + e.getMessage());
        }
    }

    // Method to update details of an existing researcher
    @Override
    public void update() {
        // taking id as user input to fetch the researcher
        System.out.print("Enter the ID of the researcher to be updated: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume the leftover newline

        // Variables to store updated values, initially empty
        String name = "";
        String email = "";
        String phone_number = "";
        String specialization = "";

        boolean exit = false; // Control flag for the update menu

        // Update menu loop
        while (!exit) {
            System.out.println("Select the option to update existing information: ");
            System.out.println("1. Name \n2. Email \n3. Phone number \n4. Specialization \n5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the leftover newline

            switch (choice) {
                case 1:
                    System.out.print("Enter the new name of the researcher: ");
                    name = scanner.nextLine();
                    break;
                case 2:
                    System.out.print("Enter the new email of the researcher: ");
                    email = scanner.nextLine();
                    break;
                case 3:
                    System.out.print("Enter the new phone number of the researcher: ");
                    phone_number = scanner.nextLine();
                    break;
                case 4:
                    System.out.print("Enter the new specialization of the researcher: ");
                    specialization = scanner.nextLine();
                    break;
                case 5:
                    System.out.println("Exiting update process.");
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }

        // Fetch existing researcher details to retain unchanged fields
        String fetchQuery = "SELECT name, email, phone_number, specialization FROM researcher WHERE researcher_id = ?";
        // query to update the researcher details
        String updateQuery = "UPDATE researcher SET name = ?, email = ?, phone_number = ?, specialization = ? WHERE researcher_id = ?";

        try {
            // establish connection with database
            PreparedStatement fetchStmt = getPreparedStatement(fetchQuery);
            PreparedStatement updateStmt = getPreparedStatement(updateQuery);
            // set values to query parameters for fetch
            fetchStmt.setInt(1, id);
            // execute query
            ResultSet rs = fetchStmt.executeQuery();

            if (rs.next()) {
                if (name.isEmpty()) name = rs.getString("name");
                if (email.isEmpty()) email = rs.getString("email");
                if (phone_number.isEmpty()) phone_number = rs.getString("phone_number");
                if (specialization.isEmpty()) specialization = rs.getString("specialization");

                // Setting the values for the update query
                updateStmt.setString(1, name);
                updateStmt.setString(2, email);
                updateStmt.setString(3, phone_number);
                updateStmt.setString(4, specialization);
                updateStmt.setInt(5, id);
                // execute the update query
                int rowsAffected = updateStmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Researcher updated successfully.");
                } else {
                    System.out.println("Failed to update the researcher. Please check the ID and try again.");
                }
            } else {
                System.out.println("No researcher found with the given id: "+id);
            }
        } catch (SQLException e) {
            System.out.println("Error while updating researcher: " + e.getMessage());
        }
    }

    // Method to delete a specific researcher based on ID
    @Override
    public void delete() {
        // taking id as user input to fetch the researcher
        System.out.print("Enter the ID of the researcher to be deleted: ");
        int id = scanner.nextInt();
        // sql query to delete researcher based on id
        String query = "DELETE FROM researcher WHERE researcher_id = ?";

        try {
            // establishing connection with database
            PreparedStatement preparedStatement = getPreparedStatement(query);
            // setting values for query parameters
            preparedStatement.setInt(1, id);
            // executing query
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Researcher deleted successfully.");
            } else {
                System.out.println("Failed to delete the researcher. Please check the ID and try again.");
            }
        } catch (SQLException e) {
            System.out.println("Error while deleting researcher: " + e.getMessage());
        }
    }

    // Method to delete all researchers from the database
    public void deleteAll() {
        // SQL query to delete all researchers
        String query = "DELETE FROM researcher";

        try {
            // establishing connection with database
            PreparedStatement preparedStatement = getPreparedStatement(query);
            // executing query
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println(rowsAffected + " researchers deleted successfully.");
            } else {
                System.out.println("No researchers found to delete.");
            }
        } catch (SQLException e) {
            System.out.println("Error while deleting all researchers: " + e.getMessage());
        }
    }

    // helper functions

    private static PreparedStatement getPreparedStatement(String query) throws SQLException {
        Connection connection = DatabaseConnection.getConnection();
        return connection.prepareStatement(query);
    }

    private void printResearcher(ResultSet resultSet) throws SQLException {
        int id = resultSet.getInt("researcher_id");
        String name = resultSet.getString("name");
        String email = resultSet.getString("email");
        String phone_number = resultSet.getString("phone_number");
        String specialization = resultSet.getString("specialization");

        System.out.println(id + " | " + name + " | " + email + " | " + phone_number + " | " + specialization);
    }

}

