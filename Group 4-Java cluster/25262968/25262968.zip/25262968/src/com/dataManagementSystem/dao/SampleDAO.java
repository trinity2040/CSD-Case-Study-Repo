package com.dataManagementSystem.dao;

import com.dataManagementSystem.database.DatabaseConnection;
import com.dataManagementSystem.exceptions.DataNotFoundException;
import com.dataManagementSystem.exceptions.InvalidDataException;
import com.dataManagementSystem.models.Sample;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SampleDAO {
    public void addSample(Sample sample) throws SQLException, InvalidDataException {
        if (sample.getName() == null || sample.getName().isEmpty()) {
            throw new InvalidDataException("Sample name cannot be null or empty.");
        }

        String query = "INSERT INTO Sample (name, type, quantity, experiment_id) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, sample.getName());
            preparedStatement.setString(2, sample.getType());
            preparedStatement.setInt(3, sample.getQuantity());
            preparedStatement.setInt(4, sample.getExperimentId());

            preparedStatement.executeUpdate();
        }
    }

    public Sample getSampleById(int id) throws SQLException, DataNotFoundException {
        String query = "SELECT * FROM Sample WHERE sample_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return new Sample(
                        resultSet.getInt("sample_id"),
                        resultSet.getString("name"),
                        resultSet.getString("type"),
                        resultSet.getInt("quantity"),
                        resultSet.getInt("experiment_id")
                );
            } else {
                throw new DataNotFoundException("Sample with ID " + id + " not found.");
            }
        }
    }

    public List<Sample> getAllSamples() throws SQLException {
        List<Sample> samples = new ArrayList<>();
        String query = "SELECT * FROM Sample";

        try (Connection connection = DatabaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                samples.add(new Sample(
                        resultSet.getInt("sample_id"),
                        resultSet.getString("name"),
                        resultSet.getString("type"),
                        resultSet.getInt("quantity"),
                        resultSet.getInt("experiment_id")
                ));
            }
        }

        return samples;
    }

    public void updateSample(Sample sample) throws SQLException, DataNotFoundException {
        String query = "UPDATE Sample SET name = ?, type = ?, quantity = ?, experiment_id = ? WHERE sample_id = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, sample.getName());
            preparedStatement.setString(2, sample.getType());
            preparedStatement.setInt(3, sample.getQuantity());
            preparedStatement.setInt(4, sample.getExperimentId());
            preparedStatement.setInt(5, sample.getSampleId());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected == 0) {
                throw new DataNotFoundException("Sample with ID " + sample.getSampleId() + " not found.");
            }
        }
    }

    public boolean deleteSample(int id) throws DataNotFoundException {
        String query = "DELETE FROM Sample WHERE sample_id = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, id);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected == 0) {
                throw new DataNotFoundException("Sample with ID " + id + " not found.");
            }
        }catch (SQLException e) {
            System.out.println("Error while deleting: " + e.getMessage());
            return false;
        }
        return true;
    }

    public boolean deleteAllSamples() throws DataNotFoundException {
        String query = "DELETE FROM Sample";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected == 0) {
                throw new DataNotFoundException("No samples were found.");
            }
        }catch (SQLException e) {
            System.out.println("Error while deleting: " + e.getMessage());
            return false;
        }
        return true;
    }
}
