package com.dataManagementSystem.dao;

import com.dataManagementSystem.database.DatabaseConnection;
import com.dataManagementSystem.exceptions.DataNotFoundException;
import com.dataManagementSystem.exceptions.InvalidDataException;
import com.dataManagementSystem.models.Researcher;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ResearcherDAO {

    public void addResearcher(Researcher researcher) throws InvalidDataException {
        if (researcher.getName() == null || researcher.getName().isEmpty()) {
            throw new InvalidDataException("Researcher name cannot be null or empty.");
        }

        String query = "INSERT INTO Researcher (name, email, phone_number, specialization) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, researcher.getName());
            preparedStatement.setString(2, researcher.getEmail());
            preparedStatement.setString(3, researcher.getPhoneNumber());
            preparedStatement.setString(4, researcher.getSpecialization());

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error while adding Researcher to database" + e.getMessage());
        }
    }

    public Researcher getResearcherById(int id) throws SQLException, DataNotFoundException {
        String query = "SELECT * FROM Researcher WHERE researcher_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return new Researcher(
                        resultSet.getInt("researcher_id"),
                        resultSet.getString("name"),
                        resultSet.getString("email"),
                        resultSet.getString("phone_number"),
                        resultSet.getString("specialization")
                );
            } else {
                throw new DataNotFoundException("Researcher with ID " + id + " not found.");
            }
        }
    }

    public List<Researcher> getAllResearchers() throws SQLException {
        List<Researcher> researchers = new ArrayList<>();
        String query = "SELECT * FROM Researcher";

        try (Connection connection = DatabaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                researchers.add(new Researcher(
                        resultSet.getInt("researcher_id"),
                        resultSet.getString("name"),
                        resultSet.getString("email"),
                        resultSet.getString("phone_number"),
                        resultSet.getString("specialization")
                ));
            }
        }

        return researchers;
    }

    public void updateResearcher(Researcher researcher) throws SQLException, DataNotFoundException {
        String query = "UPDATE Researcher SET name = ?, email = ?, phone_number = ?, specialization = ? WHERE researcher_id = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, researcher.getName());
            preparedStatement.setString(2, researcher.getEmail());
            preparedStatement.setString(3, researcher.getPhoneNumber());
            preparedStatement.setString(4, researcher.getSpecialization());
            preparedStatement.setInt(5, researcher.getResearcherId());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected == 0) {
                throw new DataNotFoundException("Researcher with ID " + researcher.getResearcherId() + " not found.");
            }
        }
    }

    public boolean deleteResearcher(int id) throws DataNotFoundException {
        String query = "DELETE FROM Researcher WHERE researcher_id = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, id);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected == 0) {
                throw new DataNotFoundException("Researcher with ID " + id + " not found.");
            }
        }catch (SQLException e) {
            System.out.println("Error while deleting: " + e.getMessage());
            return false;
        }
        return true;
    }

    public boolean deleteAllResearchers() throws DataNotFoundException {
        String query = "DELETE FROM Researcher";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected == 0) {
                throw new DataNotFoundException("No researchers were found.");
            }
        }catch (SQLException e) {
            return false;
        }
        return true;
    }
}
