package com.dataManagementSystem.dao;

import com.dataManagementSystem.database.DatabaseConnection;
import com.dataManagementSystem.exceptions.DataNotFoundException;
import com.dataManagementSystem.exceptions.InvalidDataException;
import com.dataManagementSystem.models.Experiment;
import com.dataManagementSystem.models.Sample;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ExperimentDAO {

    public void addExperiment(Experiment experiment) throws SQLException, InvalidDataException {
        if (experiment.getName() == null || experiment.getName().isEmpty()) {
            throw new InvalidDataException("Experiment name cannot be null or empty.");
        }
        if(experiment.getEndDate().isBefore(experiment.getStartDate())){
            throw new InvalidDataException("Experiment end date cannot be before start date.");
        }

        String query = "INSERT INTO Experiment (name, description, start_date, end_date) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, experiment.getName());
            preparedStatement.setString(2, experiment.getDescription());
            preparedStatement.setDate(3, Date.valueOf(experiment.getStartDate()));
            preparedStatement.setDate(4, Date.valueOf(experiment.getEndDate()));

            preparedStatement.executeUpdate();
        }
    }

    public Experiment getExperimentById(int id) throws SQLException, DataNotFoundException {
        String query = "SELECT * FROM Experiment WHERE experiment_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return new Experiment(
                        resultSet.getInt("experiment_id"),
                        resultSet.getString("name"),
                        resultSet.getString("description"),
                        resultSet.getDate("start_date").toLocalDate(),
                        resultSet.getDate("end_date").toLocalDate()
                );
            } else {
                throw new DataNotFoundException("Experiment with ID " + id + " not found.");
            }
        }
    }

    public List<Experiment> getAllExperiments() throws SQLException {
        List<Experiment> experiments = new ArrayList<>();
        String query = "SELECT * FROM Experiment";

        try (Connection connection = DatabaseConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                experiments.add(new Experiment(
                        resultSet.getInt("experiment_id"),
                        resultSet.getString("name"),
                        resultSet.getString("description"),
                        resultSet.getDate("start_date").toLocalDate(),
                        resultSet.getDate("end_date").toLocalDate()
                ));
            }
        }

        return experiments;
    }

    public void updateExperiment(Experiment experiment) throws SQLException, DataNotFoundException {
        if(experiment.getEndDate().isBefore(experiment.getStartDate())){
            throw new InvalidDataException("Experiment end date cannot be before start date.");
        }
        String query = "UPDATE Experiment SET name = ?, description = ?, start_date = ?, end_date = ? WHERE experiment_id = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, experiment.getName());
            preparedStatement.setString(2, experiment.getDescription());
            preparedStatement.setDate(3, Date.valueOf(experiment.getStartDate()));
            preparedStatement.setDate(4, Date.valueOf(experiment.getEndDate()));
            preparedStatement.setInt(5, experiment.getExperimentId());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected == 0) {
                throw new DataNotFoundException("Experiment with ID " + experiment.getExperimentId() + " not found.");
            }
        }
    }

    public boolean deleteExperiment(int id) throws DataNotFoundException {
        String query = "DELETE FROM Experiment WHERE experiment_id = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, id);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected == 0) {
                throw new DataNotFoundException("Experiment with ID " + id + " not found.");
            }
        }catch (SQLException e){
            System.out.println("Error deleting: " + e.getMessage());
            return false;
        }
        return true;
    }

    public boolean deleteAllExperiments() throws DataNotFoundException{
        String query = "DELETE FROM Experiment";
        try(Connection connection = DatabaseConnection.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(query)){
            int rowsAffected = preparedStatement.executeUpdate();
            if(rowsAffected == 0){
                throw new DataNotFoundException("No experiments were found.");
            }
        } catch (SQLException e) {
            System.out.println("Error while deleting: " + e.getMessage());
            return false;
        }
        return true;
    }

    public Sample getSampleByExperimentId(int id) throws SQLException, DataNotFoundException {
        String fetchQuery = "SELECT * FROM Sample WHERE experiment_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
        PreparedStatement preparedStatement = connection.prepareStatement(fetchQuery)) {
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();

            if(resultSet.next()){
                return new Sample(
                        resultSet.getInt("sample_id"),
                        resultSet.getString("name"),
                        resultSet.getString("type"),
                        resultSet.getInt("quantity"),
                        resultSet.getInt("experiment_id")
                );
            }
            else{
                throw new DataNotFoundException("Sample with Experiment ID " + id + " not found.");
            }
        }
    }
}
