package com.dataManagementSystem.main;

import com.dataManagementSystem.managers.ExperimentManager;
import com.dataManagementSystem.managers.Manager;
import com.dataManagementSystem.managers.ResearcherManager;
import com.dataManagementSystem.managers.SampleManager;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        menu(); // Start the menu-driven console application
    }

    // Method to start the menu-driven application
    private static void menu() {
        Scanner scanner = new Scanner(System.in);

        // Instances for handling CRUD operations of different sections
        ExperimentManager experimentManager = new ExperimentManager();
        SampleManager sampleManager = new SampleManager();
        ResearcherManager researcherManager = new ResearcherManager();

        while (true) {
            System.out.println("Data Management System");
            System.out.println("1. Manage Experiments \n2. Manage Samples \n3. Manage Researchers \n4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            if(handleMainMenuChoice(choice, experimentManager, sampleManager, researcherManager, scanner)) break;
        }
    }

    // Handle main menu choices
    private static boolean handleMainMenuChoice(int choice, ExperimentManager experimentManager,
                                                SampleManager sampleManager, ResearcherManager researcherManager, Scanner scanner) {
        switch (choice) {
            case 1:
                manageSection("Experiments", experimentManager, scanner);
                break;
            case 2:
                manageSection("Samples", sampleManager, scanner);
                break;
            case 3:
                manageSection("Researchers", researcherManager, scanner);
                break;
            case 4:
                System.out.println("Exiting the application ...");
                return true;
            default:
                System.out.println("Invalid command: Please try again");
        }
        return false;
    }

    // Generic method to manage different sections
    private static void manageSection(String sectionName, Manager manager, Scanner scanner) {
        while (true) {
            // print the common menu for each section
            printSectionMenu(sectionName);
            // take user's choice of operation to be performed on particular section
            int choice = scanner.nextInt();

            if (handleSectionChoice(choice, manager)) break;
        }
    }

    // Print section-specific menu
    private static void printSectionMenu(String sectionName) {
        System.out.printf("Manage %s:\n", sectionName);
        System.out.println("1. Add new " + sectionName + " \n2. View all " + sectionName + "s \n3. View " + sectionName + " Details \n4. Update " + sectionName + " \n5. Delete " + sectionName + " \n6. Delete All " + sectionName + "s \n7. Back to com.dataManagementSystem.main.Main Menu");
        System.out.print("Enter your choice: ");
    }

    // Handle choices for sections
    private static boolean handleSectionChoice(int choice, Manager manager) {
        switch (choice) {
            case 1:
                manager.add();         // calling interface method to add a new record to the section
                break;
            case 2:
                manager.viewAll();     // calling interface method to view all records in the section
                break;
            case 3:
                manager.viewDetails(); // calling interface method to view details of a particular record
                break;
            case 4:
                manager.update();      // calling interface method to update a particular record
                break;
            case 5:
                manager.delete();      // calling interface method to delete a particular record
                break;
            case 6:
                manager.deleteAll();   // calling interface method to delete all records in the section
                break;
            case 7:
                return true;           // go back to the main menu
            default:
                System.out.println("Invalid choice. Please try again.");
        }
        return false;
    }
}