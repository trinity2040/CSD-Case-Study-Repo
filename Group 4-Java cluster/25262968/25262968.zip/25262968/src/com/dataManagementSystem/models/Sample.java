package com.dataManagementSystem.models;

public class Sample {
    private int sampleId;
    private String name;
    private String type;
    private int quantity;
    private int experimentId;

    // Constructors
    public Sample() {
    }

    public Sample(String name, String type, int quantity, int experimentId) {
        this.name = name;
        this.type = type;
        this.quantity = quantity;
        this.experimentId = experimentId;
    }

    public Sample(int sampleId, String name, String type, int quantity, int experimentId) {
        this.sampleId = sampleId;
        this.name = name;
        this.type = type;
        this.quantity = quantity;
        this.experimentId = experimentId;
    }

    // Getters and Setters
    public int getSampleId() {
        return sampleId;
    }

    public void setSampleId(int sampleId) {
        this.sampleId = sampleId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getExperimentId() {
        return experimentId;
    }

    public void setExperimentId(int experimentId) {
        this.experimentId = experimentId;
    }

    @Override
    public String toString() {
        return "Sample{" +
                "sampleId=" + sampleId +
                ", name='" + name + '\'' +
                ", type='" + type + '\'' +
                ", quantity=" + quantity +
                ", experimentId=" + experimentId +
                '}';
    }
}
