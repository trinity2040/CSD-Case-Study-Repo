package com.dataManagementSystem.managers;

import com.dataManagementSystem.dao.ResearcherDAO;
import com.dataManagementSystem.models.Researcher;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class ResearcherManager implements Manager {
    // Scanner object to take user inputs
    private final Scanner scanner = new Scanner(System.in);
    private final ResearcherDAO researcherDAO = new ResearcherDAO();

    // Method to add a new researcher to the database
    @Override
    public void add() {
        System.out.println("Add the details of the new Researcher: ");

        // Taking input from the user about the details of the Researcher
        System.out.print("Enter name of the researcher: ");
        String name = scanner.nextLine();
        System.out.print("Enter email of the researcher: ");
        String email = scanner.nextLine();
        System.out.print("Enter phone number of the researcher: ");
        String phone_number = scanner.nextLine();
        System.out.print("Enter specialization of the researcher: ");
        String specialization = scanner.nextLine();

        Researcher researcher = new Researcher(name, email, phone_number, specialization);

        researcherDAO.addResearcher(researcher);
        System.out.println("Researcher added successfully.");
    }

    // Method to view all researchers in the database
    @Override
    public void viewAll() {
        System.out.println("ResearcherId | Name | Email | Phone | Specialization");
        try {
            List<Researcher> researcherList = researcherDAO.getAllResearchers();
            printResearchers(researcherList);
        } catch (SQLException e) {
            System.out.println("Error while viewing all researchers: " + e.getMessage());
        }
    }

    // Method to view details of a specific researcher based on ID
    @Override
    public void viewDetails() {
        // Taking ID as input from user to fetch the researcher
        System.out.print("Enter the ID of the researcher: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over

        try {
            Researcher researcher = researcherDAO.getResearcherById(id);
            if (researcher != null) {
                printResearcher(researcher);
            } else {
                System.out.println("Researcher not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error while viewing details: " + e.getMessage());
        }
    }

    // Method to update details of an existing researcher
    @Override
    public void update() {
        // Taking ID as user input to fetch the researcher
        System.out.print("Enter the ID of the researcher to be updated: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume the leftover newline

        // Variables to store updated values, initially empty
        String name = "";
        String email = "";
        String phone_number = "";
        String specialization = "";

        boolean exit = false; // Control flag for the update menu

        // Update menu loop
        while (!exit) {
            System.out.println("Select the option to update existing information: ");
            System.out.println("1. Name \n2. Email \n3. Phone number \n4. Specialization \n5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the leftover newline

            switch (choice) {
                case 1:
                    System.out.print("Enter the new name of the researcher: ");
                    name = scanner.nextLine();
                    break;
                case 2:
                    System.out.print("Enter the new email of the researcher: ");
                    email = scanner.nextLine();
                    break;
                case 3:
                    System.out.print("Enter the new phone number of the researcher: ");
                    phone_number = scanner.nextLine();
                    break;
                case 4:
                    System.out.print("Enter the new specialization of the researcher: ");
                    specialization = scanner.nextLine();
                    break;
                case 5:
                    System.out.println("Exiting update process.");
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }

        try {
            Researcher researcher = researcherDAO.getResearcherById(id);
            if (researcher != null) {
                // Update only if a new value is provided
                if (!name.isEmpty()) researcher.setName(name);
                if (!email.isEmpty()) researcher.setEmail(email);
                if (!phone_number.isEmpty()) researcher.setPhoneNumber(phone_number);
                if (!specialization.isEmpty()) researcher.setSpecialization(specialization);

                researcherDAO.updateResearcher(researcher);
                System.out.println("Researcher updated successfully.");
            } else {
                System.out.println("No researcher found with the given id: " + id);
            }
        } catch (SQLException e) {
            System.out.println("Error while updating researcher: " + e.getMessage());
        }
    }

    // Method to delete a specific researcher based on ID
    @Override
    public void delete() {
        // Taking ID as user input to delete the researcher
        System.out.print("Enter the ID of the researcher to be deleted: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume newline left-over
        if (researcherDAO.deleteResearcher(id)) {
            System.out.println("Researcher deleted successfully.");
        } else {
            System.out.println("Failed to delete the researcher. Please check the ID and try again.");
        }

    }

    // Method to delete all researchers from the database
    public void deleteAll() {
        if (researcherDAO.deleteAllResearchers()) System.out.println(" researchers deleted successfully.");
        else System.out.println("No researchers found to delete.");

    }

// Helper functions

    private void printResearchers(List<Researcher> researchers) {
        for (Researcher researcher : researchers) {
            printResearcher(researcher);
        }
    }

    private void printResearcher(Researcher researcher) {
        System.out.println(researcher.getResearcherId() + " | " + researcher.getName() + " | " +
                researcher.getEmail() + " | " + researcher.getPhoneNumber() + " | " + researcher.getSpecialization());
    }
}
