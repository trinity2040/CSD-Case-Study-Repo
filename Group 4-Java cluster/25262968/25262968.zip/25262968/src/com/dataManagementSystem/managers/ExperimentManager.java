package com.dataManagementSystem.managers;

import com.dataManagementSystem.dao.ExperimentDAO;
import com.dataManagementSystem.dao.SampleDAO;
import com.dataManagementSystem.models.Experiment;
import com.dataManagementSystem.models.Sample;

import java.sql.*;
import java.util.List;
import java.util.Scanner;

import static java.time.LocalDate.parse;

public class ExperimentManager implements Manager {
    // Scanner object to take user inputs
    Scanner scanner = new Scanner(System.in);
    ExperimentDAO experimentDAO = new ExperimentDAO();

    // Method to add a new experiment to the database
    @Override
    public void add() {
        // Taking input from the user about the details of the Experiment
        System.out.println("Add the details of the new Experiment: ");
        System.out.print("Enter name of the experiment: ");
        String name = scanner.nextLine();
        System.out.print("\nEnter description of the experiment: ");
        String description = scanner.nextLine();
        System.out.print("\nEnter start date (yyyy-mm-dd) of the experiment: ");
        String startDate = scanner.nextLine();
        System.out.print("\nEnter end date (yyyy-mm-dd) of the experiment: ");
        String endDate = scanner.nextLine();

        Experiment experiment = new Experiment(name, description, parse(startDate), parse(endDate));
        try {
            experimentDAO.addExperiment(experiment);
            System.out.println("\nExperiment added successfully.");
        } catch (SQLException e) {
            System.out.println("Error while adding new experiment to the database: " + e.getMessage());
        }
    }

    // Method to view all experiments in the database
    @Override
    public void viewAll() {
        // SQL query to view all the experiments in the experiments table
        System.out.println("ExperimentId | Name | \tDescription\t | Start Date | End Date");

        try {
            List<Experiment> experiments = experimentDAO.getAllExperiments();
            printExperiments(experiments);
        } catch (SQLException e) {
            System.out.println("Error while retrieving the experiments: " + e.getMessage());
        }
    }

    private void printExperiments(List<Experiment> experiments) {
        for (Experiment experiment : experiments) {
            printExperiment(experiment);
        }
    }

    // Method to view details of a specific experiment based on ID
    @Override
    public void viewDetails() {
        // taking experiment_id as input from user to fetch the experiment
        System.out.println("Enter the id of the experiment: ");
        int id = scanner.nextInt();
        System.out.println("ExperimentId | Name | \tDescription\t | Start Date | End Date");

        try {
            Experiment experiment = experimentDAO.getExperimentById(id);
            if (experiment != null) {
                printExperiment(experiment);
            }
        } catch (SQLException e) {
            System.out.println("Error while retrieving the details of the Experiment: " + e.getMessage());
        }
    }

    // Method to update details of an existing experiment
    @Override
    public void update() {
        // taking experiment_id as input from user to fetch the experiment
        System.out.println("Enter the id of the experiment to be updated: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume the leftover newline
        try {
            Experiment experiment = experimentDAO.getExperimentById(id);
            String name;
            String description;
            String startDate;
            String endDate;

            boolean exit = false; // Control flag for the update menu

            while (!exit) {
                System.out.println("Select the option to update existing information: ");
                System.out.println("1. Name \n2. Description \n3. Start Date \n4. End Date \n5. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // consume the leftover newline

                switch (choice) {
                    case 1:
                        System.out.println("Enter the new name of the experiment: ");
                        name = scanner.nextLine();
                        experiment.setName(name);
                        break;
                    case 2:
                        System.out.println("Enter the new description of the experiment: ");
                        description = scanner.nextLine();
                        experiment.setDescription(description);
                        break;
                    case 3:
                        System.out.println("Enter the new start date of the experiment: ");
                        startDate = scanner.nextLine();
                        experiment.setStartDate(parse(startDate));
                        break;
                    case 4:
                        System.out.println("Enter the new end date of the experiment: ");
                        endDate = scanner.nextLine();
                        experiment.setEndDate(parse(endDate));
                        break;
                    case 5:
                        System.out.println("Exiting the update process.");
                        exit = true;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
            experimentDAO.updateExperiment(experiment);
            System.out.println("Experiment updated successfully.");
            System.out.println("Do you want update sample from experiment: (y/n)");
            String choice = scanner.nextLine();
            if (choice.equalsIgnoreCase("y")) updateSamplesForExperiment(id);
            else System.out.println("Task Completed.");

        } catch (SQLException e) {
            System.out.println("Error while updating the experiment: " + e.getMessage());
        }
    }

    // Method to delete a specific experiment based on ID
    @Override
    public void delete() {
        // taking experiment_id as input from user to fetch the experiment
        System.out.println("Enter the id of the experiment to be deleted: ");
        int id = scanner.nextInt();

        if (experimentDAO.deleteExperiment(id)) {
            System.out.println("Experiment deleted successfully.");
        } else {
            System.out.println("Experiment delete failed");
        }
    }

    // Method to delete all Experiments
    @Override
    public void deleteAll() {
        if (experimentDAO.deleteAllExperiments()) {
            System.out.println("Experiment deleted successfully.");
        } else {
            System.out.println("Experiment delete failed");
        }
    }

    // Method to update associated samples
    public void updateSamplesForExperiment(int experimentId) {
        SampleDAO sampleDAO = new SampleDAO();
        try {
            Sample sample = experimentDAO.getSampleByExperimentId(experimentId);
            String name;
            String type;
            int quantity;
            int experiment_id;

            boolean exit = false; // Control flag for the update menu

            while (!exit) {
                System.out.println("Select the option to update existing information: ");
                System.out.println("1. Name \n2. Type \n3. Experiment number \n4. Quantity \n5. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // consume the leftover newline

                switch (choice) {
                    case 1:
                        System.out.println("Enter name of the sample: ");
                        name = scanner.nextLine();
                        sample.setName(name);
                        break;
                    case 2:
                        System.out.println("Enter type of the sample: ");
                        type = scanner.nextLine();
                        sample.setType(type);
                        break;
                    case 3:
                        System.out.println("Enter experiment id related to the sample: ");
                        experiment_id = scanner.nextInt();
                        sample.setExperimentId(experiment_id);
                        break;
                    case 4:
                        System.out.println("Enter quantity of the sample: ");
                        quantity = scanner.nextInt();
                        sample.setQuantity(quantity);
                        break;
                    case 5:
                        System.out.println("Exiting the update process.");
                        exit = true;
                        break;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
            sampleDAO.updateSample(sample);
        } catch (SQLException e) {
            System.out.println("Error while retrieving the samples associated with this experiment: " + e.getMessage());
        }
    }

    // helper-functions

    private void printExperiment(Experiment experiment) {
        System.out.println(experiment.getExperimentId() + " | " + experiment.getName() + " | " + experiment.getDescription() + " | " + experiment.getStartDate() + " | " + experiment.getEndDate());
    }

}
