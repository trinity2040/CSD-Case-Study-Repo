package com.dataManagementSystem.managers;

import com.dataManagementSystem.dao.SampleDAO;
import com.dataManagementSystem.models.Sample;

import java.sql.*;
import java.util.List;
import java.util.Scanner;

public class SampleManager implements Manager {
    // Scanner object to take user inputs
    Scanner scanner = new Scanner(System.in);
    private final SampleDAO sampleDAO = new SampleDAO();

    // Method to add a new Sample to the database
    @Override
    public void add() {
        // Taking input from the user about the details of the Sample
        System.out.println("Add the details of the new sample: ");
        System.out.println("Enter name of the sample: ");
        String name = scanner.nextLine();
        System.out.println("Enter type of the sample: ");
        String type = scanner.nextLine();
        System.out.println("Enter quantity of the sample: ");
        int quantity = scanner.nextInt();
        System.out.println("Enter experiment id related to the sample: ");
        int experiment_id = scanner.nextInt();

        Sample sample = new Sample(name, type, quantity, experiment_id);
        try {
            sampleDAO.addSample(sample);
            System.out.println("Sample added successfully!");
        } catch (SQLException e) {
            System.out.println("Error adding sample:" + e.getMessage());
        }
    }

    // Method to view all Samples
    @Override
    public void viewAll() {

        System.out.println("Sample_ID | Experiment ID | Name | Type | Quantity");
        try {
            List<Sample> sampleList = sampleDAO.getAllSamples();
            printSamples(sampleList);
        } catch (SQLException e) {
            System.out.println("Error while viewing all samples: " + e.getMessage());
        }
    }

    // Method to view Sample based on ID
    @Override
    public void viewDetails() {
        // taking sample id as input from user to fetch the sample
        System.out.println("Enter the id of the required sample: ");
        int id = scanner.nextInt();

        try {
            Sample sample = sampleDAO.getSampleById(id);
            if (sample != null) {
                printSample(sample);
            }
        } catch (SQLException e) {
            System.out.println("Error while viewing sample: " + e.getMessage());
        }
    }

    // Method to update details of an existing sample
    @Override
    public void update() {
        // taking id as input from user to fetch the experiment
        System.out.println("Enter the id of the sample to be updated: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consume the leftover newline

        // Variables to store updated values, initially empty
        String name = "";
        String type = "";
        int quantity = 0;
        int experiment_id = 0;

        boolean exit = false; // Control flag for the update menu

        while (!exit) {
            System.out.println("Select the option to update existing information: ");
            System.out.println("1. Name \n2. Type \n3. Experiment number \n4. Quantity \n5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume the leftover newline

            switch (choice) {
                case 1:
                    System.out.println("Enter name of the sample: ");
                    name = scanner.nextLine();
                    break;
                case 2:
                    System.out.println("Enter type of the sample: ");
                    type = scanner.nextLine();
                    break;
                case 3:
                    System.out.println("Enter experiment id related to the sample: ");
                    experiment_id = scanner.nextInt();
                    break;
                case 4:
                    System.out.println("Enter quantity of the sample: ");
                    quantity = scanner.nextInt();
                    break;
                case 5:
                    System.out.println("Exiting the update process.");
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        try {
            Sample sample = sampleDAO.getSampleById(id);
            if (sample != null) {
                if (name.isEmpty()) sample.setName(name);
                if (type.isEmpty()) sample.setType(type);
                if (experiment_id == 0) sample.setExperimentId(experiment_id);
                if (quantity == 0) sample.setQuantity(quantity);

                sampleDAO.updateSample(sample);
                System.out.println("Sample updated successfully.");
            } else {
                System.out.println("Sample not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error while updating sample: " + e.getMessage());
        }
    }

    // Method to delete a specific sample based on ID
    @Override
    public void delete() {
        //taking id as input from user to fetch the sample
        System.out.println("Enter the id of the sample to be deleted: ");
        int id = scanner.nextInt();
        if (sampleDAO.deleteSample(id)) {
            System.out.println("Sample deleted successfully.");
        } else {
            System.out.println("Sample delete failed. Please check the id and try again.");
        }
    }

    // Method to delete all samples
    @Override
    public void deleteAll() {
        if (sampleDAO.deleteAllSamples()) {
            System.out.println("Samples deleted successfully.");
        }
        else {
            System.out.println("Samples delete failed.");
        }
    }

    // helper functions

    private void printSamples(List<Sample> samples) {
        for (Sample sample : samples) {
            printSample(sample);
        }
    }

    private void printSample(Sample sample) {
        System.out.println(sample.getSampleId() + " | " + sample.getExperimentId() + " | " + sample.getName() + " | " + sample.getType() + " | " + sample.getQuantity());
    }
}
