# Case Study: Research Lab Data Management System

## Objective:

<p> 
    Develop a menu-based console application to manage Experiments, Samples and Researchers.
    The application uses Core Java for the backend logic, MySQL database and JDBC for database interaction.
</p>

## Prerequisites

1. Java Development Kit (JDK) 8 or
   higher [Download JDK](https://www.oracle.com/java/technologies/javase-jdk11-downloads.html)
2. MySQL 5.7 or higher [Download MySQL](https://dev.mysql.com/downloads/mysql/)
3. MySQL connector/J [Download JDBC Driver](https://dev.mysql.com/downloads/connector/j/)

## Project Setup

1. Clone the repository to the local system and move into the cloned repository
   ```bash
   git clone "https://github.com/username/repositoryname.git"
   ```
2. **Create the database**:
    ```sql
    CREATE DATABASE data_management_system;
    USE data_management_system;
    ```
   1. **Create the Tables keeping in mind the database schema**
       1. Create Researcher Table
          ```sql
          CREATE TABLE Researcher (
          researcher_id INT PRIMARY KEY AUTO_INCREMENT,
          name VARCHAR(255) NOT NULL,
          email VARCHAR(255) NOT NULL,
          phone_number VARCHAR(20),
          specialization VARCHAR(255)
          );
          ```
       2. Create Experiment Table
          ```sql
          CREATE TABLE Experiment (
          experiment_id INT PRIMARY KEY AUTO_INCREMENT,
          name VARCHAR(255) NOT NULL,
          description TEXT,
          start_date DATE,
          end_date DATE
          );
          ```
       3. Create Sample Table
         ```sql 
         CREATE TABLE Sample (
         sample_id INT PRIMARY KEY AUTO_INCREMENT,
         name VARCHAR(255) NOT NULL,
         type VARCHAR(50) NOT NULL,
         quantity INT NOT NULL,
         experiment_id INT,
         FOREIGN KEY (experiment_id) REFERENCES Experiment(experiment_id)
         );
         ```
3. **Import MySQL Connector/J in your project** :
   Right-click on the project → Open Module Settings → Libraries → Click + → Select the downloaded JAR file.
4. Update your MySQL Credentials in the `main.com.dataManagementSystem.service.DatabaseConnection.java` file.
   ```java
   private static final String db_user = "root";
   private static final String db_pass = "password"; // change to your password
   ```
5. Compile and Run the application. (If using an IDE, simply run the `main.com.dataManagementSystem.Main.java` file).
    1. Compile the Java Classes
       ```bash
         javac src/main/com/dataManagementSystem/Main.java;
       ```
    2. Run the java Class
       ```bash
          java src/main/com/dataManagementSystem/Main
       ```

## Usage Instructions:

1. Launch the application and interact with the menu to manage experiments, samples, and researchers.
2. Add, view, update, or delete records as required.
3. Ensure that sample data is correctly associated with experiments, and updates are reflected based on the requirements
   of the experiments.
4. **Available actions**
   ### 1. Experiment Management:
         -  Add a new experiment
         -  View experiment details
         -  Update experiment information
         -  Delete an experiment
         -  Delete all experiments
         -  Update sample quantity using experiment id.

   ### 2. Sample Management:
         -  Add a new sample
         -  View sample details
         -  Update sample information
         -  Delete a sample
         -  Delete all samples

   ### 3. Researcher Management:
         -  Add a new researcher
         -  View researcher details
         -  Update researcher information
         -  Delete a researcher
         -  Delete all researchers
## Publishing
To publish the project to git follow the following steps:
1. Add all the changes to the staging area
   ```bash
    git add .
   ```
2. Commit the changes with a commit message
   ```bash 
   git commit -m "message"
   ```
3. Push your changes to the forked repository
   ```bash
   git push origin main
   ```