package com.cts.exceptions;

public class EquipmentNotFoundException extends Exception {
    public EquipmentNotFoundException(int equipmentId) {
        super("Equipment with ID " + equipmentId + " was not found. Please verify the ID and try again.");
    }

    public EquipmentNotFoundException(int equipmentId, Throwable cause) {
        super("Equipment with ID " + equipmentId + " was not found. Please verify the ID and try again.", cause);
    }
}
