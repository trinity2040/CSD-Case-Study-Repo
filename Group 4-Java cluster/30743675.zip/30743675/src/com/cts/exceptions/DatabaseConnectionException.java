package com.cts.exceptions;

public class DatabaseConnectionException extends Exception {
    public DatabaseConnectionException() {
        super("Unable to connect to the database. Please check your network connection and database settings.");
    }

    public DatabaseConnectionException(Throwable cause) {
        super("Unable to connect to the database. Please check your network connection and database settings.", cause);
    }
}
