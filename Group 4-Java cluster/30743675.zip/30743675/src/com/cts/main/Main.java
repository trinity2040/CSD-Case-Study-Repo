package com.cts.main;

import com.cts.dao.EquipmentDAO;
import com.cts.dao.MaintenanceScheduleDAO;
import com.cts.dao.MaintenanceLogDAO;
import com.cts.model.Equipment;
import com.cts.model.MaintenanceSchedule;
import com.cts.model.MaintenanceLog;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static Scanner scanner = new Scanner(System.in);
    private static EquipmentDAO equipmentDAO = new EquipmentDAO();
    private static MaintenanceScheduleDAO scheduleDAO = new MaintenanceScheduleDAO();
    private static MaintenanceLogDAO logDAO = new MaintenanceLogDAO();

    public static void main(String[] args) {
        while (true) {
            printMainMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            try {
                switch (choice) {
                    case 1:
                        manageEquipment();
                        break;
                    case 2:
                        manageMaintenanceSchedule();
                        break;
                    case 3:
                        manageMaintenanceLog();
                        break;
                    case 4:
                        System.out.println("Exiting the application. Goodbye!");
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (SQLException e) {
                System.err.println("An error occurred while processing your request: " + e.getMessage());
            }
        }
    }

    private static void printMainMenu() {
        System.out.println("\n=== Maintenance Management System ===");
        System.out.println("1. Manage Equipment");
        System.out.println("2. Manage Maintenance Schedules");
        System.out.println("3. Manage Maintenance Logs");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void manageEquipment() throws SQLException {
        System.out.println("\n=== Equipment Management ===");
        System.out.println("1. Add New Equipment");
        System.out.println("2. View Equipment Details");
        System.out.println("3. Update Equipment Information");
        System.out.println("4. Delete Equipment");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline

        switch (choice) {
            case 1:
                addEquipment();
                break;
            case 2:
                viewEquipment();
                break;
            case 3:
                updateEquipment();
                break;
            case 4:
                deleteEquipment();
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void addEquipment() throws SQLException {
        System.out.print("Enter equipment name: ");
        String name = scanner.nextLine();
        System.out.print("Enter equipment description: ");
        String description = scanner.nextLine();
        System.out.print("Enter purchase date (YYYY-MM-DD): ");
        String purchaseDate = scanner.nextLine();
        System.out.print("Enter equipment status (active/inactive): ");
        String status = scanner.nextLine();

        Equipment equipment = new Equipment(name, description, purchaseDate, status);
        equipmentDAO.addEquipment(equipment);
        System.out.println("Equipment added successfully.");
    }

    private static void viewEquipment() throws SQLException {
        System.out.print("Enter equipment ID to view details: ");
        int equipmentId = scanner.nextInt();
        Equipment equipment = equipmentDAO.getEquipmentById(equipmentId);
        if (equipment != null) {
            System.out.println(equipment);
        } else {
            System.out.println("Equipment not found.");
        }
    }

    private static void updateEquipment() throws SQLException {
        System.out.print("Enter equipment ID to update: ");
        int equipmentId = scanner.nextInt();
        scanner.nextLine(); // consume newline

        Equipment equipment = equipmentDAO.getEquipmentById(equipmentId);
        if (equipment != null) {
            System.out.print("Enter new equipment name (current: " + equipment.getName() + "): ");
            String name = scanner.nextLine();
            System.out.print("Enter new equipment description (current: " + equipment.getDescription() + "): ");
            String description = scanner.nextLine();
            System.out.print("Enter new purchase date (current: " + equipment.getPurchaseDate() + "): ");
            String purchaseDate = scanner.nextLine();
            System.out.print("Enter new equipment status (current: " + equipment.getStatus() + "): ");
            String status = scanner.nextLine();

            equipment.setName(name);
            equipment.setDescription(description);
            equipment.setPurchaseDate(purchaseDate);
            equipment.setStatus(status);

            equipmentDAO.updateEquipment(equipment);
            System.out.println("Equipment updated successfully.");
        } else {
            System.out.println("Equipment not found.");
        }
    }

    private static void deleteEquipment() throws SQLException {
        System.out.print("Enter equipment ID to delete: ");
        int equipmentId = scanner.nextInt();
        equipmentDAO.deleteEquipment(equipmentId);
        System.out.println("Equipment deleted successfully.");
    }

    private static void manageMaintenanceSchedule() throws SQLException {
        System.out.println("\n=== Maintenance Schedule Management ===");
        System.out.println("1. Schedule Maintenance");
        System.out.println("2. View Maintenance Schedules");
        System.out.println("3. Update Maintenance Schedule");
        System.out.println("4. Cancel Maintenance Schedule");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline

        switch (choice) {
            case 1:
                scheduleMaintenance();
                break;
            case 2:
                viewMaintenanceSchedules();
                break;
            case 3:
                updateMaintenanceSchedule();
                break;
            case 4:
                cancelMaintenanceSchedule();
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void scheduleMaintenance() throws SQLException {
        System.out.print("Enter equipment ID for maintenance: ");
        int equipmentId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Enter scheduled date (YYYY-MM-DD): ");
        String scheduledDate = scanner.nextLine();
        System.out.print("Enter maintenance status (scheduled/completed/cancelled): ");
        String status = scanner.nextLine();

        MaintenanceSchedule schedule = new MaintenanceSchedule(equipmentId, scheduledDate, status);
        scheduleDAO.addMaintenanceSchedule(schedule);
        System.out.println("Maintenance scheduled successfully.");
    }

    private static void viewMaintenanceSchedules() throws SQLException {
        List<MaintenanceSchedule> schedules = scheduleDAO.getAllSchedules();
        if (!schedules.isEmpty()) {
            schedules.forEach(System.out::println);
        } else {
            System.out.println("No maintenance schedules found.");
        }
    }

    private static void updateMaintenanceSchedule() throws SQLException {
        System.out.print("Enter schedule ID to update: ");
        int scheduleId = scanner.nextInt();
        scanner.nextLine(); // consume newline

        MaintenanceSchedule schedule = scheduleDAO.getScheduleById(scheduleId);
        if (schedule != null) {
            System.out.print("Enter new equipment ID (current: " + schedule.getEquipmentId() + "): ");
            int equipmentId = scanner.nextInt();
            scanner.nextLine(); // consume newline
            System.out.print("Enter new scheduled date (current: " + schedule.getScheduledDate() + "): ");
            String scheduledDate = scanner.nextLine();
            System.out.print("Enter new status (current: " + schedule.getStatus() + "): ");
            String status = scanner.nextLine();

            schedule.setEquipmentId(equipmentId);
            schedule.setScheduledDate(scheduledDate);
            schedule.setStatus(status);

            scheduleDAO.updateMaintenanceSchedule(schedule);
            System.out.println("Maintenance schedule updated successfully.");
        } else {
            System.out.println("Schedule not found.");
        }
    }

    private static void cancelMaintenanceSchedule() throws SQLException {
        System.out.print("Enter schedule ID to cancel: ");
        int scheduleId = scanner.nextInt();
        scheduleDAO.deleteMaintenanceSchedule(scheduleId);
        System.out.println("Maintenance schedule cancelled successfully.");
    }

    private static void manageMaintenanceLog() throws SQLException {
        System.out.println("\n=== Maintenance Log Management ===");
        System.out.println("1. Log Maintenance Activity");
        System.out.println("2. View Maintenance Logs");
        System.out.println("3. Update Maintenance Log");
        System.out.println("4. Delete Maintenance Log");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline

        switch (choice) {
            case 1:
                logMaintenanceActivity();
                break;
            case 2:
                viewMaintenanceLogs();
                break;
            case 3:
                updateMaintenanceLog();
                break;
            case 4:
                deleteMaintenanceLog();
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void logMaintenanceActivity() throws SQLException {
        System.out.print("Enter equipment ID for maintenance: ");
        int equipmentId = scanner.nextInt();
        scanner.nextLine(); // consume newline
        System.out.print("Enter maintenance date (YYYY-MM-DD): ");
        String maintenanceDate = scanner.nextLine();
        System.out.print("Enter maintenance description: ");
        String description = scanner.nextLine();
        System.out.print("Enter technician name: ");
        String technicianName = scanner.nextLine();

        MaintenanceLog log = new MaintenanceLog(equipmentId, maintenanceDate, description, technicianName);
        logDAO.addMaintenanceLog(log);
        System.out.println("Maintenance activity logged successfully.");
    }

    private static void viewMaintenanceLogs() throws SQLException {
        List<MaintenanceLog> logs = logDAO.getAllLogs();
        if (!logs.isEmpty()) {
            logs.forEach(System.out::println);
        } else {
            System.out.println("No maintenance logs found.");
        }
    }

    private static void updateMaintenanceLog() throws SQLException {
        System.out.print("Enter log ID to update: ");
        int logId = scanner.nextInt();
        scanner.nextLine(); // consume newline

        MaintenanceLog log = logDAO.getLogById(logId);
        if (log != null) {
            System.out.print("Enter new equipment ID (current: " + log.getEquipmentId() + "): ");
            int equipmentId = scanner.nextInt();
            scanner.nextLine(); // consume newline
            System.out.print("Enter new maintenance date (current: " + log.getMaintenanceDate() + "): ");
            String maintenanceDate = scanner.nextLine();
            System.out.print("Enter new description (current: " + log.getDescription() + "): ");
            String description = scanner.nextLine();
            System.out.print("Enter new technician name (current: " + log.getTechnicianName() + "): ");
            String technicianName = scanner.nextLine();

            log.setEquipmentId(equipmentId);
            log.setMaintenanceDate(maintenanceDate);
            log.setDescription(description);
            log.setTechnicianName(technicianName);

            logDAO.updateMaintenanceLog(log);
            System.out.println("Maintenance log updated successfully.");
        } else {
            System.out.println("Log not found.");
        }
    }

    private static void deleteMaintenanceLog() throws SQLException {
        System.out.print("Enter log ID to delete: ");
        int logId = scanner.nextInt();
        logDAO.deleteMaintenanceLog(logId);
        System.out.println("Maintenance log deleted successfully.");
    }
}
