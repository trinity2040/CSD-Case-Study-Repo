package com.cts.dao;

import com.cts.model.MaintenanceLog;
import com.cts.utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MaintenanceLogDAO {

    public void addMaintenanceLog(MaintenanceLog log) throws SQLException {
        String query = "INSERT INTO MaintenanceLog (equipment_id, maintenance_date, description, technician_name) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, log.getEquipmentId());
            stmt.setDate(2, Date.valueOf(log.getMaintenanceDate()));
            stmt.setString(3, log.getDescription());
            stmt.setString(4, log.getTechnicianName());
            stmt.executeUpdate();
        }
    }

    public MaintenanceLog getLogById(int logId) throws SQLException {
        String query = "SELECT * FROM MaintenanceLog WHERE log_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, logId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new MaintenanceLog(
                        rs.getInt("log_id"),
                        rs.getInt("equipment_id"),
                        rs.getDate("maintenance_date").toString(),
                        rs.getString("description"),
                        rs.getString("technician_name")
                );
            }
        }
        return null;
    }

    public List<MaintenanceLog> getAllLogs() throws SQLException {
        String query = "SELECT * FROM MaintenanceLog";
        List<MaintenanceLog> logList = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                MaintenanceLog log = new MaintenanceLog(
                        rs.getInt("log_id"),
                        rs.getInt("equipment_id"),
                        rs.getDate("maintenance_date").toString(),
                        rs.getString("description"),
                        rs.getString("technician_name")
                );
                logList.add(log);
            }
        }
        return logList;
    }

    public void updateMaintenanceLog(MaintenanceLog log) throws SQLException {
        String query = "UPDATE MaintenanceLog SET equipment_id = ?, maintenance_date = ?, description = ?, technician_name = ? WHERE log_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, log.getEquipmentId());
            stmt.setDate(2, Date.valueOf(log.getMaintenanceDate()));
            stmt.setString(3, log.getDescription());
            stmt.setString(4, log.getTechnicianName());
            stmt.setInt(5, log.getLogId());
            stmt.executeUpdate();
        }
    }

    public void deleteMaintenanceLog(int logId) throws SQLException {
        String query = "DELETE FROM MaintenanceLog WHERE log_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, logId);
            stmt.executeUpdate();
        }
    }
}
