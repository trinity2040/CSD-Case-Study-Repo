package com.cts.dao;

import com.cts.model.Equipment;
import com.cts.utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EquipmentDAO {

    public void addEquipment(Equipment equipment) throws SQLException {
        String query = "INSERT INTO Equipment (name, description, purchase_date, status) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, equipment.getName());
            stmt.setString(2, equipment.getDescription());
            stmt.setDate(3, Date.valueOf(equipment.getPurchaseDate()));
            stmt.setString(4, equipment.getStatus());
            stmt.executeUpdate();
        }
    }

    public Equipment getEquipmentById(int equipmentId) throws SQLException {
        String query = "SELECT * FROM Equipment WHERE equipment_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, equipmentId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Equipment(
                        rs.getInt("equipment_id"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getDate("purchase_date").toString(),
                        rs.getString("status")
                );
            }
        }
        return null;
    }

    public List<Equipment> getAllEquipment() throws SQLException {
        String query = "SELECT * FROM Equipment";
        List<Equipment> equipmentList = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                Equipment equipment = new Equipment(
                        rs.getInt("equipment_id"),
                        rs.getString("name"),
                        rs.getString("description"),
                        rs.getDate("purchase_date").toString(),
                        rs.getString("status")
                );
                equipmentList.add(equipment);
            }
        }
        return equipmentList;
    }

    public void updateEquipment(Equipment equipment) throws SQLException {
        String query = "UPDATE Equipment SET name = ?, description = ?, purchase_date = ?, status = ? WHERE equipment_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, equipment.getName());
            stmt.setString(2, equipment.getDescription());
            stmt.setDate(3, Date.valueOf(equipment.getPurchaseDate()));
            stmt.setString(4, equipment.getStatus());
            stmt.setInt(5, equipment.getEquipmentId());
            stmt.executeUpdate();
        }
    }

    public void deleteEquipment(int equipmentId) throws SQLException {
        String query = "DELETE FROM Equipment WHERE equipment_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, equipmentId);
            stmt.executeUpdate();
        }
    }
}
