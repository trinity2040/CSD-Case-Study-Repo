package com.cts.dao;

import com.cts.model.MaintenanceSchedule;
import com.cts.utils.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MaintenanceScheduleDAO {

    public void addMaintenanceSchedule(MaintenanceSchedule schedule) throws SQLException {
        String query = "INSERT INTO MaintenanceSchedule (equipment_id, scheduled_date, status) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, schedule.getEquipmentId());
            stmt.setDate(2, Date.valueOf(schedule.getScheduledDate()));
            stmt.setString(3, schedule.getStatus());
            stmt.executeUpdate();
        }
    }

    public MaintenanceSchedule getScheduleById(int scheduleId) throws SQLException {
        String query = "SELECT * FROM MaintenanceSchedule WHERE schedule_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, scheduleId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new MaintenanceSchedule(
                        rs.getInt("schedule_id"),
                        rs.getInt("equipment_id"),
                        rs.getDate("scheduled_date").toString(),
                        rs.getString("status")
                );
            }
        }
        return null;
    }

    public List<MaintenanceSchedule> getAllSchedules() throws SQLException {
        String query = "SELECT * FROM MaintenanceSchedule";
        List<MaintenanceSchedule> scheduleList = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                MaintenanceSchedule schedule = new MaintenanceSchedule(
                        rs.getInt("schedule_id"),
                        rs.getInt("equipment_id"),
                        rs.getDate("scheduled_date").toString(),
                        rs.getString("status")
                );
                scheduleList.add(schedule);
            }
        }
        return scheduleList;
    }

    public void updateMaintenanceSchedule(MaintenanceSchedule schedule) throws SQLException {
        String query = "UPDATE MaintenanceSchedule SET equipment_id = ?, scheduled_date = ?, status = ? WHERE schedule_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, schedule.getEquipmentId());
            stmt.setDate(2, Date.valueOf(schedule.getScheduledDate()));
            stmt.setString(3, schedule.getStatus());
            stmt.setInt(4, schedule.getScheduleId());
            stmt.executeUpdate();
        }
    }

    public void deleteMaintenanceSchedule(int scheduleId) throws SQLException {
        String query = "DELETE FROM MaintenanceSchedule WHERE schedule_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, scheduleId);
            stmt.executeUpdate();
        }
    }
}
