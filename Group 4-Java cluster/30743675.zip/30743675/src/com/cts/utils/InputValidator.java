package com.cts.utils;

public class InputValidator {

    public static boolean isValidDate(String date) {
        // Basic validation for YYYY-MM-DD format
        return date.matches("\\d{4}-\\d{2}-\\d{2}");
    }

    public static boolean isValidStatus(String status, String[] validStatuses) {
        for (String validStatus : validStatuses) {
            if (validStatus.equalsIgnoreCase(status)) {
                return true;
            }
        }
        return false;
    }

    public static boolean isPositiveNumber(int number) {
        return number > 0;
    }
}
