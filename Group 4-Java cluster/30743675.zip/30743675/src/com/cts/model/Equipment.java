package com.cts.model;

public class Equipment {
    private int equipmentId;
    private String name;
    private String description;
    private String purchaseDate;
    private String status;

    public Equipment() {}

    public Equipment(int equipmentId, String name, String description, String purchaseDate, String status) {
        this.equipmentId = equipmentId;
        this.name = name;
        this.description = description;
        this.purchaseDate = purchaseDate;
        this.status = status;
    }

    public Equipment(String name, String description, String purchaseDate, String status) {
        this.name = name;
        this.description = description;
        this.purchaseDate = purchaseDate;
        this.status = status;
    }

    public int getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(int equipmentId) {
        this.equipmentId = equipmentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPurchaseDate() {
        return purchaseDate;
    }

    public void setPurchaseDate(String purchaseDate) {
        this.purchaseDate = purchaseDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Equipment{" +
                "equipmentId=" + equipmentId +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", purchaseDate='" + purchaseDate + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
