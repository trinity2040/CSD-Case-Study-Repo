package com.cts.model;

public class MaintenanceLog {
    private int logId;
    private int equipmentId;
    private String maintenanceDate;
    private String description;
    private String technicianName;

    public MaintenanceLog() {}

    public MaintenanceLog(int logId, int equipmentId, String maintenanceDate, String description, String technicianName) {
        this.logId = logId;
        this.equipmentId = equipmentId;
        this.maintenanceDate = maintenanceDate;
        this.description = description;
        this.technicianName = technicianName;
    }

    public MaintenanceLog(int equipmentId, String maintenanceDate, String description, String technicianName) {
        this.equipmentId = equipmentId;
        this.maintenanceDate = maintenanceDate;
        this.description = description;
        this.technicianName = technicianName;
    }

    public int getLogId() {
        return logId;
    }

    public void setLogId(int logId) {
        this.logId = logId;
    }

    public int getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(int equipmentId) {
        this.equipmentId = equipmentId;
    }

    public String getMaintenanceDate() {
        return maintenanceDate;
    }

    public void setMaintenanceDate(String maintenanceDate) {
        this.maintenanceDate = maintenanceDate;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTechnicianName() {
        return technicianName;
    }

    public void setTechnicianName(String technicianName) {
        this.technicianName = technicianName;
    }

    @Override
    public String toString() {
        return "MaintenanceLog{" +
                "logId=" + logId +
                ", equipmentId=" + equipmentId +
                ", maintenanceDate='" + maintenanceDate + '\'' +
                ", description='" + description + '\'' +
                ", technicianName='" + technicianName + '\'' +
                '}';
    }
}
