package com.cts.model;

public class MaintenanceSchedule {
    private int scheduleId;
    private int equipmentId;
    private String scheduledDate;
    private String status;

    public MaintenanceSchedule() {}

    public MaintenanceSchedule(int scheduleId, int equipmentId, String scheduledDate, String status) {
        this.scheduleId = scheduleId;
        this.equipmentId = equipmentId;
        this.scheduledDate = scheduledDate;
        this.status = status;
    }

    public MaintenanceSchedule(int equipmentId, String scheduledDate, String status) {
        this.equipmentId = equipmentId;
        this.scheduledDate = scheduledDate;
        this.status = status;
    }

    public int getScheduleId() {
        return scheduleId;
    }

    public void setScheduleId(int scheduleId) {
        this.scheduleId = scheduleId;
    }

    public int getEquipmentId() {
        return equipmentId;
    }

    public void setEquipmentId(int equipmentId) {
        this.equipmentId = equipmentId;
    }

    public String getScheduledDate() {
        return scheduledDate;
    }

    public void setScheduledDate(String scheduledDate) {
        this.scheduledDate = scheduledDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "MaintenanceSchedule{" +
                "scheduleId=" + scheduleId +
                ", equipmentId=" + equipmentId +
                ", scheduledDate='" + scheduledDate + '\'' +
                ", status='" + status + '\'' +
                '}';
    }
}
