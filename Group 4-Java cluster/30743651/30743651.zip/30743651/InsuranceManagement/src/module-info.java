/**
 * 
 */
/**
 * 
 */
module InsuranceManagement {
	requires java.sql;
}