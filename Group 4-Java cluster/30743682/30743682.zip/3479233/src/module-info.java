/**
 * 
 */
/**
 * 
 */
module MusicStoreManagementSystem {
	requires java.sql;
}