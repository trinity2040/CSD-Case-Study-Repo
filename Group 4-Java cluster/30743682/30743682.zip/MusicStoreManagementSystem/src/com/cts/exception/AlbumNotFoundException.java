package com.cts.exception;

public class AlbumNotFoundException extends DAOException {
    public AlbumNotFoundException(String message) {
        super(message);
    }
}
