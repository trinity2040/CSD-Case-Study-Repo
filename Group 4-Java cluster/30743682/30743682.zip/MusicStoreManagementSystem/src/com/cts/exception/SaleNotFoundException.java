package com.cts.exception;

public class SaleNotFoundException extends DAOException {
    public SaleNotFoundException(String message) {
        super(message);
    }
}
