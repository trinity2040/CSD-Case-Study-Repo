package com.cts.exception;

public class ArtistNotFoundException extends DAOException {
    

	public ArtistNotFoundException(String message) {
		super(message);
	}
}
