package com.cts.client;

import com.cts.dao.AlbumDAO;
import com.cts.dao.ArtistDAO;
import com.cts.dao.SalesDAO;
import com.cts.dao.daoimpl.AlbumDAOImpl;
import com.cts.dao.daoimpl.ArtistDAOImpl;
import com.cts.dao.daoimpl.SalesDAOImpl;
import com.cts.model.Album;
import com.cts.model.Artist;
import com.cts.model.Sales;
import com.cts.exception.AlbumNotFoundException;
import com.cts.exception.ArtistNotFoundException;
import com.cts.exception.SaleNotFoundException;

import java.util.Scanner;

//30743682
public class Main {

    private static AlbumDAO albumDAO = new AlbumDAOImpl();
    private static ArtistDAO artistDAO = new ArtistDAOImpl();
    private static SalesDAO salesDAO = new SalesDAOImpl();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("===Music Store Management System===\n");
            System.out.println("1. Manage Albums");
            System.out.println("2. Manage Artists");
            System.out.println("3. Manage Sales");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  

            switch (choice) {
                case 1:
                    manageAlbums();
                    break;
                case 2:
                    manageArtists();
                    break;
                case 3:
                    manageSales();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageAlbums() {
        while (true) {
            System.out.println("\n===Manage Albums===\n");
            System.out.println("1. Add Album");
            System.out.println("2. View Album");
            System.out.println("3. Update Album");
            System.out.println("4. Delete Album");
            System.out.println("5. Back");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  

            switch (choice) {
                case 1:
                    addAlbum();
                    break;
                case 2:
                    viewAlbum();
                    break;
                case 3:
                    updateAlbum();
                    break;
                case 4:
                    deleteAlbum();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageArtists() {
        while (true) {
            System.out.println("\n===Manage Artists===\n");
            System.out.println("1. Add Artist");
            System.out.println("2. View Artist");
            System.out.println("3. Update Artist");
            System.out.println("4. Delete Artist");
            System.out.println("5. Back");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  

            switch (choice) {
                case 1:
                    addArtist();
                    break;
                case 2:
                    viewArtist();
                    break;
                case 3:
                    updateArtist();
                    break;
                case 4:
                    deleteArtist();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageSales() {
        while (true) {
            System.out.println("\n===Manage Sales===\n");
            System.out.println("1. Record Sale");
            System.out.println("2. View Sale");
            System.out.println("3. Update Sale");
            System.out.println("4. Cancel Sale");
            System.out.println("5. Back");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  

            switch (choice) {
                case 1:
                    recordSale();
                    break;
                case 2:
                    viewSale();
                    break;
                case 3:
                    updateSale();
                    break;
                case 4:
                    cancelSale();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addAlbum() {
    	System.out.print("\nEnter Album ID: ");
        int albumId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter title: ");
        String title = scanner.nextLine();
        System.out.print("Enter artist ID: ");
        int artistId = scanner.nextInt();
        scanner.nextLine();  
        System.out.print("Enter release date (YYYY-MM-DD): ");
        String releaseDate = scanner.nextLine();
        System.out.print("Enter price: ");
        double price = scanner.nextDouble();
        scanner.nextLine();  

        Album album = new Album(albumId, title, artistId, releaseDate, price);

        try {
            albumDAO.addAlbum(album);
            System.out.println("\n===Album added successfully.===\n");
        } catch (ArtistNotFoundException e) {
            System.err.println(e.getMessage()); 
        } 

    }

    private static void viewAlbum() {
        System.out.print("\nEnter album ID: ");
        int albumId = scanner.nextInt();
        scanner.nextLine();  

        try {
            Album album = albumDAO.getAlbum(albumId);
            System.out.println("\n=== Album Details ===\n");
            System.out.println("Album ID\tTitle\t\tArtist ID\tRelease Date\tPrice");
            System.out.println("---------------------------------------------------------------");
            System.out.println(album.getAlbumId() + "\t\t" + album.getTitle() + "\t\t" + album.getArtistId() + "\t\t" + album.getReleaseDate() + "\t" + album.getPrice());
        } catch (AlbumNotFoundException e) {
            System.err.println(e.getMessage());
        }

    }

    private static void updateAlbum() {
        System.out.print("\nEnter album ID: ");
        int albumId = scanner.nextInt();
        scanner.nextLine();  

        try {
            Album album = albumDAO.getAlbum(albumId);
            System.out.print("Enter new title (current: " + album.getTitle() + "): ");
            String title = scanner.nextLine();
            System.out.print("Enter new artist ID (current: " + album.getArtistId() + "): ");
            int artistId = scanner.nextInt();
            scanner.nextLine();  
            System.out.print("Enter new release date (YYYY-MM-DD) (current: " + album.getReleaseDate() + "): ");
            String releaseDate = scanner.nextLine();
            System.out.print("Enter new price (current: " + album.getPrice() + "): ");
            double price = scanner.nextDouble();
            scanner.nextLine();  

            album.setTitle(title);
            album.setArtistId(artistId);
            album.setReleaseDate(releaseDate);
            album.setPrice(price);
            albumDAO.updateAlbum(album);
            System.out.println("\n===Album updated successfully.===\n");
        } catch (AlbumNotFoundException e) {
            System.err.println(e.getMessage());
        }
    }

    private static void deleteAlbum() {
        System.out.print("Enter album ID: ");
        int albumId = scanner.nextInt();
        scanner.nextLine();  

        try {
            albumDAO.deleteAlbum(albumId);
            System.out.println("Album deleted successfully.");
        } catch (AlbumNotFoundException e) {
            System.err.println(e.getMessage());
        }
    }

    private static void addArtist() {
    	System.out.print("\nEnter Artist ID: ");
        int artistId = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter genre: ");
        String genre = scanner.nextLine();
        System.out.print("Enter country: ");
        String country = scanner.nextLine();

        Artist artist = new Artist(artistId, name, genre, country);
        artistDAO.addArtist(artist);
        System.out.println("Artist added successfully.");
    }

    private static void viewArtist() {
        System.out.print("Enter artist ID: ");
        int artistId = scanner.nextInt();
        scanner.nextLine();  

        try {
            Artist artist = artistDAO.getArtist(artistId);
            System.out.println("\n=== Artist Details ===\n");
            System.out.println("Artist ID\tName\t\tGenre\t\tCountry");
            System.out.println("-------------------------------------------------");
            System.out.println(artist.getArtistId() + "\t\t" + artist.getName() + "\t\t" + artist.getGenre() + "\t\t" + artist.getCountry());
        } catch (ArtistNotFoundException e) {
            System.err.println(e.getMessage());
        }

    }

    private static void updateArtist() {
        System.out.print("Enter artist ID: ");
        int artistId = scanner.nextInt();
        scanner.nextLine();  

        try {
            Artist artist = artistDAO.getArtist(artistId);
            System.out.print("Enter new name (current: " + artist.getName() + "): ");
            String name = scanner.nextLine();
            System.out.print("Enter new genre (current: " + artist.getGenre() + "): ");
            String genre = scanner.nextLine();
            System.out.print("Enter new country (current: " + artist.getCountry() + "): ");
            String country = scanner.nextLine();

            artist.setName(name);
            artist.setGenre(genre);
            artist.setCountry(country);
            artistDAO.updateArtist(artist);
            System.out.println("Artist updated successfully.");
        } catch (ArtistNotFoundException e) {
            System.err.println(e.getMessage());
        }
    }

    private static void deleteArtist() {
        System.out.print("Enter artist ID: ");
        int artistId = scanner.nextInt();
        scanner.nextLine();  

        try {
            artistDAO.deleteArtist(artistId);
            System.out.println("Artist deleted successfully.");
        } catch (ArtistNotFoundException e) {
            System.err.println(e.getMessage());
        }
    }

    private static void recordSale() {
    	System.out.print("Enter Sale ID: ");
        int saleId = scanner.nextInt();
        System.out.print("Enter album ID: ");
        int albumId = scanner.nextInt();
        scanner.nextLine();  
        System.out.print("Enter sale date (YYYY-MM-DD): ");
        String saleDate = scanner.nextLine();
        System.out.print("Enter quantity sold: ");
        int quantitySold = scanner.nextInt();
        scanner.nextLine();  

        try {
            Album album = albumDAO.getAlbum(albumId);
            double totalPrice = album.getPrice() * quantitySold;
            Sales sale = new Sales(saleId, albumId, saleDate, quantitySold, totalPrice);
            salesDAO.recordSale(sale);
            System.out.println("Sale recorded successfully.");
        } catch (AlbumNotFoundException e) {
            System.err.println("Album not found. " + e.getMessage());
        }
    }

    private static void viewSale() {
        System.out.print("Enter sale ID: ");
        int saleId = scanner.nextInt();
        scanner.nextLine();  

        try {
            Sales sale = salesDAO.getSale(saleId);
            System.out.println("\n=== Sale Details ===\n");
            System.out.println("Sale ID\tAlbum ID\tSale Date\tQuantity Sold\tTotal Price");
            System.out.println("---------------------------------------------------------------");
            System.out.println(sale.getSaleId() + "\t" + sale.getAlbumId() + "\t\t" + sale.getSaleDate() + "\t" + sale.getQuantitySold() + "\t\t" + sale.getTotalPrice());
        } catch (SaleNotFoundException e) {
            System.err.println(e.getMessage());
        }

    }

    private static void updateSale() {
        System.out.print("Enter sale ID: ");
        int saleId = scanner.nextInt();
        scanner.nextLine();  

        try {
            Sales sale = salesDAO.getSale(saleId);
            System.out.print("Enter new album ID (current: " + sale.getAlbumId() + "): ");
            int albumId = scanner.nextInt();
            scanner.nextLine();  
            System.out.print("Enter new sale date (YYYY-MM-DD) (current: " + sale.getSaleDate() + "): ");
            String saleDate = scanner.nextLine();
            System.out.print("Enter new quantity sold (current: " + sale.getQuantitySold() + "): ");
            int quantitySold = scanner.nextInt();
            scanner.nextLine();  

            Album album = albumDAO.getAlbum(albumId);
            double totalPrice = album.getPrice() * quantitySold;
            sale.setAlbumId(albumId);
            sale.setSaleDate(saleDate);
            sale.setQuantitySold(quantitySold);
            sale.setTotalPrice(totalPrice);
            salesDAO.updateSale(sale);
            System.out.println("Sale updated successfully.");
        } catch (SaleNotFoundException | AlbumNotFoundException e) {
            System.err.println(e.getMessage());
        }
    }

    private static void cancelSale() {
        System.out.print("Enter sale ID: ");
        int saleId = scanner.nextInt();
        scanner.nextLine();  

        try {
            salesDAO.cancelSale(saleId);
            System.out.println("Sale cancelled successfully.");
        } catch (SaleNotFoundException e) {
            System.err.println(e.getMessage());
        }
    }
}
