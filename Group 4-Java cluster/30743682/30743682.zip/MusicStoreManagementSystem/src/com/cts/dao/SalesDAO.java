package com.cts.dao;

import java.util.List;
import com.cts.model.Sales;

public abstract class SalesDAO {
    public abstract void recordSale(Sales sale);
    public abstract Sales getSale(int saleId);
    public abstract List<Sales> getAllSales();
    public abstract void updateSale(Sales sale);
    public abstract void cancelSale(int saleId);
}
