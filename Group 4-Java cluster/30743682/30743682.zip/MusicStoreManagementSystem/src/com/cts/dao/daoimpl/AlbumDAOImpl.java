package com.cts.dao.daoimpl;

import com.cts.dao.AlbumDAO;
import com.cts.model.Album;
import com.cts.utils.DBConnection;
import com.cts.exception.AlbumNotFoundException;
import com.cts.exception.ArtistNotFoundException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AlbumDAOImpl extends AlbumDAO {

    private Connection conn;

    public AlbumDAOImpl() {
        conn = DBConnection.getConnection();
    }

    @Override
    public void addAlbum(Album album) {
        String sql = "INSERT INTO album (album_id, title, artist_id, release_date, price) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            if (!artistExists(album.getArtistId())) {
                throw new ArtistNotFoundException("\nERROR :Artist with ID " + album.getArtistId() + " not found. Pls add Artist First");
            }
            pstmt.setInt(1, album.getAlbumId());
            pstmt.setString(2, album.getTitle());
            pstmt.setInt(3, album.getArtistId());
            pstmt.setString(4, album.getReleaseDate());
            pstmt.setDouble(5, album.getPrice());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error adding album", e);
        }
    }


    private boolean artistExists(int artistId) {
    	String sql = "SELECT COUNT(*) FROM artist WHERE artist_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, artistId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error checking artist existence", e);
        }
        return false;
	}

	@Override
    public Album getAlbum(int albumId) {
        String sql = "SELECT * FROM album WHERE album_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, albumId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Album(
                    rs.getInt("album_id"),
                    rs.getString("title"),
                    rs.getInt("artist_id"),
                    rs.getString("release_date"),
                    rs.getDouble("price")
                );
            } else {
                throw new AlbumNotFoundException("\nERROR :Album with ID " + albumId + " not found.");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error retrieving album", e);
        }
    }

    @Override
    public List<Album> getAllAlbums() {
        String sql = "SELECT * FROM album";
        List<Album> albums = new ArrayList<>();
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                albums.add(new Album(
                    rs.getInt("album_id"),
                    rs.getString("title"),
                    rs.getInt("artist_id"),
                    rs.getString("release_date"),
                    rs.getDouble("price")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error retrieving albums", e);
        }
        return albums;
    }

    @Override
    public void updateAlbum(Album album) {
        String sql = "UPDATE album SET title = ?, artist_id = ?, release_date = ?, price = ? WHERE album_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, album.getTitle());
            pstmt.setInt(2, album.getArtistId());
//            pstmt.setDate(3, new java.sql.Date(album.getReleaseDate().getTime()));
            pstmt.setString(3, album.getReleaseDate());
            pstmt.setDouble(4, album.getPrice());
            pstmt.setInt(5, album.getAlbumId());
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new AlbumNotFoundException("\nERROR :Album with ID " + album.getAlbumId() + " not found.");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error updating album", e);
        }
    }

    @Override
    public void deleteAlbum(int albumId) {
        String sql = "DELETE FROM album WHERE album_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, albumId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new AlbumNotFoundException("\nERROR :Album with ID " + albumId + " not found.");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error deleting album", e);
        }
    }
}
