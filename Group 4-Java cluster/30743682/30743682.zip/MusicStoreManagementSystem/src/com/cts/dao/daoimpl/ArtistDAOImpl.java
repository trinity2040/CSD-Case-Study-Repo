package com.cts.dao.daoimpl;

import com.cts.dao.ArtistDAO;
import com.cts.model.Artist;
import com.cts.utils.DBConnection;
import com.cts.exception.ArtistNotFoundException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ArtistDAOImpl extends ArtistDAO {

    private Connection conn;

    public ArtistDAOImpl() {
        conn = DBConnection.getConnection();
    }

    @Override
    public void addArtist(Artist artist) {
        String sql = "INSERT INTO artist (name, genre, country) VALUES (?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, artist.getName());
            pstmt.setString(2, artist.getGenre());
            pstmt.setString(3, artist.getCountry());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error adding artist", e);
        }
    }

    @Override
    public Artist getArtist(int artistId) {
        String sql = "SELECT * FROM artist WHERE artist_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, artistId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Artist(
                    rs.getInt("artist_id"),
                    rs.getString("name"),
                    rs.getString("genre"),
                    rs.getString("country")
                );
            } else {
                throw new ArtistNotFoundException("Artist with ID " + artistId + " not found.");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error retrieving artist", e);
        }
    }

    @Override
    public List<Artist> getAllArtists() {
        String sql = "SELECT * FROM artist";
        List<Artist> artists = new ArrayList<>();
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                artists.add(new Artist(
                    rs.getInt("artist_id"),
                    rs.getString("name"),
                    rs.getString("genre"),
                    rs.getString("country")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error retrieving artists", e);
        }
        return artists;
    }

    @Override
    public void updateArtist(Artist artist) {
        String sql = "UPDATE artist SET name = ?, genre = ?, country = ? WHERE artist_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, artist.getName());
            pstmt.setString(2, artist.getGenre());
            pstmt.setString(3, artist.getCountry());
            pstmt.setInt(4, artist.getArtistId());
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new ArtistNotFoundException("Artist with ID " + artist.getArtistId() + " not found.");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error updating artist", e);
        }
    }

    @Override
    public void deleteArtist(int artistId) {
        String sql = "DELETE FROM artist WHERE artist_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, artistId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new ArtistNotFoundException("Artist with ID " + artistId + " not found.");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error deleting artist", e);
        }
    }
}
