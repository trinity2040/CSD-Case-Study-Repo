package com.cts.dao;

import java.util.List;
import com.cts.model.Album;

public abstract class AlbumDAO {
    public abstract void addAlbum(Album album);
    public abstract Album getAlbum(int albumId);
    public abstract List<Album> getAllAlbums();
    public abstract void updateAlbum(Album album);
    public abstract void deleteAlbum(int albumId);
}
