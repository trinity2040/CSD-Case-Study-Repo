package com.cts.dao.daoimpl;

import com.cts.dao.SalesDAO;
import com.cts.model.Sales;
import com.cts.utils.DBConnection;
import com.cts.exception.SaleNotFoundException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SalesDAOImpl extends SalesDAO {

    private Connection conn;

    public SalesDAOImpl() {
        conn = DBConnection.getConnection();
    }

    @Override
    public void recordSale(Sales sale) {
        String sql = "INSERT INTO sales (album_id, sale_date, quantity_sold, total_price) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, sale.getAlbumId());
            pstmt.setDate(2, new java.sql.Date(sale.getSaleDate().getTime()));
            pstmt.setInt(3, sale.getQuantitySold());
            pstmt.setDouble(4, sale.getTotalPrice());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error recording sale", e);
        }
    }

    @Override
    public Sales getSale(int saleId) {
        String sql = "SELECT * FROM sales WHERE sale_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, saleId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Sales(
                    rs.getInt("sale_id"),
                    rs.getInt("album_id"),
                    rs.getDate("sale_date"),
                    rs.getInt("quantity_sold"),
                    rs.getDouble("total_price")
                );
            } else {
                throw new SaleNotFoundException("Sale with ID " + saleId + " not found.");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error retrieving sale", e);
        }
    }

    @Override
    public List<Sales> getAllSales() {
        String sql = "SELECT * FROM sales";
        List<Sales> salesList = new ArrayList<>();
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                salesList.add(new Sales(
                    rs.getInt("sale_id"),
                    rs.getInt("album_id"),
                    rs.getDate("sale_date"),
                    rs.getInt("quantity_sold"),
                    rs.getDouble("total_price")
                ));
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error retrieving sales", e);
        }
        return salesList;
    }

    @Override
    public void updateSale(Sales sale) {
        String sql = "UPDATE sales SET album_id = ?, sale_date = ?, quantity_sold = ?, total_price = ? WHERE sale_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, sale.getAlbumId());
            pstmt.setDate(2, new java.sql.Date(sale.getSaleDate().getTime()));
            pstmt.setInt(3, sale.getQuantitySold());
            pstmt.setDouble(4, sale.getTotalPrice());
            pstmt.setInt(5, sale.getSaleId());
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SaleNotFoundException("Sale with ID " + sale.getSaleId() + " not found.");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error updating sale", e);
        }
    }

    @Override
    public void cancelSale(int saleId) {
        String sql = "DELETE FROM sales WHERE sale_id = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, saleId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SaleNotFoundException("Sale with ID " + saleId + " not found.");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error deleting sale", e);
        }
    }
}
