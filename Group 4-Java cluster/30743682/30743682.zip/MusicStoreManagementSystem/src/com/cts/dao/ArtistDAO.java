package com.cts.dao;

import java.util.List;
import com.cts.model.Artist;

public abstract class ArtistDAO {
    public abstract void addArtist(Artist artist);
    public abstract Artist getArtist(int artistId);
    public abstract List<Artist> getAllArtists();
    public abstract void updateArtist(Artist artist);
    public abstract void deleteArtist(int artistId);
}
