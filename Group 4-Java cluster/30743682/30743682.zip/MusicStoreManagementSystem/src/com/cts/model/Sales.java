package com.cts.model;

import java.util.Date;

public class Sales {
    private int saleId;
    private int albumId;
    private Date saleDate;
    private int quantitySold;
    private double totalPrice;

    // Constructors, Getters, and Setters
    public Sales(int saleId, int albumId, Date saleDate, int quantitySold, double totalPrice) {
        this.saleId = saleId;
        this.albumId = albumId;
        this.saleDate = saleDate;
        this.quantitySold = quantitySold;
        this.totalPrice = totalPrice;
    }

    public int getSaleId() { return saleId; }
    public void setSaleId(int saleId) { this.saleId = saleId; }

    public int getAlbumId() { return albumId; }
    public void setAlbumId(int albumId) { this.albumId = albumId; }

    public Date getSaleDate() { return saleDate; }
    public void setSaleDate(Date saleDate) { this.saleDate = saleDate; }

    public int getQuantitySold() { return quantitySold; }
    public void setQuantitySold(int quantitySold) { this.quantitySold = quantitySold; }

    public double getTotalPrice() { return totalPrice; }
    public void setTotalPrice(double totalPrice) { this.totalPrice = totalPrice; }
}
