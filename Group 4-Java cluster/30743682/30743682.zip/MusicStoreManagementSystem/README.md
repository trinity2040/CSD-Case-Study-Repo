# Music Store Management System

## Overview
The Music Store Management System is a console application developed in Core Java that simulates the management of a music store. The application allows users to manage albums, artists, and sales using a MySQL database. It features a menu-based interface for performing various operations related to albums, artists, and sales.

## Features
- **Album Management**: Add, view, update, and delete albums.
- **Artist Management**: Add, view, update, and delete artists.
- **Sales Management**: Record, view, update, and cancel sales.
- **Database Integration**: Uses MySQL for storing and managing data.
- **Custom Exceptions**: Handles errors with user-friendly messages.

## Setup Instructions

### Prerequisites
- Java Development Kit (JDK) 8 or higher
- MySQL Server
- MySQL JDBC Driver
- Eclipse IDE (optional but recommended for Java development)

### Database Setup
1. **Create the Database and Tables**
   - Open MySQL Workbench or a similar MySQL client.
   - Run the following SQL commands to create the database and tables:

     ```sql
     CREATE DATABASE MusicStore;

     USE MusicStore;

     CREATE TABLE Artist (
         artist_id INT AUTO_INCREMENT PRIMARY KEY,
         name VARCHAR(100) NOT NULL,
         genre VARCHAR(50),
         country VARCHAR(50)
     );

     CREATE TABLE Album (
         album_id INT AUTO_INCREMENT PRIMARY KEY,
         title VARCHAR(100) NOT NULL,
         artist_id INT,
         release_date DATE,
         price DECIMAL(10, 2),
         FOREIGN KEY (artist_id) REFERENCES Artist(artist_id)
     );

     CREATE TABLE Sales (
         sale_id INT AUTO_INCREMENT PRIMARY KEY,
         album_id INT,
         sale_date DATE,
         quantity_sold INT,
         total_price DECIMAL(10, 2),
         FOREIGN KEY (album_id) REFERENCES Album(album_id)
     );
     ```

### Application Setup
1. **Clone the Repository**
   - Clone the project repository from GitHub:

     ```sh
     git clone https://github.com/Ashiqjoju/Group4_CaseStudy_No_117
     ```

2. **Configure Database Connection**
   - Edit the `DBConfig` class in the `utils` package to configure the database connection settings (URL, username, password).

3. **Build and Run**
   - Import the project into your IDE (e.g., Eclipse).
   - Build the project to ensure all dependencies are resolved.
   - Run the `Main` class to start the application.

## Usage
1. **Start the Application**
   - Execute the `Main` class to launch the console-based menu.

2. **Navigate the Menu**
   - Follow the prompts to manage albums, artists, and sales. 

   - For example:
     - To add a new album, select "Manage Albums" -> "Add Album" and provide the required details.
     - To view an artist's details, select "Manage Artists" -> "View Artist" and enter the artist ID.

## Custom Exceptions
- `AlbumNotFoundException`
- `ArtistNotFoundException`
- `SaleNotFoundException`

These exceptions are thrown when attempting to perform operations on records that do not exist in the database.

