import java.util.Scanner;

public class MainClass {
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        // Initialize database connection
        DatabaseManager dbManager = new DatabaseManager();

        // Initialize managers
        PatientDAOImpl patientManager = new PatientDAOImpl(dbManager);
        DoctorDAOImpl doctorDAO = new DoctorDAOImpl(dbManager);
        MedicalRecordDAOImpl recordManager = new MedicalRecordDAOImpl(dbManager);

        // Main menu loop
        while (true) {
            displayMainMenu();
            int choice = getUserChoice();

            switch (choice) {
                case 1:
                    patientManager.manage();
                    break;
                case 2:
                    doctorDAO.manage();
                    break;
                case 3:
                    recordManager.manage();
                    break;
                case 4:
                    System.out.println("Exiting the system.");
                    dbManager.closeConnection();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void displayMainMenu() {
        System.out.println("\n--- Hospital Management System ---");
        System.out.println("1. Patient Management");
        System.out.println("2. Doctor Management");
        System.out.println("3. Medical Record Management");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    private static int getUserChoice() {
        int choice = -1;
        try {
            choice = scanner.nextInt();
        } catch (Exception e) {
            System.out.println("Invalid input. Please enter a number.");
            scanner.next(); // Clear the invalid input
        }
        return choice;
    }
}

