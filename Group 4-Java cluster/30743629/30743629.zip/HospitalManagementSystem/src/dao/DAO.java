import java.sql.SQLException;
import java.util.Scanner;

public abstract class DAO {
    protected DatabaseManager dbManager;
    protected Scanner scanner;

    public DAO(DatabaseManager dbManager) {
        this.dbManager = dbManager;
        // All subclasses are using the same scanner and opens up input field after every operation
        this.scanner = new Scanner(System.in);
    }

    // Interfaces for implementing the logic.
    // The main management loop that will be implemented by subclasses
    public abstract void manage();

    // CRUD operations to be implemented by subclasses
    protected abstract void add() throws SQLException, Exception;
    protected abstract void view() throws  SQLException, Exception;
    protected abstract void update() throws  SQLException, Exception;
    protected abstract void delete() throws  SQLException, Exception;
//
}