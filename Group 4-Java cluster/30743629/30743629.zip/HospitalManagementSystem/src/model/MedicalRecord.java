import java.sql.Date;

public class MedicalRecord {
    private int recordId;
    private int patientId;
    private int doctorId;
    private Date date;
    private String diagnosis;
    private String treatment;

    // Constructor
    public MedicalRecord(int recordId, int patientId, int doctorId, Date date, String diagnosis, String treatment) {
        this.recordId = recordId;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.date = date;
        this.diagnosis = diagnosis;
        this.treatment = treatment;
    }

    // Getters and setters
    public int getRecordId() {
        return recordId;
    }

    public void setRecordId(int recordId) {
        this.recordId = recordId;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public int getDoctorId() {
        return doctorId;
    }

    public void setDoctorId(int doctorId) {
        this.doctorId = doctorId;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getDiagnosis() {
        return diagnosis;
    }

    public void setDiagnosis(String diagnosis) {
        this.diagnosis = diagnosis;
    }

    public String getTreatment() {
        return treatment;
    }

    public void setTreatment(String treatment) {
        this.treatment = treatment;
    }

    @Override
    public String toString() {
        return "Record ID: " + recordId + "\n" +
                "Patient ID: " + patientId + "\n" +
                "DoctorId: " + doctorId+ "\n" +
                "Date: " + date+ "\n" +
                "Diagnosis: " + diagnosis+ "\n" +
                "Treatment: " + treatment + "\n";
    }
}