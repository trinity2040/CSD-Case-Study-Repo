import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MedicalRecordDAOImpl extends DAO {
    private Scanner scanner;

    // Custom Exceptions
    public static class MedicalRecordNotFoundException extends Exception {
        public MedicalRecordNotFoundException(String message) {
            super(message);
        }
    }

    public static class MedicalRecordCreationException extends Exception {
        public MedicalRecordCreationException(String message) {
            super(message);
        }
    }

    public static class MedicalRecordUpdateException extends Exception {
        public MedicalRecordUpdateException(String message) {
            super(message);
        }
    }

    public static class MedicalRecordDeletionException extends Exception {
        public MedicalRecordDeletionException(String message) {
            super(message);
        }
    }

    public MedicalRecordDAOImpl(DatabaseManager dbManager) {
        super(dbManager);
        this.scanner = new Scanner(System.in);
    }

    @Override
    public void manage() {
        while (true) {
            System.out.println("\n--- Medical Record Management ---");
            System.out.println("1. Add Medical Record");
            System.out.println("2. View Medical Record");
            System.out.println("3. Update Medical Record");
            System.out.println("4. Delete Medical Record");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            try {
                switch (choice) {
                    case 1:
                        add();
                        break;
                    case 2:
                        view();
                        break;
                    case 3:
                        update();
                        break;
                    case 4:
                        delete();
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }

    @Override
    protected void add() throws MedicalRecordCreationException {
        System.out.println("\nAdding a new medical record:");
        try {
            System.out.print("Enter patient ID: ");
            int patientId = scanner.nextInt();
            System.out.print("Enter doctor ID: ");
            int doctorId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter date (YYYY-MM-DD): ");
            String dateString = scanner.nextLine();
            Date date = Date.valueOf(dateString);
            System.out.print("Enter diagnosis: ");
            String diagnosis = scanner.nextLine();
            System.out.print("Enter treatment: ");
            String treatment = scanner.nextLine();

            String query = "INSERT INTO medicalrecord (patient_id, doctor_id, date, diagnosis, treatment) VALUES (?, ?, ?, ?, ?)";
            int rowsAffected = dbManager.executeUpdate(query, patientId, doctorId, date, diagnosis, treatment);
            if (rowsAffected > 0) {
                System.out.println("Medical record added successfully.");
            } else {
                throw new MedicalRecordCreationException("Failed to add medical record.");
            }
        } catch (SQLException e) {
            throw new MedicalRecordCreationException("Error adding medical record: " + e.getMessage());
        }
    }

    @Override
    protected void view() throws MedicalRecordNotFoundException {
        System.out.print("\nEnter record ID to view (or 0 to view all): ");
        int recordId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query;
        if (recordId == 0) {
            query = "SELECT * FROM medicalrecord";
        } else {
            query = "SELECT * FROM medicalrecord WHERE record_id = ?";
        }

        try {
            ResultSet rs = recordId == 0 ? dbManager.executeQuery(query) : dbManager.executeQuery(query, recordId);
            if (!rs.isBeforeFirst()) { // Check if ResultSet is empty
                throw new MedicalRecordNotFoundException("No medical records found.");
            }
            while (rs.next()) {
                System.out.println(new MedicalRecord(
                        rs.getInt("record_id"),
                        rs.getInt("patient_id"),
                        rs.getInt("doctor_id"),
                        rs.getDate("date"),
                        rs.getString("diagnosis"),
                        rs.getString("treatment")
                ));
            }
        } catch (SQLException e) {
            throw new MedicalRecordNotFoundException("Error viewing medical record(s): " + e.getMessage());
        }
    }

    @Override
    protected void update() throws MedicalRecordUpdateException {
        System.out.print("\nEnter record ID to update: ");
        int recordId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            System.out.print("Enter new patient ID (or press enter to skip): ");
            String patientIdStr = scanner.nextLine();
            System.out.print("Enter new doctor ID (or press enter to skip): ");
            String doctorIdStr = scanner.nextLine();
            System.out.print("Enter new date (YYYY-MM-DD) (or press enter to skip): ");
            String dateStr = scanner.nextLine();
            System.out.print("Enter new diagnosis (or press enter to skip): ");
            String diagnosis = scanner.nextLine();
            System.out.print("Enter new treatment (or press enter to skip): ");
            String treatment = scanner.nextLine();

            StringBuilder queryBuilder = new StringBuilder("UPDATE medical_records SET ");
            List<Object> params = new ArrayList<>();

            if (!patientIdStr.isEmpty()) {
                queryBuilder.append("patient_id = ?, ");
                params.add(Integer.parseInt(patientIdStr));
            }
            if (!doctorIdStr.isEmpty()) {
                queryBuilder.append("doctor_id = ?, ");
                params.add(Integer.parseInt(doctorIdStr));
            }
            if (!dateStr.isEmpty()) {
                queryBuilder.append("date = ?, ");
                params.add(Date.valueOf(dateStr));
            }
            if (!diagnosis.isEmpty()) {
                queryBuilder.append("diagnosis = ?, ");
                params.add(diagnosis);
            }
            if (!treatment.isEmpty()) {
                queryBuilder.append("treatment = ?, ");
                params.add(treatment);
            }

            if (params.isEmpty()) {
                throw new MedicalRecordUpdateException("No updates provided.");
            }

            queryBuilder.setLength(queryBuilder.length() - 2); // Remove last comma and space
            queryBuilder.append(" WHERE record_id = ?");
            params.add(recordId);

            int rowsAffected = dbManager.executeUpdate(queryBuilder.toString(), params.toArray());
            if (rowsAffected > 0) {
                System.out.println("Medical record updated successfully.");
            } else {
                throw new MedicalRecordUpdateException("Failed to update medical record. Record may not exist.");
            }
        } catch (SQLException e) {
            throw new MedicalRecordUpdateException("Error updating medical record: " + e.getMessage());
        }
    }

    @Override
    protected void delete() throws MedicalRecordDeletionException {
        System.out.print("\nEnter record ID to delete: ");
        int recordId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query = "DELETE FROM medicalrecord WHERE record_id = ?";
        try {
            int rowsAffected = dbManager.executeUpdate(query, recordId);
            if (rowsAffected > 0) {
                System.out.println("Medical record deleted successfully.");
            } else {
                throw new MedicalRecordDeletionException("Failed to delete medical record. Record may not exist.");
            }
        } catch (SQLException e) {
            throw new MedicalRecordDeletionException("Error deleting medical record: " + e.getMessage());
        }
    }
}
