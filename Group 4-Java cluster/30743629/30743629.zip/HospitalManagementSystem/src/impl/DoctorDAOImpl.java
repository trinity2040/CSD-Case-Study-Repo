import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class DoctorDAOImpl extends DAO {
    private Scanner scanner;

    // Custom Exceptions
    public static class DoctorNotFoundException extends Exception {
        public DoctorNotFoundException(String message) {
            super(message);
        }
    }

    public static class DoctorCreationException extends Exception {
        public DoctorCreationException(String message) {
            super(message);
        }
    }

    public static class DoctorUpdateException extends Exception {
        public DoctorUpdateException(String message) {
            super(message);
        }
    }

    public static class DoctorDeletionException extends Exception {
        public DoctorDeletionException(String message) {
            super(message);
        }
    }

    public DoctorDAOImpl(DatabaseManager dbManager) {
        super(dbManager);
        this.scanner = new Scanner(System.in);
    }

    @Override
    public void manage() {
        while (true) {
            System.out.println("\n--- Doctor Management ---");
            System.out.println("1. Add Doctor");
            System.out.println("2. View Doctor");
            System.out.println("3. Update Doctor");
            System.out.println("4. Delete Doctor");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            try {
                switch (choice) {
                    case 1:
                        add();
                        break;
                    case 2:
                        view();
                        break;
                    case 3:
                        update();
                        break;
                    case 4:
                        delete();
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("An error occurred: " + e.getMessage());
            }
        }
    }

    @Override
    protected void add() throws DoctorCreationException {
        System.out.println("\nAdding a new doctor:");
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter specialization: ");
        String specialization = scanner.nextLine();
        System.out.print("Enter contact number: ");
        String contactNumber = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();

        String query = "INSERT INTO doctor (name, specialization, contact_number, email) VALUES (?, ?, ?, ?)";
        try {
            int rowsAffected = dbManager.executeUpdate(query, name, specialization, contactNumber, email);
            if (rowsAffected > 0) {
                System.out.println("Doctor added successfully.");
            } else {
                throw new DoctorCreationException("Failed to add doctor.");
            }
        } catch (SQLException e) {
            throw new DoctorCreationException("Error adding doctor: " + e.getMessage());
        }
    }

    @Override
    protected void view() throws DoctorNotFoundException {
        System.out.print("\nEnter doctor ID to view (or 0 to view all): ");
        int doctorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query;
        if (doctorId == 0) {
            query = "SELECT * FROM doctor";
        } else {
            query = "SELECT * FROM doctor WHERE doctor_id = ?";
        }

        try {
            ResultSet rs = doctorId == 0 ? dbManager.executeQuery(query) : dbManager.executeQuery(query, doctorId);
            boolean found = false;
            while (rs.next()) {
                found = true;
                System.out.println(new Doctor(
                        rs.getInt("doctor_id"),
                        rs.getString("name"),
                        rs.getString("specialization"),
                        rs.getString("contact_number"),
                        rs.getString("email")
                ));
            }
            if (!found) {
                throw new DoctorNotFoundException("No doctor(s) found.");
            }
        } catch (SQLException e) {
            throw new DoctorNotFoundException("Error viewing doctor(s): " + e.getMessage());
        }
    }

    @Override
    protected void update() throws DoctorUpdateException {
        System.out.print("\nEnter doctor ID to update: ");
        int doctorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter new name (or press enter to skip): ");
        String name = scanner.nextLine();
        System.out.print("Enter new specialization (or press enter to skip): ");
        String specialization = scanner.nextLine();
        System.out.print("Enter new contact number (or press enter to skip): ");
        String contactNumber = scanner.nextLine();
        System.out.print("Enter new email (or press enter to skip): ");
        String email = scanner.nextLine();

        StringBuilder queryBuilder = new StringBuilder("UPDATE doctors SET ");
        List<Object> params = new ArrayList<>();

        if (!name.isEmpty()) {
            queryBuilder.append("name = ?, ");
            params.add(name);
        }
        if (!specialization.isEmpty()) {
            queryBuilder.append("specialization = ?, ");
            params.add(specialization);
        }
        if (!contactNumber.isEmpty()) {
            queryBuilder.append("contact_number = ?, ");
            params.add(contactNumber);
        }
        if (!email.isEmpty()) {
            queryBuilder.append("email = ?, ");
            params.add(email);
        }

        if (params.isEmpty()) {
            throw new DoctorUpdateException("No updates provided.");
        }

        queryBuilder.setLength(queryBuilder.length() - 2); // Remove last comma and space
        queryBuilder.append(" WHERE doctor_id = ?");
        params.add(doctorId);

        try {
            int rowsAffected = dbManager.executeUpdate(queryBuilder.toString(), params.toArray());
            if (rowsAffected > 0) {
                System.out.println("Doctor updated successfully.");
            } else {
                throw new DoctorUpdateException("Failed to update doctor. Doctor may not exist.");
            }
        } catch (SQLException e) {
            throw new DoctorUpdateException("Error updating doctor: " + e.getMessage());
        }
    }

    @Override
    protected void delete() throws DoctorDeletionException {
        System.out.print("\nEnter doctor ID to delete: ");
        int doctorId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query = "DELETE FROM doctor WHERE doctor_id = ?";
        try {
            int rowsAffected = dbManager.executeUpdate(query, doctorId);
            if (rowsAffected > 0) {
                System.out.println("Doctor deleted successfully.");
            } else {
                throw new DoctorDeletionException("Failed to delete doctor. Doctor may not exist.");
            }
        } catch (SQLException e) {
            throw new DoctorDeletionException("Error deleting doctor: " + e.getMessage());
        }
    }
}