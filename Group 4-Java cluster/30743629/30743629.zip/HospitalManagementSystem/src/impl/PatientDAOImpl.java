import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class PatientDAOImpl extends DAO {
    private Scanner scanner;

    // Custom Exceptions
    public static class PatientNotFoundException extends Exception {
        public PatientNotFoundException(String message) {
            super(message);
        }
    }

    public static class PatientCreationException extends Exception {
        public PatientCreationException(String message) {
            super(message);
        }
    }

    public static class PatientUpdateException extends Exception {
        public PatientUpdateException(String message) {
            super(message);
        }
    }

    public static class PatientDeletionException extends Exception {
        public PatientDeletionException(String message) {
            super(message);
        }
    }

    public PatientDAOImpl(DatabaseManager dbManager) {
        super(dbManager);
        this.scanner = new Scanner(System.in);
    }

    @Override
    public void manage() {
        while (true) {
            System.out.println("\n--- Patient Management ---");
            System.out.println("1. Add Patient");
            System.out.println("2. View Patient");
            System.out.println("3. Update Patient");
            System.out.println("4. Delete Patient");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    try {
                        add();
                    } catch (PatientCreationException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 2:
                    try {
                        view();
                    } catch (PatientNotFoundException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 3:
                    try {
                        update();
                    } catch (PatientUpdateException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 4:
                    try {
                        delete();
                    } catch (PatientDeletionException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    @Override
    protected void add() throws PatientCreationException {
        System.out.println("\nAdding a new patient:");
        System.out.print("Enter name: ");
        String name = scanner.nextLine();
        System.out.print("Enter date of birth (YYYY-MM-DD): ");
        String dobString = scanner.nextLine();
        Date dob = Date.valueOf(dobString);
        System.out.print("Enter gender: ");
        String gender = scanner.nextLine();
        System.out.print("Enter address: ");
        String address = scanner.nextLine();

        String query = "INSERT INTO patient (name, date_of_birth, gender, address) VALUES (?, ?, ?, ?)";
        try {
            int rowsAffected = dbManager.executeUpdate(query, name, dob, gender, address);
            if (rowsAffected > 0) {
                System.out.println("Patient added successfully.");
            } else {
                throw new PatientCreationException("Failed to add patient.");
            }
        } catch (SQLException e) {
            throw new PatientCreationException("Error adding patient: " + e.getMessage());
        }
    }

    @Override
    protected void view() throws PatientNotFoundException {
        System.out.print("\nEnter patient ID to view (or 0 to view all): ");
        int patientId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query;
        if (patientId == 0) {
            query = "SELECT * FROM patient";
        } else {
            query = "SELECT * FROM patient WHERE patient_id = ?";
        }

        try {
            ResultSet rs = patientId == 0 ? dbManager.executeQuery(query) : dbManager.executeQuery(query, patientId);
            if (!rs.next()) {
                throw new PatientNotFoundException("No patients found.");
            }
            do {
                System.out.println(new Patient(
                        rs.getInt("patient_id"),
                        rs.getString("name"),
                        rs.getDate("date_of_birth"),
                        rs.getString("gender"),
                        rs.getString("address")
                ));
            } while (rs.next());
        } catch (SQLException e) {
            throw new PatientNotFoundException("Error viewing patient(s): " + e.getMessage());
        }
    }

    @Override
    protected void update() throws PatientUpdateException {
        System.out.print("\nEnter patient ID to update: ");
        int patientId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        System.out.print("Enter new name (or press enter to skip): ");
        String name = scanner.nextLine();
        System.out.print("Enter new date of birth (YYYY-MM-DD) (or press enter to skip): ");
        String dobString = scanner.nextLine();
        System.out.print("Enter new gender (or press enter to skip): ");
        String gender = scanner.nextLine();
        System.out.print("Enter new address (or press enter to skip): ");
        String address = scanner.nextLine();

        StringBuilder queryBuilder = new StringBuilder("UPDATE patients SET ");
        List<Object> params = new ArrayList<>();

        if (!name.isEmpty()) {
            queryBuilder.append("name = ?, ");
            params.add(name);
        }
        if (!dobString.isEmpty()) {
            queryBuilder.append("date_of_birth = ?, ");
            params.add(Date.valueOf(dobString));
        }
        if (!gender.isEmpty()) {
            queryBuilder.append("gender = ?, ");
            params.add(gender);
        }
        if (!address.isEmpty()) {
            queryBuilder.append("address = ?, ");
            params.add(address);
        }

        if (params.isEmpty()) {
            System.out.println("No updates provided.");
            return;
        }

        queryBuilder.setLength(queryBuilder.length() - 2); // Remove last comma and space
        queryBuilder.append(" WHERE patient_id = ?");
        params.add(patientId);

        try {
            int rowsAffected = dbManager.executeUpdate(queryBuilder.toString(), params.toArray());
            if (rowsAffected > 0) {
                System.out.println("Patient updated successfully.");
            } else {
                throw new PatientUpdateException("Failed to update patient. Patient may not exist.");
            }
        } catch (SQLException e) {
            throw new PatientUpdateException("Error updating patient: " + e.getMessage());
        }
    }

    @Override
    protected void delete() throws PatientDeletionException {
        System.out.print("\nEnter patient ID to delete: ");
        int patientId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        String query = "DELETE FROM patient WHERE patient_id = ?";
        try {
            int rowsAffected = dbManager.executeUpdate(query, patientId);
            if (rowsAffected > 0) {
                System.out.println("Patient deleted successfully.");
            } else {
                throw new PatientDeletionException("Failed to delete patient. Patient may not exist.");
            }
        } catch (SQLException e) {
            throw new PatientDeletionException("Error deleting patient: " + e.getMessage());
        }
    }
}
