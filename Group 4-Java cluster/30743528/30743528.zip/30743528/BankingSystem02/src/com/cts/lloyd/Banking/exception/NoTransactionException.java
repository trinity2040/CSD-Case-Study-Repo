package com.cts.lloyd.Banking.exception;

@SuppressWarnings("serial")
public class NoTransactionException extends Exception {
    public NoTransactionException(String message) {
        super(message);
    }
}
