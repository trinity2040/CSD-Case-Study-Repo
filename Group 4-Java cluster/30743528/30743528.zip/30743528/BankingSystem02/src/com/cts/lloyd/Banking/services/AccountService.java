package com.cts.lloyd.Banking.services;

import com.cts.lloyd.Banking.model.Account;
import java.util.List;

public interface AccountService {
    void addAccount(Account account);
    Account getAccount(int accountId);
    void updateAccount(Account account);
    void deleteAccount(int accountId);
    List<Account> getAllAccounts();
}
