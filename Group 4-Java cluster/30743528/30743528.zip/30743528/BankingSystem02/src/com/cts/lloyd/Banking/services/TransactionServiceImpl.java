package com.cts.lloyd.Banking.services;

import com.cts.lloyd.Banking.dao.AccountDAO;
import com.cts.lloyd.Banking.dao.AccountDAOImpl;
import com.cts.lloyd.Banking.dao.TransactionDAO;
import com.cts.lloyd.Banking.dao.TransactionDAOImpl;
import com.cts.lloyd.Banking.model.Account;
import com.cts.lloyd.Banking.model.Transaction;
import com.cts.lloyd.Banking.exception.NoTransactionException;
import com.cts.lloyd.Banking.exception.InsufficientFundsException;



import java.util.List;

public class TransactionServiceImpl implements TransactionService {

    private final AccountDAO accountDAO;
    private final TransactionDAO transactionDAO;

    public TransactionServiceImpl() {
        this.accountDAO = new AccountDAOImpl();
        this.transactionDAO = new TransactionDAOImpl();
    }

    @Override
    public void deposit(int accountId, double amount) {
        Account account = accountDAO.getAccount(accountId);
        if (account != null) {
            account.setBalance(account.getBalance() + amount);
            accountDAO.updateAccount(account);

            Transaction transaction = new Transaction();
            transaction.setAccountId(accountId);
            transaction.setTransactionType("Deposit");
            transaction.setAmount(amount);
            transactionDAO.addTransaction(transaction);
        }
    }

    @Override
    public void withdraw(int accountId, double amount) throws InsufficientFundsException {
        Account account = accountDAO.getAccount(accountId);
        if (account == null) {
            throw new IllegalArgumentException("Account not found");
        }

        if (account.getBalance() < amount) {
            throw new InsufficientFundsException("Insufficient funds in account");
        }

        account.setBalance(account.getBalance() - amount);
        accountDAO.updateAccount(account);

        Transaction transaction = new Transaction();
        transaction.setAccountId(accountId);
        transaction.setTransactionType("Withdrawal");
        transaction.setAmount(amount);
        transactionDAO.addTransaction(transaction);
    }

    @Override
    public void transfer(int fromAccountId, int toAccountId, double amount) {
        Account fromAccount = accountDAO.getAccount(fromAccountId);
        Account toAccount = accountDAO.getAccount(toAccountId);
        if (fromAccount != null && toAccount != null && fromAccount.getBalance() >= amount) {
            fromAccount.setBalance(fromAccount.getBalance() - amount);
            toAccount.setBalance(toAccount.getBalance() + amount);
            accountDAO.updateAccount(fromAccount);
            accountDAO.updateAccount(toAccount);

            Transaction transaction = new Transaction();
            transaction.setAccountId(fromAccountId);
            transaction.setTransactionType("Transfer");
            transaction.setAmount(amount);
            transactionDAO.addTransaction(transaction);

            transaction = new Transaction();
            transaction.setAccountId(toAccountId);
            transaction.setTransactionType("Transfer");
            transaction.setAmount(amount);
            transactionDAO.addTransaction(transaction);
        } else {
            System.out.println("Transfer failed. Please check the account details and balance.");
        }
    }

    @Override
    public List<Transaction> getTransactionHistory(int accountId) throws NoTransactionException {
        List<Transaction> transactions = transactionDAO.getTransactionHistory(accountId);
        if (transactions.isEmpty()) {
            throw new NoTransactionException("No transactions found.");
        }
        return transactions;
    }
}
