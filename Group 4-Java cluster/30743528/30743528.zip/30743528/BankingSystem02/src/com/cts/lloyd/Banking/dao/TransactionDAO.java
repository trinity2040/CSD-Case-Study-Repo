package com.cts.lloyd.Banking.dao;

import com.cts.lloyd.Banking.model.Transaction;
import java.util.List;

public interface TransactionDAO {
    void addTransaction(Transaction transaction);
    List<Transaction> getTransactionHistory(int accountId);
}
