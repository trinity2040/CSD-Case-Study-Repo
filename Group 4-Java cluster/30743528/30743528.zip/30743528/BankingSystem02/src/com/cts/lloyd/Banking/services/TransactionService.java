package com.cts.lloyd.Banking.services;
import com.cts.lloyd.Banking.exception.InsufficientFundsException;
import com.cts.lloyd.Banking.exception.NoTransactionException;

import com.cts.lloyd.Banking.model.Transaction;
import java.util.List;

public interface TransactionService {
    void deposit(int accountId, double amount);
    void withdraw(int accountId, double amount) throws InsufficientFundsException;
    void transfer(int fromAccountId, int toAccountId, double amount);
    List<Transaction> getTransactionHistory(int accountId)throws NoTransactionException;
}
