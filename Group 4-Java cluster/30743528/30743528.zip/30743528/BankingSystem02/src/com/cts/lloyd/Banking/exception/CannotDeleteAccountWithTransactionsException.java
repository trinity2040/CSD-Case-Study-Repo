package com.cts.lloyd.Banking.exception;

@SuppressWarnings("serial")
public class CannotDeleteAccountWithTransactionsException extends Exception {
    public CannotDeleteAccountWithTransactionsException(String message) {
        super(message);
    }
}
