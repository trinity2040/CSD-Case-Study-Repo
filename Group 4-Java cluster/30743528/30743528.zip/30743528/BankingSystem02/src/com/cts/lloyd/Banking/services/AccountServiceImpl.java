package com.cts.lloyd.Banking.services;

import com.cts.lloyd.Banking.dao.AccountDAO;
import com.cts.lloyd.Banking.dao.AccountDAOImpl;
import com.cts.lloyd.Banking.model.Account;
import java.util.List;

public class AccountServiceImpl implements AccountService {

    private AccountDAO accountDAO;

    public AccountServiceImpl() {
        this.accountDAO = new AccountDAOImpl();
    }

    @Override
    public void addAccount(Account account) {
        accountDAO.addAccount(account);
    }

    @Override
    public Account getAccount(int accountId) {
        return accountDAO.getAccount(accountId);
    }

    @Override
    public void updateAccount(Account account) {
        accountDAO.updateAccount(account);
    }

    @Override
    public void deleteAccount(int accountId) {
        accountDAO.deleteAccount(accountId);
    }

    @Override
    public List<Account> getAllAccounts() {
        return accountDAO.getAllAccounts();
    }
}
