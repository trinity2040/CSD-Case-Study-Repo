package com.cts.lloyd.Banking.dao;

import com.cts.lloyd.Banking.model.Account;
import java.util.List;

public interface AccountDAO {
    void addAccount(Account account);
    Account getAccount(int accountId);
    void updateAccount(Account account);
    void deleteAccount(int accountId);
    List<Account> getAllAccounts();
}
