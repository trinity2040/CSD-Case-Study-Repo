
import com.cts.lloyd.Banking.model.Customer;
import com.cts.lloyd.Banking.exception.AccountNotFoundException;
import com.cts.lloyd.Banking.exception.InsufficientFundsException;
import com.cts.lloyd.Banking.exception.NoTransactionException;
import com.cts.lloyd.Banking.model.Account;
import com.cts.lloyd.Banking.model.Transaction;
import com.cts.lloyd.Banking.services.CustomerService;
import com.cts.lloyd.Banking.services.CustomerServiceImpl;
import com.cts.lloyd.Banking.services.AccountService;
import com.cts.lloyd.Banking.services.AccountServiceImpl;
import com.cts.lloyd.Banking.services.TransactionService;
import com.cts.lloyd.Banking.services.TransactionServiceImpl;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws SQLException, InsufficientFundsException, AccountNotFoundException {
        Scanner scanner = new Scanner(System.in);
        CustomerService customerService = new CustomerServiceImpl();
        AccountService accountService = new AccountServiceImpl();
        TransactionService transactionService = new TransactionServiceImpl();

        while (true) {
            System.out.println("Banking System");
            System.out.println("1. Add new customer");
            System.out.println("2. View customer details");
            System.out.println("3. Update customer information");
            System.out.println("4. Delete customer");
            System.out.println("5. Add new account");
            System.out.println("6. View account details");
            System.out.println("7. Update account information");
            System.out.println("8. Delete account");
            System.out.println("9. Deposit funds");
            System.out.println("10. Withdraw funds");
            System.out.println("11. Transfer funds");
            System.out.println("12. View transaction history");
            System.out.println("13. Exit");
            System.out.println("--------------------");
            System.out.print("Enter your choice: ");
            

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    Customer newCustomer = new Customer();
                    System.out.print("Enter name: ");
                    newCustomer.setName(scanner.next());
                    System.out.print("Enter email: ");
                    newCustomer.setEmail(scanner.next());
                    System.out.print("Enter phone: ");
                    newCustomer.setPhone(scanner.next());
                    customerService.addCustomer(newCustomer);
                    System.out.println("Customer added successfully.");
                    System.out.println("--------------------");
                    break;
                case 2:
                    System.out.print("Enter customer ID: ");
                    Customer customer = customerService.getCustomer(scanner.nextInt());
                    if (customer != null) {
                        System.out.println("Customer ID: " + customer.getCustomerId());
                        System.out.println("Name: " + customer.getName());
                        System.out.println("Email: " + customer.getEmail());
                        System.out.println("Phone: " + customer.getPhone());
                    } else {
                        System.out.println("Customer not found.");
                    }
                    System.out.println("--------------------");
                    break;
                case 3:
                    Customer updateCustomer = new Customer();
                    System.out.print("Enter customer ID: ");
                    updateCustomer.setCustomerId(scanner.nextInt());
                    System.out.print("Enter name: ");
                    updateCustomer.setName(scanner.next());
                    System.out.print("Enter email: ");
                    updateCustomer.setEmail(scanner.next());
                    System.out.print("Enter phone: ");
                    updateCustomer.setPhone(scanner.next());
                    customerService.updateCustomer(updateCustomer);
                    System.out.println("Customer updated successfully.");
                    System.out.println("--------------------");
                    break;
                case 4:
                    System.out.print("Enter customer ID: ");
                    customerService.deleteCustomer(scanner.nextInt());
                    System.out.println("Customer deleted successfully.");
                    System.out.println("--------------------");
                    break;
                case 5:
                    Account newAccount = new Account();
                    System.out.print("Enter customer ID: ");
                    newAccount.setCustomerId(scanner.nextInt());
                    System.out.print("Enter account type (Savings/Checking): ");
                    newAccount.setAccountType(scanner.next());
                    System.out.print("Enter balance: ");
                    newAccount.setBalance(scanner.nextDouble());
                    accountService.addAccount(newAccount);
                    System.out.println("Account added successfully.");
                    System.out.println("--------------------");
                    break;
                case 6:
                    System.out.print("Enter account ID: ");
                    Account account = accountService.getAccount(scanner.nextInt());
                    if (account != null) {
                        System.out.println("Account ID: " + account.getAccountId());
                        System.out.println("Customer ID: " + account.getCustomerId());
                        System.out.println("Account Type: " + account.getAccountType());
                        System.out.println("Balance: " + account.getBalance());
                    } else {
                        System.out.println("Account not found.");
                    }
                    System.out.println("--------------------");
                    break;
                case 7:
                    Account updateAccount = new Account();
                    System.out.print("Enter account ID: ");
                    updateAccount.setAccountId(scanner.nextInt());
                    System.out.print("Enter account type (Savings/Checking): ");
                    updateAccount.setAccountType(scanner.next());
                    System.out.print("Enter balance: ");
                    updateAccount.setBalance(scanner.nextDouble());
                    accountService.updateAccount(updateAccount);
                    System.out.println("Account updated successfully.");
                    System.out.println("--------------------");
                    break;
                case 8:
                    System.out.print("Enter account ID: ");
                    accountService.deleteAccount(scanner.nextInt());
                    System.out.println("Account deleted successfully.");
                    System.out.println("--------------------");
                    break;
                case 9:
                    System.out.print("Enter account ID: ");
                    int depositAccountId = scanner.nextInt();
                    System.out.print("Enter amount: ");
                    double depositAmount = scanner.nextDouble();
				transactionService.deposit(depositAccountId, depositAmount);
				System.out.println("Funds deposited successfully.");
				System.out.println("--------------------");
                    break;
                case 10:
                	System.out.print("Enter account ID to withdraw: ");
                    int withdrawAccountId = scanner.nextInt();
                    System.out.print("Enter amount to withdraw: ");
                    double withdrawAmount = scanner.nextDouble();
                    try {
                        transactionService.withdraw(withdrawAccountId, withdrawAmount);
                        System.out.println("Amount withdrawn successfully.");
                    } catch (InsufficientFundsException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    System.out.println("--------------------");
                    break;
                case 11:
                    System.out.print("Enter from account ID: ");
                    int fromAccountId = scanner.nextInt();
                    System.out.print("Enter to account ID: ");
                    int toAccountId = scanner.nextInt();
                    System.out.print("Enter amount: ");
                    double transferAmount = scanner.nextDouble();
				transactionService.transfer(fromAccountId, toAccountId, transferAmount);
				System.out.println("Funds transferred successfully.");
				System.out.println("--------------------");
                    break;
                case 12:
                	System.out.print("Enter account ID to view transaction history: ");
                    int transactionAccountId = scanner.nextInt();
                    try {
                        List<Transaction> transactions = transactionService.getTransactionHistory(transactionAccountId);
                        for (Transaction transaction : transactions) {
                            System.out.print("Transaction ID: " + transaction.getTransactionId() + " ");
                            System.out.print("Transaction Type: " + transaction.getTransactionType() + " ");
                            System.out.print("Amount: " + transaction.getAmount() + " ");
                            System.out.println("Date: " + transaction.getTransactionDate() + " ");
                        }
                    } catch (NoTransactionException e) {
                        System.out.println(e.getMessage());
                    }
                    System.out.println("--------------------");
                    break;
                case 13:
                    System.out.println("Exiting...");
                    System.out.println("--------------------");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
