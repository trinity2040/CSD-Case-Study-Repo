
package com.cts.online.learning.platform;
import java.util.*;
import java.sql.SQLException;
import static com.cts.EnrollmentManagement.deleteEnrollment.cancelEnrollment;
import static com.cts.EnrollmentManagement.enrollCourse.enrollCourse;
import static com.cts.EnrollmentManagement.updateEnrollment.updateEnrollment;
import static com.cts.EnrollmentManagement.viewEnrollment.viewEnrollment;
import static com.cts.CourseManager.addCourse.addCourse;
import static com.cts.CourseManager.viewCourse.viewCourse;
import static com.cts.CourseManager.DeleteCourse.DeleteCourse;
import static com.cts.CourseManager.UpdateCourse.UpdateCourse;
import static com.cts.moduleManager.deleteModule.deleteModule;
import static com.cts.moduleManager.viewModule.viewModule;
import static com.cts.moduleManager.newModule.addModule;

import static com.cts.moduleManager.updateModule.updateModule;

public class OnlineLearningPlatform {
    public static void main(String[] args) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            
            System.out.println("=== Learning Platform Menu ===");
            System.out.println("1. Course Management");
            System.out.println("2. Module Management");
            System.out.println("3. Enrollment Management");
            System.out.println("4. Exit");
            System.out.print("Select an option: ");
            
            
            int choice = scanner.nextInt();
            
            
            switch (choice) {
                case 1:
                    manageCourses(scanner);
                    break;
                case 2:
                    manageModules(scanner);
                    break;
                case 3:
                    manageEnrollments(scanner);
                    break;
                case 4:
                    exit = true;
                    System.out.println("Exiting the application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }

        scanner.close();

    
    
}
  
    
    
     public static void manageEnrollments(Scanner scanner) {
        System.out.println("===Online Course Management ===");
        System.out.println("1. Enroll in a course");
        System.out.println("2. View enrollment details");
        System.out.println("3. Update enrollment information");
        System.out.println("4. Cancel enrollment");
        System.out.println("5. Back to main menu");
        System.out.print("Select an option: ");
        
        int choice = scanner.nextInt();
        
        switch (choice) {
            case 1:
                enrollCourse(scanner);
                break;
            case 2:
                viewEnrollment(scanner);
                break;
            case 3:
                updateEnrollment(scanner);
                break;
            case 4:
                cancelEnrollment(scanner);
                break;
            case 5:
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }
    
    
    
    
    
    public static void manageCourses(Scanner scanner) {
        System.out.println("===Online Course Management ===");
        System.out.println("1. Add a new course");
        System.out.println("2. View course details");
        System.out.println("3. Update course information");
        System.out.println("4. Delete a course");
        System.out.println("5. Back to main menu");
        System.out.print("Select an option: ");
        
        int choice = scanner.nextInt();
        
        switch (choice) {
            case 1:
               
                addCourse(scanner);
                break;
            case 2:
              
                viewCourse(scanner);
                break;
            case 3:
                
                UpdateCourse(scanner);
                break;
            case 4:
               
                DeleteCourse(scanner);
                break;
            case 5:
                
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }
    public static void manageModules(Scanner scanner) {
    System.out.println("=== Module Management ===");
    System.out.println("1. Add a new module");
    System.out.println("2. View module details");
    System.out.println("3. Update module information");
    System.out.println("4. Delete a module");
    System.out.println("5. Back to main menu");
    System.out.print("Select an option: ");

    int choice = scanner.nextInt();
    scanner.nextLine(); 

    switch (choice) {
        case 1:
            addModule(scanner);
            break;
        case 2:
            viewModule(scanner);
            break;
        case 3:
            updateModule(scanner);
            break;
        case 4:
            deleteModule(scanner);
            break;
        case 5:
            
            break;
        default:
            System.out.println("Invalid option. Please try again.");
    }
}

 
}
