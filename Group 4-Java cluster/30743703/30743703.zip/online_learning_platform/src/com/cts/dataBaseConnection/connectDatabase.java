package com.cts.dataBaseConnection;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class connectDatabase {
    private static final String URL = "jdbc:mysql://localhost:3306/online learning platform";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public static ResultSet connectDatabase(String sql) {
        ResultSet rs = null;
        try {
            Connection con = DriverManager.getConnection(URL, USER, PASSWORD);                     
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);                     
            rs = stmt.executeQuery(sql);
        } catch (SQLException e) {
           System.out.print(e);
        }
        return rs;
    }
    public static Connection getConnection() {
        Connection con = null;
        try {
            con = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (SQLException e) {
            System.out.println(e);
        }
        return con;
    }
}
