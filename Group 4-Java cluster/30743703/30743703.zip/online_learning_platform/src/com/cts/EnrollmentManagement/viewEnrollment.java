package com.cts.EnrollmentManagement;

import com.cts.dataBaseConnection.connectDatabase;
import java.sql.*;
import java.util.Date;
import java.util.Scanner;

public class viewEnrollment {

    public static void viewEnrollment(Scanner scanner) {
        try (Connection con = connectDatabase.getConnection()) {
            String sql = "SELECT * FROM `enrollmenttable`";
            PreparedStatement pstmt = con.prepareStatement(sql);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                int enrollmentId = rs.getInt("enrollment_id");
                int courseId = rs.getInt("course_id");
                Date enrollmentDate = rs.getDate("enrollment_date");
                Date completionDate = rs.getDate("completion_date");
                String status = rs.getString("status");

                System.out.println("Enrollment ID: " + enrollmentId);
                System.out.println("Course ID: " + courseId);
                System.out.println("Enrollment Date: " + enrollmentDate);
                System.out.println("Completion Date: " + completionDate);
                System.out.println("Status: " + status);
                System.out.println();
            }

            rs.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    
}
