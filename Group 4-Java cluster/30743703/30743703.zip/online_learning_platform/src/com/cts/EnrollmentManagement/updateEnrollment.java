package com.cts.EnrollmentManagement;

import com.cts.dataBaseConnection.connectDatabase;
import java.sql.*;
import java.util.Scanner;

public class updateEnrollment {

    public static void updateEnrollment(Scanner scanner) {
        try (Connection con = connectDatabase.getConnection()) {
            System.out.println("Enter Enrollment ID to update:");
            int enrollmentId = scanner.nextInt();

            System.out.println("Enter new User ID:");
            int userId = scanner.nextInt();

            System.out.println("Enter new Course ID:");
            int courseId = scanner.nextInt();

            System.out.println("Enter new Enrollment Date (YYYY-MM-DD):");
            String enrollmentDateStr = scanner.next();
            java.sql.Date enrollmentDate = java.sql.Date.valueOf(enrollmentDateStr);

            System.out.println("Enter new status (active/completed):");
            String newStatus = scanner.next();

            System.out.println("Enter new Completion Date (YYYY-MM-DD) or NULL if not completed:");
            String completionDateStr = scanner.next();
            java.sql.Date completionDate = completionDateStr.equalsIgnoreCase("NULL") ? null : java.sql.Date.valueOf(completionDateStr);

            String sql = "UPDATE `enrollmenttable` SET `user_id` = ?, `course_id` = ?, `enrollment_date` = ?, `status` = ?, `completion_date` = ? WHERE `enrollment_id` = ?";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setInt(1, userId);
                pstmt.setInt(2, courseId);
                pstmt.setDate(3, enrollmentDate);
                pstmt.setString(4, newStatus);
                pstmt.setDate(5, completionDate);
                pstmt.setInt(6, enrollmentId);

                int rowsUpdated = pstmt.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("Enrollment updated successfully!");
                } else {
                    System.out.println("No enrollment found with the provided Enrollment ID.");
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

   
}
