package com.cts.EnrollmentManagement;

import com.cts.dataBaseConnection.connectDatabase;
import com.cts.exceptions.CourseNotFoundException;

import java.sql.*;
import java.util.Scanner;

public class enrollCourse {

    public static void enrollCourse(Scanner scanner) {
        try (Connection con = connectDatabase.getConnection()) {
            System.out.println("Enter User ID:");
            int userId = scanner.nextInt();
            scanner.nextLine();

            if (!doesUserExist(con, userId)) {
                createUser(scanner, con, userId);
            }

            System.out.println("Enter Enrollment ID:");
            int enrollmentId = scanner.nextInt();
            System.out.println("Enter Course ID:");
            int courseId = scanner.nextInt();

            if (!doesCourseExist(con, courseId)) {
                throw new CourseNotFoundException("Course with ID " + courseId + " not found or the course is full.");
            }

            System.out.println("Enter Enrollment Date (YYYY-MM-DD):");
            String enrollmentDateStr = scanner.next();
            java.sql.Date enrollmentDate = java.sql.Date.valueOf(enrollmentDateStr);
            System.out.println("Enter Status (e.g., 'active'):");
            String status = scanner.next();
            System.out.println("Enter Completion Date (YYYY-MM-DD) or NULL if not completed:");
            String completionDateStr = scanner.next();
            java.sql.Date completionDate = completionDateStr.equalsIgnoreCase("NULL") ? null : java.sql.Date.valueOf(completionDateStr);

            String sql = "INSERT INTO `enrollmenttable` (`enrollment_id`, `user_id`, `course_id`, `enrollment_date`, `status`, `completion_date`) VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setInt(1, enrollmentId);
                pstmt.setInt(2, userId);
                pstmt.setInt(3, courseId);
                pstmt.setDate(4, enrollmentDate);
                pstmt.setString(5, status);
                pstmt.setDate(6, completionDate);

                int rowsInserted = pstmt.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println("Enrollment successful!");
                } else {
                    System.out.println("Enrollment failed.");
                }
            }
        } catch (CourseNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    private static boolean doesUserExist(Connection con, int userId) throws SQLException {
        String sql = "SELECT * FROM `usertable` WHERE `user_id` = ?";
        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    private static boolean doesCourseExist(Connection con, int courseId) throws SQLException {
        String sql = "SELECT * FROM `coursetable` WHERE `course_id` = ?";
        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setInt(1, courseId);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();
            }
        }
    }

    private static void createUser(Scanner scanner, Connection con, int userId) throws SQLException {
        System.out.println("User not found. Please create a new user.");
        System.out.println("Enter Username:");
        String username = scanner.nextLine();
        System.out.println("Enter Email:");
        String email = scanner.nextLine();
        System.out.println("Enter Date of Birth (YYYY-MM-DD):");
        String dobStr = scanner.nextLine();
        java.sql.Date dob = java.sql.Date.valueOf(dobStr);
        System.out.println("Enter Registration Date (YYYY-MM-DD):");
        String registrationDateStr = scanner.nextLine();
        java.sql.Date registrationDate = java.sql.Date.valueOf(registrationDateStr);

        String sql = "INSERT INTO `usertable` (`user_id`, `username`, `email`, `dob`, `registration_date`) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            pstmt.setString(2, username);
            pstmt.setString(3, email);
            pstmt.setDate(4, dob);
            pstmt.setDate(5, registrationDate);

            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("User created successfully!");
            } else {
                System.out.println("User creation failed.");
            }
        }
    }
}
