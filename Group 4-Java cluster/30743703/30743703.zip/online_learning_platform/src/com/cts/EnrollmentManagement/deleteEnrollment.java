    package com.cts.EnrollmentManagement;

import com.cts.dataBaseConnection.connectDatabase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;
    import java.sql.ResultSet;

public class deleteEnrollment {

    public static void cancelEnrollment(Scanner scanner) {
        try (Connection con = connectDatabase.getConnection()) {
            System.out.println("Enter Enrollment ID to cancel:");
            int enrollmentId = scanner.nextInt();

            int userId = getUserIdByEnrollmentId(con, enrollmentId);
            if (userId == -1) {
                System.out.println("No enrollment found with the provided Enrollment ID.");
                return;
            }

            String deleteEnrollmentSql = "DELETE FROM `enrollmenttable` WHERE `enrollment_id` = ?";
            try (PreparedStatement pstmt = con.prepareStatement(deleteEnrollmentSql)) {
                pstmt.setInt(1, enrollmentId);
                int rowsDeleted = pstmt.executeUpdate();
                if (rowsDeleted > 0) {
                    System.out.println("Enrollment canceled successfully!");

                    deleteUser(con, userId);
                } else {
                    System.out.println("Failed to cancel the enrollment.");
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    private static int getUserIdByEnrollmentId(Connection con, int enrollmentId) {
        String sql = "SELECT `user_id` FROM `enrollmenttable` WHERE `enrollment_id` = ?";
        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setInt(1, enrollmentId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("user_id");
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
        return -1; 
    }

    private static void deleteUser(Connection con, int userId) {
        String sql = "DELETE FROM `usertable` WHERE `user_id` = ?";
        try (PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setInt(1, userId);
            int rowsDeleted = pstmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("User deleted successfully!");
            } else {
                System.out.println("No user found with the provided User ID.");
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
}
