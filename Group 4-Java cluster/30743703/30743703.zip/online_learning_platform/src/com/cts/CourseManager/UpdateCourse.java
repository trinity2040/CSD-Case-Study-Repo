package com.cts.CourseManager;

import com.cts.dataBaseConnection.connectDatabase;
import java.sql.*;
import java.util.Scanner;

public class UpdateCourse {

    public static void UpdateCourse(Scanner scanner) {
        try (Connection con = connectDatabase.getConnection()) {
            String sql = "SELECT * FROM `coursetable`";
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("course_id");
                String courseName = rs.getString("title");
                String instructor = rs.getString("instructor");

                System.out.println("ID: " + id + ", Course Name: " + courseName + ", Instructor: " + instructor);
            }

            System.out.println("Enter the ID of the course you would like to update:");
            int idToUpdate = scanner.nextInt();
            scanner.nextLine();

            System.out.println("Enter the new course title:");
            String newTitle = scanner.nextLine();

            System.out.println("Enter the new instructor name:");
            String newInstructor = scanner.nextLine();

            System.out.println("Enter the new course description:");
            String newDescription = scanner.nextLine();

            System.out.println("Enter the new course duration:");
            int newDuration = scanner.nextInt();

            String updateSql = "UPDATE `coursetable` SET title = ?, instructor = ?, description = ?, duration = ? WHERE course_id = ?";

            PreparedStatement pstmt = con.prepareStatement(updateSql);
            pstmt.setString(1, newTitle);
            pstmt.setString(2, newInstructor);
            pstmt.setString(3, newDescription);
            pstmt.setInt(4, newDuration);
            pstmt.setInt(5, idToUpdate);

            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Course with ID " + idToUpdate + " was successfully updated.");
            } else {
                System.out.println("No course found with ID " + idToUpdate + ".");
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    
}
