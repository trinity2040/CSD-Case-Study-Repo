package com.cts.CourseManager;

import com.cts.dataBaseConnection.connectDatabase; 
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class addCourse {
    
    public static void addCourse(Scanner scanner) {
        System.out.println("Enter the course id");
        int courseId = scanner.nextInt();
        scanner.nextLine(); 

        System.out.println("Enter the course title");
        String title = scanner.nextLine(); 

        System.out.println("Enter the course description");
        String desc = scanner.nextLine();

        System.out.println("Enter the course instructor");
        String instructor = scanner.nextLine();

        System.out.println("Enter the course duration");
        int duration = scanner.nextInt();
        scanner.nextLine(); 

        
        try (Connection con = connectDatabase.getConnection()) {
            if (con != null) {
                String sql = "INSERT INTO `coursetable` (`course_id`, `title`, `description`, `instructor`, `duration`) VALUES (?, ?, ?, ?, ?)";

                PreparedStatement pstmt = con.prepareStatement(sql);
                pstmt.setInt(1, courseId);       
                pstmt.setString(2, title);       
                pstmt.setString(3, desc);        
                pstmt.setString(4, instructor);  
                pstmt.setInt(5, duration);       

                int rowsInserted = pstmt.executeUpdate();  

                if (rowsInserted > 0) {
                    System.out.println("A new course was inserted successfully!");
                }
            } else {
                System.out.println("Failed to make a connection!");
            }
        } catch (SQLException e) {
            System.out.print(e);
        }
    }
}
