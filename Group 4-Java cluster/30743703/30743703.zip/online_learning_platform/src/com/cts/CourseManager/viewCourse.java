package com.cts.CourseManager;

import com.cts.dataBaseConnection.connectDatabase;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class viewCourse {
    
    public static void viewCourse(Scanner scanner) {
        try {
            
            String sql = "SELECT * FROM `coursetable`";                
            ResultSet rs = connectDatabase.connectDatabase(sql);                      
            while (rs != null && rs.next()) {               
                int id = rs.getInt("course_id"); 
                String courseName = rs.getString("title"); 
                String instructor = rs.getString("instructor");                               
                System.out.println("ID: " + id + ", Course Name: " + courseName + ", Instructor: " + instructor);
            }                     
            if (rs != null) {
                rs.close();
            }
        } catch (SQLException e) {
            System.out.print(e);
        }
    }
}
