package com.cts.CourseManager;

import com.cts.dataBaseConnection.connectDatabase;
import java.sql.*;
import java.util.Scanner;

public class DeleteCourse {

    public static void DeleteCourse(Scanner scanner) {
        try (Connection con = connectDatabase.getConnection()) {
            Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
            String sql = "SELECT * FROM `coursetable`";
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                int id = rs.getInt("course_id");
                String courseName = rs.getString("title");
                String instructor = rs.getString("instructor");

                System.out.println("ID: " + id + ", Course Name: " + courseName + ", Instructor: " + instructor);
            }

            System.out.println("Enter the Id of the course you would like to delete:");
            int idToDelete = scanner.nextInt();

            String deleteSql = "DELETE FROM `coursetable` WHERE course_id = ?";
            PreparedStatement pstmt = con.prepareStatement(deleteSql);
            pstmt.setInt(1, idToDelete);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected > 0) {
                System.out.println("Course with ID " + idToDelete + " was successfully deleted.");
            } else {
                System.out.println("No course found with ID " + idToDelete + ".");
            }

            rs.close();
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    
}
