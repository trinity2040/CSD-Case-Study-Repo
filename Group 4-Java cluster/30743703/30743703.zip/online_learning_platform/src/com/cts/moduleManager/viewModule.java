package com.cts.moduleManager;

import com.cts.dataBaseConnection.connectDatabase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class viewModule {

    public static void viewModule(Scanner scanner) {
        try (Connection con = connectDatabase.getConnection()) {

            String sql = "SELECT * FROM `module`";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {

                ResultSet rs = pstmt.executeQuery();
                while (rs.next()) {
                    System.out.println("Module ID: " + rs.getInt("module_id"));
                    System.out.println("Course ID: " + rs.getInt("course_id"));
                    System.out.println("Title: " + rs.getString("title"));
                    System.out.println("Content: " + rs.getString("content"));
                    System.out.println("Duration: " + rs.getInt("duration") + " hours");
                    System.out.println();
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
    }
    
   
}
