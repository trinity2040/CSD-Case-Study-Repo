package com.cts.moduleManager;

import com.cts.dataBaseConnection.connectDatabase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class updateModule {

    public static void updateModule(Scanner scanner) {
        try (Connection con = connectDatabase.getConnection()) {
            System.out.println("Enter Module ID to update:");
            int moduleId = scanner.nextInt();
            scanner.nextLine(); 

            System.out.println("Enter new Module Title:");
            String newTitle = scanner.nextLine();
            System.out.println("Enter new Module Content:");
            String newContent = scanner.nextLine();
            System.out.println("Enter new Module Duration (in hours):");
            int newDuration = scanner.nextInt();

            String sql = "UPDATE `module` SET `title` = ?, `content` = ?, `duration` = ? WHERE `module_id` = ?";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setString(1, newTitle);
                pstmt.setString(2, newContent);
                pstmt.setInt(3, newDuration);
                pstmt.setInt(4, moduleId);

                int rowsUpdated = pstmt.executeUpdate();
                if (rowsUpdated > 0) {
                    System.out.println("Module updated successfully!");
                } else {
                    System.out.println("No module found with the provided Module ID.");
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

}
