package com.cts.moduleManager;

import com.cts.dataBaseConnection.connectDatabase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class deleteModule {

    public static void deleteModule(Scanner scanner) {
        try (Connection con = connectDatabase.getConnection()) {
            System.out.println("Enter Module ID to delete:");
            int moduleId = scanner.nextInt();

            String sql = "DELETE FROM `module` WHERE `module_id` = ?";
            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setInt(1, moduleId);

                int rowsDeleted = pstmt.executeUpdate();
                if (rowsDeleted > 0) {
                    System.out.println("Module deleted successfully!");
                } else {
                    System.out.println("No module found with the provided Module ID.");
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

    
}

