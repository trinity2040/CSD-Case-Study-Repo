package com.cts.moduleManager;

import com.cts.dataBaseConnection.connectDatabase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class newModule {

    public static void addModule(Scanner scanner) {
        try (Connection con = connectDatabase.getConnection()) {
            
            System.out.println("Enter Module ID:");
            int moduleId = scanner.nextInt();
            scanner.nextLine(); 
            System.out.println("Enter Course ID:");
            int courseId = scanner.nextInt();
            scanner.nextLine(); 

            System.out.println("Enter Module Title:");
            String title = scanner.nextLine();

            System.out.println("Enter Module Content:");
            String content = scanner.nextLine();

            System.out.println("Enter Module Duration (in hours):");
            int duration = scanner.nextInt();

            
            String sql = "INSERT INTO `module` (`module_id`, `course_id`, `title`, `content`, `duration`) VALUES (?, ?, ?, ?, ?)";

            try (PreparedStatement pstmt = con.prepareStatement(sql)) {
                pstmt.setInt(1, moduleId);      
                pstmt.setInt(2, courseId);      
                pstmt.setString(3, title);     
                pstmt.setString(4, content);    
                pstmt.setInt(5, duration);     

                // Execute the update
                int rowsInserted = pstmt.executeUpdate();
                if (rowsInserted > 0) {
                    System.out.println("Module added successfully!");
                } else {
                    System.out.println("Failed to add module.");
                }
            }
        } catch (SQLException e) {
            System.out.println(e);
        }
    }

 
}
