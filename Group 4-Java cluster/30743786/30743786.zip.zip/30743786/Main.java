package project;

import java.sql.*;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\nStock Management System");
            System.out.println("1. Product Management");
            System.out.println("2. Supplier Management");
            System.out.println("3. Order Management");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    manageProducts();
                    break;
                case 2:
                    manageSuppliers();
                    break;
                case 3:
                    manageOrders();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 4);
    }

    // Product Management
    private static void manageProducts() {
        Scanner sc = new Scanner(System.in);
        int choice;
        do {
            System.out.println("\nProduct Management");
            System.out.println("1. Add a new Product");
            System.out.println("2. View all Products");
            System.out.println("3. View Product by ID");
            System.out.println("4. Update Product by ID");
            System.out.println("5. Delete Product by ID");
            System.out.println("6. Back to Main Menu");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    addProduct();
                    break;
                case 2:
                    viewAllProducts();
                    break;
                case 3:
                    viewProductById();
                    break;
                case 4:
                    updateProductById();
                    break;
                case 5:
                    deleteProductById();
                    break;
                case 6:
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 6);
    }

    private static void addProduct() {
        try (Connection conn = Database.getConnection()) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter product name: ");
            String name = sc.nextLine();
            System.out.print("Enter product description: ");
            String description = sc.nextLine();
            System.out.print("Enter product price: ");
            double price = sc.nextDouble();
            System.out.print("Enter quantity in stock: ");
            int quantityInStock = sc.nextInt();

            String sql = "INSERT INTO Product (name, description, price, quantity_in_stock) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, name);
                pstmt.setString(2, description);
                pstmt.setDouble(3, price);
                pstmt.setInt(4, quantityInStock);
                pstmt.executeUpdate();
                System.out.println("Product added successfully!");
            }
        } catch (SQLException e) {
            System.out.println("Error adding product: " + e.getMessage());
        }
    }

    private static void viewAllProducts() {
        try (Connection conn = Database.getConnection()) {
            String sql = "SELECT * FROM Product";
            try (Statement stmt = conn.createStatement()) {
                ResultSet rs = stmt.executeQuery(sql);
                while (rs.next()) {
                    System.out.println("Product ID: " + rs.getInt("product_id"));
                    System.out.println("Name: " + rs.getString("name"));
                    System.out.println("Description: " + rs.getString("description"));
                    System.out.println("Price: " + rs.getDouble("price"));
                    System.out.println("Quantity in Stock: " + rs.getInt("quantity_in_stock"));
                    System.out.println("---------------------------");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error viewing products: " + e.getMessage());
        }
    }

    private static void viewProductById() {
        try (Connection conn = Database.getConnection()) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter product ID: ");
            int productId = sc.nextInt();

            String sql = "SELECT * FROM Product WHERE product_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, productId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    System.out.println("Product ID: " + rs.getInt("product_id"));
                    System.out.println("Name: " + rs.getString("name"));
                    System.out.println("Description: " + rs.getString("description"));
                    System.out.println("Price: " + rs.getDouble("price"));
                    System.out.println("Quantity in Stock: " + rs.getInt("quantity_in_stock"));
                } else {
                    System.out.println("Product not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error viewing product: " + e.getMessage());
        }
    }

    private static void updateProductById() {
        try (Connection conn = Database.getConnection()) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter product ID: ");
            int productId = sc.nextInt();
            sc.nextLine(); 
            System.out.print("Enter new product name: ");
            String name = sc.nextLine();
            System.out.print("Enter new product description: ");
            String description = sc.nextLine();
            System.out.print("Enter new product price: ");
            double price = sc.nextDouble();
            System.out.print("Enter new quantity in stock: ");
            int quantityInStock = sc.nextInt();

            String sql = "UPDATE Product SET name = ?, description = ?, price = ?, quantity_in_stock = ? WHERE product_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, name);
                pstmt.setString(2, description);
                pstmt.setDouble(3, price);
                pstmt.setInt(4, quantityInStock);
                pstmt.setInt(5, productId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Product updated successfully!");
                } else {
                    System.out.println("Product not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error updating product: " + e.getMessage());
        }
    }

    private static void deleteProductById() {
        try (Connection conn = Database.getConnection()) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter product ID: ");
            int productId = sc.nextInt();

            String sql = "DELETE FROM Product WHERE product_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, productId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Product deleted successfully!");
                } else {
                    System.out.println("Product not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error deleting product: " + e.getMessage());
        }
    }

    // Supplier Management
    private static void manageSuppliers() {
        Scanner sc = new Scanner(System.in);
        int choice;
        do {
            System.out.println("\nSupplier Management");
            System.out.println("1. Add a new Supplier");
            System.out.println("2. View all Suppliers");
            System.out.println("3. View Supplier by ID");
            System.out.println("4. Update Supplier by ID");
            System.out.println("5. Delete Supplier by ID");
            System.out.println("6. Back to Main Menu");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    addSupplier();
                    break;
                case 2:
                    viewAllSuppliers();
                    break;
                case 3:
                    viewSupplierById();
                    break;
                case 4:
                    updateSupplierById();
                    break;
                case 5:
                    deleteSupplierById();
                    break;
                case 6:
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 6);
    }

    private static void addSupplier() {
        try (Connection conn = Database.getConnection()) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter supplier name: ");
            String name = sc.nextLine();
            System.out.print("Enter supplier email: ");
            String email = sc.nextLine();
            System.out.print("Enter supplier phone number: ");
            String phoneNumber = sc.nextLine();
            System.out.print("Enter supplier address: ");
            String address = sc.nextLine();

            String sql = "INSERT INTO Supplier (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, name);
                pstmt.setString(2, email);
                pstmt.setString(3, phoneNumber);
                pstmt.setString(4, address);
                pstmt.executeUpdate();
                System.out.println("Supplier added successfully!");
            }
        } catch (SQLException e) {
            System.out.println("Error adding supplier: " + e.getMessage());
        }
    }

    private static void viewAllSuppliers() {
        try (Connection conn = Database.getConnection()) {
            String sql = "SELECT * FROM Supplier";
            try (Statement stmt = conn.createStatement()) {
                ResultSet rs = stmt.executeQuery(sql);
                while (rs.next()) {
                    System.out.println("Supplier ID: " + rs.getInt("supplier_id"));
                    System.out.println("Name: " + rs.getString("name"));
                    System.out.println("Email: " + rs.getString("email"));
                    System.out.println("Phone Number: " + rs.getString("phone_number"));
                    System.out.println("Address: " + rs.getString("address"));
                    System.out.println("---------------------------");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error viewing suppliers: " + e.getMessage());
        }
    }

    private static void viewSupplierById() {
        try (Connection conn = Database.getConnection()) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter supplier ID: ");
            int supplierId = sc.nextInt();

            String sql = "SELECT * FROM Supplier WHERE supplier_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, supplierId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    System.out.println("Supplier ID: " + rs.getInt("supplier_id"));
                    System.out.println("Name: " + rs.getString("name"));
                    System.out.println("Email: " + rs.getString("email"));
                    System.out.println("Phone Number: " + rs.getString("phone_number"));
                    System.out.println("Address: " + rs.getString("address"));
                } else {
                    System.out.println("Supplier not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error viewing supplier: " + e.getMessage());
        }
    }

    private static void updateSupplierById() {
        try (Connection conn = Database.getConnection()) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter supplier ID: ");
            int supplierId = sc.nextInt();
            sc.nextLine(); 
            System.out.print("Enter new supplier name: ");
            String name = sc.nextLine();
            System.out.print("Enter new supplier email: ");
            String email = sc.nextLine();
            System.out.print("Enter new supplier phone number: ");
            String phoneNumber = sc.nextLine();
            System.out.print("Enter new supplier address: ");
            String address = sc.nextLine();

            String sql = "UPDATE Supplier SET name = ?, email = ?, phone_number = ?, address = ? WHERE supplier_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, name);
                pstmt.setString(2, email);
                pstmt.setString(3, phoneNumber);
                pstmt.setString(4, address);
                pstmt.setInt(5, supplierId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Supplier updated successfully!");
                } else {
                    System.out.println("Supplier not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error updating supplier: " + e.getMessage());
        }
    }

    private static void deleteSupplierById() {
        try (Connection conn = Database.getConnection()) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter supplier ID: ");
            int supplierId = sc.nextInt();

            String sql = "DELETE FROM Supplier WHERE supplier_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, supplierId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Supplier deleted successfully!");
                } else {
                    System.out.println("Supplier not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error deleting supplier: " + e.getMessage());
        }
    }

    // Order Management
    private static void manageOrders() {
        Scanner sc = new Scanner(System.in);
        int choice;
        do {
            System.out.println("\nOrder Management");
            System.out.println("1. Place a new Order");
            System.out.println("2. View all Orders");
            System.out.println("3. View Order by ID");
            System.out.println("4. Update Order by ID");
            System.out.println("5. Cancel an Order");
            System.out.println("6. Back to Main Menu");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    placeOrder();
                    break;
                case 2:
                    viewAllOrders();
                    break;
                case 3:
                    viewOrderById();
                    break;
                case 4:
                    updateOrderById();
                    break;
                case 5:
                    cancelOrder();
                    break;
                case 6:
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 6);
    }

    private static void placeOrder() {
        try (Connection conn = Database.getConnection()) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter product ID: ");
            int productId = sc.nextInt();
            System.out.print("Enter supplier ID: ");
            int supplierId = sc.nextInt();
            System.out.print("Enter quantity: ");
            int quantity = sc.nextInt();

            String sql = "INSERT INTO `Order` (product_id, supplier_id, quantity) VALUES (?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, productId);
                pstmt.setInt(2, supplierId);
                pstmt.setInt(3, quantity);
                pstmt.executeUpdate();
                System.out.println("Order placed successfully!");
            }
        } catch (SQLException e) {
            System.out.println("Error placing order: " + e.getMessage());
        }
    }

    private static void viewAllOrders() {
        try (Connection conn = Database.getConnection()) {
            String sql = "SELECT * FROM `Order`";
            try (Statement stmt = conn.createStatement()) {
                ResultSet rs = stmt.executeQuery(sql);
                while (rs.next()) {
                    System.out.println("Order ID: " + rs.getInt("order_id"));
                    System.out.println("Product ID: " + rs.getInt("product_id"));
                    System.out.println("Supplier ID: " + rs.getInt("supplier_id"));
                    System.out.println("Quantity: " + rs.getInt("quantity"));
                    System.out.println("---------------------------");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error viewing orders: " + e.getMessage());
        }
    }

    private static void viewOrderById() {
        try (Connection conn = Database.getConnection()) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter order ID: ");
            int orderId = sc.nextInt();

            String sql = "SELECT * FROM `Order` WHERE order_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, orderId);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    System.out.println("Order ID: " + rs.getInt("order_id"));
                    System.out.println("Product ID: " + rs.getInt("product_id"));
                    System.out.println("Supplier ID: " + rs.getInt("supplier_id"));
                    System.out.println("Quantity: " + rs.getInt("quantity"));
                } else {
                    System.out.println("Order not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error viewing order: " + e.getMessage());
        }
    }

    private static void updateOrderById() {
        try (Connection conn = Database.getConnection()) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter order ID: ");
            int orderId = sc.nextInt();
            System.out.print("Enter new quantity: ");
            int quantity = sc.nextInt();

            String sql = "UPDATE `Order` SET quantity = ? WHERE order_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, quantity);
                pstmt.setInt(2, orderId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Order updated successfully!");
                } else {
                    System.out.println("Order not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error updating order: " + e.getMessage());
        }
    }

    private static void cancelOrder() {
        try (Connection conn = Database.getConnection()) {
            Scanner sc = new Scanner(System.in);
            System.out.print("Enter order ID: ");
            int orderId = sc.nextInt();

            String sql = "DELETE FROM `Order` WHERE order_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, orderId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("Order canceled successfully!");
                } else {
                    System.out.println("Order not found.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Error canceling order: " + e.getMessage());
        }
    }
}
