# Car Insurance Management System

## Description
The Car Insurance Management System is a console-based Java application that allows users to manage car insurance policies, customers, and claims. The system is built using Core Java and utilizes MySQL as the backend database, with JDBC (Java Database Connectivity) for database operations. This application provides a simple menu-driven interface to perform CRUD (Create, Read, Update, Delete) operations on the data.

## Features
- **Policy Management**: Add, view, update, and delete policies.
- **Customer Management**: Add, view, update, and delete artists.
- **SClaim Management**: Record, view, update, and cancel sales.

## System Requirements
- Java Development Kit (JDK) 8 or later
- MySQL Server
- MySQL Connector/J (JDBC Driver)
- Integrated Development Environment (IDE): IntelliJ IDEA, Eclipse, or   any other Java IDE

## Setup Instructions
1. **Database Setup**:
   - Create a MySQL database named `car_insurance_db`.
   - Create the following tables:

     ```sql
     CREATE TABLE Policy (
    policy_id INT AUTO_INCREMENT PRIMARY KEY,
    policy_number VARCHAR(50) NOT NULL,
    type VARCHAR(50) NOT NULL,
    coverage_amount DECIMAL(10, 2) NOT NULL,
    premium_amount DECIMAL(10, 2) NOT NULL
    );

    CREATE TABLE Customer (
        customer_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        phone_number VARCHAR(15) NOT NULL,
        address TEXT NOT NULL
    );

    CREATE TABLE Claim (
        claim_id INT AUTO_INCREMENT PRIMARY KEY,
        policy_id INT,
        customer_id INT,
        claim_date DATE NOT NULL,
        status ENUM('submitted', 'processed') DEFAULT 'submitted',
        FOREIGN KEY (policy_id) REFERENCES Policy(policy_id),
        FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
    );
     ```

2. **Configure the Application**:
   - Open the DBconnection.java file located in the src/database  directory and update it with your MySQL database credentials:
 
   ```java
      private static final String URL = "jdbc:mysql://localhost:3306/car_insurance_db";
      private static final String USER = "your_username";
      private static final String PASSWORD = "your_password";

   ```

3. **Run the Application**:
   - Compile and run the `DBconnection.java` class.
   - Follow the on-screen menu to manage policy, customer, claim.

## Usage
- Select the appropriate menu option to perform operations like adding, viewing, updating, or deleting records in the system.

## Notes
- Ensure that your MySQL server is running and accessible.
- Modify the database credentials in the `DBconnection.java` file if necessary.



