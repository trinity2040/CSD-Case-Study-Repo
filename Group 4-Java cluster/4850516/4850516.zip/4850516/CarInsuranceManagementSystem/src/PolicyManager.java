import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class PolicyManager {

    public static void managePolicies() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\n--- Policy Management ---");
        
        System.out.println("1. Add a new policy");
        System.out.println("2. View policy details");
        System.out.println("3. Update policy information");
        System.out.println("4. Delete a policy");
        System.out.print("\nEnter your choice: ");
        
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                addPolicy();
                break;
            case 2:
                viewPolicy();
                break;
            case 3:
                updatePolicy();
                break;
            case 4:
                deletePolicy();
                break;
            default:
                System.out.println("Invalid choice! Please try again.");
        }
    }

    public static void addPolicy() {
        try (Connection conn = DBconnection.getConnection()) {
            String sql = "INSERT INTO Policy (policy_number, type, coverage_amount, premium_amount) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter policy number: ");
            stmt.setString(1, scanner.nextLine());

            System.out.print("Enter policy type: ");
            stmt.setString(2, scanner.nextLine());

            System.out.print("Enter coverage amount: ");
            stmt.setDouble(3, scanner.nextDouble());

            System.out.print("Enter premium amount: ");
            stmt.setDouble(4, scanner.nextDouble());

            stmt.executeUpdate();
            System.out.println("Policy added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewPolicy() {
        try (Connection conn = DBconnection.getConnection()) {
            String sql = "SELECT * FROM Policy WHERE policy_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter policy ID to view: ");
            int policyId = scanner.nextInt();
            stmt.setInt(1, policyId);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Policy ID: " + rs.getInt("policy_id"));
                System.out.println("Policy Number: " + rs.getString("policy_number"));
                System.out.println("Type: " + rs.getString("type"));
                System.out.println("Coverage Amount: " + rs.getDouble("coverage_amount"));
                System.out.println("Premium Amount: " + rs.getDouble("premium_amount"));
            } else {
                System.out.println("Policy not found with ID: " + policyId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updatePolicy() {
        try (Connection conn = DBconnection.getConnection()) {
            String sql = "UPDATE Policy SET policy_number = ?, type = ?, coverage_amount = ?, premium_amount = ? WHERE policy_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter policy ID to update: ");
            int policyId = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            System.out.print("Enter new policy number: ");
            stmt.setString(1, scanner.nextLine());

            System.out.print("Enter new policy type: ");
            stmt.setString(2, scanner.nextLine());

            System.out.print("Enter new coverage amount: ");
            stmt.setDouble(3, scanner.nextDouble());

            System.out.print("Enter new premium amount: ");
            stmt.setDouble(4, scanner.nextDouble());

            stmt.setInt(5, policyId);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Policy updated successfully!");
            } else {
                System.out.println("Policy not found with ID: " + policyId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deletePolicy() {
        try (Connection conn = DBconnection.getConnection()) {
            String sql = "DELETE FROM Policy WHERE policy_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter policy ID to delete: ");
            int policyId = scanner.nextInt();
            stmt.setInt(1, policyId);

            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Policy deleted successfully!");
            } else {
                System.out.println("Policy not found with ID: " + policyId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}

