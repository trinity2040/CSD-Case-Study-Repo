package main.java.com.eventmanagement.services;

import main.java.com.eventmanagement.dao.EventDAO;
import main.java.com.eventmanagement.models.Event;

public class EventService {
    private EventDAO eventDAO = new EventDAO();

    public void createEvent(int eventId, String name, String date, String location, int capacity) {
        Event event = new Event(eventId, name, date, location, capacity);
        eventDAO.addEvent(event);
    }

    public Event getEvent(int eventId) {
        return eventDAO.getEvent(eventId);
    }

    public void updateEvent(int eventId, String name, String date, String location, int capacity) {
        Event event = new Event(eventId, name, date, location, capacity);
        eventDAO.updateEvent(event);
    }

    public void deleteEvent(int eventId) {
        eventDAO.deleteEvent(eventId);
    }
}
