package main.java.com.eventmanagement.dao;

import main.java.com.eventmanagement.models.Participant;
import main.java.com.eventmanagement.config.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ParticipantDAO {

    public void registerParticipant(Participant participant) {
        String query = "INSERT INTO Participant (participant_id, name, email, phone_number) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, participant.getParticipantId());
            stmt.setString(2, participant.getName());
            stmt.setString(3, participant.getEmail());
            stmt.setString(4, participant.getPhoneNumber());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Participant getParticipant(int participantId) {
        String query = "SELECT * FROM Participant WHERE participant_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, participantId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Participant(
                        rs.getInt("participant_id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("phone_number")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updateParticipant(Participant participant) {
        String query = "UPDATE Participant SET name = ?, email = ?, phone_number = ? WHERE participant_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, participant.getName());
            stmt.setString(2, participant.getEmail());
            stmt.setString(3, participant.getPhoneNumber());
            stmt.setInt(4, participant.getParticipantId());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteParticipant(int participantId) {
        String query = "DELETE FROM Participant WHERE participant_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, participantId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}