package main.java.com.eventmanagement.services;

import main.java.com.eventmanagement.dao.ParticipantDAO;
import main.java.com.eventmanagement.models.Participant;

public class ParticipantService {
    private ParticipantDAO participantDAO = new ParticipantDAO();

    public void registerParticipant(int participantId, String name, String email, String phoneNumber) {
        Participant participant = new Participant(participantId, name, email, phoneNumber);
        participantDAO.registerParticipant(participant);
    }

    public Participant getParticipant(int participantId) {
        return participantDAO.getParticipant(participantId);
    }

    public void updateParticipant(int participantId, String name, String email, String phoneNumber) {
        Participant participant = new Participant(participantId, name, email, phoneNumber);
        participantDAO.updateParticipant(participant);
    }

    public void deleteParticipant(int participantId) {
        participantDAO.deleteParticipant(participantId);
    }
}
