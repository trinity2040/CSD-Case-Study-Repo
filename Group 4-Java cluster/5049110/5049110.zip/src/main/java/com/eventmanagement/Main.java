package main.java.com.eventmanagement;

import main.java.com.eventmanagement.services.EventService;
import main.java.com.eventmanagement.services.ParticipantService;
import main.java.com.eventmanagement.services.RegistrationService;
import main.java.com.eventmanagement.utils.InputUtil;

public class Main {
    private static EventService eventService = new EventService();
    private static ParticipantService participantService = new ParticipantService();
    private static RegistrationService registrationService = new RegistrationService();

    public static void main(String[] args) {
        while (true) {
            System.out.println("-------------------------------");
            System.out.println("1. EVENT MANAGEMENT");
            System.out.println("2. PARTICIPANT MANAGEMENT");
            System.out.println("3. REGISTRATION MANAGEMENT");
            System.out.println("4. EXIT");
            System.out.println("-------------------------------");
            System.out.print("Choose an option: ");
            int choice = InputUtil.getIntInput("");

            switch (choice) {
                case 1:
                    eventManagementMenu();
                    break;
                case 2:
                    participantManagementMenu();
                    break;
                case 3:
                    registrationManagementMenu();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void eventManagementMenu() {
        System.out.println("Event Management Menu:");
        System.out.println("-------------------------------");
        System.out.println("1. Add Event");
        System.out.println("2. View Event");
        System.out.println("3. Update Event");
        System.out.println("4. Delete Event");
        System.out.println("5. Go Back");
        System.out.println("-------------------------------");
        System.out.print("Choose an option: ");
        int choice = InputUtil.getIntInput("");

        switch (choice) {
            case 1:
                int eventId = InputUtil.getIntInput("Enter Event ID: ");
                String name = InputUtil.getStringInput("Enter Event Name: ");
                String date = InputUtil.getStringInput("Enter Event Date (YYYY-MM-DD): ");
                String location = InputUtil.getStringInput("Enter Event Location: ");
                int capacity = InputUtil.getIntInput("Enter Event Capacity: ");
                eventService.createEvent(eventId, name, date, location, capacity);
                System.out.println("Event added successfully!");
                break;
            case 2:
                eventId = InputUtil.getIntInput("Enter Event ID: ");
                var event = eventService.getEvent(eventId);
                if (event != null) {
                    System.out.println("Event ID: " + event.getEventId());
                    System.out.println("Name: " + event.getName());
                    System.out.println("Date: " + event.getDate());
                    System.out.println("Location: " + event.getLocation());
                    System.out.println("Capacity: " + event.getCapacity());
                } else {
                    System.out.println("Event not found.");
                }
                break;
            case 3:
                eventId = InputUtil.getIntInput("Enter Event ID to update: ");
                name = InputUtil.getStringInput("Enter new Event Name: ");
                date = InputUtil.getStringInput("Enter new Event Date (YYYY-MM-DD): ");
                location = InputUtil.getStringInput("Enter new Event Location: ");
                capacity = InputUtil.getIntInput("Enter new Event Capacity: ");
                eventService.updateEvent(eventId, name, date, location, capacity);
                System.out.println("Event updated successfully!");
                break;
            case 4:
                eventId = InputUtil.getIntInput("Enter Event ID to delete: ");
                eventService.deleteEvent(eventId);
                System.out.println("Event deleted successfully!");
                break;
            case 5:
                return;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void participantManagementMenu() {
        System.out.println("Participant Management Menu:");
        System.out.println("-------------------------------");
        System.out.println("1. Register Participant");
        System.out.println("2. View Participant");
        System.out.println("3. Update Participant");
        System.out.println("4. Delete Participant");
        System.out.println("-------------------------------");
        System.out.print("Choose an option: ");
        int choice = InputUtil.getIntInput("");

        switch (choice) {
            case 1:
                int participantId = InputUtil.getIntInput("Enter Participant ID: ");
                String name = InputUtil.getStringInput("Enter Participant Name: ");
                String email = InputUtil.getStringInput("Enter Participant Email: ");
                String phoneNumber = InputUtil.getStringInput("Enter Participant Phone Number: ");
                participantService.registerParticipant(participantId, name, email, phoneNumber);
                System.out.println("Participant registered successfully!");
                break;
            case 2:
                participantId = InputUtil.getIntInput("Enter Participant ID: ");
                var participant = participantService.getParticipant(participantId);
                if (participant != null) {
                    System.out.println("Participant ID: " + participant.getParticipantId());
                    System.out.println("Name: " + participant.getName());
                    System.out.println("Email: " + participant.getEmail());
                    System.out.println("Phone Number: " + participant.getPhoneNumber());
                } else {
                    System.out.println("Participant not found.");
                }
                break;
            case 3:
                participantId = InputUtil.getIntInput("Enter Participant ID to update: ");
                name = InputUtil.getStringInput("Enter new Participant Name: ");
                email = InputUtil.getStringInput("Enter new Participant Email: ");
                phoneNumber = InputUtil.getStringInput("Enter new Participant Phone Number: ");
                participantService.updateParticipant(participantId, name, email, phoneNumber);
                System.out.println("Participant updated successfully!");
                break;
            case 4:
                participantId = InputUtil.getIntInput("Enter Participant ID to delete: ");
                participantService.deleteParticipant(participantId);
                System.out.println("Participant deleted successfully!");
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void registrationManagementMenu() {
        System.out.println("Registration Management Menu:");
        System.out.println("-------------------------------");
        System.out.println("1. Register for Event");
        System.out.println("2. View Registration");
        System.out.println("3. Cancel Registration");
        System.out.println("4. List Participants for Event");
        System.out.println("-------------------------------");
        System.out.print("Choose an option: ");
        int choice = InputUtil.getIntInput("");

        switch (choice) {
            case 1:
                int registrationId = InputUtil.getIntInput("Enter Registration ID: ");
                int eventId = InputUtil.getIntInput("Enter Event ID: ");
                int participantId = InputUtil.getIntInput("Enter Participant ID: ");
                String registrationDate = InputUtil.getStringInput("Enter Registration Date (YYYY-MM-DD): ");
                registrationService.registerForEvent(registrationId, eventId, participantId, registrationDate);
                System.out.println("Participant registered for the event successfully!");
                break;
            case 2:
                registrationId = InputUtil.getIntInput("Enter Registration ID: ");
                var registration = registrationService.getRegistration(registrationId);
                if (registration != null) {
                    System.out.println("Registration ID: " + registration.getRegistrationId());
                    System.out.println("Event ID: " + registration.getEventId());
                    System.out.println("Participant ID: " + registration.getParticipantId());
                    System.out.println("Registration Date: " + registration.getRegistrationDate());
                } else {
                    System.out.println("Registration not found.");
                }
                break;
            case 3:
                registrationId = InputUtil.getIntInput("Enter Registration ID to cancel: ");
                registrationService.cancelRegistration(registrationId);
                System.out.println("Registration canceled successfully!");
                break;
            case 4:
                eventId = InputUtil.getIntInput("Enter Event ID: ");
                registrationService.listParticipantsForEvent(eventId);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
}