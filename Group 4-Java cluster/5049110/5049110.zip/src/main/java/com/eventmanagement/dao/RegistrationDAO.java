package main.java.com.eventmanagement.dao;

import main.java.com.eventmanagement.models.Registration;
import main.java.com.eventmanagement.config.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class RegistrationDAO {

    public void registerForEvent(Registration registration) {
        String query = "INSERT INTO Registration (registration_id, event_id, participant_id, registration_date) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, registration.getRegistrationId());
            stmt.setInt(2, registration.getEventId());
            stmt.setInt(3, registration.getParticipantId());
            stmt.setString(4, registration.getRegistrationDate());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Registration getRegistration(int registrationId) {
        String query = "SELECT * FROM Registration WHERE registration_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, registrationId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Registration(
                        rs.getInt("registration_id"),
                        rs.getInt("event_id"),
                        rs.getInt("participant_id"),
                        rs.getString("registration_date")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void cancelRegistration(int registrationId) {
        String query = "DELETE FROM Registration WHERE registration_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, registrationId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ResultSet listParticipantsForEvent(int eventId) {
        String query = "SELECT p.participant_id, p.name, p.email, p.phone_number FROM Participant p " +
                "JOIN Registration r ON p.participant_id = r.participant_id " +
                "WHERE r.event_id = ?";
        try {
            Connection conn = DBUtil.getConnection();
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setInt(1, eventId);
            return stmt.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
