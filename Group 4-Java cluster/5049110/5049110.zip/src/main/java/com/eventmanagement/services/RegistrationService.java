package main.java.com.eventmanagement.services;

import main.java.com.eventmanagement.dao.RegistrationDAO;
import main.java.com.eventmanagement.models.Registration;

import java.sql.SQLException;

public class RegistrationService {
    private RegistrationDAO registrationDAO = new RegistrationDAO();

    public void registerForEvent(int registrationId, int eventId, int participantId, String registrationDate) {
        Registration registration = new Registration(registrationId, eventId, participantId, registrationDate);
        registrationDAO.registerForEvent(registration);
    }

    public Registration getRegistration(int registrationId) {
        return registrationDAO.getRegistration(registrationId);
    }

    public void cancelRegistration(int registrationId) {
        registrationDAO.cancelRegistration(registrationId);
    }

    public void listParticipantsForEvent(int eventId) {
        try {
            var rs = registrationDAO.listParticipantsForEvent(eventId);
            while (rs != null && rs.next()) {
                System.out.println("Participant ID: " + rs.getInt("participant_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone Number: " + rs.getString("phone_number"));
                System.out.println();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
