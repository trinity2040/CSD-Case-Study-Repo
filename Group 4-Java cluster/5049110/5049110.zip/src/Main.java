
import java.sql.Date;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        EventManagement eventManager = new EventManagement();
        ParticipantManagement participantManager = new ParticipantManagement();
        RegistrationManagement registrationManager = new RegistrationManagement();

        while (true) {
            System.out.println("------------------------");
            System.out.println("1. EVENT MANAGEMENT");
            System.out.println("2. PARTICIPANT MANAGEMENT");
            System.out.println("3. REGISTRATION MANAGEMENT");
            System.out.println("4. EXIT");
            System.out.println("------------------------");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1: // Event Management
                    eventManagementMenu(scanner, eventManager);
                    break;
                case 2: // Participant Management
                    participantManagementMenu(scanner, participantManager);
                    break;
                case 3: // Registration Management
                    registrationManagementMenu(scanner, registrationManager);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void eventManagementMenu(Scanner scanner, EventManagement eventManager) {
        while (true) {
            System.out.println("Event Management Menu:");
            System.out.println("--------------------------");
            System.out.println("1. Add Event");
            System.out.println("2. View Event Details");
            System.out.println("3. Update Event Information");
            System.out.println("4. Delete Event");
            System.out.println("5. Back to Main Menu");
            System.out.println("--------------------------");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter event name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter event date (YYYY-MM-DD): ");
                        Date date = Date.valueOf(scanner.nextLine());
                        System.out.print("Enter event location: ");
                        String location = scanner.nextLine();
                        System.out.print("Enter event capacity: ");
                        int capacity = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        eventManager.addEvent(name, date, location, capacity);
                        System.out.println("Event added successfully.");
                        break;
                    case 2:
                        System.out.print("Enter event ID: ");
                        int eventId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        eventManager.viewEvent(eventId);
                        break;
                    case 3:
                        System.out.print("Enter event ID to update: ");
                        eventId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        System.out.print("Enter new event name: ");
                        name = scanner.nextLine();
                        System.out.print("Enter new event date (YYYY-MM-DD): ");
                        date = Date.valueOf(scanner.nextLine());
                        System.out.print("Enter new event location: ");
                        location = scanner.nextLine();
                        System.out.print("Enter new event capacity: ");
                        capacity = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        eventManager.updateEvent(eventId, name, date, location, capacity);
                        System.out.println("Event updated successfully.");
                        break;
                    case 4:
                        System.out.print("Enter event ID to delete: ");
                        eventId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        eventManager.deleteEvent(eventId);
                        System.out.println("Event deleted successfully.");
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void participantManagementMenu(Scanner scanner, ParticipantManagement participantManager) {
        while (true) {
            System.out.println("Participant Management Menu:");
            System.out.println("----------------------------------");
            System.out.println("1. Register Participant");
            System.out.println("2. View Participant Details");
            System.out.println("3. Update Participant Information");
            System.out.println("4. Delete Participant");
            System.out.println("5. Back to Main Menu");
            System.out.println("----------------------------------");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter participant name: ");
                        String name = scanner.nextLine();
                        System.out.print("Enter participant email: ");
                        String email = scanner.nextLine();
                        System.out.print("Enter participant phone number: ");
                        String phoneNumber = scanner.nextLine();
                        participantManager.registerParticipant(name, email, phoneNumber);
                        System.out.println("Participant registered successfully.");
                        break;
                    case 2:
                        System.out.print("Enter participant ID: ");
                        int participantId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        participantManager.viewParticipant(participantId);
                        break;
                    case 3:
                        System.out.print("Enter participant ID to update: ");
                        participantId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        System.out.print("Enter new participant name: ");
                        name = scanner.nextLine();
                        System.out.print("Enter new participant email: ");
                        email = scanner.nextLine();
                        System.out.print("Enter new participant phone number: ");
                        phoneNumber = scanner.nextLine();
                        participantManager.updateParticipant(participantId, name, email, phoneNumber);
                        System.out.println("Participant updated successfully.");
                        break;
                    case 4:
                        System.out.print("Enter participant ID to delete: ");
                        participantId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        participantManager.deleteParticipant(participantId);
                        System.out.println("Participant deleted successfully.");
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void registrationManagementMenu(Scanner scanner, RegistrationManagement registrationManager) {
        while (true) {
            System.out.println("Registration Management Menu:");
            System.out.println("----------------------------------");
            System.out.println("1. Register for Event");
            System.out.println("2. View Registration Details");
            System.out.println("3. Cancel Registration");
            System.out.println("4. List Participants for an Event");
            System.out.println("5. Back to Main Menu");
            System.out.println("----------------------------------");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter event ID: ");
                        int eventId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        System.out.print("Enter participant ID: ");
                        int participantId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        registrationManager.registerForEvent(eventId, participantId);
                        System.out.println("Participant registered for the event successfully.");
                        break;
                    case 2:
                        System.out.print("Enter registration ID: ");
                        int registrationId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        registrationManager.viewRegistration(registrationId);
                        break;
                    case 3:
                        System.out.print("Enter registration ID to cancel: ");
                        registrationId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        registrationManager.cancelRegistration(registrationId);
                        System.out.println("Registration canceled successfully.");
                        break;
                    case 4:
                        System.out.print("Enter event ID to list participants: ");
                        eventId = scanner.nextInt();
                        scanner.nextLine(); // consume newline
                        registrationManager.listParticipantsForEvent(eventId);
                        break;
                    case 5:
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }
}
