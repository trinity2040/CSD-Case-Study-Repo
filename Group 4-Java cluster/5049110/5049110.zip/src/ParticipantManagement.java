//import java.sql.*;
//import java.util.Scanner;
//
//public class ParticipantManagement {
//
//    public void addParticipant() {
//        try (Connection connection = DatabaseConnection.getConnection()) {
//            Scanner scanner = new Scanner(System.in);
//            System.out.println("Enter participant name:");
//            String name = scanner.nextLine();
//            System.out.println("Enter participant email:");
//            String email = scanner.nextLine();
//            System.out.println("Enter participant phone number:");
//            String phone = scanner.nextLine();
//
//            String sql = "INSERT INTO Participant (name, email, phone_number) VALUES (?, ?, ?)";
//            PreparedStatement statement = connection.prepareStatement(sql);
//            statement.setString(1, name);
//            statement.setString(2, email);
//            statement.setString(3, phone);
//
//            int rowsInserted = statement.executeUpdate();
//            if (rowsInserted > 0) {
//                System.out.println("A new participant was inserted successfully!");
//            }
//        } catch (SQLException ex) {
//            ex.printStackTrace();
//        }
//    }
//
//    // Implement other methods: viewParticipant, updateParticipant, deleteParticipant
//}
//
import java.sql.*;

public class ParticipantManagement {

    public void registerParticipant(String name, String email, String phoneNumber) throws SQLException {
        String query = "INSERT INTO Participant (name, email, phone_number) VALUES (?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, phoneNumber);
            stmt.executeUpdate();
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void viewParticipant(int participantId) throws SQLException {
        String query = "SELECT * FROM Participant WHERE participant_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, participantId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Participant ID: " + rs.getInt("participant_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone Number: " + rs.getString("phone_number"));
            } else {
                System.out.println("Participant not found.");
            }
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void updateParticipant(int participantId, String name, String email, String phoneNumber) throws SQLException {
        String query = "UPDATE Participant SET name = ?, email = ?, phone_number = ? WHERE participant_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setString(2, email);
            stmt.setString(3, phoneNumber);
            stmt.setInt(4, participantId);
            stmt.executeUpdate();
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void deleteParticipant(int participantId) throws SQLException {
        String query = "DELETE FROM Participant WHERE participant_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, participantId);
            stmt.executeUpdate();
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
