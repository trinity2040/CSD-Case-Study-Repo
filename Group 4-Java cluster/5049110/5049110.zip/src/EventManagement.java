//import java.sql.*;
//import java.util.Scanner;
//
//public class EventManagement {
//
//    public void addEvent() {
//        try (Connection connection = DatabaseConnection.getConnection()) {
//            Scanner scanner = new Scanner(System.in);
//            System.out.println("Enter event name:");
//            String name = scanner.nextLine();
//            System.out.println("Enter event date (YYYY-MM-DD):");
//            String date = scanner.nextLine();
//            System.out.println("Enter event location:");
//            String location = scanner.nextLine();
//            System.out.println("Enter event capacity:");
//            int capacity = scanner.nextInt();
//
//            String sql = "INSERT INTO Event (name, date, location, capacity) VALUES (?, ?, ?, ?)";
//            PreparedStatement statement = connection.prepareStatement(sql);
//            statement.setString(1, name);
//            statement.setString(2, date);
//            statement.setString(3, location);
//            statement.setInt(4, capacity);
//
//            int rowsInserted = statement.executeUpdate();
//            if (rowsInserted > 0) {
//                System.out.println("A new event was inserted successfully!");
//            }
//        } catch (SQLException ex) {
//            ex.printStackTrace();
//        }
//    }
//
//    // Implement other methods: viewEvent, updateEvent, deleteEvent
//}
import java.sql.*;

public class EventManagement {

    public void addEvent(String name, Date date, String location, int capacity) throws SQLException {
        String query = "INSERT INTO Event (name, date, location, capacity) VALUES (?, ?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setDate(2, date);
            stmt.setString(3, location);
            stmt.setInt(4, capacity);
            stmt.executeUpdate();
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void viewEvent(int eventId) throws SQLException {
        String query = "SELECT * FROM Event WHERE event_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, eventId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Event ID: " + rs.getInt("event_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Date: " + rs.getDate("date"));
                System.out.println("Location: " + rs.getString("location"));
                System.out.println("Capacity: " + rs.getInt("capacity"));
            } else {
                System.out.println("Event not found.");
            }
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

    }

    public void updateEvent(int eventId, String name, Date date, String location, int capacity) throws SQLException {
        String query = "UPDATE Event SET name = ?, date = ?, location = ?, capacity = ? WHERE event_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, name);
            stmt.setDate(2, date);
            stmt.setString(3, location);
            stmt.setInt(4, capacity);
            stmt.setInt(5, eventId);
            stmt.executeUpdate();
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void deleteEvent(int eventId) throws SQLException {
        String query = "DELETE FROM Event WHERE event_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, eventId);
            stmt.executeUpdate();
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
