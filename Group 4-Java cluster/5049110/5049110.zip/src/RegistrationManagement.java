//import java.sql.*;
//import java.util.Scanner;
//
//public class RegistrationManagement {
//
//    public void registerParticipantForEvent() {
//        try (Connection connection = DatabaseConnection.getConnection()) {
//            Scanner scanner = new Scanner(System.in);
//            System.out.println("Enter event ID:");
//            int eventId = scanner.nextInt();
//            System.out.println("Enter participant ID:");
//            int participantId = scanner.nextInt();
//
//            String sql = "INSERT INTO Registration (event_id, participant_id, registration_date) VALUES (?, ?, NOW())";
//            PreparedStatement statement = connection.prepareStatement(sql);
//            statement.setInt(1, eventId);
//            statement.setInt(2, participantId);
//
//            int rowsInserted = statement.executeUpdate();
//            if (rowsInserted > 0) {
//                System.out.println("Participant registered successfully!");
//            }
//
//            // Update capacity in Event table
//            sql = "UPDATE Event SET capacity = capacity - 1 WHERE event_id = ?";
//            statement = connection.prepareStatement(sql);
//            statement.setInt(1, eventId);
//            statement.executeUpdate();
//        } catch (SQLException ex) {
//            ex.printStackTrace();
//        }
//    }
//
//    // Implement other methods: viewRegistration, cancelRegistration, listParticipantsForEvent
//}
//
import java.sql.*;

public class RegistrationManagement {

    public void registerForEvent(int eventId, int participantId) throws SQLException {
        // Check if capacity is available
        String checkCapacityQuery = "SELECT capacity FROM Event WHERE event_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement checkStmt = conn.prepareStatement(checkCapacityQuery)) {
            checkStmt.setInt(1, eventId);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next()) {
                int capacity = rs.getInt("capacity");

                // Check current registrations
                String countRegistrationsQuery = "SELECT COUNT(*) FROM Registration WHERE event_id = ?";
                try (PreparedStatement countStmt = conn.prepareStatement(countRegistrationsQuery)) {
                    countStmt.setInt(1, eventId);
                    ResultSet countRs = countStmt.executeQuery();
                    if (countRs.next()) {
                        int currentRegistrations = countRs.getInt(1);
                        if (currentRegistrations >= capacity) {
                            System.out.println("No capacity available for this event.");
                            return;
                        }
                    }
                }
            }
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        // Register participant for the event
        String registerQuery = "INSERT INTO Registration (event_id, participant_id, registration_date) VALUES (?, ?, ?)";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(registerQuery)) {
            stmt.setInt(1, eventId);
            stmt.setInt(2, participantId);
            stmt.setDate(3, new Date(System.currentTimeMillis()));
            stmt.executeUpdate();
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void viewRegistration(int registrationId) throws SQLException {
        String query = "SELECT * FROM Registration WHERE registration_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, registrationId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("Registration ID: " + rs.getInt("registration_id"));
                System.out.println("Event ID: " + rs.getInt("event_id"));
                System.out.println("Participant ID: " + rs.getInt("participant_id"));
                System.out.println("Registration Date: " + rs.getDate("registration_date"));
            } else {
                System.out.println("Registration not found.");
            }
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void cancelRegistration(int registrationId) throws SQLException {
        String query = "DELETE FROM Registration WHERE registration_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, registrationId);
            stmt.executeUpdate();
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    public void listParticipantsForEvent(int eventId) throws SQLException {
        String query = "SELECT p.participant_id, p.name, p.email, p.phone_number " +
                "FROM Participant p " +
                "JOIN Registration r ON p.participant_id = r.participant_id " +
                "WHERE r.event_id = ?";
        try (Connection conn = DBUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setInt(1, eventId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                System.out.println("Participant ID: " + rs.getInt("participant_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone Number: " + rs.getString("phone_number"));
                System.out.println();
            }
        }
        catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
