# Event Management System

## Overview

This project is a menu-based console application developed using Core Java, MySQL, and JDBC to manage an event management system. The application allows users to manage events, participants, and registrations through a simple command-line interface.

## Features

- *Event Management:*
    - Add a new event
    - View event details
    - Update event information
    - Delete an event

- *Participant Management:*
    - Register a new participant
    - View participant details
    - Update participant information
    - Delete a participant

- *Registration Management:*
    - Register a participant for an event
    - View registration details
    - Cancel a registration
    - List participants for a specific event

## Tech Stack

- *Programming Language:* Java
- *Database:* MySQL
- *Database Connectivity:* JDBC (Java Database Connectivity)
- *IDE:* IntelliJ IDEA, Eclipse, or any Java-supported IDE
- *Version Control:* Git

## Prerequisites

Before running the application, ensure you have the following installed:

1. *Java Development Kit (JDK)* - Version 8 or higher.
2. *MySQL Database Server* - Version 5.7 or higher.
3. *MySQL Workbench* (optional) - For database management.
4. *IDE* - IntelliJ IDEA, Eclipse, or any other Java-supported IDE.

## Database Setup

1. *Install MySQL:*
    - Download and install MySQL from the official [MySQL website](https://dev.mysql.com/downloads/installer/).
    - Set up a root user with a password.

2. *Create the Database:*
    - Open MySQL Workbench or use the MySQL command line to create a database.
    - Run the following SQL commands to create the necessary tables:

    ```sql
    CREATE DATABASE event_management;

    USE event_management;

    CREATE TABLE Event (
        event_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        date DATE NOT NULL,
        location VARCHAR(255) NOT NULL,
        capacity INT NOT NULL
    );

    CREATE TABLE Participant (
        participant_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        phone_number VARCHAR(20)
    );

    CREATE TABLE Registration (
        registration_id INT AUTO_INCREMENT PRIMARY KEY,
        event_id INT,
        participant_id INT,
        registration_date DATE NOT NULL,
        FOREIGN KEY (event_id) REFERENCES Event(event_id),
        FOREIGN KEY (participant_id) REFERENCES Participant(participant_id)
    );
    ```



###  Java Setup:
- Download the project and place the ```mysql-connector-java-x.x.xx.jar``` in the ```lib/``` directory.
- Add the MySQL connector JAR to your project’s classpath.

### Configure Database Connection

- Open the DBUtil.java file (or equivalent database utility file in your project).

- Update the JDBC URL, username, and password according to your MySQL setup:

```java
public class DBUtil {
    private static final String URL = "jdbc:mysql://localhost:3306/event_management";
    private static final String USER = "root";
    private static final String PASSWORD = "yourpassword";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
```

---

Make sure to replace placeholder text like ```yourpassword``` and ```yourusername``` with your correct credentials to connect to the MySQL server.

---

###  Run the Application:
- Compile and run the Main.java class.
- Follow the on-screen menu to manage events, participants, and registrations.

## Usage

Upon running the application, you will be presented with a menu that allows you to manage events, participants, and registrations. Follow the prompts to perform various operations.

### Sample Workflow

#### Event Management:
- Add an event by providing the event ID, name, date, location, and capacity.
- View or update event details using the event ID.

#### Participant Management:
- Register a participant by providing the participant ID, name, email, and phone number.
- View or update participant details using the participant ID.

#### Registration Management:
- Register a participant for an event by providing the event ID and participant ID.
- View registration details or cancel a registration using the registration ID.

## Notes
- Ensure that your MySQL server is running and accessible.
- Modify the database credentials in the ``` DBUtil.java ```file if necessary
