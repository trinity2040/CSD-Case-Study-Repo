package Models;

public class Vehicle {
    private int vehicleId;
    private String vehicleNumber;
    private int capacity;
    private String status;

    public Vehicle(int vehicleId, String vehicleNumber, int capacity, String status) {
        this.vehicleId = vehicleId;
        this.vehicleNumber = vehicleNumber;
        this.capacity = capacity;
        this.status = status;
    }
    public int getCapacity(){
	    return this.capacity;
	}

    // Getters and Setters

    @Override
    public String toString() {
        return "Vehicle ID: " + vehicleId + ", Number: " + vehicleNumber + ", Capacity: " + capacity + ", Status: " + status;
    }
}
