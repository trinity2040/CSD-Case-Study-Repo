package demo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import DataBase.DatabaseConnection;
import Models.Cargo;
import Models.Vehicle;

public class CargoDAO {
    private Connection connection;
    private VehicleDAO vehicleDAO;

    public CargoDAO() {
        connection = DatabaseConnection.getConnection();
        vehicleDAO = new VehicleDAO();
    }

    public void addCargo(String description, double weight, String status, int assignedVehicleId) {
        Vehicle vehicle = vehicleDAO.getVehicleById(assignedVehicleId);

        if (vehicle != null && vehicle.getCapacity() >= weight) {
            String sql = "INSERT INTO Cargo (description, weight, status, assigned_vehicle_id) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, description);
                stmt.setDouble(2, weight);
                stmt.setString(3, status);
                stmt.setInt(4, assignedVehicleId);
                stmt.executeUpdate();
                vehicleDAO.updateVehicleCapacity(assignedVehicleId, vehicle.getCapacity() - weight);
                System.out.println("Cargo added and assigned to vehicle successfully!");
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Error: Vehicle is already assigned for the cargo.");
        }
    }

    public List<Cargo> getAllCargo() {
        List<Cargo> cargoList = new ArrayList<>();
        String sql = "SELECT * FROM Cargo";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Cargo cargo = new Cargo(rs.getInt("cargo_id"), rs.getString("description"),
                        rs.getDouble("weight"), rs.getString("status"), rs.getInt("assigned_vehicle_id"));
                cargoList.add(cargo);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return cargoList;
    }

    public void updateCargoStatus(int cargoId, String status) {
        String sql = "UPDATE Cargo SET status = ? WHERE cargo_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setInt(2, cargoId);
            stmt.executeUpdate();
            System.out.println("Cargo status updated successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteCargo(int cargoId) {
        String sql = "DELETE FROM Cargo WHERE cargo_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, cargoId);
            stmt.executeUpdate();
            System.out.println("Cargo deleted successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean isVehicleAssignedToCargo(int cargoId) {
        String sql = "SELECT assigned_vehicle_id FROM Cargo WHERE cargo_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, cargoId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("assigned_vehicle_id") != 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
