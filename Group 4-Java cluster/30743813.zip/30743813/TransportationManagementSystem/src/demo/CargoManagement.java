package demo;

import java.util.List;
import java.util.Scanner;

import Models.Cargo;


public class CargoManagement {
    private static CargoDAO cargoDAO = new CargoDAO();
    private static Scanner scanner = new Scanner(System.in);

    public static void cargoMenu() {
        while (true) {
            System.out.println("\nCargo Management");
            System.out.println("1. Add Cargo");
            System.out.println("2. View Cargo");
            System.out.println("3. Update Cargo Status");
            System.out.println("4. Delete Cargo");
            System.out.println("5. Exit");

            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    addCargo();
                    break;
                case 2:
                    viewCargo();
                    break;
                case 3:
                    updateCargoStatus();
                    break;
                case 4:
                    deleteCargo();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addCargo() {
        System.out.print("Enter cargo description: ");
        String description = scanner.nextLine();
        System.out.print("Enter weight (in kg): ");
        double weight = scanner.nextDouble();
        scanner.nextLine();  // Consume newline
        System.out.print("Enter status (Pending, In Transit, Delivered): ");
        String status = scanner.nextLine();
        System.out.print("Enter assigned vehicle ID: ");
        int assignedVehicleId = scanner.nextInt();

        cargoDAO.addCargo(description, weight, status, assignedVehicleId);
    }

    private static void viewCargo() {
        List<Cargo> cargoList = cargoDAO.getAllCargo();
        for (Cargo cargo : cargoList) {
            System.out.println(cargo);
        }
    }

    private static void updateCargoStatus() {
        System.out.print("Enter cargo ID to update: ");
        int cargoId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Enter new status (Pending, In Transit, Delivered): ");
        String status = scanner.nextLine();

        cargoDAO.updateCargoStatus(cargoId, status);
    }

    private static void deleteCargo() {
        System.out.print("Enter cargo ID to delete: ");
        int cargoId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        cargoDAO.deleteCargo(cargoId);
    }
}
