package demo;

import java.util.Scanner;

public class TransportationManagementSystem {
    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\nTransportation Management System");
            System.out.println("1. Vehicle Management");
            System.out.println("2. Route Management");
            System.out.println("3. Cargo Management");
            System.out.println("4. Exit");

            System.out.print("Choose an option: ");
            int choice = sc.nextInt();
            sc.nextLine();  

            switch (choice) {
                case 1:
                    VehicleManagement.vehicleMenu();
                    break;
                case 2:
                    RouteManagement.routeMenu();
                    break;
                case 3:
                    CargoManagement.cargoMenu();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
