package demo;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import DataBase.DatabaseConnection;
import Models.Route;

public class RouteDAO {
    private Connection connection;

    public RouteDAO() {
        connection = DatabaseConnection.getConnection();
    }

    public void addRoute(String origin, String destination, double distance, double estimatedDuration) {
        String sql = "INSERT INTO Route (origin, destination, distance, estimated_duration) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, origin);
            stmt.setString(2, destination);
            stmt.setDouble(3, distance);
            stmt.setDouble(4, estimatedDuration);
            stmt.executeUpdate();
            System.out.println("Route added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Route> getAllRoutes() {
        List<Route> routes = new ArrayList<>();
        String sql = "SELECT * FROM Route";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Route route = new Route(rs.getInt("route_id"), rs.getString("origin"),
                        rs.getString("destination"), rs.getDouble("distance"), rs.getDouble("estimated_duration"));
                routes.add(route);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return routes;
    }

    public void updateRoute(int routeId, String origin, String destination, double distance, double estimatedDuration) {
        String sql = "UPDATE Route SET origin = ?, destination = ?, distance = ?, estimated_duration = ? WHERE route_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, origin);
            stmt.setString(2, destination);
            stmt.setDouble(3, distance);
            stmt.setDouble(4, estimatedDuration);
            stmt.setInt(5, routeId);
            stmt.executeUpdate();
            System.out.println("Route updated successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void deleteRoute(int routeId) {
        String sql = "DELETE FROM Route WHERE route_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, routeId);
            stmt.executeUpdate();
            System.out.println("Route deleted successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
