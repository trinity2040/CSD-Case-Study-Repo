package com.cts.main;

import com.cts.dao.AgentDAO;
import com.cts.dao.TicketDAO;
import com.cts.dao.iml.AgentDAOIML;
import com.cts.dao.iml.TicketDAOIML;
import com.cts.exception.DatabaseOperationException;
import com.cts.exception.EntityNotFoundException;
import com.cts.util.DatabaseConnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class App {

    // Create a Scanner object to take user input
    private static final Scanner scanner = new Scanner(System.in);

    // Create instances of the DAO interfaces
    private static final TicketDAO ticketDAO = new TicketDAOIML(); // TicketDAO implementation
    private static final AgentDAO agentDAO = new AgentDAOIML(); // AgentDAO implementation

    public static void main(String[] args) {
        // Establish a connection to the database
        Connection connection = DatabaseConnection.getConnection();

        // Check if the connection is successful
        if (connection != null) {
            while (true) { // Loop to keep the program running until the user decides to exit
                showMainMenu(); // Display the main menu options
                int choice = Integer.parseInt(scanner.nextLine()); // Get the user's menu choice

                // Handle the user's menu choice
                switch (choice) {
                    case 1:
                        handleTicketManagement(connection); // Ticket management operations
                        break;
                    case 2:
                        handleAgentAssignment(connection); // Agent assignment operations
                        break;
                    case 3:
                        handleTicketResolution(connection); // Ticket resolution operations
                        break;
                    case 4:
                        System.out.println("Exiting the program. Goodbye!");
                        closeConnection(connection); // Close the database connection
                        return; // Exit the program
                    default:
                        System.out.println("Invalid choice. Please choose a number between 1 and 4.");
                }
            }
        }
    }

    // Display the main menu options
    private static void showMainMenu() {
        System.out.println("\n--- Main Menu ---");
        System.out.println("1. Ticket Management");
        System.out.println("2. Agent Assignment");
        System.out.println("3. Ticket Resolution");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    // Handle ticket management operations
    private static void handleTicketManagement(Connection connection) {
        while (true) {
            showTicketManagementMenu(); // Display the ticket management menu
            int choice = Integer.parseInt(scanner.nextLine()); // Get the user's menu choice

            // Handle the user's choice for ticket management
            switch (choice) {
                case 1:
                    createTicket(connection); // Create a new ticket
                    break;
                case 2:
                    viewTicketDetails(connection); // View details of an existing ticket
                    break;
                case 3:
                    updateTicketInformation(connection); // Update ticket information
                    break;
                case 4:
                    deleteTicket(connection); // Delete a ticket
                    break;
                case 5:
                    return; // Go back to the main menu
                default:
                    System.out.println("Invalid choice. Please choose a number between 1 and 5.");
            }
        }
    }

    // Display the ticket management menu options
    private static void showTicketManagementMenu() {
        System.out.println("\n--- Ticket Management ---");
        System.out.println("1. Create New Ticket");
        System.out.println("2. View Ticket Details");
        System.out.println("3. Update Ticket Information");
        System.out.println("4. Delete Ticket");
        System.out.println("5. Back to Main Menu");
        System.out.print("Enter your choice: ");
    }

    // Create a new ticket in the database
    private static void createTicket(Connection connection) {
        try {
            System.out.print("Enter ticket ID: ");
            int ticketId = Integer.parseInt(scanner.nextLine()); // Get ticket ID from user
            System.out.print("Enter customer name: ");
            String customerName = scanner.nextLine(); // Get customer name from user
            System.out.print("Enter issue description: ");
            String issueDescription = scanner.nextLine(); // Get issue description from user
            System.out.print("Enter status (Open/In Progress/Closed): ");
            String status = scanner.nextLine(); // Get ticket status from user
            System.out.print("Enter priority (Low/Medium/High): ");
            String priority = scanner.nextLine(); // Get ticket priority from user
            System.out.print("Enter assigned agent ID: ");
            int agentId = Integer.parseInt(scanner.nextLine()); // Get agent ID from user

            // Insert the new ticket into the database
            ticketDAO.insertTicket(connection, ticketId, customerName, issueDescription, status, priority, agentId);
        } catch (DatabaseOperationException e) {
            System.err.println("Error creating ticket: " + e.getMessage()); // Handle database operation exceptions
        }
    }

    // View details of a specific ticket
    private static void viewTicketDetails(Connection connection) {
        try {
            System.out.print("Enter ticket ID: ");
            int ticketId = Integer.parseInt(scanner.nextLine()); // Get ticket ID from user

            // Retrieve and display ticket details
            ticketDAO.getTicketDetails(connection, ticketId);
        } catch (DatabaseOperationException | EntityNotFoundException e) {
            System.err.println("Error viewing ticket details: " + e.getMessage()); // Handle exceptions
        }
    }

    // Update the status of an existing ticket
    private static void updateTicketInformation(Connection connection) {
        try {
            System.out.print("Enter ticket ID: ");
            int ticketId = Integer.parseInt(scanner.nextLine()); // Get ticket ID from user
            System.out.print("Enter new status (Open/In Progress/Closed): ");
            String newStatus = scanner.nextLine(); // Get new status from user

            // Update the ticket's status in the database
            ticketDAO.updateTicketStatus(connection, ticketId, newStatus);
        } catch (DatabaseOperationException e) {
            System.err.println("Error updating ticket: " + e.getMessage()); // Handle database operation exceptions
        }
    }

    // Delete a specific ticket from the database
    private static void deleteTicket(Connection connection) {
        try {
            System.out.print("Enter ticket ID: ");
            int ticketId = Integer.parseInt(scanner.nextLine()); // Get ticket ID from user

            // Delete the ticket from the database
            ticketDAO.deleteTicket(connection, ticketId);
        } catch (DatabaseOperationException e) {
            System.err.println("Error deleting ticket: " + e.getMessage()); // Handle database operation exceptions
        }
    }

    // Handle agent assignment operations
    private static void handleAgentAssignment(Connection connection) {
        while (true) {
            showAgentAssignmentMenu(); // Display the agent assignment menu
            int choice = Integer.parseInt(scanner.nextLine()); // Get the user's menu choice

            // Handle the user's choice for agent assignment
            switch (choice) {
                case 1:
                    createAgent(connection); // Create a new agent
                    break;
                case 2:
                    viewAgentDetails(connection); // View details of an existing agent
                    break;
                case 3:
                    updateAgentInformation(connection); // Update agent information
                    break;
                case 4:
                    return; // Go back to the main menu
                default:
                    System.out.println("Invalid choice. Please choose a number between 1 and 4.");
            }
        }
    }

    // Display the agent assignment menu options
    private static void showAgentAssignmentMenu() {
        System.out.println("\n--- Agent Assignment ---");
        System.out.println("1. Create New Agent");
        System.out.println("2. View Agent Details");
        System.out.println("3. Update Agent Information");
        System.out.println("4. Back to Main Menu");
        System.out.print("Enter your choice: ");
    }

    // Create a new agent in the database
    private static void createAgent(Connection connection) {
        try {
            System.out.print("Enter agent ID: ");
            int agentId = Integer.parseInt(scanner.nextLine()); // Get agent ID from user
            System.out.print("Enter agent name: ");
            String agentName = scanner.nextLine(); // Get agent name from user
            System.out.print("Enter skillset: ");
            String skillset = scanner.nextLine(); // Get skillset from user
            System.out.print("Enter availability (Available/Unavailable): ");
            String availability = scanner.nextLine(); // Get availability status from user

            // Insert the new agent into the database
            agentDAO.insertAgent(connection, agentId, agentName, skillset, availability);
        } catch (DatabaseOperationException e) {
            System.err.println("Error creating agent: " + e.getMessage()); // Handle database operation exceptions
        }
    }

    // View details of a specific agent
    private static void viewAgentDetails(Connection connection) {
        try {
            System.out.print("Enter agent ID: ");
            int agentId = Integer.parseInt(scanner.nextLine()); // Get agent ID from user

            // Retrieve and display agent details
            agentDAO.getAgentDetails(connection, agentId);
        } catch (DatabaseOperationException | EntityNotFoundException e) {
            System.err.println("Error viewing agent details: " + e.getMessage()); // Handle exceptions
        }
    }

    // Update the availability status of an existing agent
    private static void updateAgentInformation(Connection connection) {
        try {
            System.out.print("Enter agent ID: ");
            int agentId = Integer.parseInt(scanner.nextLine()); // Get agent ID from user
            System.out.print("Enter new availability (Available/Unavailable): ");
            String newAvailability = scanner.nextLine(); // Get new availability status from user

            // Update the agent's availability in the database
            agentDAO.updateAgentAvailability(connection, agentId, newAvailability);
        } catch (DatabaseOperationException e) {
            System.err.println("Error updating agent: " + e.getMessage()); // Handle database operation exceptions
        }
    }

    // Handle ticket resolution operations
    private static void handleTicketResolution(Connection connection) {
        while (true) {
            showTicketResolutionMenu(); // Display the ticket resolution menu
            int choice = Integer.parseInt(scanner.nextLine()); // Get the user's menu choice

            // Handle the user's choice for ticket resolution
            switch (choice) {
                case 1:
                    trackTicketResolutionStatus(connection); // Track the resolution status of a ticket
                    break;
                case 2:
                    closeTicket(connection); // Close a ticket
                    break;
                case 3:
                    viewTicketHistory(connection); // View the history of a ticket
                    break;
                case 4:
                    return; // Go back to the main menu
                default:
                    System.out.println("Invalid choice. Please choose a number between 1 and 4.");
            }
        }
    }

    // Display the ticket resolution menu options
    private static void showTicketResolutionMenu() {
        System.out.println("\n--- Ticket Resolution ---");
        System.out.println("1. Track Ticket Resolution Status");
        System.out.println("2. Close Ticket");
        System.out.println("3. View Ticket History");
        System.out.println("4. Back to Main Menu");
        System.out.print("Enter your choice: ");
    }

    // Track the resolution status of a specific ticket
    private static void trackTicketResolutionStatus(Connection connection) {
        try {
            System.out.print("Enter ticket ID: ");
            int ticketId = Integer.parseInt(scanner.nextLine()); // Get ticket ID from user

            // Retrieve and display the current status of the ticket
            ticketDAO.getTicketDetails(connection, ticketId);
        } catch (DatabaseOperationException | EntityNotFoundException e) {
            System.err.println("Error tracking ticket resolution: " + e.getMessage()); // Handle exceptions
        }
    }

    // Close a specific ticket by updating its status to "Closed"
    private static void closeTicket(Connection connection) {
        try {
            System.out.print("Enter ticket ID: ");
            int ticketId = Integer.parseInt(scanner.nextLine()); // Get ticket ID from user
            String newStatus = "Closed"; // Set the status to "Closed"

            // Update the ticket's status to "Closed"
            ticketDAO.updateTicketStatus(connection, ticketId, newStatus);
        } catch (DatabaseOperationException e) {
            System.err.println("Error closing ticket: " + e.getMessage()); // Handle database operation exceptions
        }
    }

    // View the history of a specific ticket
    private static void viewTicketHistory(Connection connection) {
        try {
            System.out.print("Enter ticket ID: ");
            int ticketId = Integer.parseInt(scanner.nextLine()); // Get ticket ID from user

            // Retrieve and display the ticket's history
            ticketDAO.getTicketHistory(connection, ticketId);
        } catch (DatabaseOperationException e) {
            System.err.println("Error viewing ticket history: " + e.getMessage()); // Handle database operation exceptions
        }
    }

    // Close the database connection when exiting the program
    private static void closeConnection(Connection connection) {
        try {
            connection.close(); // Close the connection
            System.out.println("Connection closed.");
        } catch (SQLException e) {
            System.err.println("Failed to close connection: " + e.getMessage()); // Handle SQL exceptions
        }
    }
}

