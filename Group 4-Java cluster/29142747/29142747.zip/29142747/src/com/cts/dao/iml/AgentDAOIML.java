package com.cts.dao.iml;

import com.cts.dao.AgentDAO;
import com.cts.exception.DatabaseOperationException;
import com.cts.exception.EntityNotFoundException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AgentDAOIML implements AgentDAO {
    @Override
    public void insertAgent(Connection connection, int agentId, String agentName, String skillset, String availability) throws DatabaseOperationException {
        String query = "INSERT INTO Agent (agent_id, agent_name, skillset, availability) VALUES (?, ?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, agentId);
            pstmt.setString(2, agentName);
            pstmt.setString(3, skillset);
            pstmt.setString(4, availability);

            int rowsInserted = pstmt.executeUpdate();
            System.out.println("Agent inserted: " + rowsInserted);

        } catch (SQLException e) {
            throw new DatabaseOperationException("Failed to insert agent.", e);
        }
    }

    @Override
    public void getAgentDetails(Connection connection, int agentId) throws DatabaseOperationException, EntityNotFoundException {
        String query = "SELECT * FROM Agent WHERE agent_id = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, agentId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                System.out.println("Agent ID: " + rs.getInt("agent_id"));
                System.out.println("Agent Name: " + rs.getString("agent_name"));
                System.out.println("Skillset: " + rs.getString("skillset"));
                System.out.println("Availability: " + rs.getString("availability"));
            } else {
                throw new EntityNotFoundException("Agent with ID " + agentId + " not found.");
            }

        } catch (SQLException e) {
            throw new DatabaseOperationException("Failed to retrieve agent details.", e);
        }
    }

    @Override
    public void updateAgentAvailability(Connection connection, int agentId, String newAvailability) throws DatabaseOperationException {
        String query = "UPDATE Agent SET availability = ? WHERE agent_id = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, newAvailability);
            pstmt.setInt(2, agentId);

            int rowsUpdated = pstmt.executeUpdate();
            System.out.println("Agent availability updated: " + rowsUpdated);

        } catch (SQLException e) {
            throw new DatabaseOperationException("Failed to update agent availability.", e);
        }
    }

    @Override
    public void deleteAgent(Connection connection, int agentId) throws DatabaseOperationException {
        String query = "DELETE FROM Agent WHERE agent_id = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, agentId);

            int rowsDeleted = pstmt.executeUpdate();
            System.out.println("Agent deleted: " + rowsDeleted);

        } catch (SQLException e) {
            throw new DatabaseOperationException("Failed to delete agent.", e);
        }
    }
}
