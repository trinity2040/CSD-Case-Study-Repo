package com.cts.exception;

public class DatabaseOperationException extends Exception{

    /**
     * Constructs a new DatabaseOperationException with the specified detail message.
     *
     *  message The detail message.
     */
    public DatabaseOperationException(String message) {
        super(message);
    }

    /**
     * Constructs a new DatabaseOperationException with the specified detail message and cause.
     *
     *  message The detail message.
     *  cause   The cause of the exception (a Throwable).
     */
    public DatabaseOperationException(String message, Throwable cause) {
        super(message, cause);
    }
}
