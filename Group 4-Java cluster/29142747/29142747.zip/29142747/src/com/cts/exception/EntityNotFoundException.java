package com.cts.exception;

public class EntityNotFoundException extends Exception{
    /**
     * Constructs a new EntityNotFoundException with the specified detail message.
     *
     *  message The detail message.
     */
    public EntityNotFoundException(String message) {
        super(message);
    }
}
