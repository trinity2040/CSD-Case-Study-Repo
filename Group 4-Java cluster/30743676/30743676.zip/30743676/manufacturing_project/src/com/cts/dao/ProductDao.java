package com.cts.dao;
import com.cts.model.Product;
import util.JdbcConnection;
import Exceptions.ProductNotFoundException;
import java.sql.*;

public class ProductDao {
    public void addProduct(Product product) throws SQLException {
        String query = "INSERT INTO Product (name, description, unit_price, quantity_in_stock) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pst = JdbcConnection.getConnection().prepareStatement(query)) {
            pst.setString(1, product.getName());
            pst.setString(2, product.getDescription());
            pst.setDouble(3, product.getUnitPrice());
            pst.setInt(4, product.getQuantityInStock());
            pst.executeUpdate();
        }
    }

    public Product getProduct(int productId) throws SQLException, ProductNotFoundException {
        String query = "SELECT * FROM Product WHERE product_id = ?";
        try (PreparedStatement pst = JdbcConnection.getConnection().prepareStatement(query)) {
            pst.setInt(1, productId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                Product product = new Product();
                product.setProductId(rs.getInt("product_id"));
                product.setName(rs.getString("name"));
                product.setDescription(rs.getString("description"));
                product.setUnitPrice(rs.getDouble("unit_price"));
                product.setQuantityInStock(rs.getInt("quantity_in_stock"));
                return product;
            }else {
                throw new ProductNotFoundException("Product with ID " + productId + " not found.");
            }
        }
       
    }

    public void updateProduct(Product product) throws SQLException {
        String query = "UPDATE Product SET name = ?, description = ?, unit_price = ?, quantity_in_stock = ? WHERE product_id = ?";
        try (PreparedStatement pst = JdbcConnection.getConnection().prepareStatement(query)) {
            pst.setString(1, product.getName());
            pst.setString(2, product.getDescription());
            pst.setDouble(3, product.getUnitPrice());
            pst.setInt(4, product.getQuantityInStock());
            pst.setInt(5, product.getProductId());
            pst.executeUpdate();
        }
    }

    public void deleteProduct(int productId) throws SQLException {
        String query = "DELETE FROM Product WHERE product_id = ?";
        try (PreparedStatement pst = JdbcConnection.getConnection().prepareStatement(query)) {
            pst.setInt(1, productId);
            pst.executeUpdate();
        }
    }
}

