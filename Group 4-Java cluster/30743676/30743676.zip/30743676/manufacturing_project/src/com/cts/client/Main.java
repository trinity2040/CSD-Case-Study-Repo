package com.cts.client;

import com.cts.dao.ProductDao;
import com.cts.dao.SupplierDao;
import com.cts.dao.ProductionOrderDao;
import com.cts.model.Product;
import com.cts.model.Supplier;
import com.cts.model.ProductionOrder;
import util.JdbcConnection;
import java.sql.Date;
import java.sql.SQLException;
import java.util.Scanner;
import Exceptions.ProductNotFoundException;
import Exceptions.SupplierNotFoundException;


public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static final ProductDao productDao = new ProductDao();
    private static final SupplierDao supplierDao = new SupplierDao();
    private static final ProductionOrderDao productionOrderDao = new ProductionOrderDao();

    public static void main(String[] args) {
        while (true) {
            System.out.println("Manufacturing Management System");
            System.out.println("1. Product Management");
            System.out.println("2. Supplier Management");
            System.out.println("3. Production Order Management");
            System.out.println("4. Exit");
            System.out.println("Enter your choice:");
            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    handleProductManagement();
                    break;
                case 2:
                    handleSupplierManagement();
                    break;
                case 3:
                    handleProductionOrderManagement();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    try {
                        JdbcConnection.closeConnection();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
    //Product Management Functionality
    private static void handleProductManagement() {
        System.out.println("Product Management");
        System.out.println("1. Add Product");
        System.out.println("2. View Product");
        System.out.println("3. Update Product");
        System.out.println("4. Delete Product");
        System.out.println("5. Back");
        System.out.println("Enter your Choice:");
        int choice = scanner.nextInt();
        scanner.nextLine(); 

        try {
            switch (choice) {
                case 1:
                    addProduct();
                    break;
                case 2:
                    viewProduct();
                    break;
                case 3:
                    updateProduct();
                    break;
                case 4:
                    deleteProduct();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }catch (ProductNotFoundException e) {
            System.out.println(e.getMessage());
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    // Add The Product
    private static void addProduct() throws SQLException {
        System.out.println("Enter Product Name:");
        String name = scanner.nextLine();

        System.out.println("Enter Product Description:");
        String description = scanner.nextLine();

        System.out.println("Enter Unit Price:");
        double unitPrice = scanner.nextDouble();

        System.out.println("Enter Quantity in Stock:");
        int quantityInStock = scanner.nextInt();
        scanner.nextLine(); 

        Product product = new Product();
        product.setName(name);
        product.setDescription(description);
        product.setUnitPrice(unitPrice);
        product.setQuantityInStock(quantityInStock);

        productDao.addProduct(product);
        System.out.println("Product added successfully.");
    }
    //View The Product
    private static void viewProduct() {
        System.out.println("Enter Product ID to view:");
        int productId = scanner.nextInt();
        scanner.nextLine();

        try {
            Product product = productDao.getProduct(productId);
            System.out.println("Product ID: " + product.getProductId());
            System.out.println("Name: " + product.getName());
            System.out.println("Description: " + product.getDescription());
            System.out.println("Unit Price: " + product.getUnitPrice());
            System.out.println("Quantity in Stock: " + product.getQuantityInStock());
        } catch (ProductNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Update The Product
    private static void updateProduct() throws SQLException, ProductNotFoundException {
        System.out.println("Enter Product ID to update:");
        int productId = scanner.nextInt();
        scanner.nextLine(); 

        Product product = productDao.getProduct(productId);
        if (product != null) {
            System.out.println("Enter new Name for Product:");
            String name = scanner.nextLine();
            if (!name.isEmpty()) product.setName(name);

            System.out.println("Enter new Description:");
            String description = scanner.nextLine();
            if (!description.isEmpty()) product.setDescription(description);

            System.out.println("Enter new Unit Price:");
            String unitPriceStr = scanner.nextLine();
            if (!unitPriceStr.isEmpty()) product.setUnitPrice(Double.parseDouble(unitPriceStr));

            System.out.println("Enter new Quantity in Stock:");
            String quantityInStockStr = scanner.nextLine();
            if (!quantityInStockStr.isEmpty()) product.setQuantityInStock(Integer.parseInt(quantityInStockStr));

            productDao.updateProduct(product);
            System.out.println("Product updated successfully.");
        } else {
            System.out.println("Product not found.");
        }
    }
    //Delete The product
    private static void deleteProduct() throws SQLException {
        System.out.println("Enter Product ID to delete:");
        int productId = scanner.nextInt();
        scanner.nextLine(); 

        productDao.deleteProduct(productId);
        System.out.println("Product deleted successfully.");
    }

    // Supplier Management Functionality
    
    private static void handleSupplierManagement() {
        System.out.println("Supplier Management");
        System.out.println("1. Add Supplier");
        System.out.println("2. View Supplier");
        System.out.println("3. Update Supplier");
        System.out.println("4. Delete Supplier");
        System.out.println("5. Back");
        System.out.println("Enter your Choice:");
        int choice = scanner.nextInt();
        scanner.nextLine(); 

        try {
            switch (choice) {
                case 1:
                    addSupplier();
                    break;
                case 2:
                    viewSupplier();
                    break;
                case 3:
                    updateSupplier();
                    break;
                case 4:
                    deleteSupplier();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }catch (SupplierNotFoundException e) {
            System.out.println(e.getMessage());
        }  catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // Add The Supplier
    private static void addSupplier() throws SQLException {
        System.out.println("Enter Supplier Name:");
        String name = scanner.nextLine();

        System.out.println("Enter Supplier Email:");
        String email = scanner.nextLine();

        System.out.println("Enter Supplier Phone Number:");
        String phoneNumber = scanner.nextLine();

        System.out.println("Enter Supplier Address:");
        String address = scanner.nextLine();

        Supplier supplier = new Supplier();
        supplier.setName(name);
        supplier.setEmail(email);
        supplier.setPhoneNumber(phoneNumber);
        supplier.setAddress(address);

        supplierDao.addSupplier(supplier);
        System.out.println("Supplier added successfully.");
    }
    //View The Supplier
    private static void viewSupplier() throws SQLException, SupplierNotFoundException {
        System.out.println("Enter Supplier ID to view:");
        int supplierId = scanner.nextInt();
        scanner.nextLine(); 
        try {
        Supplier supplier = supplierDao.getSupplier(supplierId);
        if (supplier != null) {
            System.out.println("Supplier ID: " + supplier.getSupplierId());
            System.out.println("Name: " + supplier.getName());
            System.out.println("Email: " + supplier.getEmail());
            System.out.println("Phone Number: " + supplier.getPhoneNumber());
            System.out.println("Address: " + supplier.getAddress());
        }
        }catch (SupplierNotFoundException e) {
            System.out.println(e.getMessage());
        }
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    //Update The Supplier
    private static void updateSupplier() throws SQLException, SupplierNotFoundException {
        System.out.println("Enter Supplier ID to update:");
        int supplierId = scanner.nextInt();
        scanner.nextLine(); 
        try {
        Supplier supplier = supplierDao.getSupplier(supplierId);
        if (supplier != null) {
            System.out.println("Enter new  Supplier Name:");
            String name = scanner.nextLine();
            if (!name.isEmpty()) supplier.setName(name);

            System.out.println("Enter new Email:");
            String email = scanner.nextLine();
            if (!email.isEmpty()) supplier.setEmail(email);

            System.out.println("Enter new Phone Number:");
            String phoneNumber = scanner.nextLine();
            if (!phoneNumber.isEmpty()) supplier.setPhoneNumber(phoneNumber);

            System.out.println("Enter new Address:");
            String address = scanner.nextLine();
            if (!address.isEmpty()) supplier.setAddress(address);

            supplierDao.updateSupplier(supplier);
            System.out.println("Supplier updated successfully.");
        } }catch (SupplierNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (SQLException e) {
            e.printStackTrace();
        }
        }
    

    
    //Delete The Supplier
    private static void deleteSupplier() throws SQLException {
        System.out.println("Enter Supplier ID to delete:");
        int supplierId = scanner.nextInt();
        scanner.nextLine(); 

        supplierDao.deleteSupplier(supplierId);
        System.out.println("Supplier deleted successfully.");
    }
    
    //ProductionOrder Management Functionality

    private static void handleProductionOrderManagement() {
        System.out.println("Production Order Management");
        System.out.println("1. Create Production Order");
        System.out.println("2. View Production Order");
        System.out.println("3. Update Production Order");
        System.out.println("4. Cancel Production Order");
        System.out.println("5. Back");
        System.out.println("Enter your Choice:");
        int choice = scanner.nextInt();
        scanner.nextLine(); 

        try {
            switch (choice) {
                case 1:
                    createProductionOrder();
                    break;
                case 2:
                    viewProductionOrder();
                    break;
                case 3:
                    updateProductionOrder();
                    break;
                case 4:
                    cancelProductionOrder();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //Create the ProductOrder
    private static void createProductionOrder() throws SQLException {
        System.out.println("Enter Product ID:");
        int productId = scanner.nextInt();

        System.out.println("Enter Supplier ID:");
        int supplierId = scanner.nextInt();
        scanner.nextLine(); 

        System.out.println("Enter Order Date (YYYY-MM-DD):");
        Date orderDate = Date.valueOf(scanner.nextLine());

        System.out.println("Enter Due Date (YYYY-MM-DD):");
        Date dueDate = Date.valueOf(scanner.nextLine());

        System.out.println("Enter Status (open/closed):");
        String status = scanner.nextLine();

        ProductionOrder productionOrder = new ProductionOrder();
        productionOrder.setProductId(productId);
        productionOrder.setSupplierId(supplierId);
        productionOrder.setOrderDate(orderDate);
        productionOrder.setDueDate(dueDate);
        productionOrder.setStatus(status);

        productionOrderDao.createProductionOrder(productionOrder);
        System.out.println("Production order created successfully.");
    }
    
    
    // View The ProductOrder
    private static void viewProductionOrder() throws SQLException {
        System.out.println("Enter Production Order ID to view:");
        int orderId = scanner.nextInt();
        scanner.nextLine(); 

        ProductionOrder productionOrder = productionOrderDao.getProductionOrder(orderId);
        if (productionOrder != null) {
            System.out.println("Order ID: " + productionOrder.getOrderId());
            System.out.println("Product ID: " + productionOrder.getProductId());
            System.out.println("Supplier ID: " + productionOrder.getSupplierId());
            System.out.println("Order Date: " + productionOrder.getOrderDate());
            System.out.println("Due Date: " + productionOrder.getDueDate());
            System.out.println("Status: " + productionOrder.getStatus());
        } else {
            System.out.println("Production order not found.");
        }
    }
    
    //Update The ProductOrder
    private static void updateProductionOrder() throws SQLException {
        System.out.println("Enter Production Order ID to update:");
        int orderId = scanner.nextInt();
        scanner.nextLine(); 

        ProductionOrder productionOrder = productionOrderDao.getProductionOrder(orderId);
        if (productionOrder != null) {
            System.out.println("Enter new Product ID :");
            String productIdStr = scanner.nextLine();
            if (!productIdStr.isEmpty()) productionOrder.setProductId(Integer.parseInt(productIdStr));

            System.out.println("Enter new Supplier ID:");
            String supplierIdStr = scanner.nextLine();
            if (!supplierIdStr.isEmpty()) productionOrder.setSupplierId(Integer.parseInt(supplierIdStr));

            System.out.println("Enter new Order Date (YYYY-MM-DD):");
            String orderDateStr = scanner.nextLine();
            if (!orderDateStr.isEmpty()) productionOrder.setOrderDate(Date.valueOf(orderDateStr));

            System.out.println("Enter new Due Date (YYYY-MM-DD):");
            String dueDateStr = scanner.nextLine();
            if (!dueDateStr.isEmpty()) productionOrder.setDueDate(Date.valueOf(dueDateStr));

            System.out.println("Enter new Status (open/closed):");
            String status = scanner.nextLine();
            if (!status.isEmpty()) productionOrder.setStatus(status);

            productionOrderDao.updateProductionOrder(productionOrder);
            System.out.println("Production order updated successfully.");
        } else {
            System.out.println("Production order not found.");
        }
    }
    //Cancel The Order
    private static void cancelProductionOrder() throws SQLException {
        System.out.println("Enter Production Order ID to cancel:");
        int orderId = scanner.nextInt();
        scanner.nextLine(); 

        productionOrderDao.cancelProductionOrder(orderId);
        System.out.println("Production order canceled successfully.");
    }
}

