package com.cts.dao;



import com.cts.model.ProductionOrder;
import util.JdbcConnection;

import java.sql.*;

public class ProductionOrderDao {
    public void createProductionOrder(ProductionOrder productionOrder) throws SQLException {
        String query = "INSERT INTO ProductionOrder (product_id, supplier_id, order_date, due_date, status) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pst = JdbcConnection.getConnection().prepareStatement(query)) {
            pst.setInt(1, productionOrder.getProductId());
            pst.setInt(2, productionOrder.getSupplierId());
            pst.setDate(3, productionOrder.getOrderDate());
            pst.setDate(4, productionOrder.getDueDate());
            pst.setString(5, productionOrder.getStatus());
            pst.executeUpdate();
        }
    }

    public ProductionOrder getProductionOrder(int orderId) throws SQLException {
        String query = "SELECT * FROM ProductionOrder WHERE order_id = ?";
        try (PreparedStatement pst = JdbcConnection.getConnection().prepareStatement(query)) {
            pst.setInt(1, orderId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                ProductionOrder productionOrder = new ProductionOrder();
                productionOrder.setOrderId(rs.getInt("order_id"));
                productionOrder.setProductId(rs.getInt("product_id"));
                productionOrder.setSupplierId(rs.getInt("supplier_id"));
                productionOrder.setOrderDate(rs.getDate("order_date"));
                productionOrder.setDueDate(rs.getDate("due_date"));
                productionOrder.setStatus(rs.getString("status"));
                return productionOrder;
            }
        }
        return null;
    }

    public void updateProductionOrder(ProductionOrder productionOrder) throws SQLException {
        String query = "UPDATE ProductionOrder SET product_id = ?, supplier_id = ?, order_date = ?, due_date = ?, status = ? WHERE order_id = ?";
        try (PreparedStatement pst = JdbcConnection.getConnection().prepareStatement(query)) {
            pst.setInt(1, productionOrder.getProductId());
            pst.setInt(2, productionOrder.getSupplierId());
            pst.setDate(3, productionOrder.getOrderDate());
            pst.setDate(4, productionOrder.getDueDate());
            pst.setString(5, productionOrder.getStatus());
            pst.setInt(6, productionOrder.getOrderId());
            pst.executeUpdate();
        }
    }

    public void cancelProductionOrder(int orderId) throws SQLException {
        String query = "DELETE FROM ProductionOrder WHERE order_id = ?";
        try (PreparedStatement pst = JdbcConnection.getConnection().prepareStatement(query)) {
            pst.setInt(1, orderId);
            pst.executeUpdate();
        }
    }
}

