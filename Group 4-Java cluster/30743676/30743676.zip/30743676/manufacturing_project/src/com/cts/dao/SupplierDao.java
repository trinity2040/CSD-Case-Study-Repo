package com.cts.dao;



import com.cts.model.Supplier;
import util.JdbcConnection;
import Exceptions.SupplierNotFoundException;
import java.sql.*;

public class SupplierDao {
    public void addSupplier(Supplier supplier) throws SQLException {
        String query = "INSERT INTO Supplier (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pst = JdbcConnection.getConnection().prepareStatement(query)) {
            pst.setString(1, supplier.getName());
            pst.setString(2, supplier.getEmail());
            pst.setString(3, supplier.getPhoneNumber());
            pst.setString(4, supplier.getAddress());
            pst.executeUpdate();
        }
    }

    public Supplier getSupplier(int supplierId) throws SQLException, SupplierNotFoundException {
        String query = "SELECT * FROM Supplier WHERE supplier_id = ?";
        try (PreparedStatement pst = JdbcConnection.getConnection().prepareStatement(query)) {
            pst.setInt(1, supplierId);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                Supplier supplier = new Supplier();
                supplier.setSupplierId(rs.getInt("supplier_id"));
                supplier.setName(rs.getString("name"));
                supplier.setEmail(rs.getString("email"));
                supplier.setPhoneNumber(rs.getString("phone_number"));
                supplier.setAddress(rs.getString("address"));
                return supplier;
            }else {
                throw new SupplierNotFoundException("Supplier with ID " + supplierId + " not found.");
            }
        }
       
    }

    public void updateSupplier(Supplier supplier) throws SQLException {
        String query = "UPDATE Supplier SET name = ?, email = ?, phone_number = ?, address = ? WHERE supplier_id = ?";
        try (PreparedStatement pst = JdbcConnection.getConnection().prepareStatement(query)) {
            pst.setString(1, supplier.getName());
            pst.setString(2, supplier.getEmail());
            pst.setString(3, supplier.getPhoneNumber());
            pst.setString(4, supplier.getAddress());
            pst.setInt(5, supplier.getSupplierId());
            pst.executeUpdate();
        }
    }

    public void deleteSupplier(int supplierId) throws SQLException {
        String query = "DELETE FROM Supplier WHERE supplier_id = ?";
        try (PreparedStatement pst = JdbcConnection.getConnection().prepareStatement(query)) {
            pst.setInt(1, supplierId);
            pst.executeUpdate();
        }
    }
}
