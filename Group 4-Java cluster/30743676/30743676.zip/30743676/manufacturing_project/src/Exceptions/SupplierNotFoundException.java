package Exceptions;

public class SupplierNotFoundException extends Exception {
    public SupplierNotFoundException(String message) {
        super(message);
    }
}