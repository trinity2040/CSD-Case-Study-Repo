Manufacturing Management System
This application helps user to manage products, suppliers, and production orders for manufacturing business. It is an console based application developed using Core java concepts, MySQL and JDBC connection.

1) Setup
   -Install MySQL Server for database and Eclipse IDe for java.
   -Configure Database Connection
   The application uses MySQL as the database. You need to configure the database connection details.
   . Navigate to src/main/java/util/JdbcConnection.java.
   . Update the following details with your database credentials:
     private static final String URL = "jdbc:mysql://localhost:3306/manufacturing_db";
     private static final String USER = "root";
     private static final String PASSWORD = "your_password";
   -Create database manufacturing_db.
   -Execute the MySQL Script found in folder with file named mysql_code.sql.
2) Run 
   In your IDE, locate the folder and open the folder manufacturing_project and find src file and run it.
   open main.java file under com.cts.client package. When you start this application, you will see a menu with the following options:
   . Product Management: add, view, update and delete Product.
   . Supplier Management: add, view, update and delete Supplier.
   . Production Order Management: create, view, update, and delete ProductionOrder.
3) Custom Exceptions
   The project uses custom exceptions to handle specific errors:
   . ProductNotFoundException: Thrown if a product is not found.
   . SupplierNotFoundException: Thrown if a supplier is not found.
3) Usage
   -Follow the above instruction  to Navigate the main menu
   -The application allows user to manage Product, Supplier and ProductionOrder.
   
   