package com.cts.coms.exception;

// CustomerNotFoundException.java

public class CustomerNotFoundException extends Exception {
    public CustomerNotFoundException(String message) {
        super(message);
        
    }
}
