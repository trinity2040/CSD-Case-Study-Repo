package com.cts.coms.exception;

// ProductNotFoundException.java

 public class ProductNotFoundException extends Exception {
    public ProductNotFoundException(String message) {
        super(message);
    }
}
