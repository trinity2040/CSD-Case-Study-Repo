package com.cts.coms.exception;

// OrderNotFoundException.java

 public class OrderNotFoundException extends Exception {
    public OrderNotFoundException(String message) {
        super(message);
    }
}


