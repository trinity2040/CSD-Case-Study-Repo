/**
 * 
 */
/**
 * 
 */
module Inventory_SystemF {
	requires java.sql;
}