package com.cts.client;

import com.cts.model.Product;
import com.cts.service.InventoryService;
import com.cts.exception.InvalidDataException;
import com.cts.exception.ProductNotFoundException;
import java.math.BigDecimal;
import java.util.Scanner;

public class Main {

    private static final InventoryService inventoryService = new InventoryService();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Inventory Management System");
            System.out.println("1. Add Product");
            System.out.println("2. View Product");
            System.out.println("3. Update Product");
            System.out.println("4. Delete Product");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int option = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (option) {
                case 1:
                    addProduct(scanner);
                    break;
                case 2:
                    viewProduct(scanner);
                    break;
                case 3:
                    updateProduct(scanner);
                    break;
                case 4:
                    deleteProduct(scanner);
                    break;
                case 5:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void addProduct(Scanner scanner) {
        try {
            System.out.print("Enter product name: ");
            String name = scanner.nextLine();

            System.out.print("Enter category: ");
            String category = scanner.nextLine();

            System.out.print("Enter price: ");
            BigDecimal price = new BigDecimal(scanner.nextLine());

            System.out.print("Enter quantity in stock: ");
            int quantityInStock = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            Product product = new Product(name, category, price, quantityInStock);
            inventoryService.addProduct(product);

            System.out.println("Product added successfully.");
        } catch (InvalidDataException e) {
            System.out.println("Error adding product: " + e.getMessage());
        }
    }

    private static void viewProduct(Scanner scanner) {
        System.out.print("Enter product ID: ");
        int productId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            Product product = inventoryService.getProductById(productId);
            System.out.println("Product Details: " + product);
        } catch (ProductNotFoundException e) {
            System.out.println("Product not found: " + e.getMessage());
        }
    }

    private static void updateProduct(Scanner scanner) {
        System.out.print("Enter product ID to update: ");
        int productId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            Product product = inventoryService.getProductById(productId);

            System.out.print("Enter new name (leave blank to keep current): ");
            String name = scanner.nextLine();
            if (!name.isEmpty()) {
                product.setName(name);
            }

            System.out.print("Enter new category (leave blank to keep current): ");
            String category = scanner.nextLine();
            if (!category.isEmpty()) {
                product.setCategory(category);
            }

            System.out.print("Enter new price (leave blank to keep current): ");
            String priceInput = scanner.nextLine();
            if (!priceInput.isEmpty()) {
                product.setPrice(new BigDecimal(priceInput));
            }

            System.out.print("Enter new quantity in stock (leave blank to keep current): ");
            String quantityInput = scanner.nextLine();
            if (!quantityInput.isEmpty()) {
                product.setQuantityInStock(Integer.parseInt(quantityInput));
            }

            inventoryService.updateProduct(product);
            System.out.println("Product updated successfully.");
        } catch (ProductNotFoundException e) {
            System.out.println("Product not found: " + e.getMessage());
        } catch (InvalidDataException e) {
            System.out.println("Error updating product: " + e.getMessage());
        }
    }

    private static void deleteProduct(Scanner scanner) {
        System.out.print("Enter product ID to delete: ");
        int productId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            inventoryService.deleteProduct(productId);
            System.out.println("Product deleted successfully.");
        } catch (ProductNotFoundException e) {
            System.out.println("Product not found: " + e.getMessage());
        }
    }
}
