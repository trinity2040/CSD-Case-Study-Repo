package com.cts.service;

import com.cts.dao.ProductDAO;
import com.cts.dao.SupplierDAO;
import com.cts.dao.OrderDAO;
import com.cts.dao.impl.ProductDAOImpl;
import com.cts.dao.impl.SupplierDAOImpl;
import com.cts.dao.impl.OrderDAOImpl;
import com.cts.model.Product;
import com.cts.model.Supplier;
import com.cts.model.Order;
import com.cts.exception.InvalidDataException;
import com.cts.exception.ProductNotFoundException;
import com.cts.exception.SupplierNotFoundException;

import java.math.BigDecimal;
import java.util.List;

public class InventoryService {

    private final ProductDAO productDAO = new ProductDAOImpl();
    private final SupplierDAO supplierDAO = new SupplierDAOImpl();
    private final OrderDAO orderDAO = new OrderDAOImpl();

    // Add a product
    public void addProduct(Product product) throws InvalidDataException {
        validateProduct(product);
        productDAO.addProduct(product);
    }

    // Get product by ID
    public Product getProductById(int productId) throws ProductNotFoundException {
        return productDAO.getProductById(productId);
    }

    // Update a product
    public void updateProduct(Product product) throws InvalidDataException, ProductNotFoundException {
        validateProduct(product);
        if (productDAO.getProductById(product.getProductId()) == null) {
            throw new ProductNotFoundException("Product not found.");
        }
        productDAO.updateProduct(product);
    }

    // Delete a product
    public void deleteProduct(int productId) throws ProductNotFoundException {
        if (productDAO.getProductById(productId) == null) {
            throw new ProductNotFoundException("Product not found.");
        }
        productDAO.deleteProduct(productId);
    }

    // Add a supplier
    public void addSupplier(Supplier supplier) throws InvalidDataException {
        validateSupplier(supplier);
        supplierDAO.addSupplier(supplier);
    }

    // Get supplier by ID
    public Supplier getSupplierById(int supplierId) throws SupplierNotFoundException {
        return supplierDAO.getSupplierById(supplierId);
    }

    // Update a supplier
    public void updateSupplier(Supplier supplier) throws InvalidDataException, SupplierNotFoundException {
        validateSupplier(supplier);
        if (supplierDAO.getSupplierById(supplier.getSupplierId()) == null) {
            throw new SupplierNotFoundException("Supplier not found.");
        }
        supplierDAO.updateSupplier(supplier);
    }

    // Delete a supplier
    public void deleteSupplier(int supplierId) throws SupplierNotFoundException {
        if (supplierDAO.getSupplierById(supplierId) == null) {
            throw new SupplierNotFoundException("Supplier not found.");
        }
        supplierDAO.deleteSupplier(supplierId);
    }

    // Place an order
    public void placeOrder(Order order) throws InvalidDataException {
        validateOrder(order);
        orderDAO.placeOrder(order);
        Product product = productDAO.getProductById(order.getProductId());
        if (product == null) {
            throw new InvalidDataException("Product does not exist.");
        }
        int newQuantity = product.getQuantityInStock() - order.getQuantity();
        if (newQuantity < 0) {
            throw new InvalidDataException("Not enough stock.");
        }
        product.setQuantityInStock(newQuantity);
        productDAO.updateProduct(product);
    }

    // View an order
    public Order getOrderById(int orderId) throws InvalidDataException {
        return orderDAO.getOrderById(orderId);
    }

    // Cancel an order
    public void cancelOrder(int orderId) throws InvalidDataException {
        Order order = orderDAO.getOrderById(orderId);
        if (order == null) {
            throw new InvalidDataException("Order not found.");
        }
        if ("canceled".equals(order.getStatus())) {
            throw new InvalidDataException("Order is already canceled.");
        }
        order.setStatus("canceled");
        orderDAO.updateOrder(order);
        Product product = productDAO.getProductById(order.getProductId());
        if (product == null) {
            throw new InvalidDataException("Product does not exist.");
        }
        int newQuantity = product.getQuantityInStock() + order.getQuantity();
        product.setQuantityInStock(newQuantity);
        productDAO.updateProduct(product);
    }

    // List all orders for a specific product
    public List<Order> listOrdersForProduct(int productId) {
        return orderDAO.getOrdersByProductId(productId);
    }

    // Validation methods
    private void validateProduct(Product product) throws InvalidDataException {
        if (product.getName() == null || product.getName().isEmpty()) {
            throw new InvalidDataException("Product name cannot be empty.");
        }
        if (product.getCategory() == null || product.getCategory().isEmpty()) {
            throw new InvalidDataException("Product category cannot be empty.");
        }
        if (product.getPrice() == null || product.getPrice().compareTo(BigDecimal.ZERO) <= 0) {
            throw new InvalidDataException("Product price must be greater than zero.");
        }
        if (product.getQuantityInStock() < 0) {
            throw new InvalidDataException("Product quantity in stock cannot be negative.");
        }
    }

    private void validateSupplier(Supplier supplier) throws InvalidDataException {
        if (supplier.getName() == null || supplier.getName().isEmpty()) {
            throw new InvalidDataException("Supplier name cannot be empty.");
        }
        if (supplier.getContactInformation() == null || supplier.getContactInformation().isEmpty()) {
            throw new InvalidDataException("Supplier contact information cannot be empty.");
        }
        if (supplier.getAddress() == null || supplier.getAddress().isEmpty()) {
            throw new InvalidDataException("Supplier address cannot be empty.");
        }
    }

    private void validateOrder(Order order) throws InvalidDataException {
        if (order.getProductId() <= 0) {
            throw new InvalidDataException("Invalid product ID.");
        }
        if (order.getSupplierId() <= 0) {
            throw new InvalidDataException("Invalid supplier ID.");
        }
        if (order.getQuantity() <= 0) {
            throw new InvalidDataException("Order quantity must be greater than zero.");
        }
    }
}
