package com.cts.dao.impl;

import com.cts.dao.OrderDAO;
import com.cts.model.Order;
import com.cts.exception.InvalidDataException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderDAOImpl implements OrderDAO {

    private static final String URL = "jdbc:mysql://localhost:3306/InventoryDB";
    private static final String USER = "root";
    private static final String PASSWORD = "password";

    @Override
    public void placeOrder(Order order) {
        String query = "INSERT INTO `Order` (product_id, supplier_id, order_date, quantity, status) VALUES (?, ?, ?, ?, ?)";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, order.getProductId());
            preparedStatement.setInt(2, order.getSupplierId());
            preparedStatement.setDate(3, new Date(order.getOrderDate().getTime()));
            preparedStatement.setInt(4, order.getQuantity());
            preparedStatement.setString(5, order.getStatus());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected == 0) {
                throw new InvalidDataException("Failed to place order.");
            }

            // Update the quantity in stock in the Product table
            updateProductQuantity(order.getProductId(), -order.getQuantity(), connection);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Order getOrderById(int orderId) {
        String query = "SELECT * FROM `Order` WHERE order_id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, orderId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return new Order(
                        resultSet.getInt("order_id"),
                        resultSet.getInt("product_id"),
                        resultSet.getInt("supplier_id"),
                        resultSet.getDate("order_date"),
                        resultSet.getInt("quantity"),
                        resultSet.getString("status")
                );
            } else {
                return null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public void cancelOrder(int orderId) {
        String query = "UPDATE `Order` SET status = 'canceled' WHERE order_id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, orderId);
            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected == 0) {
                throw new InvalidDataException("Failed to cancel order.");
            }

            // Retrieve the order details
            Order order = getOrderById(orderId);
            if (order != null) {
                // Update the quantity in stock in the Product table
                updateProductQuantity(order.getProductId(), order.getQuantity(), connection);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public List<Order> getOrdersByProductId(int productId) {
        String query = "SELECT * FROM `Order` WHERE product_id = ?";
        List<Order> orders = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, productId);
            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                orders.add(new Order(
                        resultSet.getInt("order_id"),
                        resultSet.getInt("product_id"),
                        resultSet.getInt("supplier_id"),
                        resultSet.getDate("order_date"),
                        resultSet.getInt("quantity"),
                        resultSet.getString("status")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }

    private void updateProductQuantity(int productId, int quantityChange, Connection connection) {
        String query = "UPDATE Product SET quantity_in_stock = quantity_in_stock + ? WHERE product_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setInt(1, quantityChange);
            preparedStatement.setInt(2, productId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

	@Override
	public void updateOrder(Order order) {
		// TODO Auto-generated method stub
		
	}
}
