package com.cts.dao.impl;

import com.cts.dao.SupplierDAO;
import com.cts.model.Supplier;
import com.cts.exception.InvalidDataException;
import com.cts.exception.SupplierNotFoundException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SupplierDAOImpl implements SupplierDAO {

    private static final String URL = "jdbc:mysql://localhost:3306/InventoryDB";
    private static final String USER = "root";
    private static final String PASSWORD = "password";

    @Override
    public void addSupplier(Supplier supplier) {
        String query = "INSERT INTO Supplier (name, contact_information, address) VALUES (?, ?, ?)";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, supplier.getName());
            preparedStatement.setString(2, supplier.getContactInformation());
            preparedStatement.setString(3, supplier.getAddress());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected == 0) {
                throw new InvalidDataException("Failed to add supplier.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Supplier getSupplierById(int supplierId) {
        String query = "SELECT * FROM Supplier WHERE supplier_id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, supplierId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                return new Supplier(
                        resultSet.getInt("supplier_id"),
                        resultSet.getString("name"),
                        resultSet.getString("contact_information"),
                        resultSet.getString("address")
                );
            } else {
                throw new SupplierNotFoundException("Supplier not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Supplier> getAllSuppliers() {
        String query = "SELECT * FROM Supplier";
        List<Supplier> suppliers = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {

            while (resultSet.next()) {
                suppliers.add(new Supplier(
                        resultSet.getInt("supplier_id"),
                        resultSet.getString("name"),
                        resultSet.getString("contact_information"),
                        resultSet.getString("address")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return suppliers;
    }

    @Override
    public void updateSupplier(Supplier supplier) {
        String query = "UPDATE Supplier SET name = ?, contact_information = ?, address = ? WHERE supplier_id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, supplier.getName());
            preparedStatement.setString(2, supplier.getContactInformation());
            preparedStatement.setString(3, supplier.getAddress());
            preparedStatement.setInt(4, supplier.getSupplierId());

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected == 0) {
                throw new SupplierNotFoundException("Supplier not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void deleteSupplier(int supplierId) {
        String query = "DELETE FROM Supplier WHERE supplier_id = ?";
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, supplierId);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected == 0) {
                throw new SupplierNotFoundException("Supplier not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
