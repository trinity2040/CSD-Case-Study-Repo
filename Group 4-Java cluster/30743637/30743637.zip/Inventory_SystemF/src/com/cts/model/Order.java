package com.cts.model;

import java.util.Date;

public class Order {
    private int orderId;
    private int productId;
    private int supplierId;
    private Date orderDate;
    private int quantity;
    private String status;

    // Constructors
    public Order() {}

    public Order(int orderId, int productId, int supplierId, Date orderDate, int quantity, String status) {
        this.orderId = orderId;
        this.productId = productId;
        this.supplierId = supplierId;
        this.orderDate = orderDate;
        this.quantity = quantity;
        this.status = status;
    }

    // Getters and Setters
    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Order{" +
               "orderId=" + orderId +
               ", productId=" + productId +
               ", supplierId=" + supplierId +
               ", orderDate=" + orderDate +
               ", quantity=" + quantity +
               ", status='" + status + '\'' +
               '}';
    }
}
