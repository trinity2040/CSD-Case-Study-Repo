package com.cts.model;

public class Supplier {
    private int supplierId;
    private String name;
    private String contactInformation;
    private String address;

    // Constructors
    public Supplier() {}

    public Supplier(int supplierId, String name, String contactInformation, String address) {
        this.supplierId = supplierId;
        this.name = name;
        this.contactInformation = contactInformation;
        this.address = address;
    }

    // Getters and Setters
    public int getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContactInformation() {
        return contactInformation;
    }

    public void setContactInformation(String contactInformation) {
        this.contactInformation = contactInformation;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Supplier{" +
               "supplierId=" + supplierId +
               ", name='" + name + '\'' +
               ", contactInformation='" + contactInformation + '\'' +
               ", address='" + address + '\'' +
               '}';
    }
}
