package com.cts;

import com.cts.db.CreateSchema;
import com.cts.services.AgreementServices;
import com.cts.services.PropertyServices;
import com.cts.services.TenantServices;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Main {


    public static void menu(){
        System.out.println("""
                Welcome to the Rental System

                Choose The Service
                1. Property Management
                2. Tenant Management
                3. Rental Agreement Management
                4. Exit

                Enter your choice:\s"""
        );
    }



    public static void main(String[] args) throws Exception {
        CreateSchema.createTables();
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int choice = 0;
        outer_loop:
        while(true){
            menu();
            choice = Integer.parseInt(br.readLine());
            switch (choice){
                case 1: propertyManagement();
                break;
                case 2: tenantManagement();
                break;
                case 3: rentalAgreementManagement();
                break;
                case 4: break outer_loop;
                default: System.out.println("Invalid choice");

            }
        }
        System.out.println("Thank you for using Rental System");
    }

    // ------------------------PROPERTY--------------------------

    public static void propertyMenu(){
        System.out.println("""
                Property Management

                Choose The Service
                1. View All Properties
                2. Create Property
                3. Delete Property
                0. Return to Main menu

                Enter your choice:\s"""
        );
    }
    public static void propertyManagement() throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        PropertyServices service = new PropertyServices();
        while(true){
            propertyMenu();
            int choice = Integer.parseInt(br.readLine());
            switch (choice){
                case 1: service.printAllProperties();
                    break;
                case 2: service.createProperty();
                    break;
                case 3: service.deleteProperty();
                    break;
                case 0: System.out.println("In 3rd Exiting \n");
                    return;
            }
        }
    }

    // ------------------------TENANT--------------------------

    public static void tenantMenu(){
        System.out.println("""
                Tenant Management

                Choose The Service
                1. View All Tenants
                2. Create Tenant
                3. Delete Tenant
                0. Return to Main menu

                Enter your choice:\s"""
        );
    }
    public static void tenantManagement() throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        TenantServices service = new TenantServices();
        while(true){
            tenantMenu();
            int choice = Integer.parseInt(br.readLine());
            switch (choice){
                case 1: service.printAllTenants();
                break;
                case 2: service.createTenant();
                break;
                case 3: service.deleteTenant();
                break;
                case 0: System.out.println("Back to main menu \n");
                return;
            }
        }
    }

    // ------------------------Rental Agreements--------------------------

    public static void rentalAgreementMenu(){
        System.out.println("""
                Rental Agreement Management

                Choose The Service
                1. View All Rental Agreements
                2. Create Agreement
                3. Delete Agreement
                4. Edit Agreement
                0. Return to Main menu

                Enter your choice:\s"""
        );
    }

    public static void rentalAgreementManagement() throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        AgreementServices service = new AgreementServices();
        while(true){
            rentalAgreementMenu();
            int choice = Integer.parseInt(br.readLine());
            switch (choice){
                case 1: service.printAllAgreements();
                    break;
                case 2: service.createAgreement();
                    break;
                case 3: service.deleteProperty();
                    break;
                case 4: service.editRentalAgreementManagement();
                    break;
                case 0: System.out.println("Back to main menu \n");
                    return;
            }
        }
    }
}