package com.cts.dao;

import com.cts.db.DBConnection;
import com.cts.model.Tenant;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TenantDAO {

    public List<Tenant> getAllTenant() throws IOException {
        try{
            Connection conn = DBConnection.getConnection();
            String query = "SELECT * FROM tenant";
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            List<Tenant> propertyList = new ArrayList<Tenant>();

            while(rs.next()){
                int id = rs.getInt("tenant_id");
                String name = rs.getString("name");
                String type = rs.getString("phone_number");
                String email = rs.getString("email");
                propertyList.add(new Tenant(id, name, type, email));
            }
            return propertyList;
        } catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
            return new ArrayList<Tenant>();
        }
    }


    public void createTenant(Tenant tenant) throws IOException {
        try{
            Connection conn = DBConnection.getConnection();
            String query = "insert into tenant(name, phone_number, email) values\n" +
                    "(?, ?, ?);";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, tenant.getName());
            ps.setString(2, tenant.getContactNumber());
            ps.setString(3, tenant.getEmail());
            ps.executeUpdate();
            conn.commit();
            System.out.println("Tenant created!!!");
        }catch (SQLException e){
            System.out.println("SQLException: " + e.getMessage());
        }
    }

    public void deleteTenant(int id) throws Exception {
        try{
            Connection conn = DBConnection.getConnection();
            String query = "delete from tenant where tenant_id = " + id;
            PreparedStatement ps = conn.prepareStatement(query);
            ps.executeUpdate();
            conn.commit();
            System.out.println("Tenant with id="+id+" is DELETED!!!");
        }catch (SQLException e){
            System.out.println("SQLException: " + e.getMessage());
        }
    }

    public Tenant getTenant(int tenant_id) throws IOException {
        try{
            String query = "select * from tenant where tenant_id = " + tenant_id;
            PreparedStatement ps = DBConnection.getConnection().prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
                int id = rs.getInt("tenant_id");
                String name = rs.getString("name");
                String phoneNumber = rs.getString("phone_number");
                String email = rs.getString("email");
                return new Tenant(id, name, phoneNumber, email);
            }
            return null;
        }catch (Exception e){
            System.out.println("SQLException: " + e.getMessage());
            return null;
        }
    }
}
