package com.cts.exception;

public class SQLCustomException extends Exception{
    public SQLCustomException(){

    }
    public SQLCustomException(String message){
        super(message);
    }
}
