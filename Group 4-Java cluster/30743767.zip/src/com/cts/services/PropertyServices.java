package com.cts.services;

import com.cts.model.Property;
import com.cts.dao.PropertyDAO;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

public class PropertyServices {
    PropertyDAO propertyDAO = new PropertyDAO();
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

    public void createProperty() throws IOException {
        System.out.println("Enter property address: ");
        String address = br.readLine();
        System.out.println("Enter property type(Apartment, House, etc): ");
        String type = br.readLine();
        System.out.println("Enter number of bathrooms: ");
        int bathrooms = Integer.parseInt(br.readLine());
        System.out.println("Enter number of bedrooms: ");
        int bedrooms = Integer.parseInt(br.readLine());
        System.out.println("Enter number of Rate Amount: ");
        int rateAmount = Integer.parseInt(br.readLine());
        Property property = new Property(address, type, bathrooms, bedrooms, rateAmount);
        propertyDAO.createProperty(property);
    }

    public void printAllProperties() throws IOException {
        PropertyDAO propertyRepository = new PropertyDAO();
        List<Property> propertyList = propertyRepository.getAllProperty();
        if(!propertyList.isEmpty()) {
            System.out.format("%-10s %-40s %-20s %-10s %-10s %10s\n", "ID", "Address", "Type", "Bathrooms", "Bedrooms", "Rate Amount");
            for(Property property : propertyList) {
                System.out.println(property);
            }
        }else{
            System.out.println("\n\nNo property found\n\n");
        }
    }

    public void deleteProperty() throws Exception{
        printAllProperties();
        System.out.println("\nENTER ID OF PROPERTY TO DELETE: ");
        int id = Integer.parseInt(br.readLine());
        propertyDAO.deleteProperty(id);
    }

    public List<Property> getAll() throws IOException {
        return propertyDAO.getAllProperty();
    }

    public Property getProperty(int id) throws Exception{
        return propertyDAO.getProperty(id);
    }

}
