package com.cts.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {

    static String url = "jdbc:mysql://localhost:3306/rentaldb";
    static String username = "root";
    static String password = "Aryan@08062000";

    static Connection conn = null;

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            System.out.println("Driver not found");
            throw new RuntimeException(e);
        }
    }

    public static Connection getConnection() throws SQLException {
        if(conn == null) {
            conn = DriverManager.getConnection(url, username, password);
        }
        return conn;
    }
}
