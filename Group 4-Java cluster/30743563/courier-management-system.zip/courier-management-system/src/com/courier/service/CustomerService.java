package com.courier.service;

import com.courier.dao.CustomerDau;
import com.courier.model.Customer;

import java.util.List;

public class CustomerService {
    private CustomerDau customerDAO;

    public CustomerService() {
        customerDAO = new CustomerDau();
    }

    public void addCustomer(Customer customer) {
        customerDAO.addCustomer(customer);
    }

    public List<Customer> getAllCustomers() {
        return customerDAO.getAllCustomers();
    }

    public void updateCustomer(Customer customer) {
        customerDAO.updateCustomer(customer);
    }

    public void deleteCustomer(int customerId) {
        customerDAO.deleteCustomer(customerId);
    }
}
