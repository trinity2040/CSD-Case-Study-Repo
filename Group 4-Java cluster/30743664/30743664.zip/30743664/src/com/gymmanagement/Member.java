package com.gymmanagement;
import java.sql.*;
import java.time.LocalDate;
import java.util.Scanner;


public class Member 
{
	private static Connection conn;

    // Initialize connection (call this method before using any methods)
    public static void setConnection(Connection connection) 
    {
        conn = connection;
    }
    public static void viewAllMember(Scanner scanner) {
    	try {
            String sql = "SELECT m.*, mp.name AS plan_name, mp.price_per_month, ms.start_date, ms.end_date " +
                         "FROM Member m " +
                         "JOIN MemberSubscription ms ON m.member_id = ms.member_id " +
                         "JOIN MembershipPlan mp ON ms.plan_id = mp.plan_id";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            ResultSet rs = pstmt.executeQuery();
            
            if (!rs.isBeforeFirst()) { // Check if the ResultSet is empty
                System.out.println("No members found.");
            } else {
                while (rs.next()) {
                    System.out.println("Member ID: " + rs.getInt("member_id"));
                    System.out.println("Name: " + rs.getString("name"));
                    System.out.println("Email: " + rs.getString("email"));
                    System.out.println("Phone Number: " + rs.getString("phone_number"));
                    System.out.println("Address: " + rs.getString("address"));
                    System.out.println("Membership Plan: " + rs.getString("plan_name"));
                    System.out.println("Price per Month: $" + rs.getDouble("price_per_month"));
                    System.out.println("Membership Start Date: " + rs.getDate("start_date"));
                    System.out.println("Membership End Date: " + rs.getDate("end_date"));

                    LocalDate endDate = rs.getDate("end_date").toLocalDate();
                    LocalDate today = LocalDate.now();

                    if (today.isAfter(endDate)) {
                        System.out.println("Membership has expired. Please renew.");
                    }
                    System.out.println(); // Adds a blank line between members for readability
                }
            }
        } catch (SQLException e) {
            System.out.println("Error viewing member: " + e.getMessage());
        }
		
	}

	public static void addMember(Scanner scanner) {
		try {
	        System.out.print("Enter name: ");
	        String name = scanner.nextLine();
	        System.out.print("Enter email: ");
	        String email = scanner.nextLine();
	        System.out.print("Enter phone number: ");
	        String phoneNumber = scanner.nextLine();
	        System.out.print("Enter address: ");
	        String address = scanner.nextLine();

	        String sql = "INSERT INTO Member (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
	        PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
	        pstmt.setString(1, name);
	        pstmt.setString(2, email);
	        pstmt.setString(3, phoneNumber);
	        pstmt.setString(4, address);

	        int rows = pstmt.executeUpdate();
	        if (rows > 0) {
	            ResultSet generatedKeys = pstmt.getGeneratedKeys();
	            if (generatedKeys.next()) {
	                int memberId = generatedKeys.getInt(1);
	                assignMembership(scanner, memberId);
	            }
	        }
	    } catch (SQLException e) {
	        System.out.println("Error adding member: " + e.getMessage());
	    }
    }

    public static void assignMembership(Scanner scanner, int memberId) {
    	try {
            // Query to fetch all available membership plans
            String sqlPlans = "SELECT * FROM MembershipPlan";
            Statement stmtPlans = conn.createStatement();
            ResultSet rsPlans = stmtPlans.executeQuery(sqlPlans);

            if (!rsPlans.next()) {
                // No plans available, prompt user to add a new plan
                System.out.println("No membership plans available.");
                System.out.println("Please add a new membership plan first.");
                // Optionally call a method to add a new plan here
                return;
            }

            // Display available membership plans
            System.out.println("Available Membership Plans:");
            do {
                System.out.println("Plan ID: " + rsPlans.getInt("plan_id"));
                System.out.println("Plan Name: " + rsPlans.getString("name"));
                System.out.println("Duration (Months): " + rsPlans.getInt("duration_months"));
                System.out.println("Price per Month: $" + rsPlans.getDouble("price_per_month"));
                System.out.println();
            } while (rsPlans.next());

            // Prompt user to select a plan ID
            System.out.print("Enter membership plan ID: ");
            int planId = scanner.nextInt();
            System.out.print("Enter membership start date (YYYY-MM-DD): ");
            String startDateStr = scanner.next();
            LocalDate startDate = LocalDate.parse(startDateStr);

            // Fetch details of the selected plan
            String sqlPlan = "SELECT * FROM MembershipPlan WHERE plan_id = ?";
            PreparedStatement pstmtPlan = conn.prepareStatement(sqlPlan);
            pstmtPlan.setInt(1, planId);
            ResultSet rsPlan = pstmtPlan.executeQuery();

            if (rsPlan.next()) {
                int durationMonths = rsPlan.getInt("duration_months");
                LocalDate endDate = startDate.plusMonths(durationMonths);
                double pricePerMonth = rsPlan.getDouble("price_per_month");

                double totalFee = calculateMembershipFee(pricePerMonth, durationMonths);
                System.out.println("Total Membership Fee: $" + totalFee);

                // Insert new membership assignment into MemberSubscription
                String sqlMembership = "INSERT INTO MemberSubscription (member_id, plan_id, start_date, end_date) VALUES (?, ?, ?, ?)";
                PreparedStatement pstmtMembership = conn.prepareStatement(sqlMembership);
                pstmtMembership.setInt(1, memberId);
                pstmtMembership.setInt(2, planId);
                pstmtMembership.setDate(3, Date.valueOf(startDate));
                pstmtMembership.setDate(4, Date.valueOf(endDate));

                int rows = pstmtMembership.executeUpdate();
                if (rows > 0) {
                    System.out.println("Membership assigned successfully.");
                }
            } else {
                System.out.println("Membership plan not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error assigning membership: " + e.getMessage());
        }
    }

    public static double calculateMembershipFee(double pricePerMonth, int durationMonths) {
        return pricePerMonth * durationMonths;
    }

    public static void renewMembership(Scanner scanner) {
    	try {
            System.out.print("Enter member ID: ");
            int memberId = scanner.nextInt();

            // Query to get the end date and current plan of the member
            String sql = "SELECT end_date, plan_id FROM MemberSubscription WHERE member_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, memberId);

            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                LocalDate endDate = rs.getDate("end_date").toLocalDate();
                int planId = rs.getInt("plan_id");
                LocalDate currentDate = LocalDate.now();

                // Check if the membership is expired
                if (currentDate.isAfter(endDate)) {
                    System.out.println("Your membership has expired.");

                    // Show available plans for renewal
                    String sqlPlans = "SELECT plan_id, name, duration_months, price_per_month FROM MembershipPlan";
                    Statement stmtPlans = conn.createStatement();
                    ResultSet rsPlans = stmtPlans.executeQuery(sqlPlans);

                    System.out.println("Available Membership Plans:");
                    while (rsPlans.next()) {
                        System.out.println("Plan ID: " + rsPlans.getInt("plan_id"));
                        System.out.println("Plan Name: " + rsPlans.getString("name"));
                        System.out.println("Duration (Months): " + rsPlans.getInt("duration_months"));
                        System.out.println("Price per Month: $" + rsPlans.getDouble("price_per_month"));
                        System.out.println();
                    }

                    // Prompt user to choose a new plan
                    System.out.print("Choose a new plan ID for renewal: ");
                    int newPlanId = scanner.nextInt();

                    // Fetch details of the selected plan
                    String sqlPlanDetails = "SELECT duration_months, price_per_month FROM MembershipPlan WHERE plan_id = ?";
                    PreparedStatement pstmtPlanDetails = conn.prepareStatement(sqlPlanDetails);
                    pstmtPlanDetails.setInt(1, newPlanId);
                    ResultSet rsPlanDetails = pstmtPlanDetails.executeQuery();

                    if (rsPlanDetails.next()) {
                        int newDuration = rsPlanDetails.getInt("duration_months");
                        double pricePerMonth = rsPlanDetails.getDouble("price_per_month");

                        LocalDate newEndDate = currentDate.plusMonths(newDuration);
                        double renewalFee = calculateMembershipFee(pricePerMonth, newDuration);

                        System.out.println("Renewal Fee: $" + renewalFee);

                        // Update the membership with the new plan and end date
                        String sqlUpdate = "UPDATE MemberSubscription SET plan_id = ?, end_date = ? WHERE member_id = ?";
                        PreparedStatement pstmtUpdate = conn.prepareStatement(sqlUpdate);
                        pstmtUpdate.setInt(1, newPlanId);
                        pstmtUpdate.setDate(2, Date.valueOf(newEndDate));
                        pstmtUpdate.setInt(3, memberId);

                        int rows = pstmtUpdate.executeUpdate();
                        if (rows > 0) {
                            System.out.println("Membership renewed successfully with the new plan.");
                        } else {
                            System.out.println("Membership renewal failed.");
                        }
                    } else {
                        System.out.println("Selected membership plan not found.");
                    }
                } else {
                    System.out.println("Your membership is not expired.");

                    // Ask if the user wants to renew anyway
                    System.out.print("Do you want to renew your membership anyway? (yes/no): ");
                    String choice = scanner.next();

                    if (choice.equalsIgnoreCase("yes")) {
                        System.out.print("Enter additional duration in months: ");
                        int additionalMonths = scanner.nextInt();

                        LocalDate newEndDate = endDate.plusMonths(additionalMonths);

                        // Get the price per month for the current plan
                        String sqlPlan = "SELECT price_per_month FROM MembershipPlan WHERE plan_id = ?";
                        PreparedStatement pstmtPlan = conn.prepareStatement(sqlPlan);
                        pstmtPlan.setInt(1, planId);
                        ResultSet rsPlan = pstmtPlan.executeQuery();

                        if (rsPlan.next()) {
                            double pricePerMonth = rsPlan.getDouble("price_per_month");
                            double additionalFee = calculateMembershipFee(pricePerMonth, additionalMonths);

                            System.out.println("Additional Membership Fee: $" + additionalFee);

                            // Update the membership with the new end date
                            String sqlUpdate = "UPDATE MemberSubscription SET end_date = ? WHERE member_id = ?";
                            PreparedStatement pstmtUpdate = conn.prepareStatement(sqlUpdate);
                            pstmtUpdate.setDate(1, Date.valueOf(newEndDate));
                            pstmtUpdate.setInt(2, memberId);

                            int rows = pstmtUpdate.executeUpdate();
                            if (rows > 0) {
                                System.out.println("Membership renewed successfully.");
                            } else {
                                System.out.println("Membership renewal failed.");
                            }
                        } else {
                            System.out.println("Membership plan not found.");
                        }
                    } else {
                        System.out.println("Membership renewal cancelled.");
                    }
                }
            } else {
                System.out.println("Membership not found for the member.");
            }
        } catch (SQLException e) {
            System.out.println("Error renewing membership: " + e.getMessage());
        }
    }

    public static void viewMemberByID(Scanner scanner) {
    	 try {
    	        System.out.print("Enter member ID: ");
    	        int memberId = scanner.nextInt();

    	        // Updated SQL query to use the new table and column names
    	        String sql = "SELECT m.*, mp.name AS plan_name, mp.price_per_month, ms.start_date, ms.end_date " +
    	                     "FROM Member m " +
    	                     "JOIN MemberSubscription ms ON m.member_id = ms.member_id " + // Changed table name and column name
    	                     "JOIN MembershipPlan mp ON ms.plan_id = mp.plan_id " +
    	                     "WHERE m.member_id = ?"; // Changed column name

    	        PreparedStatement pstmt = conn.prepareStatement(sql);
    	        pstmt.setInt(1, memberId);

    	        ResultSet rs = pstmt.executeQuery();
    	        if (rs.next()) {
    	            System.out.println("Member ID: " + rs.getInt("member_id")); // Changed column name
    	            System.out.println("Name: " + rs.getString("name"));
    	            System.out.println("Email: " + rs.getString("email"));
    	            System.out.println("Phone Number: " + rs.getString("phone_number"));
    	            System.out.println("Address: " + rs.getString("address"));
    	            System.out.println("Membership Plan: " + rs.getString("plan_name"));
    	            System.out.println("Price per Month: $" + rs.getDouble("price_per_month"));
    	            System.out.println("Membership Start Date: " + rs.getDate("start_date"));
    	            System.out.println("Membership End Date: " + rs.getDate("end_date"));

    	            LocalDate endDate = rs.getDate("end_date").toLocalDate();
    	            LocalDate today = LocalDate.now();

    	            if (today.isAfter(endDate)) {
    	                System.out.println("Membership has expired. Please renew.");
    	            }
    	        } else {
    	            System.out.println("Member not found.");
    	        }
    	    } catch (SQLException e) {
    	        System.out.println("Error viewing member: " + e.getMessage());
    	    }
    }

    public static void updateMember(Scanner scanner) {
    	try {
            System.out.print("Enter member ID to update: ");
            int memberId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter new name (leave blank to keep current): ");
            String name = scanner.nextLine();
            System.out.print("Enter new email (leave blank to keep current): ");
            String email = scanner.nextLine();
            System.out.print("Enter new phone number (leave blank to keep current): ");
            String phoneNumber = scanner.nextLine();
            System.out.print("Enter new address (leave blank to keep current): ");
            String address = scanner.nextLine();

            String sql = "UPDATE Member SET name = COALESCE(NULLIF(?, ''), name), " +
                         "email = COALESCE(NULLIF(?, ''), email), " +
                         "phone_number = COALESCE(NULLIF(?, ''), phone_number), " +
                         "address = COALESCE(NULLIF(?, ''), address) " +
                         "WHERE member_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phoneNumber);
            pstmt.setString(4, address);
            pstmt.setInt(5, memberId);

            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                System.out.println("Member updated successfully.");
            } else {
                System.out.println("Member not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating member: " + e.getMessage());
        }
    }

    public static void deleteMember(Scanner scanner) {
    	try {
            System.out.print("Enter member ID to delete: ");
            int memberId = scanner.nextInt();

            // Delete memberships associated with the member
            deleteMembership(memberId);

            // Delete the member
            String sql = "DELETE FROM Member WHERE member_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, memberId);

            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                System.out.println("Member deleted successfully.");
            } else {
                System.out.println("Member not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting member: " + e.getMessage());
        }
    }

    public static void deleteMembership(int memberId) {
    	try {
            String sql = "DELETE FROM MemberSubscription WHERE id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, memberId);

            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error deleting membership: " + e.getMessage());
        }
    }


}
