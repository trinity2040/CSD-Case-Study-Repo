package com.gymmanagement;
import java.sql.*;
import java.util.Scanner;

public class Trainer 
{
	private static Connection conn;

    public static void setConnection(Connection connection) 
    {
        conn = connection;
    }
    public static void addTrainer(Scanner scanner) {
    	try {
            System.out.print("Enter name: ");
            String name = scanner.nextLine();
            System.out.print("Enter email: ");
            String email = scanner.nextLine();
            System.out.print("Enter phone number: ");
            String phoneNumber = scanner.nextLine();
            System.out.print("Enter speciality: ");
            String speciality = scanner.nextLine();

            // SQL query to insert a new trainer
            String sql = "INSERT INTO Trainer (name, email, phone_number, speciality) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phoneNumber);
            pstmt.setString(4, speciality);

            // Execute the update and check the result
            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                System.out.println("Trainer added successfully.");
            } else {
                System.out.println("Failed to add trainer.");
            }
        } catch (SQLException e) {
            System.out.println("Error adding trainer: " + e.getMessage());
        }
    }

    public static void viewTrainer(Scanner scanner) {
    	try {
            String sql = "SELECT * FROM Trainer";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            ResultSet rs = pstmt.executeQuery();

            if (!rs.isBeforeFirst()) { // Check if the ResultSet is empty
                System.out.println("No trainers found.");
            } else {
                while (rs.next()) {
                    System.out.println("Trainer ID: " + rs.getInt("trainer_id"));
                    System.out.println("Name: " + rs.getString("name"));
                    System.out.println("Email: " + rs.getString("email"));
                    System.out.println("Phone Number: " + rs.getString("phone_number"));
                    System.out.println("Speciality: " + rs.getString("speciality"));
                    System.out.println(); // Adds a blank line between trainers for readability
                }
            }
        } catch (SQLException e) {
            System.out.println("Error viewing trainers: " + e.getMessage());
        }
    }

    public static void updateTrainer(Scanner scanner) {
        try {
            System.out.print("Enter trainer ID to update: ");
            int trainerId = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            System.out.print("Enter new name (leave blank to keep current): ");
            String name = scanner.nextLine();
            System.out.print("Enter new email (leave blank to keep current): ");
            String email = scanner.nextLine();
            System.out.print("Enter new phone number (leave blank to keep current): ");
            String phoneNumber = scanner.nextLine();
            System.out.print("Enter new speciality (leave blank to keep current): ");
            String speciality = scanner.nextLine();

            String sql = "UPDATE Trainer SET name = COALESCE(NULLIF(?, ''), name), " +
                         "email = COALESCE(NULLIF(?, ''), email), " +
                         "phone_number = COALESCE(NULLIF(?, ''), phone_number), " +
                         "speciality = COALESCE(NULLIF(?, ''), speciality) " +
                         "WHERE trainer_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, phoneNumber);
            pstmt.setString(4, speciality);
            pstmt.setInt(5, trainerId);

            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                System.out.println("Trainer updated successfully.");
            } else {
                System.out.println("Trainer not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating trainer: " + e.getMessage());
        }
    }

    public static void deleteTrainer(Scanner scanner) {
        try {
            System.out.print("Enter trainer ID to delete: ");
            int trainerId = scanner.nextInt();

            String sql = "DELETE FROM Trainer WHERE trainer_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, trainerId);

            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                System.out.println("Trainer deleted successfully.");
            } else {
                System.out.println("Trainer not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting trainer: " + e.getMessage());
        }
    }

}
