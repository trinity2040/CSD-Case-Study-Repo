package com.gymmanagement;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class GymManagementSystem 
{

	public static void main(String[] args) {
		try 
        {
        	Connection conn = DatabaseConnection.getConnection();
            Member.setConnection(conn);
            Trainer.setConnection(conn);
            MembershipPlan.setConnection(conn);

            Scanner scanner = new Scanner(System.in);

            while (true) {
                System.out.println("\n--- Gym Membership Management System ---");
                System.out.println("1. Manage Members");
                System.out.println("2. Manage Trainers");
                System.out.println("3. Manage Membership Plans");
                System.out.println("4. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        manageMembers(scanner);
                        break;
                    case 2:
                        manageTrainers(scanner);
                        break;
                    case 3:
                        manageMembershipPlans(scanner);
                        break;
                    case 4:
                        System.out.println("Exiting the system...");
                        conn.close();
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }


	}
	private static void manageMembers(Scanner scanner) {
        while (true) {
            System.out.println("\n--- Manage Members ---");
            System.out.println("1. Add Member");
            System.out.println("2. View All Members");
            System.out.println("3. View Member By Id");
            System.out.println("4. Update Member");
            System.out.println("5. Delete Member");
            System.out.println("6. Renew Membership");
            System.out.println("7. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); 
            switch (choice) {
                case 1:
                    Member.addMember(scanner);
                    break;
                case 2:
                	Member.viewAllMember(scanner);
                    break;
                case 3:Member.viewMemberByID(scanner);
                	   break;
                case 4:
                    Member.updateMember(scanner);
                    break;
                case 5:
                    Member.deleteMember(scanner);
                    break;
                case 6:
                    Member.renewMembership(scanner);
                    break;
                case 7:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    

    private static void manageTrainers(Scanner scanner) {
        while (true) {
            System.out.println("\n--- Manage Trainers ---");
            System.out.println("1. Add Trainer");
            System.out.println("2. View Trainer");
            System.out.println("3. Update Trainer");
            System.out.println("4. Delete Trainer");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    Trainer.addTrainer(scanner);
                    break;
                case 2:
                    Trainer.viewTrainer(scanner);
                    break;
                case 3:
                    Trainer.updateTrainer(scanner);
                    break;
                case 4:
                    Trainer.deleteTrainer(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void manageMembershipPlans(Scanner scanner) {
        while (true) {
            System.out.println("\n--- Manage Membership Plans ---");
            System.out.println("1. Create Membership Plan");
            System.out.println("2. View Membership Plan");
            System.out.println("3. Update Membership Plan");
            System.out.println("4. Delete Membership Plan");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    MembershipPlan.createMembershipPlan(scanner);
                    break;
                case 2:
                    MembershipPlan.viewMembershipPlan(scanner);
                    break;
                case 3:
                    MembershipPlan.updateMembershipPlan(scanner);
                    break;
                case 4:
                    MembershipPlan.deleteMembershipPlan(scanner);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    


}
