package com.gymmanagement;
import java.sql.*;
import java.util.Scanner;
public class MembershipPlan 
{
	private static Connection conn;

    public static void setConnection(Connection connection) 
    {
        conn = connection;
    }
    public static void createMembershipPlan(Scanner scanner) {
    	try {
            // Read input from the user
            System.out.print("Enter plan name: ");
            String name = scanner.nextLine();
            System.out.print("Enter duration in months: ");
            int durationMonths = scanner.nextInt();
            System.out.print("Enter price per month: ");
            double pricePerMonth = scanner.nextDouble();

            // Prepare SQL statement to insert new membership plan
            String sql = "INSERT INTO MembershipPlan (name, duration_months, price_per_month) VALUES (?, ?, ?)";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, name);
            pstmt.setInt(2, durationMonths);
            pstmt.setDouble(3, pricePerMonth);

            // Execute the SQL statement
            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                System.out.println("Membership plan created successfully.");
            } else {
                System.out.println("Failed to create membership plan.");
            }
        } catch (SQLException e) {
            System.out.println("Error creating membership plan: " + e.getMessage());
        }
    }

    public static void viewMembershipPlan(Scanner scanner) {
    	try {
            // SQL query to select all rows from the MembershipPlan table
            String sql = "SELECT * FROM MembershipPlan";
            PreparedStatement pstmt = conn.prepareStatement(sql);

            ResultSet rs = pstmt.executeQuery();
            if (!rs.isBeforeFirst()) { // Check if the ResultSet is empty
                System.out.println("No membership plans are listed.");
            } else {
                while (rs.next()) {
                    System.out.println("Plan ID: " + rs.getInt("plan_id"));
                    System.out.println("Name: " + rs.getString("name"));
                    System.out.println("Duration (months): " + rs.getInt("duration_months"));
                    System.out.println("Price per Month: $" + rs.getDouble("price_per_month"));
                    System.out.println(); // Adds a blank line between records for readability
                }
            }
        } 
        catch (SQLException e) {
            System.out.println("Error viewing membership plan: " + e.getMessage());
        }
    }

    public static void updateMembershipPlan(Scanner scanner) {
    	 try {
    	        System.out.print("Enter plan ID to update: ");
    	        int planId = scanner.nextInt();
    	        scanner.nextLine(); // Consume newline

    	        System.out.print("Enter new name (leave blank to keep current): ");
    	        String name = scanner.nextLine();
    	        System.out.print("Enter new duration in months (enter 0 to keep current): ");
    	        int durationMonths = scanner.nextInt();
    	        System.out.print("Enter new price per month (enter 0 to keep current): ");
    	        double pricePerMonth = scanner.nextDouble();

    	        // SQL query to update the MembershipPlan table
    	        String sql = "UPDATE MembershipPlan SET name = COALESCE(NULLIF(?, ''), name), " +
    	                     "duration_months = COALESCE(NULLIF(?, 0), duration_months), " +
    	                     "price_per_month = COALESCE(NULLIF(?, 0), price_per_month) " +
    	                     "WHERE plan_id = ?";
    	        PreparedStatement pstmt = conn.prepareStatement(sql);
    	        pstmt.setString(1, name);
    	        pstmt.setInt(2, durationMonths);
    	        pstmt.setDouble(3, pricePerMonth);
    	        pstmt.setInt(4, planId);

    	        int rows = pstmt.executeUpdate();
    	        if (rows > 0) {
    	            System.out.println("Membership plan updated successfully.");
    	        } else {
    	            System.out.println("Membership plan not found.");
    	        }
    	    } catch (SQLException e) {
    	        System.out.println("Error updating membership plan: " + e.getMessage());
    	    }
    }

    public static void deleteMembershipPlan(Scanner scanner) {
        try {
            System.out.print("Enter plan ID to delete: ");
            int planId = scanner.nextInt();

            String sql = "DELETE FROM MembershipPlan WHERE plan_id = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, planId);

            int rows = pstmt.executeUpdate();
            if (rows > 0) {
                System.out.println("Membership plan deleted successfully.");
            } else {
                System.out.println("Membership plan not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting membership plan: " + e.getMessage());
        }
    }

}
