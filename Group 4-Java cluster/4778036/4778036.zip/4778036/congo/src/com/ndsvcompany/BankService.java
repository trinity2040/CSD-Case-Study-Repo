package com.ndsvcompany;

import java.sql.Timestamp;
import java.util.List;
import java.util.Scanner;

public class BankService {
    private AccountDAO accountDAO = new AccountDAO();
    private TransactionDAO transactionDAO = new TransactionDAO();
    private Scanner scanner = new Scanner(System.in);

    public void run() {
        System.out.println("Welcome to the Banking System");
        while (true) {
            System.out.println("1. Add Account");
            System.out.println("2. View Account Details");
            System.out.println("3. Update Account Information");
            System.out.println("4. Close Account");
            System.out.println("5. Deposit Funds");
            System.out.println("6. Withdraw Funds");
            System.out.println("7. Transfer Funds");
            System.out.println("8. View Transactions");
            System.out.println("9. Exit");
            System.out.print("Choose an option: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addAccount();
                    break;
                case 2:
                    viewAccountDetails();
                    break;
                case 3:
                    updateAccountInformation();
                    break;
                case 4:
                    closeAccount();
                    break;
                case 5:
                    depositFunds();
                    break;
                case 6:
                    withdrawFunds();
                    break;
                case 7:
                    transferFunds();
                    break;
                case 8:
                    viewTransactions();
                    break;
                case 9:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void addAccount() {
        System.out.print("Enter customer ID: ");
        int customerId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        // Check if customer exists
        if (!accountDAO.customerExists(customerId)) {
            System.out.println("Customer ID does not exist.");
            return;
        }

        System.out.print("Enter account type (Savings/Checking): ");
        String accountType = scanner.nextLine();

        System.out.print("Enter initial balance: ");
        double balance = scanner.nextDouble();

        Account account = new Account(0, customerId, accountType, balance);
        accountDAO.addAccount(account);
    }

    private void viewAccountDetails() {
        System.out.print("Enter account ID: ");
        int accountId = scanner.nextInt();

        Account account = accountDAO.getAccount(accountId);
        if (account != null) {
            System.out.println("Account ID: " + account.getAccountId());
            System.out.println("Customer ID: " + account.getCustomerId());
            System.out.println("Account Type: " + account.getAccountType());
            System.out.println("Balance: " + account.getBalance());
        } else {
            System.out.println("Account not found.");
        }
    }

    private void updateAccountInformation() {
        System.out.print("Enter account ID: ");
        int accountId = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Account account = accountDAO.getAccount(accountId);
        if (account != null) {
            System.out.print("Enter new account type (Savings/Checking): ");
            String accountType = scanner.nextLine();
            System.out.print("Enter new balance: ");
            double balance = scanner.nextDouble();

            account.setAccountType(accountType);
            account.setBalance(balance);
            accountDAO.updateAccount(account);
            System.out.println("Account updated successfully.");
        } else {
            System.out.println("Account not found.");
        }
    }

    private void closeAccount() {
        System.out.print("Enter account ID: ");
        int accountId = scanner.nextInt();

        boolean success = accountDAO.deleteAccount(accountId);
        if (success) {
            System.out.println("Account closed successfully.");
        } else {
            System.out.println("Failed to close account.");
        }
    }

    private void depositFunds() {
        System.out.print("Enter account ID: ");
        int accountId = scanner.nextInt();

        System.out.print("Enter amount to deposit: ");
        double amount = scanner.nextDouble();

        boolean success = transactionDAO.depositFunds(accountId, amount);
        if (success) {
            System.out.println("Funds deposited successfully.");
        } else {
            System.out.println("Failed to deposit funds.");
        }
    }

    private void withdrawFunds() {
        System.out.print("Enter account ID: ");
        int accountId = scanner.nextInt();

        System.out.print("Enter amount to withdraw: ");
        double amount = scanner.nextDouble();

        boolean success = transactionDAO.withdrawFunds(accountId, amount);
        if (success) {
            System.out.println("Funds withdrawn successfully.");
        } else {
            System.out.println("Failed to withdraw funds.");
        }
    }

    private void transferFunds() {
        System.out.print("Enter source account ID: ");
        int sourceAccountId = scanner.nextInt();

        System.out.print("Enter destination account ID: ");
        int destinationAccountId = scanner.nextInt();

        System.out.print("Enter amount to transfer: ");
        double amount = scanner.nextDouble();

        boolean success = transactionDAO.transferFunds(sourceAccountId, destinationAccountId, amount);
        if (success) {
            System.out.println("Funds transferred successfully.");
        } else {
            System.out.println("Failed to transfer funds.");
        }
    }

    private void viewTransactions() {
        System.out.print("Enter account ID: ");
        int accountId = scanner.nextInt();

        List<Transaction> transactions = transactionDAO.getTransactions(accountId);
        if (transactions.isEmpty()) {
            System.out.println("No transactions found.");
        } else {
            for (Transaction transaction : transactions) {
                System.out.println("ID: " + transaction.getTransactionId()
                        + ", Type: " + transaction.getTransactionType()
                        + ", Amount: " + transaction.getAmount()
                        + ", Date: " + transaction.getTransactionDate());
            }
        }
    }
}
