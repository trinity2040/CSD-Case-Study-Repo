package com.ndsvcompany;

public class Main {
    public static void main(String[] args) {
        BankService bankService = new BankService();
        bankService.run();
    }
}
