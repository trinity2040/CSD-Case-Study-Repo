package com.ndsvcompany;

import java.sql.*;

public class AccountDAO {

    public void addAccount(Account account) {
        String sql = "INSERT INTO account (customer_id, account_type, balance) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setInt(1, account.getCustomerId());
            pstmt.setString(2, account.getAccountType());
            pstmt.setDouble(3, account.getBalance());
            pstmt.executeUpdate();

            try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    account.setAccountId(generatedKeys.getInt(1));
                }
            }

            System.out.println("Account added successfully with ID: " + account.getAccountId());

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public Account getAccount(int accountId) {
        String sql = "SELECT * FROM account WHERE account_id = ?";
        Account account = null;

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, accountId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int customerId = rs.getInt("customer_id");
                    String accountType = rs.getString("account_type");
                    double balance = rs.getDouble("balance");
                    account = new Account(accountId, customerId, accountType, balance);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return account;
    }

    public void updateAccount(Account account) {
        String sql = "UPDATE account SET account_type = ?, balance = ? WHERE account_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, account.getAccountType());
            pstmt.setDouble(2, account.getBalance());
            pstmt.setInt(3, account.getAccountId());
            pstmt.executeUpdate();

            System.out.println("Account updated successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public boolean deleteAccount(int accountId) {
        String sql = "DELETE FROM account WHERE account_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, accountId);
            int rowsAffected = pstmt.executeUpdate();

            return rowsAffected > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean customerExists(int customerId) {
        String sql = "SELECT COUNT(*) FROM customer WHERE customer_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, customerId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
