package com.ndsvcompany;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TransactionDAO {

    public void addTransaction(Transaction transaction) {
        String sql = "INSERT INTO transaction (account_id, transaction_type, amount, transaction_date) VALUES (?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, transaction.getAccountId());
            pstmt.setString(2, transaction.getTransactionType());
            pstmt.setDouble(3, transaction.getAmount());
            pstmt.setTimestamp(4, transaction.getTransactionDate());
            pstmt.executeUpdate();

            System.out.println("Transaction added successfully.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Transaction> getTransactions(int accountId) {
        String sql = "SELECT * FROM transaction WHERE account_id = ?";
        List<Transaction> transactions = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, accountId);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    int transactionId = rs.getInt("transaction_id");
                    String transactionType = rs.getString("transaction_type");
                    double amount = rs.getDouble("amount");
                    Timestamp transactionDate = rs.getTimestamp("transaction_date");

                    Transaction transaction = new Transaction(transactionId, accountId, transactionType, amount, transactionDate);
                    transactions.add(transaction);
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return transactions;
    }

    public boolean depositFunds(int accountId, double amount) {
        String sqlUpdateBalance = "UPDATE account SET balance = balance + ? WHERE account_id = ?";
        String sqlInsertTransaction = "INSERT INTO transaction (account_id, transaction_type, amount, transaction_date) VALUES (?, 'Deposit', ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmtUpdate = conn.prepareStatement(sqlUpdateBalance);
             PreparedStatement pstmtInsert = conn.prepareStatement(sqlInsertTransaction)) {

            // Update account balance
            pstmtUpdate.setDouble(1, amount);
            pstmtUpdate.setInt(2, accountId);
            int rowsUpdated = pstmtUpdate.executeUpdate();

            if (rowsUpdated > 0) {
                // Insert transaction record
                pstmtInsert.setInt(1, accountId);
                pstmtInsert.setDouble(2, amount);
                pstmtInsert.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
                pstmtInsert.executeUpdate();

                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean withdrawFunds(int accountId, double amount) {
        String sqlUpdateBalance = "UPDATE account SET balance = balance - ? WHERE account_id = ?";
        String sqlInsertTransaction = "INSERT INTO transaction (account_id, transaction_type, amount, transaction_date) VALUES (?, 'Withdrawal', ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmtUpdate = conn.prepareStatement(sqlUpdateBalance);
             PreparedStatement pstmtInsert = conn.prepareStatement(sqlInsertTransaction)) {

            // Update account balance
            pstmtUpdate.setDouble(1, amount);
            pstmtUpdate.setInt(2, accountId);
            int rowsUpdated = pstmtUpdate.executeUpdate();

            if (rowsUpdated > 0) {
                // Insert transaction record
                pstmtInsert.setInt(1, accountId);
                pstmtInsert.setDouble(2, amount);
                pstmtInsert.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
                pstmtInsert.executeUpdate();

                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean transferFunds(int sourceAccountId, int destinationAccountId, double amount) {
        String sqlWithdraw = "UPDATE account SET balance = balance - ? WHERE account_id = ?";
        String sqlDeposit = "UPDATE account SET balance = balance + ? WHERE account_id = ?";
        String sqlInsertWithdraw = "INSERT INTO transaction (account_id, transaction_type, amount, transaction_date) VALUES (?, 'Withdrawal', ?, ?)";
        String sqlInsertDeposit = "INSERT INTO transaction (account_id, transaction_type, amount, transaction_date) VALUES (?, 'Deposit', ?, ?)";

        Connection conn = null;
        PreparedStatement pstmtWithdraw = null;
        PreparedStatement pstmtDeposit = null;
        PreparedStatement pstmtInsertWithdraw = null;
        PreparedStatement pstmtInsertDeposit = null;

        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false); // Start transaction

            // Withdraw from source account
            pstmtWithdraw = conn.prepareStatement(sqlWithdraw);
            pstmtWithdraw.setDouble(1, amount);
            pstmtWithdraw.setInt(2, sourceAccountId);
            int rowsWithdrawn = pstmtWithdraw.executeUpdate();

            if (rowsWithdrawn > 0) {
                // Deposit into destination account
                pstmtDeposit = conn.prepareStatement(sqlDeposit);
                pstmtDeposit.setDouble(1, amount);
                pstmtDeposit.setInt(2, destinationAccountId);
                int rowsDeposited = pstmtDeposit.executeUpdate();

                if (rowsDeposited > 0) {
                    // Insert withdrawal transaction record
                    pstmtInsertWithdraw = conn.prepareStatement(sqlInsertWithdraw);
                    pstmtInsertWithdraw.setInt(1, sourceAccountId);
                    pstmtInsertWithdraw.setDouble(2, amount);
                    pstmtInsertWithdraw.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
                    pstmtInsertWithdraw.executeUpdate();

                    // Insert deposit transaction record
                    pstmtInsertDeposit = conn.prepareStatement(sqlInsertDeposit);
                    pstmtInsertDeposit.setInt(1, destinationAccountId);
                    pstmtInsertDeposit.setDouble(2, amount);
                    pstmtInsertDeposit.setTimestamp(3, new Timestamp(System.currentTimeMillis()));
                    pstmtInsertDeposit.executeUpdate();

                    conn.commit(); // Commit transaction
                    return true;
                }
            }

            conn.rollback(); // Rollback transaction in case of failure

        } catch (SQLException e) {
            e.printStackTrace();
            if (conn != null) {
                try {
                    conn.rollback(); // Rollback transaction in case of failure
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        } finally {
            if (pstmtWithdraw != null) {
                try {
                    pstmtWithdraw.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmtDeposit != null) {
                try {
                    pstmtDeposit.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmtInsertWithdraw != null) {
                try {
                    pstmtInsertWithdraw.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmtInsertDeposit != null) {
                try {
                    pstmtInsertDeposit.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
        return false;
    }
}
