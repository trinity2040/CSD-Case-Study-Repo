package com.cts.dao.daoimpl;

import com.cts.dao.AbstractPolicyDAO;
import com.cts.exception.PolicyNotFoundException;
import com.cts.model.Policy;
import com.cts.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PolicyDAOImpl extends AbstractPolicyDAO {

    @Override
    public void addPolicy(Policy policy) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO Policy (policy_number, type, coverage_amount, premium_amount) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, policy.getPolicyNumber());
            ps.setString(2, policy.getType());
            ps.setDouble(3, policy.getCoverageAmount());
            ps.setDouble(4, policy.getPremiumAmount());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Policy getPolicyById(int policyId) throws PolicyNotFoundException {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Policy WHERE policy_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, policyId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Policy(
                        rs.getInt("policy_id"),
                        rs.getString("policy_number"),
                        rs.getString("type"),
                        rs.getDouble("coverage_amount"),
                        rs.getDouble("premium_amount")
                );
            } else {
                throw new PolicyNotFoundException("Policy with ID " + policyId + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new PolicyNotFoundException("Database error occurred.");
        }
    }

    @Override
    public List<Policy> getAllPolicies() {
        List<Policy> policies = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Policy";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                policies.add(new Policy(
                        rs.getInt("policy_id"),
                        rs.getString("policy_number"),
                        rs.getString("type"),
                        rs.getDouble("coverage_amount"),
                        rs.getDouble("premium_amount")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return policies;
    }

    @Override
    public void updatePolicy(Policy policy) throws PolicyNotFoundException {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "UPDATE Policy SET policy_number = ?, type = ?, coverage_amount = ?, premium_amount = ? WHERE policy_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, policy.getPolicyNumber());
            ps.setString(2, policy.getType());
            ps.setDouble(3, policy.getCoverageAmount());
            ps.setDouble(4, policy.getPremiumAmount());
            ps.setInt(5, policy.getPolicyId());

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected == 0) {
                throw new PolicyNotFoundException("Policy with ID " + policy.getPolicyId() + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new PolicyNotFoundException("Database error occurred.");
        }
    }

    @Override
    public void deletePolicy(int policyId) throws PolicyNotFoundException {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "DELETE FROM Policy WHERE policy_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, policyId);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected == 0) {
                throw new PolicyNotFoundException("Policy with ID " + policyId + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new PolicyNotFoundException("Database error occurred.");
        }
    }
}
