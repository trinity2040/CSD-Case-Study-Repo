package com.cts.client;

import com.cts.dao.daoimpl.CustomerDAOImpl;
import com.cts.dao.daoimpl.PolicyDAOImpl;
import com.cts.dao.daoimpl.ClaimDAOImpl;
import com.cts.model.Customer;
import com.cts.model.Policy;
import com.cts.model.Claim;

import java.util.Scanner;
import java.util.Date;

public class Main {
    public static void main(String[] args) {
        CustomerDAOImpl customerDAO = new CustomerDAOImpl();
        PolicyDAOImpl policyDAO = new PolicyDAOImpl();
        ClaimDAOImpl claimDAO = new ClaimDAOImpl();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== Car Insurance Management System ===");
            System.out.println("1. Manage Policies");
            System.out.println("2. Manage Customers");
            System.out.println("3. Manage Claims");
            System.out.println("4. Exit");

            int mainChoice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (mainChoice) {
                case 1:
                    managePolicies(scanner, policyDAO);
                    break;
                case 2:
                    manageCustomers(scanner, customerDAO);
                    break;
                case 3:
                    manageClaims(scanner, claimDAO);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    private static void managePolicies(Scanner scanner, PolicyDAOImpl policyDAO) {
        while (true) {
            System.out.println("\nPolicy Management");
            System.out.println("1. Add Policy");
            System.out.println("2. View Policy");
            System.out.println("3. Update Policy");
            System.out.println("4. Delete Policy");
            System.out.println("5. Back to Main Menu");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    System.out.println("Enter Policy Number:");
                    String policyNumber = scanner.nextLine();
                    System.out.println("Enter Type:");
                    String type = scanner.nextLine();
                    System.out.println("Enter Coverage Amount:");
                    double coverageAmount = scanner.nextDouble();
                    System.out.println("Enter Premium Amount:");
                    double premiumAmount = scanner.nextDouble();
                    Policy policy = new Policy(0, policyNumber, type, coverageAmount, premiumAmount);
                    policyDAO.addPolicy(policy);
                    System.out.println("Policy added successfully.");
                    break;
                case 2:
                    System.out.println("Enter Policy ID:");
                    int policyId = scanner.nextInt();
                    try {
                        Policy retrievedPolicy = policyDAO.getPolicyById(policyId);
                        System.out.println("Policy Details: " + retrievedPolicy.getPolicyNumber() + ", " + retrievedPolicy.getType());
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 3:
                    System.out.println("Enter Policy ID to update:");
                    int updatePolicyId = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                    try {
                        Policy updatePolicy = policyDAO.getPolicyById(updatePolicyId);
                        System.out.println("Enter New Policy Number:");
                        updatePolicy.setPolicyNumber(scanner.nextLine());
                        System.out.println("Enter New Type:");
                        updatePolicy.setType(scanner.nextLine());
                        System.out.println("Enter New Coverage Amount:");
                        updatePolicy.setCoverageAmount(scanner.nextDouble());
                        System.out.println("Enter New Premium Amount:");
                        updatePolicy.setPremiumAmount(scanner.nextDouble());
                        policyDAO.updatePolicy(updatePolicy);
                        System.out.println("Policy updated successfully.");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 4:
                    System.out.println("Enter Policy ID to delete:");
                    int deletePolicyId = scanner.nextInt();
                    try {
                        policyDAO.deletePolicy(deletePolicyId);
                        System.out.println("Policy deleted successfully.");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 5:
                    return;  // Return to main menu
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    private static void manageCustomers(Scanner scanner, CustomerDAOImpl customerDAO) {
        while (true) {
            System.out.println("\nCustomer Management");
            System.out.println("1. Add Customer");
            System.out.println("2. View Customer");
            System.out.println("3. Update Customer");
            System.out.println("4. Delete Customer");
            System.out.println("5. Back to Main Menu");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    System.out.println("Enter Customer Name:");
                    String name = scanner.nextLine();
                    System.out.println("Enter Email:");
                    String email = scanner.nextLine();
                    System.out.println("Enter Phone Number:");
                    String phoneNumber = scanner.nextLine();
                    System.out.println("Enter Address:");
                    String address = scanner.nextLine();
                    Customer customer = new Customer(0, name, email, phoneNumber, address);
                    customerDAO.addCustomer(customer);
                    System.out.println("Customer added successfully.");
                    break;
                case 2:
                    System.out.println("Enter Customer ID:");
                    int customerId = scanner.nextInt();
                    try {
                        Customer retrievedCustomer = customerDAO.getCustomerById(customerId);
                        System.out.println("Customer Details: \nName:" + retrievedCustomer.getName() + "\nEmail: " + retrievedCustomer.getEmail());
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 3:
                    System.out.println("Enter Customer ID to update:");
                    int updateCustomerId = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                    try {
                        Customer updateCustomer = customerDAO.getCustomerById(updateCustomerId);
                        System.out.println("Enter New Name:");
                        updateCustomer.setName(scanner.nextLine());
                        System.out.println("Enter New Email:");
                        updateCustomer.setEmail(scanner.nextLine());
                        System.out.println("Enter New Phone Number:");
                        updateCustomer.setPhoneNumber(scanner.nextLine());
                        System.out.println("Enter New Address:");
                        updateCustomer.setAddress(scanner.nextLine());
                        customerDAO.updateCustomer(updateCustomer);
                        System.out.println("Customer updated successfully.");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 4:
                    System.out.println("Enter Customer ID to delete:");
                    int deleteCustomerId = scanner.nextInt();
                    try {
                        customerDAO.deleteCustomer(deleteCustomerId);
                        System.out.println("Customer deleted successfully.");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 5:
                    return;  // Return to main menu
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }

    private static void manageClaims(Scanner scanner, ClaimDAOImpl claimDAO) {
        while (true) {
            System.out.println("\nClaim Management");
            System.out.println("1. Add Claim");
            System.out.println("2. View Claim");
            System.out.println("3. Update Claim");
            System.out.println("4. Delete Claim");
            System.out.println("5. Back to Main Menu");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    System.out.println("Enter Policy ID for Claim:");
                    int claimPolicyId = scanner.nextInt();
                    System.out.println("Enter Customer ID for Claim:");
                    int claimCustomerId = scanner.nextInt();
                    System.out.println("Enter Claim Date (yyyy-mm-dd):");
                    String claimDateStr = scanner.next();
                    Date claimDate = java.sql.Date.valueOf(claimDateStr);
                    System.out.println("Enter Claim Status:");
                    String claimStatus = scanner.next();
                    Claim claim = new Claim(0, claimPolicyId, claimCustomerId, claimDate, claimStatus);
                    claimDAO.addClaim(claim);
                    System.out.println("Claim added successfully.");
                    break;
                case 2:
                    System.out.println("Enter Claim ID:");
                    int claimId = scanner.nextInt();
                    try {
                        Claim retrievedClaim = claimDAO.getClaimById(claimId);
                        System.out.println("Claim Details: " + retrievedClaim.getClaimDate() + ", " + retrievedClaim.getStatus());
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 3:
                    System.out.println("Enter Claim ID to update:");
                    int updateClaimId = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                    try {
                        Claim updateClaim = claimDAO.getClaimById(updateClaimId);
                        System.out.println("Enter New Status:");
                        updateClaim.setStatus(scanner.nextLine());
                        claimDAO.updateClaim(updateClaim);
                        System.out.println("Claim updated successfully.");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 4:
                    System.out.println("Enter Claim ID to delete:");
                    int deleteClaimId = scanner.nextInt();
                    try {
                        claimDAO.deleteClaim(deleteClaimId);
                        System.out.println("Claim deleted successfully.");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 5:
                    return;  // Return to main menu
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
}
