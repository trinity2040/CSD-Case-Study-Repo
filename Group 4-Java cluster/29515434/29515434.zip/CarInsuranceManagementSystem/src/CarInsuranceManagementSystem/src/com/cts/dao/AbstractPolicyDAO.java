package com.cts.dao;

import com.cts.model.Policy;
import com.cts.exception.PolicyNotFoundException;
import java.util.List;

public abstract class AbstractPolicyDAO {
    public abstract void addPolicy(Policy policy);
    public abstract Policy getPolicyById(int policyId) throws PolicyNotFoundException;
    public abstract List<Policy> getAllPolicies();
    public abstract void updatePolicy(Policy policy) throws PolicyNotFoundException;
    public abstract void deletePolicy(int policyId) throws PolicyNotFoundException;
}
