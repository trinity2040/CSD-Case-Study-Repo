package com.cts.dao;

import com.cts.model.Claim;
import com.cts.exception.ClaimNotFoundException;
import java.util.List;

public abstract class AbstractClaimDAO {
    public abstract void addClaim(Claim claim);
    public abstract Claim getClaimById(int claimId) throws ClaimNotFoundException;
    public abstract List<Claim> getAllClaims();
    public abstract void updateClaim(Claim claim) throws ClaimNotFoundException;
    public abstract void deleteClaim(int claimId) throws ClaimNotFoundException;
}
