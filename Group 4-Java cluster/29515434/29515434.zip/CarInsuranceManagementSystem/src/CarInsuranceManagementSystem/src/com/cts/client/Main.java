package com.cts.client;

import com.cts.dao.daoimpl.CustomerDAOImpl;
import com.cts.dao.daoimpl.PolicyDAOImpl;
import com.cts.dao.daoimpl.ClaimDAOImpl;
import com.cts.model.Customer;
import com.cts.model.Policy;
import com.mysql.cj.protocol.x.Ok;
import com.cts.model.Claim;

import java.util.Scanner;
import java.util.Date;

public class Main {
    public static void main(String[] args) {
        CustomerDAOImpl customerDAO = new CustomerDAOImpl();
        PolicyDAOImpl policyDAO = new PolicyDAOImpl();
        ClaimDAOImpl claimDAO = new ClaimDAOImpl();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== Car Insurance Management System ===");
            System.out.println("1. Policy Management");
            System.out.println("2. Customer Management");
            System.out.println("3. Claim Management");
            System.out.println("4. Exit");
            System.out.print("Enter your Choice: ");

            int mainChoice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (mainChoice) {
                case 1:
                    managePolicies(scanner, policyDAO);
                    break;
                case 2:
                    manageCustomers(scanner, customerDAO);
                    break;
                case 3:
                    manageClaims(scanner, claimDAO);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
    // 1. Policy Management
    private static void managePolicies(Scanner scanner, PolicyDAOImpl policyDAO) {
        while (true) {
            System.out.println("\n---- Policy Management ---");
            System.out.println("1. Add a new Policy");
            System.out.println("2. View Policy details");
            System.out.println("3. Update Policy information");
            System.out.println("4. Delete a Policy");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
            // Add a new Policy
                case 1:
                	System.out.print("Enter Policy ID: ");
                    int policyId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter Policy Number: ");
                    String policyNumber = scanner.nextLine();
                    System.out.print("Enter Policy Type: ");
                    String type = scanner.nextLine();
                    System.out.print("Enter Coverage Amount: ");
                    double coverageAmount = scanner.nextDouble();
                    System.out.print("Enter Premium Amount: ");
                    double premiumAmount = scanner.nextDouble();
                    Policy policy = new Policy(policyId, policyNumber, type, coverageAmount, premiumAmount);
                    policyDAO.addPolicy(policy);
                    System.out.println("Policy added successfully!");
                    break;
             // View Policy Details
                case 2:
                    System.out.print("Enter Policy ID: ");
                    policyId = scanner.nextInt();
                    try {
                        Policy retrievedPolicy = policyDAO.getPolicyById(policyId);
                        System.out.println("Policy ID: " + retrievedPolicy.getPolicyId());
                        System.out.println("Policy Number: " + retrievedPolicy.getPolicyNumber());
                        System.out.println("Type: " + retrievedPolicy.getType());
                        System.out.println("Coverage Amount: " + retrievedPolicy.getCoverageAmount());
                        System.out.println("Premium Amount: " + retrievedPolicy.getPremiumAmount());
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
              // Update Policy Details
                case 3:
                    System.out.print("Enter Policy ID to update: ");
                    int updatePolicyId = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                    try {
                        Policy updatePolicy = policyDAO.getPolicyById(updatePolicyId);
                        System.out.print("Enter New Policy ID: ");
                        updatePolicy.setPolicyId(scanner.nextInt());
                        System.out.print("Enter New Policy Number: ");
                        updatePolicy.setPolicyNumber(scanner.next());
                        System.out.print("Enter New Type: ");
                        updatePolicy.setType(scanner.nextLine());
                        scanner.nextLine();
                        System.out.print("Enter New Coverage Amount: ");
                        updatePolicy.setCoverageAmount(scanner.nextDouble());
                        System.out.print("Enter New Premium Amount: ");
                        updatePolicy.setPremiumAmount(scanner.nextDouble());
                        policyDAO.updatePolicy(updatePolicy);
                        System.out.print("Policy updated successfully!");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                // Delete Policy
                case 4:
                    System.out.println("Enter Policy ID to delete: ");
                    int deletePolicyId = scanner.nextInt();
                    try {
                        policyDAO.deletePolicy(deletePolicyId);
                        System.out.println("Policy deleted successfully!");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 5:
                    return;  // Return to main menu
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
    // 2. Customer Management
    private static void manageCustomers(Scanner scanner, CustomerDAOImpl customerDAO) {
        while (true) {
            System.out.println("\n--- Customer Management ---");
            System.out.println("1. Register a new customer");
            System.out.println("2. View customer details");
            System.out.println("3. Update customer information");
            System.out.println("4. Delete a customer");
            System.out.println("5. Go back to the main menu");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
            	// Register a new customer
                case 1:
                	System.out.print("Enter customer ID: ");
                    int customerId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter customer name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter customer email: ");
                    String email = scanner.nextLine();
                    System.out.print("Enter customer phone number: ");
                    String phoneNumber = scanner.nextLine();
                    System.out.print("Enter customer Address: ");
                    String address = scanner.nextLine();
                    Customer customer = new Customer(customerId, name, email, phoneNumber, address);
                    customerDAO.addCustomer(customer);
                    System.out.println("Customer added successfully!");
                    break;
               // View customer details
                case 2:
                    System.out.print("Enter customer ID to view: ");
                    customerId = scanner.nextInt();
                    try {
                        Customer retrievedCustomer = customerDAO.getCustomerById(customerId);
                        
                        System.out.println("\n--- Customer Details ---");
                        System.out.println("Customer ID: " + retrievedCustomer.getCustomerId());
                        System.out.println("Name: " + retrievedCustomer.getName());
                        System.out.println("Email: " + retrievedCustomer.getEmail());
                        System.out.println("Phone Number: " + retrievedCustomer.getPhoneNumber());
                        System.out.println("Address: " + retrievedCustomer.getAddress());
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                // Update customer Information
                case 3:
                    System.out.print("Enter customer ID to update: ");
                    int updateCustomerId = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                    try {
                        Customer updateCustomer = customerDAO.getCustomerById(updateCustomerId);
                        
                        System.out.print("Enter new customer name: ");
                        updateCustomer.setName(scanner.nextLine());
                        System.out.print("Enter new customer email: ");
                        updateCustomer.setEmail(scanner.nextLine());
                        System.out.print("Enter new customer phone number: ");
                        updateCustomer.setPhoneNumber(scanner.nextLine());
                        System.out.print("Enter new customer address: ");
                        updateCustomer.setAddress(scanner.nextLine());
                        customerDAO.updateCustomer(updateCustomer);
                        System.out.print("Customer updated successfully!");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                // Delete Customer Information
                case 4:
                    System.out.println("Enter Customer ID to delete: ");
                    int deleteCustomerId = scanner.nextInt();
                    try {
                        customerDAO.deleteCustomer(deleteCustomerId);
                        System.out.println("Customer deleted successfully!");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 5:
                    return;  // Return to main menu
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
    // 3. Claim Management
    private static void manageClaims(Scanner scanner, ClaimDAOImpl claimDAO) {
        while (true) {
            System.out.println("\n--- Claim Management ---");
            System.out.println("1. Submit a new claim");
            System.out.println("2. View claim details");
            System.out.println("3. Update claim information");
            System.out.println("4. Delete a claim");
            System.out.println("5. Go back to the main menu");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
            // Submit a new claim
                case 1:
                	System.out.print("Enter your claim ID: ");
                	int claimId = scanner.nextInt();
                    System.out.print("Enter policy ID: ");
                    int claimPolicyId = scanner.nextInt();
                    System.out.print("Enter customer ID: ");
                    int claimCustomerId = scanner.nextInt();
                    System.out.print("Enter claim date (yyyy-mm-dd): ");
                    
                    String claimDate = scanner.next();
                    System.out.print("Enter claim status (submitted/processed): ");
                    String claimStatus = scanner.next();
                    Claim claim = new Claim(claimId, claimPolicyId, claimCustomerId, claimDate, claimStatus);
                    claimDAO.addClaim(claim);
                    System.out.println("Claim submitted successfully!");
                    break;
                // View claim details
                case 2:
                    System.out.print("Enter claim ID to view: ");
                    claimId = scanner.nextInt();
                    try {
                        Claim retrievedClaim = claimDAO.getClaimById(claimId);
 
                        System.out.println("\n--- Claim Details ---\n");
                        System.out.println("Claim ID: " + retrievedClaim.getClaimId());
                        System.out.println("Policy ID: " + retrievedClaim.getPolicyId());
                        System.out.println("Customer ID: " + retrievedClaim.getCustomerId());
                        System.out.println("Claim Date: " + retrievedClaim.getClaimDate());
                        System.out.println("Status: " + retrievedClaim.getStatus());
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                 // Update claim information
                    
                    
                case 3:
                    System.out.print("Enter Claim ID to update: ");
                    int updateClaimId = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                    try {
                        Claim updateClaim = claimDAO.getClaimById(updateClaimId);
                        System.out.print("Enter policy ID: ");
                        updateClaim.setStatus(scanner.nextLine());
                        
                        System.out.print("Enter customer ID: ");
                        updateClaim.setCustomerId(scanner.nextInt());
                        System.out.print("Enter claim date (YYYY-MM-DD): ");
                        updateClaim.setClaimDate(scanner.next());
                        System.out.print("Enter new claim status (submitted/processed): ");
                        
                        updateClaim.setStatus(scanner.next());
                        claimDAO.updateClaim(updateClaim);
                        System.out.println("Claim updated successfully.");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                // Delete a claim
                case 4:
                    System.out.print("Enter Claim ID to delete: ");
                    int deleteClaimId = scanner.nextInt();
                    try {
                        claimDAO.deleteClaim(deleteClaimId);
                        System.out.println("Claim deleted successfully.");
                    } catch (Exception e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 5:
                    return;  // Return to main menu
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }
    }
}
