# Car Insurance Management System

## Overview
This is a simple Java-based console application that simulates a Car Insurance Management System. The application allows users to manage policies, customers, and claims using a menu-driven interface.

## Requirements
- Java 8 or later
- MySQL Server
- JDBC Driver for MySQL

## Database Setup
1. Create the database and tables:
    ```sql
    CREATE DATABASE car_insurance_db;

    USE car_insurance_db;

    CREATE TABLE Policy (
        policy_id INT AUTO_INCREMENT PRIMARY KEY,
        policy_number VARCHAR(20) NOT NULL,
        type VARCHAR(50) NOT NULL,
        coverage_amount DECIMAL(10,2) NOT NULL,
        premium_amount DECIMAL(10,2) NOT NULL
    );

    CREATE TABLE Customer (
        customer_id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        phone_number VARCHAR(15) NOT NULL,
        address VARCHAR(255) NOT NULL
    );

    CREATE TABLE Claim (
        claim_id INT AUTO_INCREMENT PRIMARY KEY,
        policy_id INT,
        customer_id INT,
        claim_date DATE NOT NULL,
        status VARCHAR(20) NOT NULL,
        FOREIGN KEY (policy_id) REFERENCES Policy(policy_id),
        FOREIGN KEY (customer_id) REFERENCES Customer(customer_id)
    );
    ```

## Running the Application
1. Clone the repository to your local machine.
2. Import the project into your favorite IDE (e.g., Eclipse, IntelliJ IDEA).
3. Update the database credentials in `DatabaseConnection.java`.
4. Run the `CarInsuranceManagementSystem` main class.

## Features
- Policy Management: Add, view, update, and delete insurance policies.
- Customer Management: Register, view, update, and delete customers.
- Claim Management: Submit, view, update, and delete insurance claims.
