import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBconnection {

    private static Connection connection;

    // Method to get the database connection
    public static Connection getConnection() {
        try {
            // Loading the MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establishing connection
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/car_insurance_db", "root", "Mahi_1324");
        } catch (ClassNotFoundException e) {
            System.out.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Connection failed. Check output console.");
            e.printStackTrace();
        }
        return connection;
    }
}



