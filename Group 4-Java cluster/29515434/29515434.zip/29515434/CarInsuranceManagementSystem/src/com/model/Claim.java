package com.model;

import java.sql.Date;

public class Claim {
    private int claimId;
    private int policyId;
    private int customerId;
    private Date claimDate;
    private String status;
	public Claim(int claimId, int policyId, int customerId, Date claimDate, String status) {
		super();
		this.claimId = claimId;
		this.policyId = policyId;
		this.customerId = customerId;
		this.claimDate = claimDate;
		this.status = status;
	}
	public int getClaimId() {
		return claimId;
	}
	public void setClaimId(int claimId) {
		this.claimId = claimId;
	}
	public int getPolicyId() {
		return policyId;
	}
	public void setPolicyId(int policyId) {
		this.policyId = policyId;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public Date getClaimDate() {
		return claimDate;
	}
	public void setClaimDate(Date claimDate) {
		this.claimDate = claimDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "Claim [claimId=" + claimId + ", policyId=" + policyId + ", customerId=" + customerId + ", claimDate="
				+ claimDate + ", status=" + status + "]";
	}

    
}
