package com.cts.dao;

import com.cts.model.Customer;
import com.cts.exception.CustomerNotFoundException;
import java.util.List;

public abstract class AbstractCustomerDAO {
    public abstract void addCustomer(Customer customer);
    public abstract Customer getCustomerById(int customerId) throws CustomerNotFoundException;
    public abstract List<Customer> getAllCustomers();
    public abstract void updateCustomer(Customer customer) throws CustomerNotFoundException;
    public abstract void deleteCustomer(int customerId) throws CustomerNotFoundException;
}
