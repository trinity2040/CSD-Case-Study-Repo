package com.cts.dao.daoimpl;

import com.cts.dao.AbstractClaimDAO;
import com.cts.exception.ClaimNotFoundException;
import com.cts.model.Claim;
import com.cts.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class ClaimDAOImpl extends AbstractClaimDAO {

    @Override
    public void addClaim(Claim claim) {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "INSERT INTO Claim (claim_id, policy_id, customer_id, claim_date, status) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, claim.getClaimId());
            ps.setInt(2, claim.getPolicyId());
            ps.setInt(3, claim.getCustomerId());
            ps.setString(4, claim.getClaimDate());
            ps.setString(5, claim.getStatus());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Claim getClaimById(int claimId) throws ClaimNotFoundException {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Claim WHERE claim_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, claimId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return new Claim(
                        rs.getInt("claim_id"),
                        rs.getInt("policy_id"),
                        rs.getInt("customer_id"),
                        rs.getString("claim_date"),
                        rs.getString("status")
                );
            } else {
                throw new ClaimNotFoundException("Claim with ID " + claimId + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ClaimNotFoundException("Database error occurred.");
        }
    }

    @Override
    public List<Claim> getAllClaims() {
        List<Claim> claims = new ArrayList<>();
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "SELECT * FROM Claim";
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                claims.add(new Claim(
                        rs.getInt("claim_id"),
                        rs.getInt("policy_id"),
                        rs.getInt("customer_id"),
                        rs.getString("claim_date"),
                        rs.getString("status")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return claims;
    }

    @Override
    public void updateClaim(Claim claim) throws ClaimNotFoundException {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "UPDATE Claim SET policy_id = ?, customer_id = ?, claim_date = ?, status = ? WHERE claim_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, claim.getPolicyId());
            ps.setInt(2, claim.getCustomerId());
            ps.setString(3, claim.getClaimDate());
            ps.setString(4, claim.getStatus());
            ps.setInt(5, claim.getClaimId());

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected == 0) {
                throw new ClaimNotFoundException("Claim with ID " + claim.getClaimId() + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ClaimNotFoundException("Database error occurred.");
        }
    }

    @Override
    public void deleteClaim(int claimId) throws ClaimNotFoundException {
        try (Connection conn = DatabaseConnection.getConnection()) {
            String sql = "DELETE FROM Claim WHERE claim_id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, claimId);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected == 0) {
                throw new ClaimNotFoundException("Claim with ID " + claimId + " not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new ClaimNotFoundException("Database error occurred.");
        }
    }
}
