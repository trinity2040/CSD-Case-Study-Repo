package com;

import com.dao.ClaimDAO;
import com.dao.CustomerDAO;
import com.dao.PolicyDAO;
import com.model.Claim;
import com.model.Customer;
import com.model.Policy;

import java.sql.Connection;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import com.util.DatabaseConnection;  // Assuming this is where your connection utility is located

public class CarInsuranceManagementSystem {
    public static void main(String[] args) {
        try (Connection connection = DatabaseConnection.getConnection();
             Scanner scanner = new Scanner(System.in)) {

            PolicyDAO policyDAO = new PolicyDAO(connection);
            CustomerDAO customerDAO = new CustomerDAO(connection);
            ClaimDAO claimDAO = new ClaimDAO(connection);

            while (true) {
                System.out.println("Car Insurance Management System");
                System.out.println("1. Manage Policies");
                System.out.println("2. Manage Customers");
                System.out.println("3. Manage Claims");
                System.out.println("4. Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();
                scanner.nextLine();  // Consume newline

                switch (choice) {
                    case 1:
                        handlePolicyManagement(scanner, policyDAO);
                        break;
                    case 2:
                        handleCustomerManagement(scanner, customerDAO);
                        break;
                    case 3:
                        handleClaimManagement(scanner, claimDAO, policyDAO, customerDAO);
                        break;
                    case 4:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void handlePolicyManagement(Scanner scanner, PolicyDAO policyDAO) throws SQLException {
        System.out.println("Policy Management");
        System.out.println("1. Add Policy");
        System.out.println("2. View Policy");
        System.out.println("3. Update Policy");
        System.out.println("4. Delete Policy");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter policy number: ");
                String policyNumber = scanner.nextLine();
                System.out.print("Enter type: ");
                String type = scanner.nextLine();
                System.out.print("Enter coverage amount: ");
                double coverageAmount = scanner.nextDouble();
                System.out.print("Enter premium amount: ");
                double premiumAmount = scanner.nextDouble();
                scanner.nextLine();  // Consume newline
                Policy policy = new Policy(0, policyNumber, type, coverageAmount, premiumAmount);
                policyDAO.addPolicy(policy);
                System.out.println("Policy added successfully.");
                break;
            case 2:
                System.out.print("Enter policy ID: ");
                int policyId = scanner.nextInt();
                scanner.nextLine();
                Policy retrievedPolicy = policyDAO.getPolicy(policyId);
                if (retrievedPolicy != null) {
                    System.out.println(retrievedPolicy);
                } else {
                    System.out.println("Policy not found.");
                }
                break;
            case 3:
                System.out.print("Enter policy ID to update: ");
                policyId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                Policy updatePolicy = policyDAO.getPolicy(policyId);
                if (updatePolicy != null) {
                    System.out.print("Enter new policy number: ");
                    updatePolicy.setPolicyNumber(scanner.nextLine());
                    System.out.print("Enter new type: ");
                    updatePolicy.setType(scanner.nextLine());
                    System.out.print("Enter new coverage amount: ");
                    updatePolicy.setCoverageAmount(scanner.nextDouble());
                    System.out.print("Enter new premium amount: ");
                    updatePolicy.setPremiumAmount(scanner.nextDouble());
                    scanner.nextLine();  // Consume newline
                    policyDAO.updatePolicy(updatePolicy);
                    System.out.println("Policy updated successfully.");
                } else {
                    System.out.println("Policy not found.");
                }
                break;
            case 4:
                System.out.print("Enter policy ID to delete: ");
                policyId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                policyDAO.deletePolicy(policyId);
                System.out.println("Policy deleted successfully.");
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void handleCustomerManagement(Scanner scanner, CustomerDAO customerDAO) throws SQLException {
        System.out.println("Customer Management");
        System.out.println("1. Register Customer");
        System.out.println("2. View Customer");
        System.out.println("3. Update Customer");
        System.out.println("4. Delete Customer");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter name: ");
                String name = scanner.nextLine();
                System.out.print("Enter email: ");
                String email = scanner.nextLine();
                System.out.print("Enter phone number: ");
                String phoneNumber = scanner.nextLine();
                System.out.print("Enter address: ");
                String address = scanner.nextLine();
                Customer customer = new Customer(0, name, email, phoneNumber, address);
                customerDAO.addCustomer(customer);
                System.out.println("Customer registered successfully.");
                break;
            case 2:
                System.out.print("Enter customer ID: ");
                int customerId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                Customer retrievedCustomer = customerDAO.getCustomer(customerId);
                if (retrievedCustomer != null) {
                    System.out.println(retrievedCustomer);
                } else {
                    System.out.println("Customer not found.");
                }
                break;
            case 3:
                System.out.print("Enter customer ID to update: ");
                customerId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                Customer updateCustomer = customerDAO.getCustomer(customerId);
                if (updateCustomer != null) {
                    System.out.print("Enter new name: ");
                    updateCustomer.setName(scanner.nextLine());
                    System.out.print("Enter new email: ");
                    updateCustomer.setEmail(scanner.nextLine());
                    System.out.print("Enter new phone number: ");
                    updateCustomer.setPhoneNumber(scanner.nextLine());
                    System.out.print("Enter new address: ");
                    updateCustomer.setAddress(scanner.nextLine());
                    customerDAO.updateCustomer(updateCustomer);
                    System.out.println("Customer updated successfully.");
                } else {
                    System.out.println("Customer not found.");
                }
                break;
            case 4:
                System.out.print("Enter customer ID to delete: ");
                customerId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                customerDAO.deleteCustomer(customerId);
                System.out.println("Customer deleted successfully.");
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }

    private static void handleClaimManagement(Scanner scanner, ClaimDAO claimDAO, PolicyDAO policyDAO, CustomerDAO customerDAO) throws SQLException {
        System.out.println("Claim Management");
        System.out.println("1. Submit Claim");
        System.out.println("2. View Claim");
        System.out.println("3. Update Claim");
        System.out.println("4. Delete Claim");
        System.out.print("Choose an option: ");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter policy ID: ");
                int policyId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                System.out.print("Enter customer ID: ");
                int customerId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                System.out.print("Enter claim date (YYYY-MM-DD): ");
                String dateString = scanner.nextLine();
                Date claimDate;
                try {
                    claimDate = new SimpleDateFormat("yyyy-MM-dd").parse(dateString);
                } catch (ParseException e) {
                    System.out.println("Invalid date format.");
                    return;
                }
                System.out.print("Enter claim status (submitted/processed): ");
                String status = scanner.nextLine();
                Claim claim = new Claim(0, policyId, customerId, new java.sql.Date(claimDate.getTime()), status);
                claimDAO.addClaim(claim);
                System.out.println("Claim submitted successfully.");
                break;
            case 2:
                System.out.print("Enter claim ID: ");
                int claimId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                Claim retrievedClaim = claimDAO.getClaim(claimId);
                if (retrievedClaim != null) {
                    System.out.println(retrievedClaim);
                } else {
                    System.out.println("Claim not found.");
                }
                break;
            case 3:
                System.out.print("Enter claim ID to update: ");
                claimId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                Claim updateClaim = claimDAO.getClaim(claimId);
                if (updateClaim != null) {
                    System.out.print("Enter new policy ID: ");
                    updateClaim.setPolicyId(scanner.nextInt());
                    scanner.nextLine();  // Consume newline
                    System.out.print("Enter new customer ID: ");
                    updateClaim.setCustomerId(scanner.nextInt());
                    scanner.nextLine();  // Consume newline
                    System.out.print("Enter new claim date (YYYY-MM-DD): ");
                    dateString = scanner.nextLine();
                    try {
                        claimDate = new SimpleDateFormat("yyyy-MM-dd").parse(dateString);
                    } catch (ParseException e) {
                        System.out.println("Invalid date format.");
                        return;
                    }
                    updateClaim.setClaimDate(new java.sql.Date(claimDate.getTime()));
                    System.out.print("Enter new claim status (submitted/processed): ");
                    updateClaim.setStatus(scanner.nextLine());
                    claimDAO.updateClaim(updateClaim);
                    System.out.println("Claim updated successfully.");
                } else {
                    System.out.println("Claim not found.");
                }
                break;
            case 4:
                System.out.print("Enter claim ID to delete: ");
                claimId = scanner.nextInt();
                scanner.nextLine();  // Consume newline
                claimDAO.deleteClaim(claimId);
                System.out.println("Claim deleted successfully.");
                break;
            default:
                System.out.println("Invalid option. Please try again.");
        }
    }
}

               
