package com.dao;

import com.model.Policy;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PolicyDAO {
    private Connection connection;

    public PolicyDAO(Connection connection) {
        this.connection = connection;
    }

    public void addPolicy(Policy policy) throws SQLException {
        String query = "INSERT INTO Policy (policy_number, type, coverage_amount, premium_amount) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, policy.getPolicyNumber());
            ps.setString(2, policy.getType());
            ps.setDouble(3, policy.getCoverageAmount());
            ps.setDouble(4, policy.getPremiumAmount());
            ps.executeUpdate();
        }
    }

    public Policy getPolicy(int policyId) throws SQLException {
        String query = "SELECT * FROM Policy WHERE policy_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, policyId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Policy(
                    rs.getInt("policy_id"),
                    rs.getString("policy_number"),
                    rs.getString("type"),
                    rs.getDouble("coverage_amount"),
                    rs.getDouble("premium_amount")
                );
            }
        }
        return null;
    }

    public List<Policy> getAllPolicies() throws SQLException {
        List<Policy> policies = new ArrayList<>();
        String query = "SELECT * FROM Policy";
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                policies.add(new Policy(
                    rs.getInt("policy_id"),
                    rs.getString("policy_number"),
                    rs.getString("type"),
                    rs.getDouble("coverage_amount"),
                    rs.getDouble("premium_amount")
                ));
            }
        }
        return policies;
    }

    public void updatePolicy(Policy policy) throws SQLException {
        String query = "UPDATE Policy SET policy_number = ?, type = ?, coverage_amount = ?, premium_amount = ? WHERE policy_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, policy.getPolicyNumber());
            ps.setString(2, policy.getType());
            ps.setDouble(3, policy.getCoverageAmount());
            ps.setDouble(4, policy.getPremiumAmount());
            ps.setInt(5, policy.getPolicyId());
            ps.executeUpdate();
        }
    }

    public void deletePolicy(int policyId) throws SQLException {
        String query = "DELETE FROM Policy WHERE policy_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, policyId);
            ps.executeUpdate();
        }
    }
}
