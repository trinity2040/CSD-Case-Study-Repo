package com.dao;

import com.model.Claim;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClaimDAO {
    private Connection connection;

    public ClaimDAO(Connection connection) {
        this.connection = connection;
    }

    public void addClaim(Claim claim) throws SQLException {
        String query = "INSERT INTO Claim (policy_id, customer_id, claim_date, status) VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, claim.getPolicyId());
            ps.setInt(2, claim.getCustomerId());
            ps.setDate(3, claim.getClaimDate());
            ps.setString(4, claim.getStatus());
            ps.executeUpdate();
        }
    }

    public Claim getClaim(int claimId) throws SQLException {
        String query = "SELECT * FROM Claim WHERE claim_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, claimId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Claim(
                    rs.getInt("claim_id"),
                    rs.getInt("policy_id"),
                    rs.getInt("customer_id"),
                    rs.getDate("claim_date"),
                    rs.getString("status")
                );
            }
        }
        return null;
    }

    public List<Claim> getAllClaims() throws SQLException {
        List<Claim> claims = new ArrayList<>();
        String query = "SELECT * FROM Claim";
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                claims.add(new Claim(
                    rs.getInt("claim_id"),
                    rs.getInt("policy_id"),
                    rs.getInt("customer_id"),
                    rs.getDate("claim_date"),
                    rs.getString("status")
                ));
            }
        }
        return claims;
    }

    public void updateClaim(Claim claim) throws SQLException {
        String query = "UPDATE Claim SET policy_id = ?, customer_id = ?, claim_date = ?, status = ? WHERE claim_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, claim.getPolicyId());
            ps.setInt(2, claim.getCustomerId());
            ps.setDate(3, claim.getClaimDate());
            ps.setString(4, claim.getStatus());
            ps.setInt(5, claim.getClaimId());
            ps.executeUpdate();
        }
    }

    public void deleteClaim(int claimId) throws SQLException {
        String query = "DELETE FROM Claim WHERE claim_id = ?";
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setInt(1, claimId);
            ps.executeUpdate();
        }
    }
}
