import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.util.Scanner;

public class ClaimManager {

    public static void manageClaims() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n--- Claim Management ---");
            
            System.out.println("\n1. Submit a new claim");
            System.out.println("2. View claim details");
            System.out.println("3. Update claim information");
            System.out.println("4. Delete a claim");
            System.out.println("5. Go back to the main menu");
            System.out.print("\nEnter your choice: ");
            
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    submitClaim();
                    break;
                case 2:
                    viewClaim();
                    break;
                case 3:
                    updateClaim();
                    break;
                case 4:
                    deleteClaim();
                    break;
                case 5:
                    return; // Exit the claim management menu
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    // Submit a new claim
    public static void submitClaim() {
        try (Connection conn = DBconnection.getConnection()) {
            String sql = "INSERT INTO Claim (claim_id, policy_id, customer_id, claim_date, status) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter your claim ID: ");
            stmt.setInt(1, scanner.nextInt());

            System.out.print("Enter policy ID: ");
            stmt.setInt(2, scanner.nextInt());

            System.out.print("Enter customer ID: ");
            stmt.setInt(3, scanner.nextInt());

            System.out.print("Enter claim date (YYYY-MM-DD): ");
            stmt.setDate(4, Date.valueOf(scanner.next()));

            System.out.print("Enter claim status (submitted/processed): ");
            stmt.setString(5, scanner.next());

            stmt.executeUpdate();
            System.out.println("Claim submitted successfully!");
        } catch (SQLException e) {
            System.out.println("Error submitting claim: " + e.getMessage());
        }
    }

    // View claim details
    public static void viewClaim() {
        try (Connection conn = DBconnection.getConnection()) {
            String sql = "SELECT * FROM Claim WHERE claim_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter claim ID to view: ");
            int claimId = scanner.nextInt();
            stmt.setInt(1, claimId);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("\n--- Claim Details ---");
                System.out.println("Claim ID: " + rs.getInt("claim_id"));
                System.out.println("Policy ID: " + rs.getInt("policy_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Claim Date: " + rs.getDate("claim_date"));
                System.out.println("Status: " + rs.getString("status"));
            } else {
                System.out.println("Claim not found with ID: " + claimId);
            }
        } catch (SQLException e) {
            System.out.println("Error viewing claim: " + e.getMessage());
        }
    }

    // Update claim information
    public static void updateClaim() {
        try (Connection conn = DBconnection.getConnection()) {
            String sql = "UPDATE Claim SET policy_id = ?, customer_id = ?, claim_date = ?, status = ? WHERE claim_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter claim ID to update: ");
            int claimId = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            System.out.print("Enter new policy ID: ");
            stmt.setInt(1, scanner.nextInt());

            System.out.print("Enter new customer ID: ");
            stmt.setInt(2, scanner.nextInt());

            System.out.print("Enter new claim date (YYYY-MM-DD): ");
            stmt.setDate(3, Date.valueOf(scanner.next()));

            System.out.print("Enter new claim status (submitted/processed): ");
            stmt.setString(4, scanner.next());

            stmt.setInt(5, claimId);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Claim updated successfully!");
            } else {
                System.out.println("Claim not found with ID: " + claimId);
            }
        } catch (SQLException e) {
            System.out.println("Error updating claim: " + e.getMessage());
        }
    }

    // Delete a claim
    public static void deleteClaim() {
        try (Connection conn = DBconnection.getConnection()) {
            String sql = "DELETE FROM Claim WHERE claim_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter claim ID to delete: ");
            int claimId = scanner.nextInt();
            stmt.setInt(1, claimId);

            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Claim deleted successfully!");
            } else {
                System.out.println("Claim not found with ID: " + claimId);
            }
        } catch (SQLException e) {
            System.out.println("Error deleting claim: " + e.getMessage());
        }
        
    }
}

