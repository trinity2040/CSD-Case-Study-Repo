import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class CustomerManager {

    public static void manageCustomers() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("\n--- Customer Management ---");
            System.out.println("\n1. Register a new customer");
            System.out.println("2. View customer details");
            System.out.println("3. Update customer information");
            System.out.println("4. Delete a customer");
            System.out.println("5. Go back to the main menu");
            System.out.print("\nEnter your choice: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    registerCustomer();
                    break;
                case 2:
                    viewCustomer();
                    break;
                case 3:
                    updateCustomer();
                    break;
                case 4:
                    deleteCustomer();
                    break;
                case 5:
                    return; // Exit the customer management menu
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }

    // Register a new customer
    public static void registerCustomer() {
        try (Connection conn = DBconnection.getConnection()) {
            String sql = "INSERT INTO Customer (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter customer name: ");
            stmt.setString(1, scanner.nextLine());

            System.out.print("Enter customer email: ");
            stmt.setString(2, scanner.nextLine());

            System.out.print("Enter customer phone number: ");
            stmt.setString(3, scanner.nextLine());

            System.out.print("Enter customer address: ");
            stmt.setString(4, scanner.nextLine());

            stmt.executeUpdate();
            System.out.println("Customer registered successfully!");
        } catch (SQLException e) {
            System.out.println("Error registering customer: " + e.getMessage());
        }
    }

    // View customer details
    public static void viewCustomer() {
        try (Connection conn = DBconnection.getConnection()) {
            String sql = "SELECT * FROM Customer WHERE customer_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter customer ID to view: ");
            int customerId = scanner.nextInt();
            stmt.setInt(1, customerId);

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                System.out.println("\n--- Customer Details ---");
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Email: " + rs.getString("email"));
                System.out.println("Phone Number: " + rs.getString("phone_number"));
                System.out.println("Address: " + rs.getString("address"));
            } else {
                System.out.println("Customer not found with ID: " + customerId);
            }
        } catch (SQLException e) {
            System.out.println("Error viewing customer: " + e.getMessage());
        }
    }

    // Update customer information
    public static void updateCustomer() {
        try (Connection conn = DBconnection.getConnection()) {
            String sql = "UPDATE Customer SET name = ?, email = ?, phone_number = ?, address = ? WHERE customer_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter customer ID to update: ");
            int customerId = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            System.out.print("Enter new customer name: ");
            stmt.setString(1, scanner.nextLine());

            System.out.print("Enter new customer email: ");
            stmt.setString(2, scanner.nextLine());

            System.out.print("Enter new customer phone number: ");
            stmt.setString(3, scanner.nextLine());

            System.out.print("Enter new customer address: ");
            stmt.setString(4, scanner.nextLine());

            stmt.setInt(5, customerId);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                System.out.println("Customer updated successfully!");
            } else {
                System.out.println("Customer not found with ID: " + customerId);
            }
        } catch (SQLException e) {
            System.out.println("Error updating customer: " + e.getMessage());
        }
    }

    // Delete a customer
    public static void deleteCustomer() {
        try (Connection conn = DBconnection.getConnection()) {
            String sql = "DELETE FROM Customer WHERE customer_id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter customer ID to delete: ");
            int customerId = scanner.nextInt();
            stmt.setInt(1, customerId);

            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                System.out.println("Customer deleted successfully!");
            } else {
                System.out.println("Customer not found with ID: " + customerId);
            }
        } catch (SQLException e) {
            System.out.println("Error deleting customer: " + e.getMessage());
        }
    }
}
