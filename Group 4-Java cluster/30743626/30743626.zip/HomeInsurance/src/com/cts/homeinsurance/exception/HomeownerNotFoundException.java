package com.cts.homeinsurance.exception;

public class HomeownerNotFoundException extends Exception {
    public HomeownerNotFoundException(String message) {
        super(message);
    }
}
