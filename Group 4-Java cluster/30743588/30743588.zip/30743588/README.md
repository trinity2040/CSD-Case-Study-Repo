# Customer Feedback Management System

## Setup

1. **Database Setup:**
   - Create a MySQL database named `customer`.
   - Execute the provided SQL scripts to create the `Feedback`, `Analysis`, and `Response` tables.

2. **Configuration:**
   - Update the database URL, username, and password in `DatabaseConnection.java`.

3. **Building and Running the Project:**
   - Use IntelliJ IDEA or any other Java IDE.
   - Run the `Main` class to start the application.

## Features

1. **Manage Feedback:**
   - Add, view, update, and delete feedback entries.

2. **Analyze Feedback:**
   - Analyze feedback data and manage analysis records.

3. **Respond to Feedback:**
   - Respond to customer feedback and manage response records.

## Contributions

Feel free to contribute to the project by submitting issues or pull requests.

## License

This project is licensed under the MIT License.
