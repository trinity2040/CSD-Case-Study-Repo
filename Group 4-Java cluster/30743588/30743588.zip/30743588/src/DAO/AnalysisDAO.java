package DAO;


import Model.Analysis;
import Util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AnalysisDAO {

    public void addAnalysis(Analysis analysis) throws SQLException {
        String query = "INSERT INTO Analysis (feedback_id, analysis_date, analysis_details, status) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, analysis.getFeedbackId());
            stmt.setDate(2, analysis.getAnalysisDate()); // Use java.sql.Date
            stmt.setString(3, analysis.getAnalysisDetails());
            stmt.setString(4, analysis.getStatus());
            stmt.executeUpdate();
        }
    }

    public Analysis getAnalysis(int analysisId) throws SQLException {
        String query = "SELECT * FROM Analysis WHERE analysis_id = ?";
        Analysis analysis = null;
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, analysisId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                analysis = new Analysis();
                analysis.setAnalysisId(rs.getInt("analysis_id"));
                analysis.setFeedbackId(rs.getInt("feedback_id"));
                analysis.setAnalysisDate(rs.getDate("analysis_date")); // Use java.sql.Date
                analysis.setAnalysisDetails(rs.getString("analysis_details"));
                analysis.setStatus(rs.getString("status"));
            }
        }
        return analysis;
    }

    public void updateAnalysis(Analysis analysis) throws SQLException {
        String query = "UPDATE Analysis SET feedback_id = ?, analysis_date = ?, analysis_details = ?, status = ? WHERE analysis_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, analysis.getFeedbackId());
            stmt.setDate(2, analysis.getAnalysisDate()); // Use java.sql.Date
            stmt.setString(3, analysis.getAnalysisDetails());
            stmt.setString(4, analysis.getStatus());
            stmt.setInt(5, analysis.getAnalysisId());
            stmt.executeUpdate();
        }
    }

    public void deleteAnalysis(int analysisId) throws SQLException {
        String query = "DELETE FROM Analysis WHERE analysis_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, analysisId);
            stmt.executeUpdate();
        }
    }

    public List<Analysis> getAllAnalyses() throws SQLException {
        List<Analysis> analysisList = new ArrayList<>();
        String query = "SELECT * FROM Analysis";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Analysis analysis = new Analysis();
                analysis.setAnalysisId(rs.getInt("analysis_id"));
                analysis.setFeedbackId(rs.getInt("feedback_id"));
                analysis.setAnalysisDate(rs.getDate("analysis_date")); // Use java.sql.Date
                analysis.setAnalysisDetails(rs.getString("analysis_details"));
                analysis.setStatus(rs.getString("status"));
                analysisList.add(analysis);
            }
        }
        return analysisList;
    }
}
