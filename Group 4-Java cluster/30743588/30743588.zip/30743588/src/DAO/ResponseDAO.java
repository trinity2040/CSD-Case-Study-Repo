package DAO;
//package dao;

import Model.Response;
import Util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ResponseDAO {

    public void addResponse(Response response) throws SQLException {
        String query = "INSERT INTO Response (feedback_id, response_date, response_text, status) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, response.getFeedbackId());
            stmt.setDate(2, response.getResponseDate()); // Use java.sql.Date
            stmt.setString(3, response.getResponseText());
            stmt.setString(4, response.getStatus());
            stmt.executeUpdate();
        }
    }

    public Response getResponse(int responseId) throws SQLException {
        String query = "SELECT * FROM Response WHERE response_id = ?";
        Response response = null;
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, responseId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                response = new Response();
                response.setResponseId(rs.getInt("response_id"));
                response.setFeedbackId(rs.getInt("feedback_id"));
                response.setResponseDate(rs.getDate("response_date")); // Use java.sql.Date
                response.setResponseText(rs.getString("response_text"));
                response.setStatus(rs.getString("status"));
            }
        }
        return response;
    }

    public void updateResponse(Response response) throws SQLException {
        String query = "UPDATE Response SET feedback_id = ?, response_date = ?, response_text = ?, status = ? WHERE response_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, response.getFeedbackId());
            stmt.setDate(2, response.getResponseDate()); // Use java.sql.Date
            stmt.setString(3, response.getResponseText());
            stmt.setString(4, response.getStatus());
            stmt.setInt(5, response.getResponseId());
            stmt.executeUpdate();
        }
    }

    public void deleteResponse(int responseId) throws SQLException {
        String query = "DELETE FROM Response WHERE response_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, responseId);
            stmt.executeUpdate();
        }
    }

    public List<Response> getAllResponses() throws SQLException {
        List<Response> responseList = new ArrayList<>();
        String query = "SELECT * FROM Response";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Response response = new Response();
                response.setResponseId(rs.getInt("response_id"));
                response.setFeedbackId(rs.getInt("feedback_id"));
                response.setResponseDate(rs.getDate("response_date")); // Use java.sql.Date
                response.setResponseText(rs.getString("response_text"));
                response.setStatus(rs.getString("status"));
                responseList.add(response);
            }
        }
        return responseList;
    }
}

