package DAO;


import Model.Feedback;
import Util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FeedbackDAO {

    public void addFeedback(Feedback feedback) throws SQLException {
        String query = "INSERT INTO Feedback (customer_id, feedback_date, feedback_text, status) VALUES (?, ?, ?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, feedback.getCustomerId());
            stmt.setDate(2, feedback.getFeedbackDate()); // Use java.sql.Date
            stmt.setString(3, feedback.getFeedbackText());
            stmt.setString(4, feedback.getStatus());
            stmt.executeUpdate();
        }
    }

    public Feedback getFeedback(int feedbackId) throws SQLException {
        String query = "SELECT * FROM Feedback WHERE feedback_id = ?";
        Feedback feedback = null;
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, feedbackId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                feedback = new Feedback();
                feedback.setFeedbackId(rs.getInt("feedback_id"));
                feedback.setCustomerId(rs.getInt("customer_id"));
                feedback.setFeedbackDate(rs.getDate("feedback_date")); // Use java.sql.Date
                feedback.setFeedbackText(rs.getString("feedback_text"));
                feedback.setStatus(rs.getString("status"));
            }
        }
        return feedback;
    }

    public void updateFeedback(Feedback feedback) throws SQLException {
        String query = "UPDATE Feedback SET customer_id = ?, feedback_date = ?, feedback_text = ?, status = ? WHERE feedback_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, feedback.getCustomerId());
            stmt.setDate(2, feedback.getFeedbackDate()); // Use java.sql.Date
            stmt.setString(3, feedback.getFeedbackText());
            stmt.setString(4, feedback.getStatus());
            stmt.setInt(5, feedback.getFeedbackId());
            stmt.executeUpdate();
        }
    }

    public void deleteFeedback(int feedbackId) throws SQLException {
        String query = "DELETE FROM Feedback WHERE feedback_id = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, feedbackId);
            stmt.executeUpdate();
        }
    }

    public List<Feedback> getAllFeedbacks() throws SQLException {
        List<Feedback> feedbackList = new ArrayList<>();
        String query = "SELECT * FROM Feedback";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement stmt = connection.prepareStatement(query);
             ResultSet rs = stmt.executeQuery()) {
            while (rs.next()) {
                Feedback feedback = new Feedback();
                feedback.setFeedbackId(rs.getInt("feedback_id"));
                feedback.setCustomerId(rs.getInt("customer_id"));
                feedback.setFeedbackDate(rs.getDate("feedback_date")); // Use java.sql.Date
                feedback.setFeedbackText(rs.getString("feedback_text"));
                feedback.setStatus(rs.getString("status"));
                feedbackList.add(feedback);
            }
        }
        return feedbackList;
    }
}


