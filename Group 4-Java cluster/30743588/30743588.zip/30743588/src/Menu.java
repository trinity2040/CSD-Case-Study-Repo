import DAO.FeedbackDAO;
import DAO.AnalysisDAO;
import DAO.ResponseDAO;
import Model.Feedback;
import Model.Analysis;
import Model.Response;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

public class Menu {
    private static final Scanner scanner = new Scanner(System.in);
    private static final FeedbackDAO feedbackDAO = new FeedbackDAO();
    private static final AnalysisDAO analysisDAO = new AnalysisDAO();
    private static final ResponseDAO responseDAO = new ResponseDAO();

    public static void main(String[] args) {
        while (true) {
            System.out.println("Customer Feedback Management System");
            System.out.println("1. Manage Feedback");
            System.out.println("2. Analyze Feedback");
            System.out.println("3. Respond to Feedback");
            System.out.println("4. Exit");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    manageFeedback();
                    break;
                case 2:
                    analyzeFeedback();
                    break;
                case 3:
                    respondToFeedback();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }
        }
    }

    private static void manageFeedback() {
        System.out.println("Feedback Management");
        System.out.println("1. Add Feedback");
        System.out.println("2. View Feedback");
        System.out.println("3. Update Feedback");
        System.out.println("4. Delete Feedback");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        try {
            switch (choice) {
                case 1:
                    Feedback feedback = new Feedback();
                    System.out.println("Enter customer ID:");
                    feedback.setCustomerId(scanner.nextInt());
                    scanner.nextLine();  // Consume newline
                    System.out.println("Enter feedback date (YYYY-MM-DD):");
                    feedback.setFeedbackDate(Date.valueOf(scanner.nextLine()));
                    System.out.println("Enter feedback text:");
                    feedback.setFeedbackText(scanner.nextLine());
                    System.out.println("Enter status:");
                    feedback.setStatus(scanner.nextLine());
                    feedbackDAO.addFeedback(feedback);
                    System.out.println("Feedback added successfully.");
                    break;
                case 2:
                    System.out.println("Enter feedback ID:");
                    Feedback viewFeedback = feedbackDAO.getFeedback(scanner.nextInt());
                    scanner.nextLine();  // Consume newline
                    if (viewFeedback != null) {
                        System.out.println("ID: " + viewFeedback.getFeedbackId());
                        System.out.println("Customer ID: " + viewFeedback.getCustomerId());
                        System.out.println("Date: " + viewFeedback.getFeedbackDate());
                        System.out.println("Text: " + viewFeedback.getFeedbackText());
                        System.out.println("Status: " + viewFeedback.getStatus());
                    } else {
                        System.out.println("Feedback not found.");
                    }
                    break;
                case 3:
                    System.out.println("Enter feedback ID to update:");
                    int updateId = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                    Feedback updateFeedback = feedbackDAO.getFeedback(updateId);
                    if (updateFeedback != null) {
                        System.out.println("Enter new customer ID:");
                        updateFeedback.setCustomerId(scanner.nextInt());
                        scanner.nextLine();  // Consume newline
                        System.out.println("Enter new feedback date (YYYY-MM-DD):");
                        updateFeedback.setFeedbackDate(Date.valueOf(scanner.nextLine()));
                        System.out.println("Enter new feedback text:");
                        updateFeedback.setFeedbackText(scanner.nextLine());
                        System.out.println("Enter new status:");
                        updateFeedback.setStatus(scanner.nextLine());
                        feedbackDAO.updateFeedback(updateFeedback);
                        System.out.println("Feedback updated successfully.");
                    } else {
                        System.out.println("Feedback not found.");
                    }
                    break;
                case 4:
                    System.out.println("Enter feedback ID to delete:");
                    feedbackDAO.deleteFeedback(scanner.nextInt());
                    scanner.nextLine();  // Consume newline
                    System.out.println("Feedback deleted successfully.");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void analyzeFeedback() {
        System.out.println("Feedback Analysis");
        System.out.println("1. Add Analysis");
        System.out.println("2. View Analysis");
        System.out.println("3. Update Analysis");
        System.out.println("4. Delete Analysis");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        try {
            switch (choice) {
                case 1:
                    Analysis analysis = new Analysis();
                    System.out.println("Enter feedback ID:");
                    analysis.setFeedbackId(scanner.nextInt());
                    scanner.nextLine();  // Consume newline
                    System.out.println("Enter analysis date (YYYY-MM-DD):");
                    analysis.setAnalysisDate(Date.valueOf(scanner.nextLine()));
                    System.out.println("Enter analysis details:");
                    analysis.setAnalysisDetails(scanner.nextLine());
                    System.out.println("Enter status:");
                    analysis.setStatus(scanner.nextLine());
                    analysisDAO.addAnalysis(analysis);
                    System.out.println("Analysis added successfully.");
                    break;
                case 2:
                    System.out.println("Enter analysis ID:");
                    Analysis viewAnalysis = analysisDAO.getAnalysis(scanner.nextInt());
                    scanner.nextLine();  // Consume newline
                    if (viewAnalysis != null) {
                        System.out.println("ID: " + viewAnalysis.getAnalysisId());
                        System.out.println("Feedback ID: " + viewAnalysis.getFeedbackId());
                        System.out.println("Date: " + viewAnalysis.getAnalysisDate());
                        System.out.println("Details: " + viewAnalysis.getAnalysisDetails());
                        System.out.println("Status: " + viewAnalysis.getStatus());
                    } else {
                        System.out.println("Analysis not found.");
                    }
                    break;
                case 3:
                    System.out.println("Enter analysis ID to update:");
                    int updateId = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                    Analysis updateAnalysis = analysisDAO.getAnalysis(updateId);
                    if (updateAnalysis != null) {
                        System.out.println("Enter new feedback ID:");
                        updateAnalysis.setFeedbackId(scanner.nextInt());
                        scanner.nextLine();  // Consume newline
                        System.out.println("Enter new analysis date (YYYY-MM-DD):");
                        updateAnalysis.setAnalysisDate(Date.valueOf(scanner.nextLine()));
                        System.out.println("Enter new analysis details:");
                        updateAnalysis.setAnalysisDetails(scanner.nextLine());
                        System.out.println("Enter new status:");
                        updateAnalysis.setStatus(scanner.nextLine());
                        analysisDAO.updateAnalysis(updateAnalysis);
                        System.out.println("Analysis updated successfully.");
                    } else {
                        System.out.println("Analysis not found.");
                    }
                    break;
                case 4:
                    System.out.println("Enter analysis ID to delete:");
                    analysisDAO.deleteAnalysis(scanner.nextInt());
                    scanner.nextLine();  // Consume newline
                    System.out.println("Analysis deleted successfully.");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void respondToFeedback() {
        System.out.println("Feedback Response");
        System.out.println("1. Add Response");
        System.out.println("2. View Response");
        System.out.println("3. Update Response");
        System.out.println("4. Delete Response");
        int choice = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        try {
            switch (choice) {
                case 1:
                    Response response = new Response();
                    System.out.println("Enter feedback ID:");
                    response.setFeedbackId(scanner.nextInt());
                    scanner.nextLine();  // Consume newline
                    System.out.println("Enter response date (YYYY-MM-DD):");
                    response.setResponseDate(Date.valueOf(scanner.nextLine()));
                    System.out.println("Enter response text:");
                    response.setResponseText(scanner.nextLine());
                    System.out.println("Enter status:");
                    response.setStatus(scanner.nextLine());
                    responseDAO.addResponse(response);
                    System.out.println("Response added successfully.");
                    break;
                case 2:
                    System.out.println("Enter response ID:");
                    Response viewResponse = responseDAO.getResponse(scanner.nextInt());
                    scanner.nextLine();  // Consume newline
                    if (viewResponse != null) {
                        System.out.println("ID: " + viewResponse.getResponseId());
                        System.out.println("Feedback ID: " + viewResponse.getFeedbackId());
                        System.out.println("Date: " + viewResponse.getResponseDate());
                        System.out.println("Text: " + viewResponse.getResponseText());
                        System.out.println("Status: " + viewResponse.getStatus());
                    } else {
                        System.out.println("Response not found.");
                    }
                    break;
                case 3:
                    System.out.println("Enter response ID to update:");
                    int updateId = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                    Response updateResponse = responseDAO.getResponse(updateId);
                    if (updateResponse != null) {
                        System.out.println("Enter new feedback ID:");
                        updateResponse.setFeedbackId(scanner.nextInt());
                        scanner.nextLine();  // Consume newline
                        System.out.println("Enter new response date (YYYY-MM-DD):");
                        updateResponse.setResponseDate(Date.valueOf(scanner.nextLine()));
                        System.out.println("Enter new response text:");
                        updateResponse.setResponseText(scanner.nextLine());
                        System.out.println("Enter new status:");
                        updateResponse.setStatus(scanner.nextLine());
                        responseDAO.updateResponse(updateResponse);
                        System.out.println("Response updated successfully.");
                    } else {
                        System.out.println("Response not found.");
                    }
                    break;
                case 4:
                    System.out.println("Enter response ID to delete:");
                    responseDAO.deleteResponse(scanner.nextInt());
                    scanner.nextLine();  // Consume newline
                    System.out.println("Response deleted successfully.");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
