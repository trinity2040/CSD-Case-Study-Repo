package blogmanagement;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

import database.*;
import models.*;

public class Main {
    public static void main(String[] args) {
        try {
            Connection connection = DatabaseConnection.getConnection();
            Scanner scanner = new Scanner(System.in);
            while (true) {
                System.out.println();
                System.out.println("BLOG MANAGEMENT SYSTEM");
                System.out.println("1. Add a new Blog");
                System.out.println("2. View blog details");
                System.out.println("3. Update blog details");
                System.out.println("4. Delete a blog");
                System.out.println("5. Add comment on blog");
                System.out.println("6. View comments");
                System.out.println("7. Update comment");
                System.out.println("8. Delete a comment");
                System.out.println("0. EXIT");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume the newline character
                switch (choice) {
                    case 1:
                        BlogManager.newBlog(connection, scanner);
                        break;
                    case 2:
                        BlogManager.viewBlog(connection);
                        break;
                    case 3:
                        BlogManager.updateBlog(connection, scanner);
                        break;
                    case 4:
                        BlogManager.deleteBlog(connection, scanner);
                        break;
                    case 5:
                        CommentManager.newComment(connection, scanner);
                        break;
                    case 6:
                        CommentManager.viewComment(connection);
                        break;
                    case 7:
                        CommentManager.updateComment(connection, scanner);
                        break;
                    case 8:
                        CommentManager.deleteComment(connection, scanner);
                        break;
                    case 0:
                        exit();
                        scanner.close();
                        return;
                    default:
                        System.out.println("Invalid Choice. Try again!");
                }
            }
        } catch (SQLException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static void exit() throws InterruptedException {
        System.out.println("Exiting System");
        System.out.println("Thank You For Using Blog Management System!!!");
    }
}