package models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import static customException.blogNotExists.checkBlogExists;

public class BlogManager {

    public static void newBlog(Connection connection, Scanner scanner) {
        try {
            System.out.println("Enter blog title:");
            String blogTitle = scanner.nextLine();
            System.out.println("Enter blog description:");
            String blogDescription = scanner.nextLine();
            System.out.println("Enter blog author name:");
            String blogAuthor = scanner.nextLine();

            String sql = "INSERT INTO blog (title, description, author) VALUES (?, ?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, blogTitle);
                preparedStatement.setString(2, blogDescription);
                preparedStatement.setString(3, blogAuthor);

                int affectedRows = preparedStatement.executeUpdate();
                if (affectedRows > 0) {
                    System.out.println("Blog Added Successfully!");
                } else {
                    System.out.println("Blog Failed to get upload! Try Again");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewBlog(Connection connection) throws SQLException {
        String sql = "SELECT blog_id, title, description, author, creation_date FROM blog";

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            System.out.println("List of Blogs:");
            System.out.println("+----------------+-----------------+---------------+----------------------+-------------------------+");
            System.out.println("| Blog ID | Title           | Description   | Author      | Creation Date         ");
            System.out.println("+----------------+-----------------+---------------+----------------------+-------------------------+");

            while (resultSet.next()) {
                int blogId = resultSet.getInt("blog_id");
                String blogTitle = resultSet.getString("title");
                String blogDescription = resultSet.getString("description");
                String blogAuthor = resultSet.getString("author");
                String creationDate = resultSet.getTimestamp("creation_date").toString();

                // Format and display the reservation data in a table-like format
                System.out.printf("| %-7d | %-15s | %-13s | %-11s | %-19s   \n",
                        blogId, blogTitle, blogDescription, blogAuthor, creationDate);
            }

            System.out.println("+----------------+-----------------+---------------+----------------------+-------------------------+");
        }
    }

    public static void updateBlog(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter blog ID to update: ");
            int blogId = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            // Check if the blog exists
            if (!checkBlogExists(connection, blogId)) {
                System.out.println("Blog not found for the given ID.");
                return;
            }

            System.out.print("Enter new title: ");
            String newTitle = scanner.nextLine();
            System.out.print("Enter new description: ");
            String newDescription = scanner.nextLine();
            System.out.print("Change Author Name: ");
            String newAuthor = scanner.nextLine();

            // Use PreparedStatement to prevent SQL injection and handle strings correctly
            String sql = "UPDATE blog SET title = ?, description = ?, author = ? WHERE blog_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, newTitle);
                preparedStatement.setString(2, newDescription);
                preparedStatement.setString(3, newAuthor);
                preparedStatement.setInt(4, blogId);

                int affectedRows = preparedStatement.executeUpdate();
                if (affectedRows > 0) {
                    System.out.println("Blog updated successfully!");
                } else {
                    System.out.println("Blog update failed.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteBlog(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter blog ID to delete: ");
            int blogId = scanner.nextInt();

            if (!checkBlogExists(connection, blogId)) {
                System.out.println("Blog not found for the given ID.");
                return;
            }

            String sql = "DELETE FROM blog WHERE blog_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, blogId);

                int affectedRows = preparedStatement.executeUpdate();
                if (affectedRows > 0) {
                    System.out.println("Blog deleted successfully!");
                } else {
                    System.out.println("Blog deletion failed.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}