package models;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import static customException.blogNotExists.checkBlogExists;
import static customException.commentNotExists.checkCommentExists;

public class CommentManager {

    public static void newComment(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter blog ID to comment on: ");
            int blogId = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            if (!(checkBlogExists(connection, blogId))) {
                System.out.println("Blog not found for the given ID.");
                return;
            }

            System.out.print("Enter comment text: ");
            String commentText = scanner.nextLine();

            String sql = "INSERT INTO comment (blog_id, content) VALUES (?, ?)";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, blogId);
                preparedStatement.setString(2, commentText);

                int affectedRows = preparedStatement.executeUpdate();
                if (affectedRows > 0) {
                    System.out.println("Comment added successfully!");
                } else {
                    System.out.println("Comment addition failed.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewComment(Connection connection) throws SQLException {
        String sql = "SELECT comment_id, blog_id, content, comment_date FROM comment";

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            System.out.println("List of Comments:");
            System.out.println("+----------------+-----------------+---------------+----------------------+-------------------------+");
            System.out.println("| Comment ID | Blog ID | Comment           | Creation Date         ");
            System.out.println("+----------------+-----------------+---------------+----------------------+-------------------------+");

            while (resultSet.next()) {
                int commentId = resultSet.getInt("comment_id");
                int blogId = resultSet.getInt("blog_id");
                String commentText = resultSet.getString("content");
                String creationDate = resultSet.getTimestamp("comment_date").toString();

                // Format and display the reservation data in a table-like format
                System.out.printf("| %-7d | %-7d | %-13s | %-19s   \n",
                        commentId, blogId, commentText, creationDate);
            }

            System.out.println("+----------------+-----------------+---------------+----------------------+-------------------------+");
        }
    }

    public static void updateComment(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter comment ID to update: ");
            int commentId = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            if (!checkCommentExists(connection, commentId)) {
                System.out.println("Comment not found for the given ID.");
                return;
            }

            System.out.print("Enter new comment text: ");
            String newCommentText = scanner.nextLine();

            String sql = "UPDATE comment SET content = ? WHERE comment_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setString(1, newCommentText);
                preparedStatement.setInt(2, commentId);

                int affectedRows = preparedStatement.executeUpdate();
                if (affectedRows > 0) {
                    System.out.println("Comment updated successfully!");
                } else {
                    System.out.println("Comment update failed.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteComment(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter comment ID to delete: ");
            int commentId = scanner.nextInt();

            if (!checkCommentExists(connection, commentId)) {
                System.out.println("Comment not found for the given ID.");
                return;
            }

            String sql = "DELETE FROM comment WHERE comment_id = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
                preparedStatement.setInt(1, commentId);

                int affectedRows = preparedStatement.executeUpdate();
                if (affectedRows > 0) {
                    System.out.println("Comment deleted successfully!");
                } else {
                    System.out.println("Comment deletion failed.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}