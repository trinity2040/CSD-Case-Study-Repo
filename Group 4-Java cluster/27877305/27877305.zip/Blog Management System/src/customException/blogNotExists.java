package customException;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class blogNotExists {
    public static boolean checkBlogExists(Connection connection, int blogId) throws SQLException {
        String sql = "SELECT blog_id FROM blog WHERE blog_id = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setInt(1, blogId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                return resultSet.next();
            }
        }
    }
}