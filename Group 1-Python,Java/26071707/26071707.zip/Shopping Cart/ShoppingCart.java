import java.util.ArrayList;
import java.util.List;
public class ShoppingCart {

    private List<CartItem> items;
    public ShoppingCart() {
        items = new ArrayList<>();
    }

    public List<CartItem> getItems() {
        return items;
    }

    public void setItems(List<CartItem> items) {
        this.items = items;
    }
    
    void addItem(CartItem item){
        for(CartItem i:items) {
            if (i.getProductId() == item.getProductId()){
                i.setQuantity(i.getQuantity()+item.getQuantity());
                return;
            }
        }
        items.add(item);
    }

    void removeItem(int productId){
        items.removeIf(item -> item.getProductId() == productId);
    }

    double calculateTotalPrice(List<Product> products) {
        double total = 0;
        for(CartItem item: items){
            Product product = findProductById(products,item.getProductId());
            if (product != null){
                total = total + item.getQuantity() * product.getPrice();
            }
        }

        return total;
    }
     Product findProductById(List<Product> products, int productId) {
            Product temp=null;
            for(Product p:products){
                if (p.getProductId() == productId) {
                    temp = p;
                    break;
                }
            }
            return temp;
     }

    @Override
    public String toString() {
        return "ShoppingCart [items=" + items + "]";
    }
    
}
