public class CartItem {
    private int productId;
    private float quantity;

    public CartItem(int productId, float quantity) {
        this.productId = productId;
        this.quantity = quantity;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public float getQuantity() {
        return quantity;
    }

    public void setQuantity(float quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "CartItem [productId=" + productId + ", quantity=" + quantity + "]";
    }
}
