/*
 * Browse Products
 * Add to Cart
 * Remove from Cart
 * Place Order
 */

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.Date;
import java.util.InputMismatchException;

public class ShoppingApp {
    
    static public List<Product> products = new ArrayList<>();
    static public List<Order> orders = new ArrayList<>();
    static public ShoppingCart Cart = new ShoppingCart();
    static int orderId = 0;

    

    public static void main(String[] args){
        products.add(new Product(1, "Cricket Bat", 633, "kashmiri willow bat"));
        products.add(new Product(2, "kukaboora ball", 31, "Quality cricket ball"));
        products.add(new Product(3, "Sony Tv", 516, "Full HD quality TV"));
        products.add(new Product(4, "Iphone 16 Pro", 1600, "16Gb 512Gb"));

        Scanner scanner = new Scanner(System.in);
        System.out.println("1. Browse Products\n2. Add to Cart\n3. Remove from Cart\n4. Place Order\n5. Display Cart\n6. Exit");
        int choice=11;
        do {
            try{
                System.out.print("Enter choice :");
                choice = scanner.nextInt();
                switch(choice) {
                    case 1:
                        browseProducts(products);
                        break;

                    case 2:
                        addToCart(scanner);
                        break;

                    case 3:
                        removeFromCart(scanner);
                        break;

                    case 4:
                        placeOrder();
                        break;
                    case 5:
                            System.out.println("\n ******* Products in Cart ******");
                            displayProductsInCart();
                            System.out.println(); 
                }                  
            
            System.out.println("-------------------------------------------------------");
            System.out.println("1.Browse Products | 2.Add to Cart | 3.Remove from Cart | 4.Place Order | 5.Display Cart | 6. Exit");
            }catch(InputMismatchException e){
                System.out.println("enter valid input");
                scanner.nextLine();
            }catch(ProductNotFoundException e){
                System.out.println("Product not found");
            }
            
        } while(choice != 6);
        scanner.close();
    }

    static void browseProducts(List<Product> products){
        System.out.println("\n******* Products Available in the cart ******");
        for(Product p : products){
            System.out.println(p);
        }
    }

    static void addToCart(Scanner scanner){

        try{
        Boolean found = false;
        System.out.print("Enter product id :");
        int productId = scanner.nextInt();
        for(Product p:products){
            if (p.getId() == productId){
                found = true;
            }
        }
        if (!found){
            throw new ProductNotFoundException("product not found");
        }
        System.out.print("Enter the quantity :");
        float qty = scanner.nextFloat();
        Cart.addItem(new CartItem(productId,qty));
        System.out.println("\n******* Products in Cart ********");

        displayProductsInCart();
        System.out.println("\nCost of the items in cart :" + Cart.calculateTotalPrice(products));
        }
        catch(ProductNotFoundException e){
            System.out.println("Product Id not found!!");
        }
    }

    static void removeFromCart(Scanner scanner) {
        try{
            if (Cart.getItems().size() == 0){
                System.out.println("Cart is Empty");
            }
            System.out.print("Enter product Id :");
            int proId = scanner.nextInt();
            Boolean found = false;
            for(CartItem c:Cart.getItems()){
                if (c.getProductId() == proId){
                    found = true;
                }
            }
            if (!found){
                System.out.println("Item not present in cart!!");
                return;
            }
            Product deletedProduct = findProductById(proId);
            float qty = 0;
            for(CartItem item:Cart.getItems()){
                if(item.getProductId() == proId){
                    qty = item.getQuantity();
                    break;
                }
            }
            System.out.println("removed product "+deletedProduct + " "+" qty :"+qty);
            Cart.removeItem(proId);
        }
        catch(ProductNotFoundException e){
            System.out.println("The mentioned product is not present in the Cart!!");
        }
    }

    static void placeOrder(){
        try{
        if (Cart.getItems().size() == 0){
            System.out.println("No items in cart to place order");
            return;
        }
        System.out.println("\n******** Order Details **********");
        orders.add(new Order(++orderId, Cart.getItems(), new Date(), Cart.calculateTotalPrice(products), "Pending"));
        displayProductsInCart();
        Order lastOrder = orders.get(orders.size()-1);
        System.out.println("\nAmount to be paid : $"+Cart.calculateTotalPrice(products));
        System.out.println("order number is "+ lastOrder.getId() + "\norder on "+lastOrder.getOrderDate() + "\nstatus is " + lastOrder.getStatus());
        Cart.setItems(new ArrayList<>());
        }
        catch(ProductNotFoundException e){
            System.out.println("Invalid Product Id found");
        }
    }

    static Product findProductById(int id) throws ProductNotFoundException{
        for(Product p:products){
            if(p.getId() == id){
                return p;
            }
        }
        throw new ProductNotFoundException("Product not found");
    }

    static void displayProductsInCart() throws ProductNotFoundException{
        for(CartItem item:Cart.getItems()){
            Product currentProduct = findProductById(item.getProductId());
            System.out.println(
                currentProduct.getId() + "\t" + currentProduct.getName() + "\t$" + currentProduct.getPrice()+" x "+ item.getQuantity() +"\t$"+ (item.getQuantity()*currentProduct.getPrice())
            );
        }
    }
}
