How to Run the Application:

 Prerequisites:

1. Java Development Kit (JDK): Make sure that JDK 8 or higher is installed on your machine.
1. IDE or Text Editor: Use an IDE like IntelliJ IDEA, Eclipse, or a text editor such as VSCode.


 Steps to Run:

1. Download the Project Files: 
   - Download the zip file and place all the .java files in a single directory.

2. Compile the Java Files: 
   - Open your IDE or text editor such as VSCode.
   - Navigate to the directory containing the Java files.     

3. Run the Application:      
   - Using an IDE, right-click on the Main class and select "Run".


 Instructions for each Feature:

 1. View Events:

 Displays a list of all available events, showing details such as event ID, name, date, venue, ticket price, and available tickets. The 'viewEvents' method can be called as follows:
	
	obj.viewEvents();

 2. Book Tickets:

 Allows users to book tickets for a selected event. In the Main class, the 'bookTicket' method is called with the following parameters:

	obj.bookTicket(eventId, userId, quantity);

 3. Cancel Booking:

 Allows users to cancel an existing booking. The 'cancelBooking' method is called as follows:

	obj.cancelBooking(bookingId);

 4. View Bookings:

 Displays the booking history for a user, showing details such as booking ID, event name, booking date, and total cost. The 'viewBookings' method is called as follows:
	
	obj.viewBookings(userId);


 Exception Handling:

The application uses custom exceptions to handle specific errors that might occur. These custom exceptions help keep the code organized, making it easier to read and understand. They also make managing errors more straightforward.

 Custom Exceptions Implemented:

InvalidEventIdException:

The exception is thrown when a user enters an invalid eventID or attempts to interact with an event that does not exist. It is triggered in 'bookTicket' and 'cancelBooking' methods when the event ID is invalid.

InsufficientTicketsException:

The exception is thrown when a user tries to book more tickets than are available. It is triggered in 'bookTicket' method if the ticket quantity requested exceeds the number of available tickets.

BookingNotFoundException:

This exception is thrown when a user tries to cancel a booking that does not exist. It is triggered in 'cancelBooking' method if the booking ID does not match any existing booking.

 How Exception Handling Works:

- When an exception is triggered, the application catches it and displays a user-friendly error message. This prevents the application from crashing and guides the user on how to correct their input. Example of an exception handling scenario in the 'bookTicket' method:
  
  try 
	{
      		obj.bookTicket(eventId, userId, quantity);
  	}
 catch (InvalidEventIdException | InsufficientTicketsException | BookingNotFoundException e) 
	{
	      System.out.println("Error: " + e.getMessage());
	}
  
- Any of the errors will be displayed with a proper error clarifying why the error is occurring.



  Brief document on software design and object-oriented concepts:

 Application Design:

The online ticket reserving machine is a console-based Java software that enables users to view available occasions, book tickets online, cancel bookings, and view their reserving records. The application is structured round three most important classes: 'Event', 'Booking', and 'TicketBookingSystem'. Each class has a particular function, and collectively they manage the main functionalities of the machine.

- Event class: This class represents an event that user can book online tickets for. It stores the event's ID, name, date, venue, ticket price, and the number of available tickets. The class contain methods to retrieve these information and update the number of available tickets.

- Booking class: This class contains the information of a booking, including the  booking ID, event ID, user ID, booking date, and total cost. It helps in managing and showing booking records for the user.

- TicketBookingSystem class: This is the center class of the application, managing the list of occasions and bookings. It contain methods to view events, book tickets, cancel bookings, and view user booking history. It also includes the logic for updating event details (like number of available tickets) and validates consumer inputs during booking and cancellation.

Object-Oriented Principles implemented:

The application is designed the usage using the fundamental Object-Oriented Programming like encapsulation, abstraction, inheritance, and polymorphism.

1. Encapsulation:
   - Encapsulation is executed through retaining the data of every class private and using getter and setter methods to get entry to or alter this information. For example, the 'Event and 'Booking' encapsulate the information of events and bookings, respectively. This guarantees that the inner state of these object is protected from unintentional modification.

2. Abstraction:
   - The application simplifies complicated operations for the user by providing clear and easy strategies inside the 'TicketBookingSystem' class. User engages with the system by using the methods like 'viewEvents()', 'bookTicket()', 'cancelBooking()', and 'viewBookings()', without having to know how the data is managed.

3. Inheritance:
   - Custom exceptions that are designed inside the application inherit from a base class referred to as 'TicketBookingException'. This inheritance shape lets in the application to handle distinct errors conditions in a proper way. The particular exceptions 'InvalidEventIdException', 'InsufficientTicketsException', 'BookingNotFoundException' extend from the base exception class, making the error-handling process more organized.

4. Polymorphism:
   - Through polymorphism, the 'TicketBookingException' type can refer to any of its subclasses, 'InvalidEventIdException', 'InsufficientTicketsException', 'BookingNotFoundException', enabling flexible and reusable error-handling code in the catch blocks.

 
