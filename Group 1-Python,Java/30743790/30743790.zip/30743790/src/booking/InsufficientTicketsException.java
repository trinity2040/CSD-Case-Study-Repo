package booking;

public class InsufficientTicketsException extends TicketBookingException {
    public InsufficientTicketsException(String message) 
    {
        super(message);
    }
}