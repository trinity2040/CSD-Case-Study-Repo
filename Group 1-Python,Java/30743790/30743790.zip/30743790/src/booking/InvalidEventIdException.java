package booking;

public class InvalidEventIdException extends TicketBookingException {
    public InvalidEventIdException(String message) 
    {
        super(message);
    }
}
