package booking;

public class BookingNotFoundException extends TicketBookingException {
    public BookingNotFoundException(String message) 
    {
        super(message);
    }
}
