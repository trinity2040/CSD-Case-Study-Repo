package booking;

import java.util.Date;

public class Event {
    private int id;
    private String name;
    private Date date;
    private String venue;
    private double ticketPrice;
    private int availableTkts;

    public Event(int id, String name, Date date, String venue, double ticketPrice, int availableTkts) 
    {
        this.id = id;
        this.name = name;
        this.date = date;
        this.venue = venue;
        this.ticketPrice = ticketPrice;
        this.availableTkts = availableTkts;
    }

    
    public int getId() 
    	{ 
    		return id; 
    	}
    public String getName() 
    	{
    		return name; 
    	}
    public Date getDate() 
    	{
    	return date; 
    	}
    public String getVenue() 
    	{
    		return venue; 
    	}
    public double getTicketPrice() 
    	{
    		return ticketPrice; 
    	}
    public int getAvailableTickets() 
    	{
    		return availableTkts; 
    	}

    public void setAvailableTickets(int availableTkts) 
    	{
        	this.availableTkts = availableTkts;
    	}

    @Override
    public String toString() {
        return "Event [ID = " + id + ", Name = " + name + ", Date = " + date + ", Venue = " + venue + 
                ", Ticket_Price = " + ticketPrice + ", Available_Tickets = " + availableTkts + "]";
    }
}
