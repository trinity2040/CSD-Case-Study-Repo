package booking;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class TicketBookingSystem {
    private List<Event> events = new ArrayList<>();
    private List<Booking> bookings = new ArrayList<>();
    private int bookingCounter = 1;

    public void viewEvents() {
        if (events.isEmpty()) 
        	{
            	System.out.println("No events available.");
        	}
        else 
        	{
            	for (Event e : events) 
            	{
            		System.out.println(e);
            	}
        	}
    }

    public void bookTicket(int eventId, int userId, int quantity) 
            throws InvalidEventIdException, InsufficientTicketsException {
        Event objEve = findEventById(eventId);
        if (objEve == null) 
        	{
            	throw new InvalidEventIdException("Event with ID " + eventId + " does not exist.");
        	}
        if (objEve.getAvailableTickets() < quantity) 
        	{
            	throw new InsufficientTicketsException("Not enough tickets available for event " + objEve.getName());
        	}
        if (userId<=0) 
        {
        	System.out.println("User ID cannot be less than or equals to 0.");
        	System.exit(0);
        }
        if (quantity > 0)
        {
        	double totalCost = objEve.getTicketPrice() * quantity;
        	objEve.setAvailableTickets(objEve.getAvailableTickets() - quantity);
        	Booking obj1 = new Booking(bookingCounter++, eventId, userId, new Date(), totalCost);
        	bookings.add(obj1);
        	System.out.println("Booking confirmed: " + obj1);
        	
        }
        else
        {
        System.out.println("Number of booked tickets cannot be less than or equals to 0.");
        }

    }

    public void cancelBooking(int bookingId) 
            throws BookingNotFoundException, InvalidEventIdException {
        Booking obj2 = findBookingById(bookingId);
        if (obj2 == null) 
        	{
            	throw new BookingNotFoundException("Booking with ID " + bookingId + " does not exist.");
        	}

        Event event = findEventById(obj2.getEventId());
        if (event == null) 
        	{
            	throw new InvalidEventIdException("Event with ID " + obj2.getEventId() + " does not exist.");
        	}

        event.setAvailableTickets(event.getAvailableTickets() + 1);
        bookings.remove(obj2);
        System.out.println("Booking cancelled: " + obj2);
    }

    public void viewBookings(int userId) {
        boolean found = false;
        for (Booking b : bookings) 
        	{
            	if (b.getUserId() == userId) 
            		{
                		System.out.println(b);
                		found = true;
            		}
        	}
        if (!found) 
        	{
            	System.out.println("No bookings found for user ID: " + userId);
        	}
    }

    private Event findEventById(int eventId) {
        for (Event e : events) 
        	{
            	if (e.getId() == eventId) 
            		{
            		return e;
            		}
        	}
        return null;
    }

    private Booking findBookingById(int bookingId) {
        for (Booking b : bookings) 
        	{
            	if (b.getId() == bookingId) 
            	{
            		return b;
            	}
        	}
        return null;
    }

    public void addEvent(Event event) {
        events.add(event);
    }
}
