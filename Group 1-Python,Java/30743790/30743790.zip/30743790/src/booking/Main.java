package booking;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Main {
    public static void main(String[] args) throws ParseException {
        TicketBookingSystem obj = new TicketBookingSystem();
        
        SimpleDateFormat dt = new SimpleDateFormat("dd/MM/yyyy");
        obj.addEvent(new Event(1, "Opera", dt.parse("04/09/2024"), "Opera House", 500.0, 100));
        obj.addEvent(new Event(2, "Cricket Match", dt.parse("05/09/2024"), "Wankhade", 300.0, 50));

        obj.viewEvents();

        try 
        	{
            	obj.bookTicket(1, 101, 10);

            	obj.viewBookings(101);

            	obj.cancelBooking(1);

            	obj.viewBookings(101);
            	
            	//obj.bookTicket(2, 202, 60);
            	
            	//obj.bookTicket(5, 201, 7);
            	
            	//obj.viewBookings(201);
            	


        	} 
        catch (InvalidEventIdException | InsufficientTicketsException | BookingNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
