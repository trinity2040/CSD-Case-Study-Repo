package booking;

import java.util.Date;

public class Booking {
    private int id;
    private int eventId;
    private int userId;
    private Date bookingDate;
    private double totalCost;

    public Booking(int id, int eventId, int userId, Date bookingDate, double totalCost) 
    {
        this.id = id;
        this.eventId = eventId;
        this.userId = userId;
        this.bookingDate = bookingDate;
        this.totalCost = totalCost;
    }

    public int getId() 
    	{ 
    		return id; 
    	}
    public int getEventId() 
    	{
    		return eventId; 
    	}
    public int getUserId() 
    	{ 
    		return userId; 
    	}
    public Date getBookingDate() 
    	{ 
    		return bookingDate; 
    	}
    public double getTotalCost() 
    	{ 
    		return totalCost; 
    	}

    @Override
    public String toString() {
        return "Booking [ID = " + id + ", Event_Id = " + eventId + ", User_ID = " + userId + 
                ", Booking_Date = " + bookingDate + ", Total_Cost = " + totalCost + "]";
    }
}
