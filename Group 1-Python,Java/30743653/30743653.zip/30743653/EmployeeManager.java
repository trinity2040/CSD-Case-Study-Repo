import java.util.*;
import java.text.SimpleDateFormat;

public class EmployeeManager {
    private HashMap<Integer, Employee> employees = new HashMap<>();
    private HashMap<Integer, Department> departments = new HashMap<>();

    public void addDepartment(int id, String name) {
        departments.put(id, new Department(id, name));
    }

    public void addEmployee(int id, String name, String designation, double salary, int departmentId, String joiningDateStr) {
        Department dept = departments.get(departmentId);
        if (dept == null) {
            System.out.println("Department not found.");
            return;
        }
        try {
            Date joiningDate = new SimpleDateFormat("dd-MM-yyyy").parse(joiningDateStr);
            employees.put(id, new Employee(id, name, designation, salary, dept, joiningDate));
        } catch (Exception e) {
            System.out.println("Error parsing date.");
        }
    }

    public void calculateTotalSalaryExpenditure() {
        double total = employees.values().stream().mapToDouble(Employee::getSalary).sum();
        System.out.println("Total Salary Expenditure: " + total);
    }

    public void findHighestAndLowestSalary() {
        Optional<Employee> maxSalaryEmp = employees.values().stream().max(Comparator.comparingDouble(Employee::getSalary));
        Optional<Employee> minSalaryEmp = employees.values().stream().min(Comparator.comparingDouble(Employee::getSalary));

        maxSalaryEmp.ifPresent(employee -> System.out.println("Highest Salary Employee: " + employee));
        minSalaryEmp.ifPresent(employee -> System.out.println("Lowest Salary Employee: " + employee));
    }


    public void calculateAverageSalaryByDepartment() {
        Map<Department, Double> avgSalary = new HashMap<>();
        for (Employee emp : employees.values()) {
            avgSalary.merge(emp.getDepartment(), emp.getSalary(), Double::sum);
        }

        for (Map.Entry<Department, Double> entry : avgSalary.entrySet()) {
            long empCount = employees.values().stream().filter(e -> e.getDepartment().equals(entry.getKey())).count();
            System.out.println("Average Salary in " + entry.getKey().getDepartmentName() + ": " + entry.getValue() / empCount);
        }
    }


    public void calculateEmployeeTenure() {
        Date currentDate = new Date();
        for (Employee emp : employees.values()) {
            long tenure = (currentDate.getTime() - emp.getJoiningDate().getTime()) / (1000L * 60 * 60 * 24 * 365);
            System.out.println(emp.getName() + " has a tenure of " + tenure + " years.");
            if (tenure >= 10) {
                System.out.println(emp.getName() + " is eligible for long service award.");
            }
        }
    }

 
    public static void main(String[] args) {
        EmployeeManager manager = new EmployeeManager();
        Scanner sc = new Scanner(System.in);

        
        manager.addDepartment(1, "Marketing");
        manager.addDepartment(2, "IT");
        manager.addDepartment(3, "Sales");
        manager.addDepartment(4, "HR");

        
        manager.addEmployee(1, "Nikhil", "Manager", 70000, 1, "10-01-2020");
        manager.addEmployee(2, "Ajay", "Developer", 20000, 2, "03-05-2019");
        manager.addEmployee(3, "Jaydeep", "Salesman", 6000, 3, "25-09-2022");
        manager.addEmployee(4, "Shubham", "Tester", 10000, 2, "28-02-2023");
        manager.addEmployee(5, "Mahima", "HR", 20000, 4, "23-03-2018");

       
        while (true) {
            System.out.println("\n--- Employee Management System ---");
            System.out.println("1. Calculate Total Salary Expenditure");
            System.out.println("2. Find Highest and Lowest Salary");
            System.out.println("3. Calculate Average Salary by Department");
            System.out.println("4. Calculate Employee Tenure");
            System.out.println("5. Exit");
            System.out.print("Choose an option: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    manager.calculateTotalSalaryExpenditure();
                    break;
                case 2:
                    manager.findHighestAndLowestSalary();
                    break;
                case 3:
                    manager.calculateAverageSalaryByDepartment();
                    break;
                case 4:
                    manager.calculateEmployeeTenure();
                    break;
                case 5:
                    System.out.println("Thank You!");
                    System.exit(0);
                default:
                    System.out.println("Please try again.");
            }
        }
    }
}
