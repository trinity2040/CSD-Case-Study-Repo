import java.util.Date;
import java.util.List;

class Order {
    private int id;
    private List<CartItem> items;
    private Date orderDate;
    private double totalPrice;
    private String status;

    

    public Order(int id, List<CartItem> items, java.util.Date date, double totalPrice, String status) {
        this.id = id;
        this.items = items;
        this.orderDate = date;
        this.totalPrice = totalPrice;
        this.status = status;
    }

    
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public List<CartItem> getItems() {
        return items;
    }
    public void setItems(List<CartItem> items) {
        this.items = items;
    }
    public Date getOrderDate() {
        return orderDate;
    }
    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }
    public double getTotalPrice() {
        return totalPrice;
    }
    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    @Override
    public String toString() {
        return "Order [id=" + id + ", items=" + items + ", orderDate=" + orderDate + ", totalPrice=" + totalPrice
                + ", status=" + status + "]";
    }    
}
