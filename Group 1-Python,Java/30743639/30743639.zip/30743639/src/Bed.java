class Bed {
    private int bedNumber;
    private boolean occupied;

    Bed(int bedNumber) {
        this.bedNumber = bedNumber;
        this.occupied = false; 
    }


    public int getBedNumber() {
        return bedNumber;
    }

    public boolean isOccupied() {
        return occupied;
    }


    public void setBedNumber(int bedNumber) {
        this.bedNumber = bedNumber;
    }

    public void setOccupied(boolean occupied) {
        this.occupied = occupied;
    }

    @Override
    public String toString() {
        return "Bed{" +
                "bedNumber=" + bedNumber +
                ", occupied=" + occupied +
                '}';
    }
}
