import java.util.Date;
import java.util.HashMap;
import java.util.Scanner;
public class HospitalManager {
    private HashMap<Integer, Patient> patients = new HashMap<>();
    private HashMap<Integer, Bed> beds = new HashMap<>();
    private static int nextId = 1;

    public HospitalManager(int numberOfBeds) {
        for (int i = 1; i <= numberOfBeds; i++) {
            beds.put(i, new Bed(i));
        }
    }

    private static int generateNextId() {
        return nextId++;
    }
    
    public void admitPatient(Patient p, int bedNumber) throws Exception {
        Bed bed = beds.get(bedNumber);
        
        while (bed == null) {
            System.out.println("Bed number " + bedNumber + " does not exist.");
            System.out.println("Available bed numbers: " + beds.keySet());
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter a valid bed number: ");
            bedNumber = scanner.nextInt();
            bed = beds.get(bedNumber);
            scanner.close();
        }
        
        while (bed.isOccupied()) {
            System.out.println("Bed number " + bedNumber + " is already occupied.");
            System.out.println("Available bed numbers: ");
            for (int num : beds.keySet()) {
                Bed b = beds.get(num);
                if (!b.isOccupied()) {
                    System.out.print(num + " ");
                }
            }
            System.out.println();
            Scanner scanner = new Scanner(System.in);
            System.out.print("Enter a new bed number: ");
            bedNumber = scanner.nextInt();
            bed = beds.get(bedNumber);
            scanner.close();
            
            while (bed == null) {
                System.out.println("Bed number " + bedNumber + " does not exist.");
                System.out.println("Available bed numbers: " + beds.keySet());
                System.out.print("Enter a valid bed number: ");
                bedNumber = scanner.nextInt();
                bed = beds.get(bedNumber);
            }
        } 
        patients.put(p.getId(), p);
        bed.setOccupied(true);
    }
    
    

    public void dischargePatient(int patientId) throws Exception {
        Patient p = patients.get(patientId);
        if (p == null) {
            throw new Exception("Patient not found.");
        }
        p.setDischargeDate((new Date()));
        for (int bedNumber : beds.keySet()) {
            if (beds.get(bedNumber).isOccupied()) {
                beds.get(bedNumber).setOccupied(false);
                break;
            }
        }
        //patients.remove(patientId);
    }

    public void updatePatientDetails(int patientId, Patient updatedPatient) throws Exception {
        if (!patients.containsKey(patientId)) {
            throw new Exception("Patient not found.");
        }
        patients.put(patientId, updatedPatient);
    }

    public Patient searchPatient(int patientId) {
        return patients.get(patientId);
    }

    public Patient searchPatientByKeyword(String keyword) {
        for (Patient p : patients.values()) {
            if (p.getName().toLowerCase().contains(keyword.toLowerCase()) ||
                p.getDiagnosis().toLowerCase().contains(keyword.toLowerCase())) {
                return p;
            }
        }
        return null;
    }
    
    public void assignBed(int patientId, int bedNumber) throws Exception {
        if (!patients.containsKey(patientId)) {
            throw new Exception("Patient not found.");
        }
        if (beds.get(bedNumber).isOccupied()) {
            throw new Exception("Bed is already occupied.");
        }
        beds.get(bedNumber).setOccupied(true);
    }

   public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of beds in the hospital:");
        int numberOfBeds = scanner.nextInt();
        HospitalManager hospitalManager = new HospitalManager(numberOfBeds);

        while (true) {
            System.out.println("\nHospital Management System");
            System.out.println("1. Admit Patient");
            System.out.println("2. Discharge Patient");
            System.out.println("3. Update Patient Details");
            System.out.println("4. Search Patient");
            System.out.println("5. Assign Bed");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            int choice = 0;
            boolean validChoice = false;

            while (!validChoice) {
                try {
                    choice = scanner.nextInt();
                    if (choice >= 1 && choice <= 6) {
                        validChoice = true;
                    } else {
                        System.out.print("Invalid choice. Please enter a number between 1 and 6: ");
                    }
                } catch (Exception e) {
                    System.out.print("Invalid input. Please enter a number between 1 and 6: ");
                    scanner.next(); // Clear the invalid input
                }
            }

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter patient name: ");
                        scanner.nextLine();
                        String name = scanner.nextLine();
                        while (name == null || name.trim().isEmpty()) {
                            System.out.print("Name cannot be empty. Enter patient name: ");
                            name = scanner.nextLine();
                        }
                        
                        System.out.print("Enter patient age: ");
                        int age = 0;
                        while (true) {
                            try {
                                age = Integer.parseInt(scanner.nextLine());
                                if (age > 0) break;
                                else System.out.print("Age must be a positive number. Enter patient age: ");
                            } catch (NumberFormatException e) {
                                System.out.print("Invalid input. Enter patient age: ");
                            }
                        }
                        
                        System.out.print("Enter patient gender: ");
                        String gender = scanner.nextLine();
                        while (gender == null || gender.trim().isEmpty()) {
                            System.out.print("Gender cannot be empty. Enter patient gender: ");
                            gender = scanner.nextLine();
                        }
                        
                        System.out.print("Enter patient diagnosis: ");
                        String diagnosis = scanner.nextLine();
                        while (diagnosis == null || diagnosis.trim().isEmpty()) {
                            System.out.print("Diagnosis cannot be empty. Enter patient diagnosis: ");
                            diagnosis = scanner.nextLine();
                        }
                        
                        System.out.print("Enter patient treatment: ");
                        String treatment = scanner.nextLine();
                        while (treatment == null || treatment.trim().isEmpty()) {
                            System.out.print("Treatment cannot be empty. Enter patient treatment: ");
                            treatment = scanner.nextLine();
                        }
                        System.out.print("Enter Bed Number:");
                        int bedNumber = scanner.nextInt();
                        Date admissionDate = new Date();
                        Patient patient = new Patient(generateNextId(),name, age, gender, diagnosis, treatment, admissionDate);
                        hospitalManager.admitPatient(patient, bedNumber);
                        System.out.println("Patient admitted successfully.");
                        break;

                    case 2:
                        System.out.println("Enter Patient ID to discharge:");
                        int dischargeId = scanner.nextInt();
                        hospitalManager.dischargePatient(dischargeId);
                        System.out.println("Patient discharged successfully.");
                        break;

                    case 3:
                        System.out.println("Enter Patient ID to update:");
                        int updateId = scanner.nextInt();
                        scanner.nextLine(); 
                        if (hospitalManager.searchPatient(updateId) == null) {
                            System.out.println("Patient not found.");
                            break;
                        }
                        Patient existingPatient = hospitalManager.searchPatient(updateId);

                        System.out.println("Which details would you like to change?");
                        System.out.println("1. Name");
                        System.out.println("2. Age");
                        System.out.println("3. Gender");
                        System.out.println("4. Diagnosis");
                        System.out.println("5. Treatment");
                        System.out.print("Enter your choice (comma-separated for multiple options): ");
                        String[] options = scanner.nextLine().split(",");

                        for (String option : options) {
                            int choiceOption = Integer.parseInt(option.trim());
                            switch (choiceOption) {
                                case 1:
                                    System.out.println("Enter Updated Patient Name:");
                                    String updatedName = scanner.nextLine();
                                    existingPatient.setName(updatedName);
                                    break;
                                case 2:
                                    System.out.println("Enter Updated Patient Age:");
                                    int updatedAge = scanner.nextInt();
                                    scanner.nextLine(); // Consume newline
                                    existingPatient.setAge(updatedAge);
                                    break;
                                case 3:
                                    System.out.println("Enter Updated Patient Gender:");
                                    String updatedGender = scanner.nextLine();
                                    existingPatient.setGender(updatedGender);
                                    break;
                                case 4:
                                    System.out.println("Enter Updated Patient Diagnosis:");
                                    String updatedDiagnosis = scanner.nextLine();
                                    existingPatient.setDiagnosis(updatedDiagnosis);
                                    break;
                                case 5:
                                    System.out.println("Enter Updated Patient Treatment:");
                                    String updatedTreatment = scanner.nextLine();
                                    existingPatient.setTreatment(updatedTreatment);
                                    break;
                                default:
                                    System.out.println("Invalid option: " + choiceOption);
                                    break;
                            }
                        }
                        hospitalManager.updatePatientDetails(updateId, existingPatient);
                        System.out.println("Patient details updated successfully.");
                        break;

                    case 4:
                        System.out.println("Enter keyword to search for patient (name or diagnosis):");
                        scanner.nextLine(); 
                        String keyword = scanner.nextLine();
                        Patient foundPatient = hospitalManager.searchPatientByKeyword(keyword);
                        if (foundPatient != null) {
                            System.out.println("Patient found: " + foundPatient);
                        } else {
                            System.out.println("No patient found with the given keyword.");
                        }
                        break;
                    case 5:
                        System.out.println("Enter Patient ID to assign bed:");
                        int assignId = scanner.nextInt();
                        System.out.println("Enter Bed Number to assign:");
                        int assignBedNumber = scanner.nextInt();
                        hospitalManager.assignBed(assignId, assignBedNumber);
                        System.out.println("Bed assigned successfully.");
                        break;

                    case 6:
                        System.out.println("Exiting...");
                        scanner.close();
                        return;

                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

}
