import java.util.HashMap;
import java.util.Map;

public class SchoolManagementSystem {
    private Map<Integer, Student> students;
    private Map<Integer, Teacher> teachers;
    private Map<Integer, Course> courses;

    public SchoolManagementSystem() {
        students = new HashMap<>();
        teachers = new HashMap<>();
        courses = new HashMap<>();
    }

    // Student Management
    public void addStudent(Student student) {
        students.put(student.getId(), student);
        System.out.println("Student added: " + student);
    }

    public void removeStudent(int studentId) {
        if (students.containsKey(studentId)) {
            students.remove(studentId);
            System.out.println("Student removed with ID: " + studentId);
        } else {
            System.out.println("Student with ID " + studentId + " not found.");
        }
    }

    public void updateStudent(int studentId, Student updatedStudent) {
        if (students.containsKey(studentId)) {
            students.put(studentId, updatedStudent);
            System.out.println("Student updated: " + updatedStudent);
        } else {
            System.out.println("Student with ID " + studentId + " not found.");
        }
    }
    
    // Get all student
    public Map<Integer, Student> getStudents() {
        return students;
    }

    // Teacher Management
    public void addTeacher(Teacher teacher) {
        teachers.put(teacher.getId(), teacher);
        System.out.println("Teacher added: " + teacher);
    }

    public void removeTeacher(int teacherId) {
        if (teachers.containsKey(teacherId)) {
            teachers.remove(teacherId);
            System.out.println("Teacher removed with ID: " + teacherId);
        } else {
            System.out.println("Teacher with ID " + teacherId + " not found.");
        }
    }

    public void updateTeacher(int teacherId, Teacher updatedTeacher) {
        if (teachers.containsKey(teacherId)) {
            teachers.put(teacherId, updatedTeacher);
            System.out.println("Teacher updated: " + updatedTeacher);
        } else {
            System.out.println("Teacher with ID " + teacherId + " not found.");
        }
    }

    // Course Management
    public void addCourse(Course course) {
        courses.put(course.getId(), course);
        System.out.println("Course added: " + course);
    }

    public void removeCourse(int courseId) {
        if (courses.containsKey(courseId)) {
            courses.remove(courseId);
            System.out.println("Course removed with ID: " + courseId);
        } else {
            System.out.println("Course with ID " + courseId + " not found.");
        }
    }

    public void assignStudentToCourse(int studentId, int courseId) {
        if (students.containsKey(studentId) && courses.containsKey(courseId)) {
            Course course = courses.get(courseId);
            course.addStudent(studentId);
            System.out.println("Student with ID " + studentId + " assigned to course ID " + courseId);
        } else {
            System.out.println("Invalid student or course ID.");
        }
    }

    public void assignTeacherToCourse(int teacherId, int courseId) {
        if (teachers.containsKey(teacherId) && courses.containsKey(courseId)) {
            Course course = courses.get(courseId);
            course.setTeacherId(teacherId);
            System.out.println("Teacher with ID " + teacherId + " assigned to course ID " + courseId);
        } else {
            System.out.println("Invalid teacher or course ID.");
        }
    }
}
