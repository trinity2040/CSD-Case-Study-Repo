import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Course {
    private int id;
    private String name;
    private int teacherId;
    private List<Integer> studentIds;

    public Course(int id, String name, int teacherId) {
        this.id = id;
        this.name = name;
        this.teacherId = teacherId;
        this.studentIds = new ArrayList<>();
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTeacherId() {
        return teacherId;
    }

    public void setTeacherId(int teacherId) {
        this.teacherId = teacherId;
    }

    public List<Integer> getStudentIds() {
        return studentIds;
    }

    public void addStudent(int studentId) {
        this.studentIds.add(studentId);
    }

    public void removeStudent(int studentId) {
        this.studentIds.remove(Integer.valueOf(studentId));
    }

    @Override
    public String toString() {
        return "Course [ID=" + id + ", Name=" + name + ", Teacher ID=" + teacherId + ", Student IDs=" + studentIds + "]";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Course course = (Course) o;
        return id == course.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
