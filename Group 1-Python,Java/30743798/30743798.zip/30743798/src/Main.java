import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        SchoolManagementSystem sms = new SchoolManagementSystem();
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("School Management System");
            System.out.println("1. Add Student");
            System.out.println("2. Remove Student");
            System.out.println("3. Update Student");
            System.out.println("4. Add Teacher");
            System.out.println("5. Remove Teacher");
            System.out.println("6. Update Teacher");
            System.out.println("7. Add Course");
            System.out.println("8. Remove Course");
            System.out.println("9. Assign Student to Course");
            System.out.println("10. Assign Teacher to Course");
            System.out.println("11. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter student ID: ");
                    int studentId = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Enter student name: ");
                    String studentName = scanner.nextLine();
                    System.out.print("Enter student grade: ");
                    int studentGrade = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Enter student contact number: ");
                    String studentContact = scanner.nextLine();
                    Student student = new Student(studentId, studentName, studentGrade, studentContact);
                    sms.addStudent(student);
                    break;
                case 2:
                    System.out.print("Enter student ID to remove: ");
                    studentId = scanner.nextInt();
                    sms.removeStudent(studentId);
                    break;
                case 3:
                    System.out.print("Enter student ID to update: ");
                    studentId = scanner.nextInt();
                    scanner.nextLine(); 
                    if (sms.getStudents().containsKey(studentId)) {
                        System.out.print("Enter new student name: ");
                        studentName = scanner.nextLine();
                        System.out.print("Enter new student grade: ");
                        studentGrade = scanner.nextInt();
                        scanner.nextLine(); 
                        System.out.print("Enter new student contact number: ");
                        studentContact = scanner.nextLine();
                        Student updatedStudent = new Student(studentId, studentName, studentGrade, studentContact);
                        sms.updateStudent(studentId, updatedStudent);
                    } else {
                        System.out.println("Error: Student with ID " + studentId + " not found. Cannot update.");
                    }
                    break;

                case 4:
                    System.out.print("Enter teacher ID: ");
                    int teacherId = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Enter teacher name: ");
                    String teacherName = scanner.nextLine();
                    System.out.print("Enter subject taught: ");
                    String teacherSubject = scanner.nextLine();
                    System.out.print("Enter teacher contact number: ");
                    String teacherContact = scanner.nextLine();
                    Teacher teacher = new Teacher(teacherId, teacherName, teacherSubject, teacherContact);
                    sms.addTeacher(teacher);
                    break;
                case 5:
                    System.out.print("Enter teacher ID to remove: ");
                    teacherId = scanner.nextInt();
                    sms.removeTeacher(teacherId);
                    break;
                case 6:
                    System.out.print("Enter teacher ID to update: ");
                    teacherId = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Enter new teacher name: ");
                    teacherName = scanner.nextLine();
                    System.out.print("Enter new subject taught: ");
                    teacherSubject = scanner.nextLine();
                    System.out.print("Enter new teacher contact number: ");
                    teacherContact = scanner.nextLine();
                    Teacher updatedTeacher = new Teacher(teacherId, teacherName, teacherSubject, teacherContact);
                    sms.updateTeacher(teacherId, updatedTeacher);
                    break;
                case 7:
                    System.out.print("Enter course ID: ");
                    int courseId = scanner.nextInt();
                    scanner.nextLine(); 
                    System.out.print("Enter course name: ");
                    String courseName = scanner.nextLine();
                    System.out.print("Enter teacher ID for the course: ");
                    teacherId = scanner.nextInt();
                    Course course = new Course(courseId, courseName, teacherId);
                    sms.addCourse(course);
                    break;
                case 8:
                    System.out.print("Enter course ID to remove: ");
                    courseId = scanner.nextInt();
                    sms.removeCourse(courseId);
                    break;
                case 9:
                    System.out.print("Enter student ID to assign: ");
                    studentId = scanner.nextInt();
                    System.out.print("Enter course ID to assign to: ");
                    courseId = scanner.nextInt();
                    sms.assignStudentToCourse(studentId, courseId);
                    break;
                case 10:
                    System.out.print("Enter teacher ID to assign: ");
                    teacherId = scanner.nextInt();
                    System.out.print("Enter course ID to assign to: ");
                    courseId = scanner.nextInt();
                    sms.assignTeacherToCourse(teacherId, courseId);
                    break;
                case 11:
                    running = false;
                    System.out.println("Exiting the system...");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        }

        scanner.close();
    }
}
