
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.text.SimpleDateFormat;
import java.util.*;

public class RestaurantManager {

    // HASHMAP USE HERE AS A IN MEMORY DATA IF USER ADD DATA RECENTLY IT WILL ADD IN HASHMAP
    private HashMap<Integer,MenuItem> menuItems = new HashMap<>();


    private ArrayList<Order> ordersList = new ArrayList<>();
    private int nextOrderId = 1;

    // MENU ITEMS IS ADDED IN THE IN-MEMORY AS WELL AS IN PERSITENT MEMORY THAT IS (MENUITEM.TXT)
    public void addMenuItems(MenuItem items){
       menuItems.put(items.getItemId(),items);
        updateMenuFileWithCategory(items);
       System.out.println("Item is Added into Menu!!! "+ items);
    }

    // MENU ITEM IS ADDED IN THE PERSITENT MEMORY
    private void updateMenuFileWithCategory(MenuItem newItem) {
        String filename = "menuItems.txt";
        Map<String, List<MenuItem>> categorizedItems = new TreeMap<>(); // TREE MAP TO MAKE THE CATEGORIES IN THE SORTED FORM

        // TAKING DATA FROM THE EXISTING MENUITEM.TXT
        try {
            List<String> lines = Files.readAllLines(Paths.get(filename));
            for (String line : lines) {
                String[] parts = line.split(": ");
                if (parts.length == 2) {
                    String category = parts[0];
                    String[] itemParts = parts[1].split(", ");
                    int id = Integer.parseInt(itemParts[0].split("=")[1]);
                    String name = itemParts[1].split("=")[1];
                    double price = Double.parseDouble(itemParts[3].split("=")[1]);
                    boolean available = Boolean.parseBoolean(itemParts[3].split("=")[1]);
                    MenuItem item = new MenuItem(id, name, category, price, available);

                    categorizedItems.computeIfAbsent(category, k -> new ArrayList<>()).add(item);
                }
            }
        } catch (IOException e) {
            System.out.println("File not found or empty. Creating new file.");
        }

        // ADD NEW ITEM TO APPRORIATE CATEGORY
        categorizedItems.computeIfAbsent(newItem.getItemCategory(), k -> new ArrayList<>()).add(newItem);

        // WRITE THE CATEGORY ITEM BACK TO FILE
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Map.Entry<String, List<MenuItem>> entry : categorizedItems.entrySet()) {
                String category = entry.getKey();
                for (MenuItem item : entry.getValue()) {
                    writer.write(category + ": " + item.toString() + "\n");
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file.");
            e.printStackTrace();
        }
    }


    // REMOVING ITEM FROM BOTH THE HASHMAP(IN-MEMORY) AND THE MENUITEM.TXT FILE....
    public void removeMenuItems(int itemId){
        MenuItem removeMenuItem = menuItems.remove(itemId);
        if (removeMenuItem != null) {
            System.out.println("Menu item found and removed from in memory and from persistent memory: " + removeMenuItem);
            updateMenuFileAfterRemoval(removeMenuItem);
        } else {
            // IF NOT FOUND IN IN-MEMORY THAN DIRECTLY GO TO THE MENUITEM.TXT FILE
            System.out.println("Menu item not found in HashMap. Checking the file...");
            boolean removedFromFile = updateMenuFileDirectRemoval(itemId);
            if (removedFromFile) {
                System.out.println("Menu item removed from file.");
            } else {
                System.out.println("Menu item not found in the file.");
            }
        }
    }

    // REMOVING THE ITEM FROM THE FILE TOO IF FOUND IN THE CURRENT MENU ITEM LIST
    private void updateMenuFileAfterRemoval(MenuItem removedItem) {
        String filename = "menuItems.txt";
        List<String> remainingItems = new ArrayList<>();


        try {
            List<String> lines = Files.readAllLines(Paths.get(filename));
            for (String line : lines) {
                if (!line.contains("itemId=" + removedItem.getItemId())) {
                    remainingItems.add(line);
                }
            }


            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
                for (String item : remainingItems) {
                    writer.write(item + "\n");
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while updating the file.");
            e.printStackTrace();
        }
    }
//  REMOVING THE ITEM IF IT IS NOT FOUND IN CURRENT MENU LIST BUT FOUND IN MENU ITEMS STORE INTO FILE
    private boolean updateMenuFileDirectRemoval(int itemId) {
        String filename = "menuItems.txt";
        boolean itemRemoved = false;
        List<String> remainingItems = new ArrayList<>();

        try {
            List<String> lines = Files.readAllLines(Paths.get(filename));
            for (String line : lines) {
                if (line.contains("itemId=" + itemId)) {
                    itemRemoved = true;
                } else {
                    remainingItems.add(line);
                }
            }


            if (itemRemoved) {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
                    for (String item : remainingItems) {
                        writer.write(item + "\n");
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while updating the file.");
            e.printStackTrace();
        }

        return itemRemoved;
    }


// UPDATE THE MENU ITEM IN THE IN-MEMORY AND IN THE PERSISTENT MEMORY THAT IS MENUITEM.TXT
    public void updateMenuItem(int itemId, MenuItem updatedItem) {
        MenuItem existingItem = menuItems.get(itemId);

        if (existingItem != null) {

            menuItems.put(itemId, updatedItem);
            System.out.println("Menu item found and updated in in-memory and in persistent memory: " + updatedItem);

            updateMenuFile(updatedItem);
        } else {

            System.out.println("Menu item not found in in-memory. Checking the file...");
            boolean updatedInFile = updateMenuFileDirectUpdate(itemId, updatedItem);
            if (updatedInFile) {
                System.out.println("Menu item updated in file.");
            } else {
                System.out.println("Menu item not found in the file.");
            }
        }
    }

    // UPDATE IN THE PERSISTENT MEMORY
    private void updateMenuFile(MenuItem updatedItem) {
        String filename = "menuItems.txt";
        List<String> updatedItems = new ArrayList<>();

        try {
            List<String> lines = Files.readAllLines(Paths.get(filename));
            for (String line : lines) {
                if (line.contains("itemId=" + updatedItem.getItemId())) {
                    updatedItems.add(formatMenuItemForFile(updatedItem));
                } else {
                    updatedItems.add(line);
                }
            }


            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
                for (String item : updatedItems) {
                    writer.write(item + "\n");
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while updating the file.");
            e.printStackTrace();
        }
    }

    // UPDATE THE FILE DIRECTLY IF NOT FOUND IN THE IN-MEMORY
    private boolean updateMenuFileDirectUpdate(int itemId, MenuItem updatedItem) {
        String filename = "menuItems.txt";
        boolean itemUpdated = false;
        List<String> updatedItems = new ArrayList<>();

        try {
            List<String> lines = Files.readAllLines(Paths.get(filename));
            for (String line : lines) {
                if (line.contains("itemId=" + itemId)) {
                    updatedItems.add(formatMenuItemForFile(updatedItem));
                    itemUpdated = true;
                } else {
                    updatedItems.add(line);
                }
            }

            // WRITE THE UPDATE ITEM BACK INTO THE FILE
            if (itemUpdated) {
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
                    for (String item : updatedItems) {
                        writer.write(item + "\n");
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while updating the file.");
            e.printStackTrace();
        }

        return itemUpdated;
    }

    // HELPER METHOD TO FORMATE THE ITEM IN THE MENUITEM.TXT
    private String formatMenuItemForFile(MenuItem item) {
        return item.getItemCategory() + ": MenuItem{itemId=" + item.getItemId() +
                ", itemCategory='" + item.getItemCategory() +
                "', itemName='" + item.getItemName() +
                "', itemPrice=" + item.getItemPrice() +
                ", itemAvailability=" + item.isItemAvailaibility() + "}";
    }


// SEARCHINT MENU ITEM IN THE IN-MEMORY AND IN THE PERSISTENT MEMORY
    public void searchMenuItems(String itemName){
        boolean found = false;


        System.out.println("Searching in in-memory data...");
        for (MenuItem item : menuItems.values()) {
            if (item.getItemName().toLowerCase().contains(itemName.toLowerCase()) ||
                    item.getItemCategory().toLowerCase().contains(itemName.toLowerCase())) {
                System.out.println("Found in in-memory data: " + item);
                found = true;
            }
        }

        System.out.println("Searching in persistent data (menuItems.txt)...");
        try {
            List<String> lines = Files.readAllLines(Paths.get("menuItems.txt"));
            for (String line : lines) {
                if (line.toLowerCase().contains(itemName.toLowerCase())) {
                    System.out.println("Found in menuItems.txt: " + line);
                    found = true;
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }

        if (!found) {
            System.out.println("No menu items found matching the itemName: " + itemName);
        }
    }


// PLACING ORDER BY TAKING OUR THE ITEMS FROM THE IN-MEMORY AND PERSISTENT MEMORY
    public void placeOrder(int itemId, int quantity){
        Date date = new Date();
        MenuItem item = menuItems.get(itemId);

        if (item == null) {


            item = searchMenuItemInFile(itemId);
        }

        if (item != null && item.isItemAvailaibility()) {
            if (quantity > 0) {

                Order order = new Order(ordersList.size() + 1, item, quantity, date, "pending");
                ordersList.add(order);
                System.out.println("Order placed: " + order);


                item.setItemAvailaibility(false);
                updateMenuItemInFile(itemId, item);
            } else {
                System.out.println("Invalid quantity. Order cannot be placed.");
            }
        } else {
            System.out.println("Menu item not available.");
        }
    }

// PROCESSING ORDER AFTER THE PLACING ORDER TAKING OUT THE DETAILS FROM THE ORDERLIST ARRAYLIST
    public void processingOrder(int orderId){
        Optional<Order> orderOpt = ordersList.stream().filter(o -> o.getOrderId() == orderId).findFirst();
        if (orderOpt.isPresent()) {
            Order order = orderOpt.get();
            MenuItem item = menuItems.get(order.getItemId().getItemId());

            if (item == null) {

                item = searchMenuItemInFile(order.getOrderId());
            }

            if (item != null) {
                order.setStatus("processed");
                System.out.println("Order processed: " + order);


                item.setItemAvailaibility(true);
                updateMenuItemInFile(item.getItemId(), item);
            } else {
                System.out.println("Menu item not found for the order.");
            }
        } else {
            System.out.println("Order not found.");
        }

    }
// HELPER METHOD TO SEARCH MENU ITEM INTO FILE
    private MenuItem searchMenuItemInFile(int itemId) {
        try {
            List<String> lines = Files.readAllLines(Paths.get("menuItems.txt"));
            for (String line : lines) {
                if (line.contains("itemId=" + itemId)) {

                    return parseMenuItemFromLine(line);
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }
        return null;
    }

    // Helper method to parse a MenuItem from a line of text
    private MenuItem parseMenuItemFromLine(String line) {
        String[] parts = line.split(",");
        int id = Integer.parseInt(parts[0].split("=")[1]);
        String category = parts[1].split("=")[1].replace("'", "").trim();
        String name = parts[2].split("=")[1].replace("'", "").trim();
        double price = Double.parseDouble(parts[3].split("=")[1]);
        boolean available = Boolean.parseBoolean(parts[4].split("=")[1].replace("}", "").trim());



        return new MenuItem(id, category, name, price, available);
    }

    // HELPER METHOD TO UPDATE THE MENU ITEM IN FILE
    private void updateMenuItemInFile(int itemId, MenuItem updatedItem) {
        try {
            List<String> lines = Files.readAllLines(Paths.get("menuItems.txt"));
            List<String> updatedLines = new ArrayList<>();

            for (String line : lines) {
                if (line.contains("itemId=" + itemId)) {
                    updatedLines.add(updatedItem.getItemCategory() + ": " + updatedItem.toString());
                } else {
                    updatedLines.add(line);
                }
            }

            Files.write(Paths.get("menuItems.txt"), updatedLines, StandardOpenOption.TRUNCATE_EXISTING);
        } catch (IOException e) {
            System.out.println("An error occurred while updating the file.");
            e.printStackTrace();
        }
    }

    // ADDITIONAL METHOD TO GENRATE THE BILL ORDER WISE
    public void generateBill(int orderId) {
        Optional<Order> orderOpt = ordersList.stream().filter(o -> o.getOrderId() == orderId).findFirst();
        if (orderOpt.isPresent()) {
            Order order = orderOpt.get();
            MenuItem item = menuItems.get(order.getItemId().getItemId());

            if (item == null) {

                item = searchMenuItemInFile(order.getItemId().getItemId());
            }

            if (item != null) {
                double totalAmount = item.getItemPrice() * order.getQuantity();


                System.out.println("===== Bill =====");
                System.out.println("Order ID: " + orderId);
                System.out.println("Item Name: " + item.getItemName());
                System.out.println("Quantity: " + order.getQuantity());
                System.out.println("Price per Item: " + item.getItemPrice());
                System.out.println("Total Amount: " + totalAmount);
                System.out.println("Order Time: " + new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(order.getOrderTime()));
                System.out.println("================");
            } else {
                System.out.println("Menu item not found for the order.");
            }
        } else {
            System.out.println("Order not found.");
        }
    }

// HELPER METHOD FOR HANDLING EXCEPTOINS

    public String helper(){
        return "SOMETHING WENT WRONG PLEASE CHECK WHETHER THE INPUT IS CORRECT OR NOT!!";
    }
}
