import java.time.LocalDateTime;
import java.util.Date;

public class Order {
    private int orderId;
    private MenuItem itemId;
    private int quantity;
    private Date orderTime;
    private String status; //pending, prepared, ready, status;

    public Order(int orderId, MenuItem itemId, int quantity, Date orderTime, String status) {
        this.orderId = orderId;
        this.itemId = itemId;
        this.quantity = quantity;
        this.orderTime = orderTime;
        this.status = status;
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public MenuItem getItemId() {
        return itemId;
    }

    public void setItemId(MenuItem itemId) {
        this.itemId = itemId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public Date getOrderTime() {
        return orderTime;
    }

    public void setOrderTime(Date orderTime) {
        this.orderTime = orderTime;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderId=" + orderId +
                ", itemId=" + itemId +
                ", quantity=" + quantity +
                ", orderTime=" + orderTime +
                ", status='" + status + '\'' +
                '}';
    }
}
