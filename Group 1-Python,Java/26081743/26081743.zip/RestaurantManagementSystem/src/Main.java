import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.Security;
import java.util.*;

public class Main {

    // METHOD TO SHOW ALL CATEGORY SAVED IN THE PERSISTENT MEMORY

    public static void showCategory(){
        String filename = "menuItems.txt";
        Map<Integer, String> categoryMap = new HashMap<>();
        Set<String> categories = new HashSet<>();
        int categoryNumber = 1;

        try {

            List<String> lines = Files.readAllLines(Paths.get(filename));


            for (String line : lines) {
                if (!line.trim().isEmpty()) {
                    String category = extractCategoryFromLine(line);
                    if (category != null && !category.isEmpty() && categories.add(category)) {
                        categoryMap.put(categoryNumber++, category);
                    }
                }
            }


            if (!categoryMap.isEmpty()) {
                System.out.println("Select a Category:");
                for (Map.Entry<Integer, String> entry : categoryMap.entrySet()) {
                    System.out.println("    "+entry.getKey() + ". " + entry.getValue());
                }


                Scanner scanner = new Scanner(System.in);
                int selectedNumber = scanner.nextInt();


                if (categoryMap.containsKey(selectedNumber)) {
                    String selectedCategory = categoryMap.get(selectedNumber);
                    System.out.println("        Menu Items in Category '" + selectedCategory + "':");
                    for (String line : lines) {
                        if (line.startsWith(selectedCategory + ":")) {
                            System.out.println("        "+line.substring(line.indexOf(':') + 1).trim());
                        }
                    }
                } else {
                    System.out.println("Invalid selection. Please try again.");
                }
            } else {
                System.out.println("No categories found in the menu.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }
    }

    // HELPER METHOD TO EXTRACT THE CATEGORY FROM THE LINE
    private static String extractCategoryFromLine(String line) {
        int colonIndex = line.indexOf(":");
        if (colonIndex != -1) {
            return line.substring(0, colonIndex).trim();
        }
        return null;
    }


//  MAIN METHOD WHERE ALL MENU BASED OPERATION IS  PERFORM
    public static void main(String[] args) {
        RestaurantManager restaurantManager = new RestaurantManager();
        Scanner scanner = new Scanner(System.in);

        while(true)
        {

          System.out.println("\nWelcome to Shubhendu's Restaurent Management System !!");
          System.out.println("Are you a....?");
          System.out.println("Type Code 001 for the Customer");
          System.out.println("Type Code 002 for the Employee");

          try {
              int code = scanner.nextInt();
              if (code == 1) {
                  while (true) {
                      System.out.println("1. Want to see the menu card ");
                      System.out.println("2. Search the item by Name ");
                      System.out.println("3. Place Order");
                      System.out.println("4. Prcess Order");
                      System.out.println("5. To take out the bill");
                      System.out.println("6. Exiting...");

                      try {
                          int choices = scanner.nextInt();


                          switch (choices) {
                              case 1:
                                  showCategory();
                                  break;

                              case 2:
                                  System.out.println("Enter the name of Item to get the details");

                                  try {
                                      String itemName = scanner.next();
                                      scanner.nextLine();
                                      restaurantManager.searchMenuItems(itemName);

                                  } catch (Exception e) {
                                      restaurantManager.helper();

                                  }

                                  break;

                              case 3:
                                  System.out.println("Enter the menu item id to Order: ");
                                  int orderId = scanner.nextInt();
                                  System.out.println("Enter the Quantity");
                                  int quantity = scanner.nextInt();
                                  restaurantManager.placeOrder(orderId, quantity);
                                  break;

                              case 4:
                                  System.out.println("Enter the Order Id to Process");
                                  int processOrderId = scanner.nextInt();
                                  restaurantManager.processingOrder(processOrderId);
                                  break;

                              case 5:
//                          make the bill method here
                                  System.out.println("Enter the order id to genrate the bill");
                                  int orderIdbill = scanner.nextInt();

                                  restaurantManager.generateBill(orderIdbill);
                                  break;

                              case 6:
                                  return;
                              default:
                                  System.out.println(restaurantManager.helper());
                                  break;
                          }


                      } catch (Exception e) {
                         System.out.println(restaurantManager.helper());
                         scanner.next();

                      }

                  }
              } else if (code == 2) {
                  while (true) {
                      System.out.println("1. Add Menu Item");
                      System.out.println("2. Remove Menu Item");
                      System.out.println("3. Update Menu Item");
                      System.out.println("4. Exit");

                      try {


                          int choices = scanner.nextInt();

                          switch (choices) {
                              case 1:
                                  System.out.println("Enter the Item id");
                                  int itemId = scanner.nextInt();
                                  scanner.nextLine();
                                  System.out.println("Enter name of item");
                                  String itemName = scanner.nextLine();
                                  System.out.println("Enter category of item");
                                  String itemCategory = scanner.nextLine();
                                  System.out.println("Enter price of item");
                                  double itemPrice = scanner.nextDouble();
                                  System.out.println("Enter Availaibility of item (true/false)");
                                  boolean isItemAvailaible = scanner.nextBoolean();
                                  MenuItem mi = new MenuItem(itemId, itemName, itemCategory, itemPrice, isItemAvailaible);

                                  restaurantManager.addMenuItems(mi);
                                  break;

                              case 2:
                                  System.out.println("Enter the Menu Item Id to Remove");
                                  int removeId = scanner.nextInt();
                                  restaurantManager.removeMenuItems(removeId);
                                  break;
                              case 3:
                                  System.out.println("Enter the menu id to update ");
                                  int updateId = scanner.nextInt();
                                  scanner.nextLine();
                                  System.out.println("Enter New name of item or remain the same name ");
                                  String updateName = scanner.nextLine();
                                  System.out.println("Enter the category if item belong to different category");
                                  String updateCategory = scanner.nextLine();
                                  System.out.println("Enter the price if the price has been changed");
                                  double upddatePrice = scanner.nextDouble();
                                  System.out.println("is the item availaible or not (true/false) ");
                                  boolean isAvailaible = scanner.nextBoolean();

                                  MenuItem updateMenuItem = new MenuItem(updateId, updateName, updateCategory, upddatePrice, isAvailaible);

                                  restaurantManager.updateMenuItem(updateId, updateMenuItem);
                                  break;

                              case 4:
                                  System.out.println("Exiting...");
                                  scanner.close();
                                  return;


                              default:
                                  System.out.println(restaurantManager.helper());
                                  break;

                          }
                      } catch (Exception e) {
                          System.out.println(restaurantManager.helper());
                          scanner.next();
                      }

                  }


              }
              else {
                  System.out.println(restaurantManager.helper());
              }
          }
          catch (Exception e){
              System.out.println(restaurantManager.helper());
              scanner.next();
          }

        }



    }
}