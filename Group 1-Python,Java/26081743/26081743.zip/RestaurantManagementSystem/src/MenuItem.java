import java.util.*;


public class MenuItem {

    private int itemId;
    private String itemCategory;
    private String itemName;
    private Double itemPrice;
    private boolean itemAvailaibility;

    public MenuItem(int itemId, String itemName, String itemCategory, Double itemPrice, boolean itemAvailaibility) {
        this.itemId = itemId;
        this.itemCategory = itemCategory;
        this.itemName = itemName;
        this.itemPrice = itemPrice;
        this.itemAvailaibility = itemAvailaibility;
    }

    public int getItemId() {
        return itemId;
    }

    public void setItemId(int itemId) {
        this.itemId = itemId;
    }

    public String getItemCategory() {
        return itemCategory;
    }

    public void setItemCategory(String itemCategory) {
        this.itemCategory = itemCategory;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public Double getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(Double itemPrice) {
        this.itemPrice = itemPrice;
    }

    public boolean isItemAvailaibility() {
        return itemAvailaibility;
    }

    public void setItemAvailaibility(boolean itemAvailaibility) {
        this.itemAvailaibility = itemAvailaibility;
    }

    @Override
    public String toString() {
        return "MenuItem{" +
                "itemId=" + itemId +
                ", itemCategory='" + itemCategory + '\'' +
                ", itemName='" + itemName + '\'' +
                ", itemPrice=" + itemPrice +
                ", itemAvailaibility=" + itemAvailaibility +
                '}';
    }
}
