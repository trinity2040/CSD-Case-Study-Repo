package HotelManagementSystem;
import java.time.LocalDate;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        HotelManagement_System hms = new HotelManagement_System();
        Scanner scanner = new Scanner(System.in);

        // Example interaction loop
        while (true) {
            System.out.println("\nHotel Management System Menu:");
            System.out.println("1. Add Room");
            System.out.println("2. Remove Room");
            System.out.println("3. Update Room");
            System.out.println("4. Check Room Availability");
            System.out.println("5. Make Reservation");
            System.out.println("6. Check-in Guest");
            System.out.println("7. Check-out Guest");
            System.out.println("8. Print Rooms");
            System.out.println("9. Print Reservations");
            System.out.println("10. Exit");

            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            try {
                switch (choice) {
                    case 1:
                        System.out.print("Enter Room ID: ");
                        int id = scanner.nextInt();
                        scanner.nextLine();  // Consume newline
                        System.out.print("Enter Room Number: ");
                        String roomNumber = scanner.nextLine();
                        System.out.print("Enter Room Type: ");
                        String roomType = scanner.nextLine();
                        System.out.print("Enter Price Per Night: ");
                        double price = scanner.nextDouble();
                        hms.addRoom(new Room(id, roomNumber, roomType, price));
                        break;

                    case 2:
                        System.out.print("Enter Room ID to Remove: ");
                        int removeId = scanner.nextInt();
                        hms.removeRoom(removeId);
                        break;

                    case 3:
                        System.out.print("Enter Room ID to Update: ");
                        int updateId = scanner.nextInt();
                        scanner.nextLine();  // Consume newline
                        System.out.print("Enter New Room Number: ");
                        String newRoomNumber = scanner.nextLine();
                        System.out.print("Enter New Room Type: ");
                        String newRoomType = scanner.nextLine();
                        System.out.print("Enter New Price Per Night: ");
                        double newPrice = scanner.nextDouble();
                        hms.updateRoom(updateId, new Room(updateId, newRoomNumber, newRoomType, newPrice));
                        break;

                    case 4:
                        System.out.print("Enter Room ID to Check Availability: ");
                        int roomId = scanner.nextInt();
                        System.out.print("Enter Start Date (YYYY-MM-DD): ");
                        String startDateStr = scanner.next();
                        System.out.print("Enter End Date (YYYY-MM-DD): ");
                        String endDateStr = scanner.next();
                        LocalDate startDate = LocalDate.parse(startDateStr);
                        LocalDate endDate = LocalDate.parse(endDateStr);
                        boolean isAvailable = hms.checkRoomAvailability(roomId, startDate, endDate);
                        System.out.println("Room Availability: " + (isAvailable ? "Available" : "Not Available"));
                        break;

                    case 5:
                        System.out.print("Enter Room ID to Reserve: ");
                        int resRoomId = scanner.nextInt();
                        scanner.nextLine();  // Consume newline
                        System.out.print("Enter Guest Name: ");
                        String guestName = scanner.nextLine();
                        System.out.print("Enter Start Date (YYYY-MM-DD): ");
                        startDateStr = scanner.next();
                        System.out.print("Enter End Date (YYYY-MM-DD): ");
                        endDateStr = scanner.next();
                        startDate = LocalDate.parse(startDateStr);
                        endDate = LocalDate.parse(endDateStr);
                        hms.makeReservation(resRoomId, guestName, startDate, endDate);
                        break;

                    case 6:
                        System.out.print("Enter Room ID for Check-in: ");
                        int checkInRoomId = scanner.nextInt();
                        scanner.nextLine();  // Consume newline
                        System.out.print("Enter Guest Name for Check-in: ");
                        String checkInGuestName = scanner.nextLine();
                        hms.checkInGuest(checkInRoomId, checkInGuestName);
                        break;

                    case 7:
                        System.out.print("Enter Room ID for Check-out: ");
                        int checkOutRoomId = scanner.nextInt();
                        hms.checkOutGuest(checkOutRoomId);
                        break;

                    case 8:
                        hms.printRooms();
                        break;

                    case 9:
                        hms.printReservations();
                        break;

                    case 10:
                        System.out.println("Exiting...");
                        System.exit(0);

                    default:
                        System.out.println("Invalid choice! Please choose a valid option.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

}
