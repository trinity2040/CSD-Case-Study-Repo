package HotelManagementSystem;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class HotelManagement_System {
    private Map<Integer, Room> rooms = new HashMap<>();
    private ArrayList<Reservation> reservations = new ArrayList<>();

    // Add a room
    public void addRoom(Room room) {
        if (rooms.containsKey(room.getId())) {
            throw new IllegalArgumentException("Room with this ID already exists.");
        } else {
            rooms.put(room.getId(), room);
            System.out.println("Room added successfully.");
        }
    }

    // Remove a room
    public void removeRoom(int roomId) {
        if (rooms.containsKey(roomId)) {
            rooms.remove(roomId);
            System.out.println("Room removed successfully.");
        } else {
            throw new IllegalArgumentException("Room with this ID does not exist.");
        }
    }

    // Update room details
    public void updateRoom(int roomId, Room updatedRoom) {
        if (rooms.containsKey(roomId)) {
            rooms.put(roomId, updatedRoom);
            System.out.println("Room updated successfully.");
        } else {
            throw new IllegalArgumentException("Room with this ID does not exist.");
        }
    }

    // Check room availability
    public boolean checkRoomAvailability(int roomId, LocalDate startDate, LocalDate endDate) {
        for (Reservation reservation : reservations) {
            if (reservation.getRoomId() == roomId) {
                if (!(endDate.isBefore(reservation.getStartDate()) || startDate.isAfter(reservation.getEndDate()))) {
                    return false; // Room is not available
                }
            }
        }
        return true; // Room is available
    }

    // Make a reservation
    public void makeReservation(int roomId, String guestName, LocalDate startDate, LocalDate endDate) {
        if (!rooms.containsKey(roomId)) {
            throw new IllegalArgumentException("Room with this ID does not exist.");
        }
        if (checkRoomAvailability(roomId, startDate, endDate)) {
            Reservation reservation = new Reservation(reservations.size() + 1, roomId, guestName, startDate, endDate);
            reservations.add(reservation);
            System.out.println("Reservation made successfully.");
        } else {
            throw new IllegalStateException("Room is not available for the given dates.");
        }
    }

    // Check-in guest
    public void checkInGuest(int roomId, String guestName) {
        boolean reservationFound = false;
        Room room = rooms.get(roomId);

        if (room == null) {
            throw new IllegalArgumentException("Room with this ID does not exist.");
        }

        for (Reservation reservation : reservations) {
            if (reservation.getRoomId() == roomId && reservation.getGuestName().equals(guestName)) {
                if (LocalDate.now().isAfter(reservation.getStartDate().minusDays(1)) && LocalDate.now().isBefore(reservation.getEndDate().plusDays(1))) {
                    reservationFound = true;
                    if (room.isAvailable()) {
                        room.setAvailable(false);
                        System.out.println("Guest checked in successfully.");
                    } else {
                        throw new IllegalStateException("Room is already occupied.");
                    }
                    return;
                }
            }
        }

        if (!reservationFound) {
            throw new IllegalArgumentException("No valid reservation found for this guest and room.");
        }
    }

    // Check-out guest
    public void checkOutGuest(int roomId) {
        Room room = rooms.get(roomId);
        if (room != null && !room.isAvailable()) {
            room.setAvailable(true);
            System.out.println("Guest checked out successfully.");
        } else {
            throw new IllegalArgumentException("Room is either not found or already available.");
        }
    }

    // Print all rooms
    public void printRooms() {
        rooms.values().forEach(System.out::println);
    }

    // Print all reservations
    public void printReservations() {
        reservations.forEach(System.out::println);
    }
}
