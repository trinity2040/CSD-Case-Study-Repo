Documentation
How to Run the Application
To run the Hospital Management System application, follow these steps:

Set Up Your Development Environment:

Install Java Development Kit (JDK) on your machine. Make sure Java is added to your system's PATH.
You can download the JDK from the Oracle website or use OpenJDK.
Compile the Java Files:

Save the provided source code (Patient.java, Bed.java, HospitalManager.java, Main.java) into a directory.
Open a terminal or command prompt and navigate to the directory containing the .java files.
Run the following command to compile all the Java files:
bash
Copy code
javac *.java
Run the Application:

After compilation, run the application using the following command:
bash
Copy code
java Main
This will start the console-based Hospital Management System.
Instructions for Each Feature
Admit a Patient:

Select option 1 from the menu.
Enter the required patient details such as ID, Name, Age, Gender, Diagnosis, Treatment, Admission Date, and Bed Number.
The system will admit the patient and assign the specified bed if it's available.
Discharge a Patient:

Select option 2 from the menu.
Enter the Patient ID of the patient to be discharged.
The system will discharge the patient and free up the assigned bed.
Update Patient Details:

Select option 3 from the menu.
Enter the Patient ID of the patient whose details you want to update.
Provide the updated information for the patient, such as Name, Diagnosis, and Treatment.
The system will update the details of the specified patient.
Search for Patients:

Select option 4 from the menu.
Enter a keyword to search for patients by Name or Diagnosis.
The system will display a list of patients matching the search criteria.
Assign Bed to a Patient:

Select option 5 from the menu.
Enter the Patient ID and the Bed Number you want to assign.
The system will assign the specified bed to the patient if it's available.
Exit the Application:

Select option 6 from the menu to exit the application.
Explanation of Exception Handling Implemented
The Hospital Management System uses exception handling to manage potential errors gracefully and ensure the stability of the application. Key areas where exceptions are handled include:

Bed Availability Check:

When admitting a patient, the system checks if the specified bed is available. If the bed is already occupied or does not exist, an Exception is thrown with a message like "Bed number X is not available.".
Patient Not Found:

When attempting to update or discharge a patient, the system checks if the patient exists in the records. If the patient is not found, an Exception is thrown with a message like "Patient ID X not found.".
Input Validation:

The system performs input validation for menu options and prompts the user to re-enter valid input if the input is invalid. This prevents the program from crashing due to incorrect user input.
General Exception Handling:

All exceptions are caught in a try-catch block, and meaningful messages are displayed to the user. This ensures that the application does not crash and provides users with helpful information to correct their actions.
3. A Brief Report on the Application Design and Object-Oriented Principles
Application Design Overview
The Hospital Management System is designed using Object-Oriented Programming (OOP) principles to create a modular, maintainable, and scalable application. The system is composed of four main classes: Patient, Bed, HospitalManager, and Main.

Object-Oriented Principles Applied
Encapsulation:

Each class encapsulates its data (attributes) and provides public methods (getters and setters) to access and modify the data. This hides the internal implementation details from other classes, ensuring data integrity and security.
Abstraction:

The system abstracts the complexity of managing hospital operations by providing simple and user-friendly methods (admitPatient, dischargePatient, updatePatientDetails, etc.) in the HospitalManager class to interact with patients and beds.
Inheritance:

While the provided system does not explicitly use inheritance, the design can be easily extended to support inheritance by creating subclasses for different types of patients (e.g., Inpatient and Outpatient) or different types of hospital staff (e.g., Doctor, Nurse).
Polymorphism:

The system utilizes polymorphism through method overriding (e.g., the toString() method in both Patient and Bed classes), providing specific implementations for displaying information.
Composition:

The HospitalManager class uses composition to manage instances of Patient and Bed. It maintains collections (HashMap<Integer, Patient> and HashMap<Integer, Bed>) to manage the relationships between patients and beds.
Conclusion
The Hospital Management System effectively demonstrates the application of core Java concepts such as OOP, Collections, and Exception Handling to build a functional and user-friendly console-based application. The system can be extended with additional features, such as managing hospital staff, scheduling appointments, or integrating with a database for persistent storage.