// File: src/Main.java
import java.util.Date;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        HospitalManager manager = new HospitalManager();
        Scanner scanner = new Scanner(System.in);

        // Adding some beds
        for (int i = 1; i <= 10; i++) {
            manager.getBeds().put(i, new Bed(i));
        }

        boolean exit = false;

        while (!exit) {
            System.out.println("\n--- Hospital Management System ---");
            System.out.println("1. Admit Patient");
            System.out.println("2. Discharge Patient");
            System.out.println("3. Update Patient Details");
            System.out.println("4. Search for Patient");
            System.out.println("5. Assign Bed");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            try {
                switch (choice) {
                    case 1:
                        // Admit Patient
                        System.out.print("Enter Patient ID: ");
                        int id = scanner.nextInt();
                        scanner.nextLine(); // Consume newline

                        System.out.print("Enter Patient Name: ");
                        String name = scanner.nextLine();

                        System.out.print("Enter Patient Age: ");
                        int age = scanner.nextInt();
                        scanner.nextLine(); // Consume newline

                        System.out.print("Enter Patient Gender: ");
                        String gender = scanner.nextLine();

                        System.out.print("Enter Diagnosis: ");
                        String diagnosis = scanner.nextLine();

                        System.out.print("Enter Treatment: ");
                        String treatment = scanner.nextLine();

                        System.out.print("Enter Bed Number: ");
                        int bedNumber = scanner.nextInt();

                        Patient newPatient = new Patient(id, name, age, gender, diagnosis, treatment, new Date());
                        manager.admitPatient(newPatient, bedNumber);
                        System.out.println("Patient admitted successfully.");
                        break;

                    // Other cases...

                    case 6:
                        // Exit
                        exit = true;
                        System.out.println("Exiting the system. Goodbye!");
                        break;

                    default:
                        System.out.println("Invalid option. Please try again.");
                        break;
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }

        scanner.close();
    }
}
