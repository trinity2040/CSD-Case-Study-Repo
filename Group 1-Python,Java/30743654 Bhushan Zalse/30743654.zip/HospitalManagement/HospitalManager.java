// File: src/HospitalManager.java
import java.util.HashMap;
import java.util.Map;

public class HospitalManager {
    private Map<Integer, Patient> patients = new HashMap<>();
    private Map<Integer, Bed> beds = new HashMap<>();

    // Other methods...

    public void admitPatient(Patient p, int bedNumber) throws Exception {
        Bed bed = beds.get(bedNumber);
        if (bed == null) {
            throw new Exception("Bed number " + bedNumber + " does not exist.");
        }
        if (bed.isOccupied()) {
            throw new Exception("Bed number " + bedNumber + " is already occupied.");
        }
        patients.put(p.getId(), p);
        bed.setOccupied(true);
        System.out.println("Patient admitted to bed number " + bedNumber + ".");
    }

    // Getter for beds
    public Map<Integer, Bed> getBeds() {
        return beds;
    }

    // Other methods (like dischargePatient, updatePatientDetails, etc.)
}
