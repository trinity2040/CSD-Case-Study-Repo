import java.util.HashMap;
import java.util.Scanner;

public class EmployeeManagementSystem {
    private HashMap<Integer, Employee> employees = new HashMap<>();
    private HashMap<Integer, Department> departments = new HashMap<>();
    private Scanner scanner = new Scanner(System.in);

    // Method to add an employee
    public void addEmployee(Employee employee) {
        employees.put(employee.getId(), employee);
        System.out.println("Employee added successfully.");
    }

    // Method to remove an employee
    public void removeEmployee(int employeeId) {
        if (employees.remove(employeeId) != null) {
            System.out.println("Employee removed successfully.");
        } else {
            System.out.println("Employee not found.");
        }
    }

    // Method to update employee details
    public void updateEmployee(int employeeId, Employee updatedEmployee) {
        if (employees.containsKey(employeeId)) {
            employees.put(employeeId, updatedEmployee);
            System.out.println("Employee updated successfully.");
        } else {
            System.out.println("Employee not found.");
        }
    }

    // Method to add a department
    public void addDepartment(Department department) {
        departments.put(department.getId(), department);
        System.out.println("Department added successfully.");
    }

    // Method to remove a department
    public void removeDepartment(int departmentId) {
        if (departments.remove(departmentId) != null) {
            System.out.println("Department removed successfully.");
        } else {
            System.out.println("Department not found.");
        }
    }

    // Method to assign an employee to a department
    public void assignEmployeeToDepartment(int employeeId, int departmentId) {
        if (employees.containsKey(employeeId) && departments.containsKey(departmentId)) {
            Employee employee = employees.get(employeeId);
            employee.setDepartmentId(departmentId);
            System.out.println("Employee assigned to department successfully.");
        } else {
            System.out.println("Employee or Department not found.");
        }
    }

    // Method to update an employee's department
    public void updateEmployeeDepartment(int employeeId, int newDepartmentId) {
        assignEmployeeToDepartment(employeeId, newDepartmentId);
    }

    // Menu for HR operations
    public void menu() {
        int choice;
        do {
            System.out.println("---- Employee Management System ----");
            System.out.println("1. Add Employee");
            System.out.println("2. Remove Employee");
            System.out.println("3. Update Employee");
            System.out.println("4. Add Department");
            System.out.println("5. Remove Department");
            System.out.println("6. Assign Employee to Department");
            System.out.println("7. Update Employee Department");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    // Code to add an employee
                    System.out.print("Enter Employee ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine(); // consume the newline
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Designation: ");
                    String designation = scanner.nextLine();
                    System.out.print("Enter Salary: ");
                    double salary = scanner.nextDouble();
                    System.out.print("Enter Department ID: ");
                    int deptId = scanner.nextInt();
                    addEmployee(new Employee(id, name, designation, salary, deptId));
                    break;
                case 2:
                    // Code to remove an employee
                    System.out.print("Enter Employee ID to remove: ");
                    int removeId = scanner.nextInt();
                    removeEmployee(removeId);
                    break;
                case 3:
                    // Code to update an employee
                    System.out.print("Enter Employee ID to update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine(); // consume the newline
                    System.out.print("Enter New Name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter New Designation: ");
                    String newDesignation = scanner.nextLine();
                    System.out.print("Enter New Salary: ");
                    double newSalary = scanner.nextDouble();
                    System.out.print("Enter New Department ID: ");
                    int newDeptId = scanner.nextInt();
                    updateEmployee(updateId, new Employee(updateId, newName, newDesignation, newSalary, newDeptId));
                    break;
                case 4:
                    // Code to add a department
                    System.out.print("Enter Department ID: ");
                    int deptAddId = scanner.nextInt();
                    scanner.nextLine(); // consume the newline
                    System.out.print("Enter Department Name: ");
                    String deptName = scanner.nextLine();
                    System.out.print("Enter Department Description: ");
                    String deptDescription = scanner.nextLine();
                    addDepartment(new Department(deptAddId, deptName, deptDescription));
                    break;
                case 5:
                    // Code to remove a department
                    System.out.print("Enter Department ID to remove: ");
                    int removeDeptId = scanner.nextInt();
                    removeDepartment(removeDeptId);
                    break;
                case 6:
                    // Code to assign an employee to a department
                    System.out.print("Enter Employee ID: ");
                    int empId = scanner.nextInt();
                    System.out.print("Enter Department ID: ");
                    int assignDeptId = scanner.nextInt();
                    assignEmployeeToDepartment(empId, assignDeptId);
                    break;
                case 7:
                    // Code to update an employee's department
                    System.out.print("Enter Employee ID: ");
                    int empUpdateId = scanner.nextInt();
                    System.out.print("Enter New Department ID: ");
                    int newAssignDeptId = scanner.nextInt();
                    updateEmployeeDepartment(empUpdateId, newAssignDeptId);
                    break;
                case 8:
                    System.out.println("Exiting the system.");
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 8);
    }
}