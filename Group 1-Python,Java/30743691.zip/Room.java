public class Room {
    private int number;
    private String type; // e.g., "single", "double", "suite"
    private double price;
    private boolean available;

    public Room(int number, String type, double price, boolean available) {
        this.number = number;
        this.type = type;
        this.price = price;
        this.available = available;
    }
    public int getNumber() { return number; }
    public void setNumber(int number) { this.number = number; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    @Override
    public String toString() {
        return "Room{" +
                "number=" + number +
                ", type='" + type + '\'' +
                ", price=" + price +
                ", available=" + available +
                '}';
    }
}
