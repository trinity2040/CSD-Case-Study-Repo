import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        HotelManager hotelManager = new HotelManager();

        // Initialize some rooms for the hotel
        hotelManager.getRooms().add(new Room(101, "Single", 100.0, true));
        hotelManager.getRooms().add(new Room(102, "Double", 150.0, true));
        hotelManager.getRooms().add(new Room(201, "Suite", 250.0, true));

        while (true) {
            System.out.println("\n--- Hotel Reservation System ---");
            System.out.println("1. View Room Availability");
            System.out.println("2. Make a Reservation");
            System.out.println("3. Cancel a Reservation");
            System.out.println("4. Check-in");
            System.out.println("5. Check-out");
            System.out.println("6. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    viewRoomAvailability(hotelManager, scanner);
                    break;
                case 2:
                    makeReservation(hotelManager, scanner);
                    break;
                case 3:
                    cancelReservation(hotelManager, scanner);
                    break;
                case 4:
                    checkIn(hotelManager, scanner);
                    break;
                case 5:
                    checkOut(hotelManager, scanner);
                    break;
                case 6:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void viewRoomAvailability(HotelManager hotelManager, Scanner scanner) {
        try {
            System.out.print("Enter check-in date (yyyy-MM-dd): ");
            Date checkIn = parseDate(scanner.nextLine());
            System.out.print("Enter check-out date (yyyy-MM-dd): ");
            Date checkOut = parseDate(scanner.nextLine());

            ArrayList<Room> availableRooms = hotelManager.checkRoomAvailability(checkIn, checkOut);
            if (availableRooms.isEmpty()) {
                System.out.println("No rooms available for the selected date range.");
            } else {
                System.out.println("Available rooms:");
                for (Room room : availableRooms) {
                    System.out.println(room);
                }
            }
        } catch (ParseException e) {
            System.out.println("Invalid date format. Please use yyyy-MM-dd.");
        }
    }

    private static void makeReservation(HotelManager hotelManager, Scanner scanner) {
        try {
            System.out.print("Enter room number: ");
            int roomId = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            System.out.print("Enter guest name: ");
            String guestName = scanner.nextLine();
            System.out.print("Enter check-in date (yyyy-MM-dd): ");
            Date checkIn = parseDate(scanner.nextLine());
            System.out.print("Enter check-out date (yyyy-MM-dd): ");
            Date checkOut = parseDate(scanner.nextLine());

            Reservation reservation = hotelManager.makeReservation(roomId, guestName, checkIn, checkOut);
            if (reservation != null) {
                System.out.println("Reservation successful!");
                System.out.println(reservation);
            } else {
                System.out.println("Reservation failed. Room may not be available.");
            }
        } catch (ParseException e) {
            System.out.println("Invalid date format. Please use yyyy-MM-dd.");
        }
    }

    private static void cancelReservation(HotelManager hotelManager, Scanner scanner) {
        System.out.print("Enter reservation ID to cancel: ");
        int reservationId = scanner.nextInt();

        boolean success = hotelManager.cancelReservation(reservationId);
        if (success) {
            System.out.println("Reservation canceled successfully.");
        } else {
            System.out.println("Reservation not found or cancellation failed.");
        }
    }

    private static void checkIn(HotelManager hotelManager, Scanner scanner) {
        System.out.print("Enter reservation ID to check-in: ");
        int reservationId = scanner.nextInt();

        boolean success = hotelManager.checkIn(reservationId);
        if (success) {
            System.out.println("Check-in successful.");
        } else {
            System.out.println("Check-in failed. Reservation not found.");
        }
    }

    private static void checkOut(HotelManager hotelManager, Scanner scanner) {
        System.out.print("Enter reservation ID to check-out: ");
        int reservationId = scanner.nextInt();

        boolean success = hotelManager.checkOut(reservationId);
        if (success) {
            System.out.println("Check-out successful.");
        } else {
            System.out.println("Check-out failed. Reservation not found.");
        }
    }

    private static Date parseDate(String dateString) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return dateFormat.parse(dateString);
    }
}
