import java.util.ArrayList;
import java.util.Date;

public class HotelManager {
    private ArrayList<Room> rooms;
    private ArrayList<Reservation> reservations;
    private int nextReservationId;

    public HotelManager() {
        this.rooms = new ArrayList<>();
        this.reservations = new ArrayList<>();
        this.nextReservationId = 1;
    }

    public ArrayList<Room> checkRoomAvailability(Date checkIn, Date checkOut) {
        ArrayList<Room> availableRooms = new ArrayList<>();
        for (Room room : rooms) {
            if (room.isAvailable()) {
                availableRooms.add(room);
            }
        }
        return availableRooms;
    }

    public Reservation makeReservation(int roomId, String guestName, Date checkIn, Date checkOut) {
        Room room = findRoomById(roomId);
        if (room != null && room.isAvailable()) {
            double totalPrice = room.getPrice() * calculateNights(checkIn, checkOut);
            Reservation reservation = new Reservation(nextReservationId++, roomId, guestName, checkIn, checkOut, totalPrice);
            reservations.add(reservation);
            room.setAvailable(false);
            return reservation;
        }
        return null; // or throw an exception
    }

    public boolean cancelReservation(int reservationId) {
        Reservation reservation = findReservationById(reservationId);
        if (reservation != null) {
            reservations.remove(reservation);
            Room room = findRoomById(reservation.getRoomId());
            if (room != null) {
                room.setAvailable(true);
            }
            return true;
        }
        return false;
    }

    public boolean checkIn(int reservationId) {
        Reservation reservation = findReservationById(reservationId);
        if (reservation != null) {
            // Logic for check-in
            return true;
        }
        return false;
    }

    public boolean checkOut(int reservationId) {
        Reservation reservation = findReservationById(reservationId);
        if (reservation != null) {
            Room room = findRoomById(reservation.getRoomId());
            if (room != null) {
                room.setAvailable(true);
            }
            reservations.remove(reservation);
            return true;
        }
        return false;
    }
    
    private Room findRoomById(int roomId) {
        for (Room room : rooms) {
            if (room.getNumber() == roomId) {
                return room;
            }
        }
        return null;
    }

    private Reservation findReservationById(int reservationId) {
        for (Reservation reservation : reservations) {
            if (reservation.getId() == reservationId) {
                return reservation;
            }
        }
        return null;
    }

    private int calculateNights(Date checkIn, Date checkOut) {
        return (int) ((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24));
    }

    // Accessor methods to manage the rooms
    public ArrayList<Room> getRooms() {
        return rooms;
    }

    public ArrayList<Reservation> getReservations() {
        return reservations;
    }
}
