import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class ClinicManagementSystem {
    private HashMap<Integer, Patient> patients = new HashMap<>();
    private HashMap<Integer, Doctor> doctors = new HashMap<>();
    private ArrayList<Appointment> appointments = new ArrayList<>();
    private Scanner scanner = new Scanner(System.in);
    private DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    public static void main(String[] args) {
        ClinicManagementSystem cms = new ClinicManagementSystem();
        cms.run();
    }

    public void run() {
        int choice;
        do {
            System.out.println("\n CLINIC MANAGEMENT SYSTEM");
            System.out.println("1. Add Patient");
            System.out.println("2. Remove Patient");
            System.out.println("3. Update Patient Details");
            System.out.println("4. Add Doctor");
            System.out.println("5. Remove Doctor");
            System.out.println("6. Update Doctor Details");
            System.out.println("7. Schedule Appointment");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1: addPatient(); break;
                case 2: removePatient(); break;
                case 3: updatePatient(); break;
                case 4: addDoctor(); break;
                case 5: removeDoctor(); break;
                case 6: updateDoctor(); break;
                case 7: scheduleAppointment(); break;
                case 8: System.out.println("Exiting the system..."); break;
                default: System.out.println("Invalid choice. Please try again."); break;
            }
        } while (choice != 8);
    }

    private void addPatient() {
        try {
            System.out.print("Enter Patient ID: ");
            int id = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            if (patients.containsKey(id)) {
                throw new IllegalArgumentException("Patient with ID " + id + " already exists.");
            }
            System.out.print("Enter Patient Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter Contact Number: ");
            String contactNumber = scanner.nextLine();
            System.out.print("Enter Medical History: ");
            String medicalHistory = scanner.nextLine();

            Patient patient = new Patient(id, name, contactNumber, medicalHistory);
            patients.put(id, patient);
            System.out.println("Patient added successfully.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void removePatient() {
        try {
            System.out.print("Enter Patient ID to remove: ");
            int id = scanner.nextInt();
            if (patients.remove(id) == null) {
                throw new NoSuchElementException("Patient with ID " + id + " not found.");
            }
            System.out.println("Patient removed successfully.");
        } catch (NoSuchElementException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void updatePatient() {
        try {
            System.out.print("Enter Patient ID to update: ");
            int id = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            if (!patients.containsKey(id)) {
                throw new NoSuchElementException("Patient with ID " + id + " not found.");
            }
            System.out.print("Enter new Patient Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter new Contact Number: ");
            String contactNumber = scanner.nextLine();
            System.out.print("Enter new Medical History: ");
            String medicalHistory = scanner.nextLine();

            Patient updatedPatient = new Patient(id, name, contactNumber, medicalHistory);
            patients.put(id, updatedPatient);
            System.out.println("Patient details updated successfully.");
        } catch (NoSuchElementException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void addDoctor() {
        try {
            System.out.print("Enter Doctor ID: ");
            int id = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            if (doctors.containsKey(id)) {
                throw new IllegalArgumentException("Doctor with ID " + id + " already exists.");
            }
            System.out.print("Enter Doctor Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter Specialization: ");
            String specialization = scanner.nextLine();
            System.out.print("Enter Contact Number: ");
            String contactNumber = scanner.nextLine();

            Doctor doctor = new Doctor(id, name, specialization, contactNumber);
            doctors.put(id, doctor);
            System.out.println("Doctor added successfully.");
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void removeDoctor() {
        try {
            System.out.print("Enter Doctor ID to remove: ");
            int id = scanner.nextInt();
            if (doctors.remove(id) == null) {
                throw new NoSuchElementException("Doctor with ID " + id + " not found.");
            }
            System.out.println("Doctor removed successfully.");
        } catch (NoSuchElementException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void updateDoctor() {
        try {
            System.out.print("Enter Doctor ID to update: ");
            int id = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            if (!doctors.containsKey(id)) {
                throw new NoSuchElementException("Doctor with ID " + id + " not found.");
            }
            System.out.print("Enter new Doctor Name: ");
            String name = scanner.nextLine();
            System.out.print("Enter new Specialization: ");
            String specialization = scanner.nextLine();
            System.out.print("Enter new Contact Number: ");
            String contactNumber = scanner.nextLine();

            Doctor updatedDoctor = new Doctor(id, name, specialization, contactNumber);
            doctors.put(id, updatedDoctor);
            System.out.println("Doctor details updated successfully.");
        } catch (NoSuchElementException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private void scheduleAppointment() {
        try {
            System.out.print("Enter Patient ID: ");
            int patientId = scanner.nextInt();
            System.out.print("Enter Doctor ID: ");
            int doctorId = scanner.nextInt();
            scanner.nextLine();  // Consume newline
            if (!patients.containsKey(patientId)) {
                throw new NoSuchElementException("Patient with ID " + patientId + " not found.");
            }
            if (!doctors.containsKey(doctorId)) {
                throw new NoSuchElementException("Doctor with ID " + doctorId + " not found.");
            }
            System.out.print("Enter Appointment Date and Time (yyyy-MM-dd HH:mm): ");
            String dateTimeStr = scanner.nextLine();

            try {
                LocalDateTime appointmentDateTime = LocalDateTime.parse(dateTimeStr, formatter);
                for (Appointment appointment : appointments) {
                    if (appointment.getDoctorId() == doctorId && appointment.getAppointmentDateTime().equals(appointmentDateTime)) {
                        throw new IllegalArgumentException("Appointment time slot is already booked for this doctor.");
                    }
                }
                appointments.add(new Appointment(appointments.size() + 1, patientId, doctorId, appointmentDateTime));
                System.out.println("Appointment scheduled successfully.");
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        } catch (NoSuchElementException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
