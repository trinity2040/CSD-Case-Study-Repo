/**
 * 
 */
/**
 * 
 */
module OnlineBiddingSystem {
}