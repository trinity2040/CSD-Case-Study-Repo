package com.Bidding;

import com.cognizant.model.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

public class AuctionSystem {
    private HashMap<Integer, Item> items;
    private HashMap<Integer, ArrayList<Bid>> bids;

    public AuctionSystem() {
        items = new HashMap<>();
        bids = new HashMap<>();
    }

    public void addItem(Item item) {
        items.put(item.getId(), item);
        bids.put(item.getId(), new ArrayList<>());
        System.out.println("Item added successfully: " + item);
    }

    public void removeItem(int itemId) {
        if (items.containsKey(itemId)) {
            items.remove(itemId);
            bids.remove(itemId);
            System.out.println("Item removed successfully.");
        } else {
            System.out.println("Item not found.");
        }
    }

    public void updateItem(int itemId, Item updatedItem) {
        if (items.containsKey(itemId)) {
            items.put(itemId, updatedItem);
            System.out.println("Item updated successfully: " + updatedItem);
        } else {
            System.out.println("Item not found.");
        }
    }

    public void startAuction(int itemId) {
        Item item = items.get(itemId);
        if (item != null) {
            if (!item.isAuctionOpen()) {
                item.setAuctionOpen(true);
                System.out.println("Auction started for item: " + item.getName());
            } else {
                System.out.println("Auction is already open for this item.");
            }
        } else {
            System.out.println("Item not found.");
        }
    }

    public void endAuction(int itemId) {
        Item item = items.get(itemId);
        if (item != null) {
            if (item.isAuctionOpen()) {
                item.setAuctionOpen(false);
                System.out.println("Auction ended for item: " + item.getName());
            } else {
                System.out.println("Auction is not currently open for this item.");
            }
        } else {
            System.out.println("Item not found.");
        }
    }

    public void placeBid(int itemId, int userId, double bidAmount) {
        Item item = items.get(itemId);
        if (item != null) {
            if (item.isAuctionOpen()) {
                if (bidAmount > item.getCurrentHighestBid()) {
                    Bid newBid = new Bid(bids.get(itemId).size() + 1, itemId, userId, bidAmount);
                    bids.get(itemId).add(newBid);
                    item.setCurrentHighestBid(bidAmount);
                    System.out.println("Bid placed successfully: " + newBid);
                } else {
                    System.out.println("Bid amount must be higher than the current highest bid.");
                }
            } else {
                System.out.println("Auction is not open for this item.");
            }
        } else {
            System.out.println("Item not found.");
        }
    }

    public void viewAuctionStatus() {
        System.out.println("Auction Status:");
        for (Item item : items.values()) {
            if (item.isAuctionOpen()) {
                System.out.println(item);
            }
        }
    }

    public static void main(String[] args) {
        AuctionSystem auctionSystem = new AuctionSystem();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nOnline Auction System");
            System.out.println("1. Add Item");
            System.out.println("2. Remove Item");
            System.out.println("3. Update Item");
            System.out.println("4. Start Auction");
            System.out.println("5. End Auction");
            System.out.println("6. Place Bid");
            System.out.println("7. View Auction Status");
            System.out.println("8. Exit");
            System.out.print("Choose an option: ");
            int option = scanner.nextInt();

            switch (option) {
                case 1:
                    System.out.print("Enter item ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                    System.out.print("Enter item name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter item description: ");
                    String description = scanner.nextLine();
                    System.out.print("Enter starting price: ");
                    double startingPrice = scanner.nextDouble();
                    Item newItem = new Item(id, name, description, startingPrice);
                    auctionSystem.addItem(newItem);
                    break;
                case 2:
                    System.out.print("Enter item ID to remove: ");
                    int removeId = scanner.nextInt();
                    auctionSystem.removeItem(removeId);
                    break;
                case 3:
                    System.out.print("Enter item ID to update: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine();  // Consume newline
                    System.out.print("Enter new item name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter new item description: ");
                    String newDescription = scanner.nextLine();
                    System.out.print("Enter new starting price: ");
                    double newStartingPrice = scanner.nextDouble();
                    Item updatedItem = new Item(updateId, newName, newDescription, newStartingPrice);
                    auctionSystem.updateItem(updateId, updatedItem);
                    break;
                case 4:
                    System.out.print("Enter item ID to start auction: ");
                    int startAuctionId = scanner.nextInt();
                    auctionSystem.startAuction(startAuctionId);
                    break;
                case 5:
                    System.out.print("Enter item ID to end auction: ");
                    int endAuctionId = scanner.nextInt();
                    auctionSystem.endAuction(endAuctionId);
                    break;
                case 6:
                    System.out.print("Enter item ID to place bid: ");
                    int bidItemId = scanner.nextInt();
                    System.out.print("Enter user ID: ");
                    int userId = scanner.nextInt();
                    System.out.print("Enter bid amount: ");
                    double bidAmount = scanner.nextDouble();
                    auctionSystem.placeBid(bidItemId, userId, bidAmount);
                    break;
                case 7:
                    auctionSystem.viewAuctionStatus();
                    break;
                case 8:
                    System.out.println("Exiting the system.");
                    scanner.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }
}
