package com.cognizant.model;

import java.time.LocalDateTime;

public class Bid {
    // Unique identifier for the bid
    private int id;
    // ID of the item this bid is associated with
    private int itemId;
    // ID of the user who placed this bid
    private int userId;
    // The amount of money offered in this bid
    private double bidAmount;
    // The date and time when this bid was placed
    private LocalDateTime bidDateTime;

    // Constructor to initialize the bid with its details
    public Bid(int id, int itemId, int userId, double bidAmount) {
        this.id = id;
        this.itemId = itemId;
        this.userId = userId;
        this.bidAmount = bidAmount;
        // Automatically captures the current date and time when the bid is created
        this.bidDateTime = LocalDateTime.now();
    }

    // Getters for each attribute
    public int getId() {
        return id;
    }

    public int getItemId() {
        return itemId;
    }

    public int getUserId() {
        return userId;
    }

    public double getBidAmount() {
        return bidAmount;
    }

    public LocalDateTime getBidDateTime() {
        return bidDateTime;
    }

    // Overriding toString method to provide a string representation of the bid
    @Override
    public String toString() {
        return "Bid{" +
                "id=" + id +
                ", itemId=" + itemId +
                ", userId=" + userId +
                ", bidAmount=" + bidAmount +
                ", bidDateTime=" + bidDateTime +
                '}';
    }
}
