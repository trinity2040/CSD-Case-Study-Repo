package com.cognizant.model;

import java.util.*;

public class Item {
    // Unique identifier for the item
    private int id;
    // Name of the item
    private String name;
    // Description of the item
    private String description;
    // The starting price for the item when the auction begins
    private double startingPrice;
    // The current highest bid amount for the item
    private double currentHighestBid;
    // A flag to indicate if the auction for this item is currently open
    private boolean isAuctionOpen;

    // Constructor to initialize the item with its details
    public Item(int id, String name, String description, double startingPrice) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.startingPrice = startingPrice;
        // Initial highest bid is set to the starting price
        this.currentHighestBid = startingPrice;
        // Auction is not open by default when the item is created
        this.isAuctionOpen = false;
    }

    // Getters and Setters for each attribute
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getStartingPrice() {
        return startingPrice;
    }

    public void setStartingPrice(double startingPrice) {
        this.startingPrice = startingPrice;
    }

    public double getCurrentHighestBid() {
        return currentHighestBid;
    }

    public void setCurrentHighestBid(double currentHighestBid) {
        this.currentHighestBid = currentHighestBid;
    }

    public boolean isAuctionOpen() {
        return isAuctionOpen;
    }

    public void setAuctionOpen(boolean auctionOpen) {
        isAuctionOpen = auctionOpen;
    }

    // Overriding toString method to provide a string representation of the item
    @Override
    public String toString() {
        return "Item{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", startingPrice=" + startingPrice +
                ", currentHighestBid=" + currentHighestBid +
                ", isAuctionOpen=" + isAuctionOpen +
                '}';
    }
}
