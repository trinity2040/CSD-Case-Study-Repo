/**
 * 
 */
/**
 * 
 */
module Bid {
}