import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

// Account class to represent a customer account
class Account {
    private int id;
    private int customerId;
    private double balance;
    private String accountType;

    // Constructor
    public Account(int id, int customerId, double balance, String accountType) {
        this.id = id;
        this.customerId = customerId;
        this.balance = balance;
        this.accountType = accountType;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    // toString method for displaying account information
    @Override
    public String toString() {
        return "Account{" +
                "id=" + id +
                ", customerId=" + customerId +
                ", balance=" + balance +
                ", accountType='" + accountType + '\'' +
                '}';
    }
}

// Transaction class to store transaction details
class Transaction {
    private int id;
    private int accountId;
    private String transactionType;
    private double amount;
    private LocalDateTime transactionDate;

    // Constructor
    public Transaction(int id, int accountId, String transactionType, double amount) {
        this.id = id;
        this.accountId = accountId;
        this.transactionType = transactionType;
        this.amount = amount;
        this.transactionDate = LocalDateTime.now();
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAccountId() {
        return accountId;
    }

    public void setAccountId(int accountId) {
        this.accountId = accountId;
    }

    public String getTransactionType() {
        return transactionType;
    }

    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public LocalDateTime getTransactionDate() {
        return transactionDate;
    }

    // toString method for displaying transaction information
    @Override
    public String toString() {
        return "Transaction{" +
                "id=" + id +
                ", accountId=" + accountId +
                ", transactionType='" + transactionType + '\'' +
                ", amount=" + amount +
                ", transactionDate=" + transactionDate +
                '}';
    }
}

// BankingSystem class to manage accounts and transactions
class BankingSystem {
    private HashMap<Integer, Account> accounts = new HashMap<>();
    private ArrayList<Transaction> transactions = new ArrayList<>();
    private int transactionCounter = 1;

    // Method to add a new account
    public void addAccount(Account account) {
        if (accounts.containsKey(account.getId())) {
            System.out.println("Account already exists with ID: " + account.getId());
        } else {
            accounts.put(account.getId(), account);
            System.out.println("Account added successfully.");
        }
    }

    // Method to remove an account
    public void removeAccount(int accountId) {
        if (accounts.remove(accountId) != null) {
            System.out.println("Account removed successfully.");
        } else {
            System.out.println("Account not found.");
        }
    }

    // Method to update an account
    public void updateAccount(int accountId, Account updatedAccount) {
        if (accounts.containsKey(accountId)) {
            accounts.put(accountId, updatedAccount);
            System.out.println("Account updated successfully.");
        } else {
            System.out.println("Account not found.");
        }
    }

    // Method to deposit funds
    public void depositFunds(int accountId, double amount) {
        Account account = accounts.get(accountId);
        if (account != null && amount > 0) {
            account.setBalance(account.getBalance() + amount);
            transactions.add(new Transaction(transactionCounter++, accountId, "Deposit", amount));
            System.out.println("Deposit successful.");
        } else {
            System.out.println("Invalid account or amount.");
        }
    }

    // Method to withdraw funds
    public void withdrawFunds(int accountId, double amount) {
        Account account = accounts.get(accountId);
        if (account != null && amount > 0 && account.getBalance() >= amount) {
            account.setBalance(account.getBalance() - amount);
            transactions.add(new Transaction(transactionCounter++, accountId, "Withdrawal", amount));
            System.out.println("Withdrawal successful.");
        } else {
            System.out.println("Invalid account, amount, or insufficient funds.");
        }
    }

    // Method to transfer funds between accounts
    public void transferFunds(int fromAccountId, int toAccountId, double amount) {
        Account fromAccount = accounts.get(fromAccountId);
        Account toAccount = accounts.get(toAccountId);

        if (fromAccount != null && toAccount != null && amount > 0 && fromAccount.getBalance() >= amount) {
            fromAccount.setBalance(fromAccount.getBalance() - amount);
            toAccount.setBalance(toAccount.getBalance() + amount);
            transactions.add(new Transaction(transactionCounter++, fromAccountId, "Transfer", amount));
            transactions.add(new Transaction(transactionCounter++, toAccountId, "Transfer", amount));
            System.out.println("Transfer successful.");
        } else {
            System.out.println("Invalid accounts, amount, or insufficient funds.");
        }
    }

    // Method to display all accounts
    public void displayAccounts() {
        if (accounts.isEmpty()) {
            System.out.println("No accounts to display.");
        } else {
            accounts.values().forEach(System.out::println);
        }
    }

    // Method to display all transactions
    public void displayTransactions() {
        if (transactions.isEmpty()) {
            System.out.println("No transactions to display.");
        } else {
            transactions.forEach(System.out::println);
        }
    }
}

// Main class to interact with the banking system
public class Main {
    public static void main(String[] args) {
        BankingSystem bankingSystem = new BankingSystem();
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("\nBanking System Menu:");
            System.out.println("1. Add Account");
            System.out.println("2. Remove Account");
            System.out.println("3. Update Account");
            System.out.println("4. Deposit Funds");
            System.out.println("5. Withdraw Funds");
            System.out.println("6. Transfer Funds");
            System.out.println("7. Display Accounts");
            System.out.println("8. Display Transactions");
            System.out.println("9. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter Account ID: ");
                    int id = scanner.nextInt();
                    System.out.print("Enter Customer ID: ");
                    int customerId = scanner.nextInt();
                    System.out.print("Enter Initial Balance: ");
                    double balance = scanner.nextDouble();
                    System.out.print("Enter Account Type: ");
                    String accountType = scanner.next();
                    Account account = new Account(id, customerId, balance, accountType);
                    bankingSystem.addAccount(account);
                    break;

                case 2:
                    System.out.print("Enter Account ID to remove: ");
                    int removeId = scanner.nextInt();
                    bankingSystem.removeAccount(removeId);
                    break;

                case 3:
                    System.out.print("Enter Account ID to update: ");
                    int updateId = scanner.nextInt();
                    System.out.print("Enter New Customer ID: ");
                    int newCustomerId = scanner.nextInt();
                    System.out.print("Enter New Balance: ");
                    double newBalance = scanner.nextDouble();
                    System.out.print("Enter New Account Type: ");
                    String newAccountType = scanner.next();
                    Account updatedAccount = new Account(updateId, newCustomerId, newBalance, newAccountType);
                    bankingSystem.updateAccount(updateId, updatedAccount);
                    break;

                case 4:
                    System.out.print("Enter Account ID to deposit into: ");
                    int depositId = scanner.nextInt();
                    System.out.print("Enter Amount to deposit: ");
                    double depositAmount = scanner.nextDouble();
                    bankingSystem.depositFunds(depositId, depositAmount);
                    break;

                case 5:
                    System.out.print("Enter Account ID to withdraw from: ");
                    int withdrawId = scanner.nextInt();
                    System.out.print("Enter Amount to withdraw: ");
                    double withdrawAmount = scanner.nextDouble();
                    bankingSystem.withdrawFunds(withdrawId, withdrawAmount);
                    break;

                case 6:
                    System.out.print("Enter From Account ID: ");
                    int fromId = scanner.nextInt();
                    System.out.print("Enter To Account ID: ");
                    int toId = scanner.nextInt();
                    System.out.print("Enter Amount to transfer: ");
                    double transferAmount = scanner.nextDouble();
                    bankingSystem.transferFunds(fromId, toId, transferAmount);
                    break;

                case 7:
                    bankingSystem.displayAccounts();
                    break;

                case 8:
                    bankingSystem.displayTransactions();
                    break;

                case 9:
                    exit = true;
                    System.out.println("Exiting the system.");
                    break;

                default:
                    System.out.println("Invalid option. Please try again.");
                    break;
            }
        }
        scanner.close();
    }
}
