import java.time.LocalDateTime;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.InputMismatchException;
import java.util.Scanner;

public class ClinicManagementSystem {
    private HashMap<Integer, Patient> patients;
    private HashMap<Integer, Doctor> doctors;
    private ArrayList<Appointment> appointments;

    public ClinicManagementSystem() {
        this.patients = new HashMap<>();
        this.doctors = new HashMap<>();
        this.appointments = new ArrayList<>();
    }

    public void addPatient(Patient patient) {
        int patientId = Integer.parseInt(patient.getId());
        if (patients.containsKey(patientId)) {
            System.out.println("Patient with ID " + patient.getId() + " already exists.");
        } else {
            patients.put(patientId, patient);
            System.out.println("Patient added successfully.");
        }
    }

    public void removePatient(int patientId) {
        if (patients.containsKey(patientId)) {
            patients.remove(patientId);
            System.out.println("Patient removed successfully.");
        } else {
            System.out.println("Patient with ID " + patientId + " does not exist.");
        }
    }

    public void updatePatient(int patientId, Patient updatedPatient) {
        if (patients.containsKey(patientId)) {
            patients.put(patientId, updatedPatient);
            System.out.println("Patient updated successfully.");
        } else {
            System.out.println("Patient with ID " + patientId + " does not exist.");
        }
    }

    public void addDoctor(Doctor doctor) {
        int doctorId = Integer.parseInt(doctor.getId());
        if (doctors.containsKey(doctorId)) {
            System.out.println("Doctor with ID " + doctor.getId() + " already exists.");
        } else {
            doctors.put(doctorId, doctor);
            System.out.println("Doctor added successfully.");
        }
    }

    public void removeDoctor(int doctorId) {
        if (doctors.containsKey(doctorId)) {
            doctors.remove(doctorId);
            System.out.println("Doctor removed successfully.");
        } else {
            System.out.println("Doctor with ID " + doctorId + " does not exist.");
        }
    }

    public void updateDoctor(int doctorId, Doctor updatedDoctor) {
        if (doctors.containsKey(doctorId)) {
            doctors.put(doctorId, updatedDoctor);
            System.out.println("Doctor updated successfully.");
        } else {
            System.out.println("Doctor with ID " + doctorId + " does not exist.");
        }
    }

    public void scheduleAppointment(int patientId, int doctorId, LocalDateTime appointmentDateTime) {
        if (!patients.containsKey(patientId)) {
            System.out.println("Patient with ID " + patientId + " does not exist.");
            return;
        }
        if (!doctors.containsKey(doctorId)) {
            System.out.println("Doctor with ID " + doctorId + " does not exist.");
            return;
        }
        Appointment appointment = new Appointment("A" + (appointments.size() + 1), String.valueOf(patientId),
                String.valueOf(doctorId), appointmentDateTime);
        appointments.add(appointment);
        System.out.println("Appointment scheduled successfully.");
    }

    public static void main(String[] args) {
        ClinicManagementSystem clinicSystem = new ClinicManagementSystem();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Clinic Management System - Administrative Console");
            System.out.println("1. Add Patient");
            System.out.println("2. Remove Patient");
            System.out.println("3. Update Patient");
            System.out.println("4. Add Doctor");
            System.out.println("5. Remove Doctor");
            System.out.println("6. Update Doctor");
            System.out.println("7. Schedule Appointment");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");

            int choice = -1;
            try {
                choice = scanner.nextInt();
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a valid number.");
                scanner.next(); // Clear invalid input
                continue;
            }

            switch (choice) {
                case 1:
                    // Add Patient
                    try {
                        System.out.print("Enter Patient ID: ");
                        String patientId = scanner.next();
                        System.out.print("Enter Patient Name: ");
                        String patientName = scanner.next();
                        System.out.print("Enter Patient Contact Number: ");
                        String patientContact = scanner.next();
                        System.out.print("Enter Patient Medical History: ");
                        String medicalHistory = scanner.next();
                        Patient patient = new Patient(patientId, patientName, patientContact, medicalHistory);
                        clinicSystem.addPatient(patient);
                    } catch (Exception e) {
                        System.out.println("Error adding patient: " + e.getMessage());
                    }
                    break;

                case 2:
                    // Remove Patient
                    try {
                        System.out.print("Enter Patient ID to remove: ");
                        int patientIdToRemove = scanner.nextInt();
                        clinicSystem.removePatient(patientIdToRemove);
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input. Please enter a valid number.");
                        scanner.next(); // Clear invalid input
                    }
                    break;

                case 3:
                    // Update Patient
                    try {
                        System.out.print("Enter Patient ID to update: ");
                        int patientIdToUpdate = scanner.nextInt();
                        System.out.print("Enter Updated Patient Name: ");
                        String updatedPatientName = scanner.next();
                        System.out.print("Enter Updated Patient Contact Number: ");
                        String updatedPatientContact = scanner.next();
                        System.out.print("Enter Updated Patient Medical History: ");
                        String updatedMedicalHistory = scanner.next();
                        Patient updatedPatient = new Patient(String.valueOf(patientIdToUpdate), updatedPatientName,
                                updatedPatientContact, updatedMedicalHistory);
                        clinicSystem.updatePatient(patientIdToUpdate, updatedPatient);
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input. Please enter a valid number.");
                        scanner.next(); // Clear invalid input
                    }
                    break;

                case 4:
                    // Add Doctor
                    try {
                        System.out.print("Enter Doctor ID: ");
                        String doctorId = scanner.next();
                        System.out.print("Enter Doctor Name: ");
                        String doctorName = scanner.next();
                        System.out.print("Enter Doctor Specialization: ");
                        String doctorSpecialization = scanner.next();
                        System.out.print("Enter Doctor Contact Number: ");
                        String doctorContact = scanner.next();
                        Doctor doctor = new Doctor(doctorId, doctorName, doctorSpecialization, doctorContact);
                        clinicSystem.addDoctor(doctor);
                    } catch (Exception e) {
                        System.out.println("Error adding doctor: " + e.getMessage());
                    }
                    break;

                case 5:
                    // Remove Doctor
                    try {
                        System.out.print("Enter Doctor ID to remove: ");
                        int doctorIdToRemove = scanner.nextInt();
                        clinicSystem.removeDoctor(doctorIdToRemove);
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input. Please enter a valid number.");
                        scanner.next(); // Clear invalid input
                    }
                    break;

                case 6:
                    // Update Doctor
                    try {
                        System.out.print("Enter Doctor ID to update: ");
                        int doctorIdToUpdate = scanner.nextInt();
                        System.out.print("Enter Updated Doctor Name: ");
                        String updatedDoctorName = scanner.next();
                        System.out.print("Enter Updated Doctor Specialization: ");
                        String updatedDoctorSpecialization = scanner.next();
                        System.out.print("Enter Updated Doctor Contact Number: ");
                        String updatedDoctorContact = scanner.next();
                        Doctor updatedDoctor = new Doctor(String.valueOf(doctorIdToUpdate), updatedDoctorName,
                                updatedDoctorSpecialization, updatedDoctorContact);
                        clinicSystem.updateDoctor(doctorIdToUpdate, updatedDoctor);
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input. Please enter a valid number.");
                        scanner.next(); // Clear invalid input
                    }
                    break;

                case 7:
                    // Schedule Appointment
                    try {
                        System.out.print("Enter Patient ID: ");
                        int patientIdForAppointment = scanner.nextInt();
                        System.out.print("Enter Doctor ID: ");
                        int doctorIdForAppointment = scanner.nextInt();
                        System.out.print("Enter Appointment Date and Time (YYYY-MM-DDTHH:MM): ");
                        String appointmentDateTimeStr = scanner.next();
                        LocalDateTime appointmentDateTime = LocalDateTime.parse(appointmentDateTimeStr);
                        clinicSystem.scheduleAppointment(patientIdForAppointment, doctorIdForAppointment,
                                appointmentDateTime);
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input. Please enter a valid number.");
                        scanner.next(); // Clear invalid input
                    } catch (DateTimeParseException e) {
                        System.out.println("Invalid date/time format. Please enter in the format YYYY-MM-DDTHH:MM.");
                    }
                    break;

                case 8:
                    System.out.println("Exiting...");
                    scanner.close();
                    System.exit(0);

                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
