public class Doctor {
    // Attributes
    private String id;
    private String name;
    private String specialization;
    private String contactNumber;

    // Constructor
    public Doctor(String id, String name, String specialization, String contactNumber) {
        this.id = id;
        this.name = name;
        this.specialization = specialization;
        this.contactNumber = contactNumber;
    }

    // Getter for id
    public String getId() {
        return id;
    }

    // Setter for id
    public void setId(String id) {
        this.id = id;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Setter for name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for specialization
    public String getSpecialization() {
        return specialization;
    }

    // Setter for specialization
    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    // Getter for contactNumber
    public String getContactNumber() {
        return contactNumber;
    }

    // Setter for contactNumber
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    // toString method to display doctor details
    @Override
    public String toString() {
        return "Doctor [ID: " + id + ", Name: " + name + ", Specialization: " + specialization + ", Contact Number: "
                + contactNumber + "]";
    }
}
