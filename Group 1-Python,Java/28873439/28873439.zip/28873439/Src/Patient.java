public class Patient {
    // Attributes
    private String id;
    private String name;
    private String contactNumber;
    private String medicalHistory;

    // Constructor
    public Patient(String id, String name, String contactNumber, String medicalHistory) {
        this.id = id;
        this.name = name;
        this.contactNumber = contactNumber;
        this.medicalHistory = medicalHistory;
    }

    // Getter for id
    public String getId() {
        return id;
    }

    // Setter for id
    public void setId(String id) {
        this.id = id;
    }

    // Getter for name
    public String getName() {
        return name;
    }

    // Setter for name
    public void setName(String name) {
        this.name = name;
    }

    // Getter for contactNumber
    public String getContactNumber() {
        return contactNumber;
    }

    // Setter for contactNumber
    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    // Getter for medicalHistory
    public String getMedicalHistory() {
        return medicalHistory;
    }

    // Setter for medicalHistory
    public void setMedicalHistory(String medicalHistory) {
        this.medicalHistory = medicalHistory;
    }

    // toString method to display the patient details
    @Override
    public String toString() {
        return "Patient [ID: " + id + ", Name: " + name + ", Contact Number: " + contactNumber + ", Medical History: "
                + medicalHistory + "]";
    }
}
