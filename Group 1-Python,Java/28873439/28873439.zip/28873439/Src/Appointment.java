import java.time.LocalDateTime; // Import for handling date and time

public class Appointment {
    // Attributes
    private String id;
    private String patientId;
    private String doctorId;
    private LocalDateTime appointmentDateTime;

    // Constructor
    public Appointment(String id, String patientId, String doctorId, LocalDateTime appointmentDateTime) {
        this.id = id;
        this.patientId = patientId;
        this.doctorId = doctorId;
        this.appointmentDateTime = appointmentDateTime;
    }

    // Getter for id
    public String getId() {
        return id;
    }

    // Setter for id
    public void setId(String id) {
        this.id = id;
    }

    // Getter for patientId
    public String getPatientId() {
        return patientId;
    }

    // Setter for patientId
    public void setPatientId(String patientId) {
        this.patientId = patientId;
    }

    // Getter for doctorId
    public String getDoctorId() {
        return doctorId;
    }

    // Setter for doctorId
    public void setDoctorId(String doctorId) {
        this.doctorId = doctorId;
    }

    // Getter for appointmentDateTime
    public LocalDateTime getAppointmentDateTime() {
        return appointmentDateTime;
    }

    // Setter for appointmentDateTime
    public void setAppointmentDateTime(LocalDateTime appointmentDateTime) {
        this.appointmentDateTime = appointmentDateTime;
    }

    // toString method to display appointment details
    @Override
    public String toString() {
        return "Appointment [ID: " + id + ", Patient ID: " + patientId + ", Doctor ID: " + doctorId +
                ", Appointment Date and Time: " + appointmentDateTime + "]";
    }
}
