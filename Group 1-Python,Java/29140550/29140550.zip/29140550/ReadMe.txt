Inventory Management System
Documentation
1. How to Run the Application
To run the Inventory Management System, follow these steps:

Ensure Java is Installed: Make sure you have Java Development Kit (JDK) installed on your machine. You can download it from Oracle's website or use OpenJDK.

Compile the Code:

Open a terminal or command prompt.
Navigate to the directory containing the Main.java file.
Compile the code using the following command:
bash
Copy code
javac Main.java
Run the Application:

Execute the compiled program using:

bash
Copy code
java Main
This will run the main method in the Main class, which will execute the test cases and display the results in the console.

2. Instructions for Each Feature
Add Products:

Products can be added using the addProduct(Product p) method. Provide a Product object with details such as ID, name, category, price, and quantity.
Example:
java
Copy code
Product p1 = new Product(1, "Laptop", "Electronics", 999.99, 10);
inventory.addProduct(p1);
Remove Products:

Products can be removed using the removeProduct(int productId) method. Pass the product ID to remove the product from the inventory.
Example:
java
Copy code
inventory.removeProduct(1);
Update Products:

Update product details using the updateProduct(int productId, Product updatedProduct) method. Provide the old product ID and a new Product object with updated details.
Example:
java
Copy code
Product updatedP1 = new Product(1, "Gaming Laptop", "Electronics", 1099.99, 10);
inventory.updateProduct(1, updatedP1);
Search for Products:

Search for products by name or category using the searchProduct(String keyword) method. Provide a keyword to find products matching the name or category.
Example:
java
Copy code
inventory.searchProduct("Electronics");
View Inventory Status:

View the total number of products and total inventory value using the viewInventoryStatus() method.
Example:
java
Copy code
inventory.viewInventoryStatus();
3. Explanation of Exception Handling Implemented
The InventoryException class is used to handle errors related to invalid product data. It extends RuntimeException and includes custom validation logic. The following validation checks are implemented:

Invalid Product ID: Ensures the product ID is greater than 0.
Empty or Null Name: Ensures the product name is not null or empty.
Empty or Null Category: Ensures the product category is not null or empty.
Negative Price: Ensures the product price is not negative.
Negative Quantity: Ensures the product quantity is not negative.
If any of these conditions are violated, an InventoryException is thrown with a descriptive message. The exception handling in the addProduct method catches these exceptions and prints an error message to the console.

Application Design and Object-Oriented Principles
Design Overview
The Inventory Management System is designed to manage product records efficiently using Java Collections. The design focuses on simplicity, performance, and ease of use.

Object-Oriented Principles Applied
Encapsulation:

The Product class encapsulates product attributes and provides getters and setters to access and modify these attributes.
The InventoryManagement class encapsulates inventory management logic, including adding, removing, updating, and searching for products.
Abstraction:

The Product class abstracts the details of individual products, while the InventoryManagement class abstracts the details of managing the product inventory.
Inheritance:

Although not directly used in this specific implementation, the InventoryException class extends RuntimeException, demonstrating inheritance by creating a custom exception type.
Polymorphism:

The use of polymorphism is demonstrated by methods like printDetails in the Product class, which provides a specific implementation for printing product details.
Composition:

The InventoryManagement class is composed of multiple HashMap objects (products, nameMap, and categoryMap) and utilizes these components to manage the inventory.
Conclusion
The Inventory Management System leverages core Java features and object-oriented principles to provide a robust solution for managing product inventories. By focusing on efficient data structures and clear method implementations, the system is designed to be both effective and easy to use.