import java.util.ArrayList; // Import for ArrayList class
import java.util.HashMap;  // Import for HashMap class
import java.util.List;     // Import for List interface
import java.util.Map;      // Import for Map interface

// Define the Product class with properties and methods
class Product {
    private int id;          // Product ID
    private String name;    // Product name
    private String category; // Product category
    private double price;    // Product price
    private double quantity; // Product quantity

    // Constructor to initialize Product
    public Product(int id, String name, String category, double price, double quantity) {
        setId(id); setName(name); setCategory(category);
        setPrice(price); setQuantity(quantity);
    }

    // Getter methods for Product attributes
    public double getPrice() {
        return price;
    }

    public double getQuantity() {
        return quantity;
    }

    public int getId() {
        return id;
    }

    public String getCategory() {
        return category;
    }

    public String getName() {
        return name;
    }

    // Setter methods for Product attributes
    public void setCategory(String category) {
        this.category = category;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    // Method to print Product details
    public void printDetails() {
        System.out.println("The product " + getName() + " with id " + getId() + " belongs to the category "
                + getCategory() + " and the quantity of the product is " + getQuantity() + " with a price of " + getPrice());
    }
}

// Define the InventoryManagement class to manage products
class InventoryManagement {
    private HashMap<Integer, Product> products = new HashMap<>(); // Map to store products by ID
    private HashMap<String, List<Integer>> nameMap = new HashMap<>(); // Map to store product IDs by name
    private HashMap<String, List<Integer>> categoryMap = new HashMap<>(); // Map to store product IDs by category
    private double totalInventoryCost; // Total cost of inventory

    // Constructor for InventoryManagement
    public InventoryManagement() {
        double totalInventoryCost = 0.0; // Initialize total inventory cost
    }

    // Method to add a product to inventory
    public void addProduct(Product p) {
        try {
            InventoryException.validateProduct(p); // Validate the product before adding
            products.put(p.getId(), p); // Add product to the products map

            // Process product name
            String name = p.getName().toLowerCase();
            nameMap.putIfAbsent(name, new ArrayList<>()); // Initialize name list if absent
            nameMap.get(name).add(p.getId()); // Add product ID to name list

            // Process product category
            String category = p.getCategory().toLowerCase();
            categoryMap.putIfAbsent(category, new ArrayList<>()); // Initialize category list if absent
            categoryMap.get(category).add(p.getId()); // Add product ID to category list

            // Update total inventory cost
            totalInventoryCost += (p.getPrice() * p.getQuantity());
            System.out.println("Product Added Successfully to inventory");
        } catch (InventoryException e) {
            System.out.println("Error adding product: " + e.getMessage()); // Handle validation error
        }
    }//time complexity is O(1) on average

    // Method to remove a product from inventory by ID
    public void removeProduct(int productId) {
        if (!products.containsKey(productId)) { // Check if product exists
            System.out.print("Product Not found in inventory\nPlease add product");
            return;
        }

        // Remove product by name
        String name = products.get(productId).getName().toLowerCase();
        List<Integer> nameList = nameMap.get(name);
        if (nameList != null) {
            nameList.remove(Integer.valueOf(productId)); // Remove product ID from name list
            if (nameList.isEmpty()) {
                nameMap.remove(name); // Remove name entry if list is empty
            }
        }

        // Remove product by category
        String category = products.get(productId).getCategory().toLowerCase();
        List<Integer> categoryList = categoryMap.get(category);
        if (categoryList != null) {
            categoryList.remove(Integer.valueOf(productId)); // Remove product ID from category list
            if (categoryList.isEmpty()) {
                categoryMap.remove(category); // Remove category entry if list is empty
            }
        }

        // Update total inventory cost
        totalInventoryCost -= (products.get(productId).getPrice() * products.get(productId).getQuantity());
        products.remove(productId); // Remove product from the products map
        System.out.println("Product Removed Successfully from the inventory");
    }//time complexity is O(1) on average

    // Method to update a product's details
    public void updateProduct(int productId, Product updatedProduct) {
        if (!products.containsKey(productId)) { // Check if product exists
            System.out.print("Product Not found in inventory\nPlease add product");
            return;
        }

        Product oldProduct = products.get(productId); // Get old product details
        String oldName = oldProduct.getName().toLowerCase();
        String oldCategory = oldProduct.getCategory().toLowerCase();
        String newName = updatedProduct.getName().toLowerCase();
        String newCategory = updatedProduct.getCategory().toLowerCase();
        int newId = updatedProduct.getId();
        int oldId = productId;

        // Update product details based on changes
        if (!oldName.equals(newName) && (!oldCategory.equals(newCategory))) {
            updateName(oldProduct, updatedProduct);
            updateCategory(oldProduct, updatedProduct);
        } else if (!oldName.equals(newName)) {
            updateName(oldProduct, updatedProduct);
        } else if (!oldCategory.equals(newCategory)) {
            updateCategory(oldProduct, updatedProduct);
        } else if (oldId != newId) {
            updateId(oldProduct, updatedProduct);
        }

        // Update total inventory cost
        totalInventoryCost -= oldProduct.getPrice() * oldProduct.getQuantity();
        totalInventoryCost += updatedProduct.getPrice() * updatedProduct.getQuantity();
        products.remove(oldId); // Remove old product
        products.put(newId, updatedProduct); // Add updated product
        System.out.println("Product updated in the inventory Successfully");
    }//time complexity is O(1) on average

    // Method to update product ID
    private void updateId(Product oldProduct, Product updatedProduct) {
        int oldId = oldProduct.getId();
        int newId = updatedProduct.getId();
        String oldName = oldProduct.getName().toLowerCase();
        String oldCategory = oldProduct.getCategory().toLowerCase();
        if (oldId != newId) {
            List<Integer> nameList = nameMap.get(oldName);
            if (nameList != null) {
                nameList.remove(Integer.valueOf(oldId)); // Remove old ID from name list
                nameList.add(newId); // Add new ID to name list
            }

            List<Integer> categoryList = categoryMap.get(oldCategory);
            if (categoryList != null) {
                categoryList.remove(Integer.valueOf(oldId)); // Remove old ID from category list
                categoryList.add(newId); // Add new ID to category list
            }
        }
    }

    // Method to update product category
    private void updateCategory(Product oldProduct, Product updatedProduct) {
        String oldCategory = oldProduct.getCategory().toLowerCase();
        String newCategory = updatedProduct.getCategory().toLowerCase();
        List<Integer> oldCategoryList = categoryMap.get(oldCategory);
        if (oldCategoryList != null) {
            oldCategoryList.remove(Integer.valueOf(oldProduct.getId())); // Remove old product ID from old category list
            if (oldCategoryList.isEmpty()) {
                categoryMap.remove(oldCategory); // Remove old category if list is empty
            }
        }
        categoryMap.putIfAbsent(newCategory, new ArrayList<>()); // Initialize new category list if absent
        categoryMap.get(newCategory).add(updatedProduct.getId()); // Add product ID to new category list
    }

    // Method to update product name
    private void updateName(Product oldProduct, Product updatedProduct) {
        String oldName = oldProduct.getName().toLowerCase();
        String newName = updatedProduct.getName().toLowerCase();
        List<Integer> oldNameList = nameMap.get(oldName);
        if (oldNameList != null) {
            oldNameList.remove(Integer.valueOf(oldProduct.getId())); // Remove old product ID from old name list
            if (oldNameList.isEmpty()) {
                nameMap.remove(oldName); // Remove old name if list is empty
            }
        }
        nameMap.putIfAbsent(newName, new ArrayList<>()); // Initialize new name list if absent
        nameMap.get(newName).add(updatedProduct.getId()); // Add product ID to new name list
    }

    // Method to search for products by name or category
    public void searchProduct(String keyword) {
        if (nameMap.containsKey(keyword)) {
            for (int id : nameMap.get(keyword)) {
                Product p = products.get(id);
                if (p != null) p.printDetails(); // Print product details if found
            }
        } else if (categoryMap.containsKey(keyword)) {
            for (int id : categoryMap.get(keyword)) {
                Product p = products.get(id);
                if (p != null) p.printDetails(); // Print product details if found
            }
        } else {
            System.out.println("Name or Category entered is not found in the inventory"); // Indicate no results
        }
    }//time complexity is O(n) (where n is the number of products associated with the keyword)

    // Method to view the status of the inventory
    public void viewInventoryStatus() {
        System.out.println("Total Number of products in the inventory = " + products.size()); // Print total number of products
        System.out.println("Total value of inventory evaluates to " + totalInventoryCost); // Print total value of inventory
    }//time complexity is O(n) (where n is the number of products)
}

// Custom Exception Class for inventory management
class InventoryException extends RuntimeException {
    // Constructor for exception with message
    public InventoryException(String message) {
        super(message);
    }

    // Constructor for exception with message and cause
    public InventoryException(String message, Throwable cause) {
        super(message, cause);
    }

    // Method to validate a product's attributes
    public static void validateProduct(Product p) throws InventoryException {
        if (p.getId() <= 0) {
            throw new InventoryException("Invalid product ID: must be greater than 0."); // Validate ID
        }
        if (p.getName() == null || p.getName().trim().isEmpty()) {
            throw new InventoryException("Product name cannot be null or empty."); // Validate name
        }
        if (p.getCategory() == null || p.getCategory().trim().isEmpty()) {
            throw new InventoryException("Product category cannot be null or empty."); // Validate category
        }
        if (p.getPrice() < 0) {
            throw new InventoryException("Product price cannot be negative."); // Validate price
        }
        if (p.getQuantity() < 0) {
            throw new InventoryException("Product quantity cannot be negative."); // Validate quantity
        }
    }
}

// Main class to test the InventoryManagement system
public class Main {
    public static void main(String[] args) {
        InventoryManagement inventory = new InventoryManagement(); // Create inventory management instance

        // Test Case 1: Add Products
        System.out.println("Adding Products:");
        Product p1 = new Product(1, "Laptop", "Electronics", 999.99, 10);
        Product p2 = new Product(2, "Phone", "Electronics", 499.99, 20);
        Product p3 = new Product(3, "Desk", "Furniture", 150.00, 5);
        Product p4 = new Product(4, "Chair", "Furniture", 75.00, 15);

        inventory.addProduct(p1); // Add product p1
        inventory.addProduct(p2); // Add product p2
        inventory.addProduct(p3); // Add product p3
        inventory.addProduct(p4); // Add product p4

        // View inventory status after adding products
        inventory.viewInventoryStatus();

        // Test Case 2: Search Products by Name
        System.out.println("\nSearching Products by Name:");
        inventory.searchProduct("laptop"); // should find p1
        inventory.searchProduct("phone");  // should find p2
        inventory.searchProduct("desk");   // should find p3
        inventory.searchProduct("chair");  // should find p4

        // Test Case 3: Search Products by Category
        System.out.println("\nSearching Products by Category:");
        inventory.searchProduct("electronics"); // should find p1 and p2
        inventory.searchProduct("furniture");   // should find p3 and p4

        // Test Case 4: Update Products
        System.out.println("\nUpdating Products:");
        Product updatedP1 = new Product(1, "Gaming Laptop", "Electronics", 1099.99, 10);
        Product updatedP2 = new Product(2, "Smartphone", "Electronics", 549.99, 20);
        inventory.updateProduct(1, updatedP1); // Update product p1
        inventory.updateProduct(2, updatedP2); // Update product p2

        // View inventory status after updating products
        inventory.viewInventoryStatus();
        inventory.searchProduct("electronics"); // should find updated p1 and p2

        // Test Case 5: Remove Products
        System.out.println("\nRemoving Products:");
        inventory.removeProduct(3); // Remove product p3 (desk)
        inventory.removeProduct(4); // Remove product p4 (chair)

        // View inventory status after removing products
        inventory.viewInventoryStatus();

        // Test Case 6: Search for Removed Products
        System.out.println("\nSearching for Removed Products:");
        inventory.searchProduct("desk");  // Should not find anything
        inventory.searchProduct("chair"); // Should not find anything

        // Test Case 7: Handle Non-existent Products
        System.out.println("\nHandling Non-existent Products:");
        inventory.searchProduct("nonexistent"); // Should indicate not found
        inventory.removeProduct(999); // Try to remove a product that doesn't exist

        // Test Case 8: Exception Handling for Invalid Product Addition
        System.out.println("\nTesting Exception Handling for Invalid Product Addition:");
        try {
            Product invalidProduct1 = new Product(0, "Invalid Product", "Category", 100.00, 10); // Invalid ID
            inventory.addProduct(invalidProduct1);
        } catch (InventoryException e) {
            System.out.println("Exception caught: " + e.getMessage()); // Catch and print exception
        }

        try {
            Product invalidProduct2 = new Product(5, "", "Category", 100.00, 10); // Invalid Name
            inventory.addProduct(invalidProduct2);
        } catch (InventoryException e) {
            System.out.println("Exception caught: " + e.getMessage()); // Catch and print exception
        }

        try {
            Product invalidProduct3 = new Product(6, "Valid Product", "", 100.00, 10); // Invalid Category
            inventory.addProduct(invalidProduct3);
        } catch (InventoryException e) {
            System.out.println("Exception caught: " + e.getMessage()); // Catch and print exception
        }

        try {
            Product invalidProduct4 = new Product(7, "Valid Product", "Category", -100.00, 10); // Invalid Price
            inventory.addProduct(invalidProduct4);
        } catch (InventoryException e) {
            System.out.println("Exception caught: " + e.getMessage()); // Catch and print exception
        }

        try {
            Product invalidProduct5 = new Product(8, "Valid Product", "Category", 100.00, -10); // Invalid Quantity
            inventory.addProduct(invalidProduct5);
        } catch (InventoryException e) {
            System.out.println("Exception caught: " + e.getMessage()); // Catch and print exception
        }
    }
}
