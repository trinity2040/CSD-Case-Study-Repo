package library_management_system;

public class Book {

	    private int id;
	    private String title;
	    private String author;
	    private String category;
	    private int availableCopies;
	    
	    public Book(int id, String title, String author, String category, int availableCopies) {
	        this.id = id;
	        this.title = title;
	        this.author = author;
	        this.category = category;
	        this.availableCopies = availableCopies;
	    }
	    
	    //getters
	    
	    public int getId() {
	        return id;
	    }

	    public String getTitle() {
	        return title;
	    }

	    public String getAuthor() {
	        return author;
	    }

	    public String getCategory() {
	        return category;
	    }

	    public int getAvailableCopies() {
	        return availableCopies;
	    }
	    
	    //setters
	    
	    public void setId(int id) {
	    	this.id=id;
	    }
	    
	    public void setTitle(String t) {
	    	this.title=t;
	    }
	    
	    public void setAuthor(String a) {
	    	this.author=a;
	    }
	    
	    public void setCategory(String c) {
	    	this.category=c;
	    }
	    public void setAvailableCopies(int ac) {
	    	this.availableCopies=ac;
	    }
	    
	    public String toString() {
	    	
	    	return "Book Details: ID=" + id + ", Title=" + title + ", Author=" + author + ", Category=" + category
	                + ", Available Copies=" + availableCopies;
	    }
	    
	    
}
