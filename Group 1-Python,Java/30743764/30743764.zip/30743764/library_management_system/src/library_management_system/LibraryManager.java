package library_management_system;

import java.util.*;

public class LibraryManager {
    private Map<Integer, Book> books;
    private Map<Integer, LibraryMember> members;
    private Map<Integer, Integer> bcount;

    public LibraryManager() {
        this.books = new HashMap<>();
        this.members = new HashMap<>();
        this.bcount = new HashMap<>();
    }

    // Search for books by title, author, or category
    public List<Book> searchBooks(String keyword) {
        List<Book> answer = new ArrayList<>();
        for (Book b : books.values()) {
            if (b.getTitle().toLowerCase().contains(keyword.toLowerCase()) ||
                b.getAuthor().toLowerCase().contains(keyword.toLowerCase()) ||
                b.getCategory().toLowerCase().contains(keyword.toLowerCase())) {
                answer.add(b);
            }
        }
        return answer;
    }

    // Checkout a book for a library member
    public void checkoutBook(int m_id, int b_id) throws Exception {
        LibraryMember mem = members.get(m_id);
        Book b = books.get(b_id);

        if (b == null) {
            throw new Exception("Book not found.");
        }

        if (b.getAvailableCopies() <= 0) {
            throw new Exception("No available copies.");
        }

        mem.getBooksBorrowed().add(b);
        b.setAvailableCopies(b.getAvailableCopies() - 1);
        bcount.put(b_id, bcount.getOrDefault(b_id, 0) + 1);
    }

    // Return a book borrowed by a library member
    public void returnBook(int m_id, int b_id) throws Exception {
        LibraryMember mem = members.get(m_id);
        Book b = books.get(b_id);

        if (b == null || !mem.getBooksBorrowed().remove(b)) {
            throw new Exception("This book was not borrowed by the member.");
        }

        b.setAvailableCopies(b.getAvailableCopies() + 1);
    }

    // Calculate fine for a library member
    public double calculateFine(int m_id) throws Exception {
        LibraryMember mem = members.get(m_id);
        if (mem == null) {
            throw new Exception("Member not found.");
        }

        double fineAmount = mem.getBooksBorrowed().size() * 2.0;//fine is 2$ for per borrowed book
        mem.setFineAmount(fineAmount);
        return fineAmount;
    }

    // Generate report of most borrowed books
    public List<Book> generatePopularBooksReport() {
        List<Map.Entry<Integer, Integer>> sortedlist = new ArrayList<>(bcount.entrySet());
        sortedlist.sort(Map.Entry.comparingByValue(Comparator.reverseOrder()));

        List<Book> pop = new ArrayList<>();
        for (Map.Entry<Integer, Integer> entry : sortedlist) {
            pop.add(books.get(entry.getKey()));
        }
        return pop;
    }

    
    public void addBook(Book b) {
        books.put(b.getId(), b);
    }

    public void addMember(LibraryMember mem) {
        members.put(mem.getId(), mem);
    }

    public Book getBookById(int b_id) throws Exception {
        if (!books.containsKey(b_id)) {
            throw new Exception("Book with ID: " + b_id + " could not be found.");
        }
        return books.get(b_id);
    }

    public LibraryMember getMemberById(int m_id) throws Exception {
        if (!members.containsKey(m_id)) {
            throw new Exception("Member with ID: " + m_id + " could not be found.");
        }
        return members.get(m_id);
    }

    public void addMemberWithBooks(int m_id, String name, List<Integer> bookIds) throws Exception {
        LibraryMember mem = new LibraryMember(m_id, name);
        for (int b_id : bookIds) {
            Book b = getBookById(b_id);
            if (b.getAvailableCopies() > 0) {
                mem.getBooksBorrowed().add(b);
                b.setAvailableCopies(b.getAvailableCopies() - 1);
                bcount.put(b_id, bcount.getOrDefault(b_id, 0) + 1);
            } else {
                System.out.println("Book ID " + b_id + " is not available for borrowing.");
            }
        }
        addMember(mem);
    }
}
