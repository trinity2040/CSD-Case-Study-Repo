package library_management_system;
import java.util.ArrayList;
import java.util.List;

public class LibraryMember {
	private int id;
    private String name;
    private List<Book> booksBorrowed;
    private double fineAmount;

    public LibraryMember(int id, String name) {
        this.id = id;
        this.name = name;
        this.booksBorrowed = new ArrayList<>();
        this.fineAmount = 0.0;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public List<Book> getBooksBorrowed() { return booksBorrowed; }
    public void setBooksBorrowed(List<Book> booksBorrowed) { this.booksBorrowed = booksBorrowed; }

    public double getFineAmount() { return fineAmount; }
    public void setFineAmount(double fineAmount) { this.fineAmount = fineAmount; }

    public String toString() {
        return "Member ID: " + id + ", Name: " + name + ", Fine Amount: $" + fineAmount;
    }

}
