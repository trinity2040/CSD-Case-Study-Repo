package library_management_system;

import java.util.*;

public class LMS {
    public static void main(String[] args) {
        LibraryManager mgr = new LibraryManager();
        Scanner sc = new Scanner(System.in);

        mgr.addBook(new Book(1, "The God of Small Things", "Arundhati Roy", "Fiction", 5));
        mgr.addBook(new Book(2, "Midnight's Children", "Salman Rushdie", "Fiction", 3));
        mgr.addBook(new Book(3, "A Suitable Boy", "Vikram Seth", "Fiction", 4));
        mgr.addBook(new Book(4, "The White Tiger", "Aravind Adiga", "Fiction", 6));
        mgr.addBook(new Book(5, "The Inheritance of Loss", "Kiran Desai", "Fiction", 2));
        mgr.addBook(new Book(6, "The Immortals of Meluha", "Amish Tripathi", "Mythology", 8));
        mgr.addBook(new Book(7, "Gitanjali", "Rabindranath Tagore", "Poetry", 7));
        mgr.addBook(new Book(8, "Train to Pakistan", "Khushwant Singh", "Historical Fiction", 5));
        mgr.addBook(new Book(9, "The Palace of Illusions", "Chitra Banerjee Divakaruni", "Mythology", 3));
        mgr.addBook(new Book(10, "An Era of Darkness", "Shashi Tharoor", "Non-Fiction", 4));

        try {
            mgr.addMemberWithBooks(1, "Rahul Kumar", Arrays.asList(1, 3));
            mgr.addMemberWithBooks(2, "Sunita Williams", Arrays.asList(2, 6, 8));
            mgr.addMemberWithBooks(3, "Satyam Singh", Arrays.asList(4, 7));
            mgr.addMemberWithBooks(4, "Prity Gupta", Arrays.asList(9, 10));
            mgr.addMemberWithBooks(5, "Amit Sharma", Arrays.asList(1, 2, 5));
            mgr.addMemberWithBooks(6, "Kamran Mehta", Arrays.asList(3, 6, 9));
            mgr.addMemberWithBooks(7, "Aditya Narayan", Arrays.asList(4, 7));
            mgr.addMemberWithBooks(8, "Simrat Kaur", Arrays.asList(5, 8, 10));
            mgr.addMemberWithBooks(9, "Anil Chaudhary", Arrays.asList(2, 5, 9));
            mgr.addMemberWithBooks(10, "Sonia Sen", Arrays.asList(1, 3, 7));
            
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        }

        boolean flag = true;

        while (flag) {
            System.out.println("Library Management System");
            System.out.println("1. Search for Books");
            System.out.println("2. Checkout Book");
            System.out.println("3. Return Book");
            System.out.println("4. Calculate Fine");
            System.out.println("5. Generate Popular Books Report");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int ch = sc.nextInt();
            sc.nextLine(); // Consume newline

            try {
                switch (ch) {
                    case 1:
                        System.out.print("Enter keyword to search for books: ");
                        String keyword = sc.nextLine();
                        List<Book> found = mgr.searchBooks(keyword);
                        
                        if (found.isEmpty()) {
                            System.out.println("No books found.");
                        } else {
                            found.forEach(System.out::println);
                        }
                        break;

                    case 2:
                        System.out.print("Enter Member ID: ");
                        int m_id = sc.nextInt();
                        System.out.print("Enter Book ID: ");
                        int b_id = sc.nextInt();
                        mgr.checkoutBook(m_id, b_id);
                        System.out.println("Book checked out successfully.");
                        break;

                    case 3:
                        System.out.print("Enter Member ID: ");
                        m_id = sc.nextInt();
                        System.out.print("Enter Book ID: ");
                        b_id = sc.nextInt();
                        mgr.returnBook(m_id, b_id);
                        System.out.println("Book returned successfully.");
                        break;

                    case 4:
                        System.out.print("Enter Member ID: ");
                        m_id = sc.nextInt();
                        double fineAmount = mgr.calculateFine(m_id);
                        System.out.println("Fine amount: $" + fineAmount);
                        break;

                    case 5:
                        List<Book> popular = mgr.generatePopularBooksReport();
                        System.out.println("Popular Books:");
                        popular.forEach(System.out::println);
                        break;

                    case 6:
                        flag = false;
                        System.out.println("Exiting the system. Goodbye!");
                        break;

                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            } catch (Exception e) {
                System.out.println("Error: " + e.getMessage());
            }
        }

        sc.close();
    }
}
