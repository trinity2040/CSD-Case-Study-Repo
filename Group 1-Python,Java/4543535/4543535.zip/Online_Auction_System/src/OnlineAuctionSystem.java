import java.util.*;

public class OnlineAuctionSystem {
    // HashMaps to store items and their corresponding bids
    private HashMap<Integer, Item> items = new HashMap<>();
    private HashMap<Integer, ArrayList<Bid>> bids = new HashMap<>();
    private int bidCounter = 1; // Counter to generate unique bid IDs

    // Method to add a new item to the auction system
    public void addItem(Item item) {
        items.put(item.getId(), item); // Add item to the items map
        bids.put(item.getId(), new ArrayList<>()); // Initialize empty bid list for the item
        System.out.println("Item added: " + item);
    }

    // Method to remove an item from the auction system
    public void removeItem(int itemId) {
        if (!items.containsKey(itemId)) {
            System.out.println("Item not found."); // Handle case where item doesn't exist
            return;
        }
        items.remove(itemId); // Remove item from items map
        bids.remove(itemId); // Remove associated bids
        System.out.println("Item removed: " + itemId);
    }

    // Method to update an existing item's details
    public void updateItem(int itemId, Item updatedItem) {
        if (!items.containsKey(itemId)) {
            System.out.println("Item not found."); // Handle case where item doesn't exist
            return;
        }
        items.put(itemId, updatedItem); // Update item details
        System.out.println("Item updated: " + updatedItem);
    }

    // Method to start an auction for an item
    public void startAuction(int itemId) {
        Item item = items.get(itemId);
        if (item == null) {
            System.out.println("Item not found."); // Handle case where item doesn't exist
            return;
        }
        item.setAuctionOpen(true); // Open the auction
        System.out.println("Auction started for item: " + itemId);
    }

    // Method to end an auction for an item
    public void endAuction(int itemId) {
        Item item = items.get(itemId);
        if (item == null) {
            System.out.println("Item not found."); // Handle case where item doesn't exist
            return;
        }
        item.setAuctionOpen(false); // Close the auction
        System.out.println("Auction ended for item: " + itemId);
    }

    // Method to place a bid on an item
    public void placeBid(int itemId, int userId, double bidAmount) {
        Item item = items.get(itemId);
        if (item == null) {
            System.out.println("Item not found."); // Handle case where item doesn't exist
            return;
        }
        if (!item.isAuctionOpen()) {
            System.out.println("Auction is not open for this item."); // Check if auction is open
            return;
        }
        if (bidAmount <= item.getCurrentHighestBid()) {
            System.out.println("Bid must be higher than the current highest bid."); // Ensure bid is valid
            return;
        }
        Bid bid = new Bid(bidCounter++, itemId, userId, bidAmount); // Create new bid
        bids.get(itemId).add(bid); // Add bid to the item's bid list
        item.setCurrentHighestBid(bidAmount); // Update highest bid
        System.out.println("Bid placed: " + bid);
    }

    // Method to view the status of all auctions
    public void viewAuctionStatus() {
        for (Item item : items.values()) {
            System.out.println(item); // Print item details
            System.out.println("Bids:");
            for (Bid bid : bids.get(item.getId())) {
                System.out.println(bid); // Print all bids for the item
            }
            System.out.println(); // Separate items with a blank line
        }
    }

    // Main method to run the auction system
    public static void main(String[] args) {
        OnlineAuctionSystem system = new OnlineAuctionSystem();
        //Sample Input for to check all the features
        // Adding items to the auction system
        Item item1 = new Item(1, "Painting", "Ancient-Wave", 500);
        system.addItem(item1);

        Item item2 = new Item(2, "Watch", "Oldest Model", 300);
        system.addItem(item2);

        // Viewing auction status before any auction starts
        System.out.println("\n--- Viewing Auction Status Before Starting Auctions ---");
        system.viewAuctionStatus();

        // Updating details of an existing item (item2)
        Item updatedItem2 = new Item(2, "Watch", "Oldest Model - Limited Edition", 350);
        system.updateItem(2, updatedItem2);

        // Starting auctions for both items
        system.startAuction(1); // Start auction for the painting
        system.startAuction(2); // Start auction for the watch

        // Placing bids on the items
        system.placeBid(1, 101, 550); // Bid by user 101 on painting
        system.placeBid(1, 102, 600); // Higher bid by user 102 on painting
        system.placeBid(2, 103, 400); // Bid by user 103 on watch

        // Viewing auction status after placing bids
        System.out.println("\n--- Viewing Auction Status After Placing Bids ---");
        system.viewAuctionStatus();

        // Ending the auction for the painting
        system.endAuction(1);

        // Attempt to place a bid on an auction that has ended (should fail)
        system.placeBid(1, 104, 650); // This bid should not be accepted

        // Removing an item (watch) from the auction system before the auction ends
        system.removeItem(2);

        // Viewing final auction status after ending one auction and removing another item
        System.out.println("\n--- Viewing Final Auction Status ---");
        system.viewAuctionStatus();
    }
}
