import java.time.LocalDateTime;

public class Bid {
    // Attributes of the Bid class
    private int id;                // Unique identifier for the bid
    private int itemId;            // ID of the item being bid on
    private int userId;            // ID of the user placing the bid
    private double bidAmount;      // Amount of the bid
    private LocalDateTime bidDateTime; // Date and time when the bid was placed

    // Constructor to initialize a Bid object
    public Bid(int id, int itemId, int userId, double bidAmount) {
        this.id = id;
        this.itemId = itemId;
        this.userId = userId;
        this.bidAmount = bidAmount;
        this.bidDateTime = LocalDateTime.now(); // Capture current date and time
    }

    // Getters for the attributes
    public int getId() {
        return id;
    }

    public int getItemId() {
        return itemId;
    }

    public int getUserId() {
        return userId;
    }

    public double getBidAmount() {
        return bidAmount;
    }

    public LocalDateTime getBidDateTime() {
        return bidDateTime;
    }

    // toString method for printing bid details
    @Override
    public String toString() {
        return "Bid{" +
                "id=" + id +
                ", itemId=" + itemId +
                ", userId=" + userId +
                ", bidAmount=" + bidAmount +
                ", bidDateTime=" + bidDateTime +
                '}';
    }
}
