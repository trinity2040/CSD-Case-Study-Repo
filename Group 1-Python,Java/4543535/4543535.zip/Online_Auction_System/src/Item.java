import java.util.Objects;

public class Item {
    // Attributes of the Item class
    private int id;                    // Unique identifier for the item
    private String name;               // Name of the item
    private String description;        // Description of the item
    private double startingPrice;      // Starting price for the auction
    private double currentHighestBid;  // Current highest bid on the item
    private boolean isAuctionOpen;     // Indicates if the auction is open

    // Constructor to initialize an Item object
    public Item(int id, String name, String description, double startingPrice) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.startingPrice = startingPrice;
        this.currentHighestBid = startingPrice; // Initial bid is the starting price
        this.isAuctionOpen = false; // Auction is initially closed
    }

    // Getters and setters for the attributes
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public double getStartingPrice() {
        return startingPrice;
    }

    public void setStartingPrice(double startingPrice) {
        this.startingPrice = startingPrice;
    }

    public double getCurrentHighestBid() {
        return currentHighestBid;
    }

    public void setCurrentHighestBid(double currentHighestBid) {
        this.currentHighestBid = currentHighestBid;
    }

    public boolean isAuctionOpen() {
        return isAuctionOpen;
    }

    public void setAuctionOpen(boolean auctionOpen) {
        isAuctionOpen = auctionOpen;
    }

    // toString method for printing item details
    @Override
    public String toString() {
        return "Item{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", startingPrice=" + startingPrice +
                ", currentHighestBid=" + currentHighestBid +
                ", isAuctionOpen=" + isAuctionOpen +
                '}';
    }
}
