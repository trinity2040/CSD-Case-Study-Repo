// Book class to store book details

public class Book {
    private int id;
    private String title;
    private String author;
    private String category;
    private int availableCopies;
    private int timesBorrowed;

    public Book(int id, String title, String author, String category, int availableCopies) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.category = category;
        this.availableCopies = availableCopies;
        this.timesBorrowed = 0;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getCategory() {
        return category;
    }

    public int getAvailableCopies() {
        return availableCopies;
    }

    public void borrowBook() {
        if (availableCopies > 0) {
            availableCopies--;
            timesBorrowed++;
        } else {
            throw new IllegalStateException("No copies available for borrowing.");
        }
    }

    public void returnBook() {
        availableCopies++;
    }

    public int getTimesBorrowed() {
        return timesBorrowed;
    }

    @Override
    public String toString() {
        return "Book [ID: " + id + ", Title: " + title + ", Author: " + author +
                ", Category: " + category + ", Available Copies: " + availableCopies + "]";
    }
}
