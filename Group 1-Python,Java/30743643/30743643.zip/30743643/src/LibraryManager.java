// manages all operations

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class LibraryManager {
    private HashMap<Integer, Book> books;
    private HashMap<Integer, LibraryMember> members;

    public LibraryManager() {
        books = new HashMap<>();
        members = new HashMap<>();
    }

    // Add sample data for testing
    public void addSampleData() {
        books.put(1, new Book(1, "The Catcher in the Rye", "J.D. Salinger", "Fiction", 5));
        books.put(2, new Book(2, "The 5 AM Club", "Robin Sharma", "Self-Help", 3));
        books.put(3, new Book(3, "Atomic Habits", "James Clear", "Self-Help", 4));

        members.put(1, new LibraryMember(1, "Ramesh Singh"));
        members.put(2, new LibraryMember(2, "Aditya Joshi"));
    }

    public void searchBooks(String keyword) {
        for (Book book : books.values()) {
            if (book.getTitle().toLowerCase().contains(keyword.toLowerCase()) ||
                    book.getAuthor().toLowerCase().contains(keyword.toLowerCase()) ||
                    book.getCategory().toLowerCase().contains(keyword.toLowerCase())) {
                System.out.println(book);
            }
        }
    }

    public void checkoutBook(int memberId, int bookId) {
        LibraryMember member = members.get(memberId);
        Book book = books.get(bookId);
        if (book != null && member != null) {
            try {
                book.borrowBook();
                member.borrowBook(book);
                System.out.println("Book checked out successfully.");
            } catch (IllegalStateException e) {
                System.out.println(e.getMessage());
            }
        } else {
            System.out.println("Invalid member or book ID.");
        }
    }

    public void returnBook(int memberId, int bookId) {
        LibraryMember member = members.get(memberId);
        Book book = books.get(bookId);
        if (book != null && member != null && member.getBooksBorrowed().contains(book)) {
            book.returnBook();
            member.returnBook(book);
            System.out.println("Book returned successfully.");
        } else {
            System.out.println("Invalid return request.");
        }
    }

    public void calculateFine(int memberId) {
        LibraryMember member = members.get(memberId);
        if (member != null) {
            // In this example, a fixed fine of ₹200/- per book is applied
            double fine = member.getBooksBorrowed().size() * 2;
            member.addFine(fine);
            System.out.println("Fine for member " + memberId + ": ₹" + fine);
        } else {
            System.out.println("Invalid member ID.");
        }
    }

    public void generatePopularBooksReport() {
        List<Book> sortedBooks = new ArrayList<>(books.values());
        sortedBooks.sort((b1, b2) -> Integer.compare(b2.getTimesBorrowed(), b1.getTimesBorrowed()));

        System.out.println("Popular Books Report:");
        for (Book book : sortedBooks) {
            System.out.println(book.getTitle() + " - Borrowed " + book.getTimesBorrowed() + " times.");
        }
    }
}

