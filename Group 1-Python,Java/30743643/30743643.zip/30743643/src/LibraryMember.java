// stores member details
import java.util.ArrayList;
import java.util.List;

public class LibraryMember {
    private int id;
    private String name;
    private List<Book> booksBorrowed;
    private double fineAmount;

    public LibraryMember(int id, String name) {
        this.id = id;
        this.name = name;
        this.booksBorrowed = new ArrayList<>();
        this.fineAmount = 0;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public List<Book> getBooksBorrowed() {
        return booksBorrowed;
    }

    public void borrowBook(Book book) {
        booksBorrowed.add(book);
    }

    public void returnBook(Book book) {
        booksBorrowed.remove(book);
    }

    public double getFineAmount() {
        return fineAmount;
    }

    public void addFine(double amount) {
        fineAmount += amount;
    }

    public void payFine(double amount) {
        fineAmount -= amount;
    }

    @Override
    public String toString() {
        return "LibraryMember [ID: " + id + ", Name: " + name + ", Fine: " + fineAmount + "]";
    }
}
