// Contains all the menus of application

import java.util.Scanner;

public class LibraryManagementSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        LibraryManager manager = new LibraryManager();
        manager.addSampleData();

        while (true) {
            System.out.println("\nLibrary Management System");
            System.out.println("1. Search Books");
            System.out.println("2. Checkout Book");
            System.out.println("3. Return Book");
            System.out.println("4. Calculate Fine");
            System.out.println("5. Popular Books Report");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            int choice = sc.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter keyword to search (title/author/category): ");
                    sc.nextLine();  // Consume newline
                    String keyword = sc.nextLine();
                    manager.searchBooks(keyword);
                    break;
                case 2:
                    System.out.print("Enter Member ID: ");
                    int memberId = sc.nextInt();
                    System.out.print("Enter Book ID: ");
                    int bookId = sc.nextInt();
                    manager.checkoutBook(memberId, bookId);
                    break;
                case 3:
                    System.out.print("Enter Member ID: ");
                    memberId = sc.nextInt();
                    System.out.print("Enter Book ID: ");
                    bookId = sc.nextInt();
                    manager.returnBook(memberId, bookId);
                    break;
                case 4:
                    System.out.print("Enter Member ID: ");
                    memberId = sc.nextInt();
                    manager.calculateFine(memberId);
                    break;
                case 5:
                    manager.generatePopularBooksReport();
                    break;
                case 6:
                    System.out.println("Exiting system.");
                    sc.close();
                    System.exit(0);
                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}
