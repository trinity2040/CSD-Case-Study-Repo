create table Customers(
CUSTOMER_ID number PRIMARY KEY,
FIRST_NAME varchar2(50),
LAST_NAME varchar2(50),
EMAIL varchar2(100),
PHONE_NO varchar2(15),
ADDRESS varchar2(200)
);

create table Products(
PRODUCT_ID number PRIMARY KEY,
PRODUCT_NAME varchar2(100) NOT NULL,
CATEGORY_ varchar2(50),
PRICE number NOT NULL,
STOCK_QUANTITY number
);


create table Orders(
ORDER_ID number PRIMARY KEY,
CUSTOMER_ID number,
ORDER_DATE date,
TOTAL_AMOUNT number NOT NULL,
ORDER_STATUS varchar2(20),
CONSTRAINT fk_customer
FOREIGN KEY(CUSTOMER_ID)
REFERENCES Customers(CUSTOMER_ID)
);


