INSERT ALL
INTO Customers (CUSTOMER_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NO, ADDRESS) VALUES (1, 'John', 'Doe', 'john.doe@reddif.com', '123456', 'Alaska')
INTO Customers (CUSTOMER_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NO, ADDRESS) VALUES (2, 'Jane', 'Smith', 'jane.smith@reddif.com', '789123', 'Springfield')
INTO Customers (CUSTOMER_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NO, ADDRESS) VALUES (3, 'James', 'Pink', 'jamespink1@reddif.com', '456789', 'Australia')
INTO Customers (CUSTOMER_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NO, ADDRESS) VALUES (4, 'Peter', 'Parker', 'pete.parker22@reddif.com', '874912', 'Queens')
INTO Customers (CUSTOMER_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NO, ADDRESS) VALUES (5, 'Tony', 'Stark', 'starkindus@stark.com', '300030', 'Philadelphia')
INTO Customers (CUSTOMER_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NO, ADDRESS) VALUES (6, 'Jon', 'Jones', 'jonesjon@reddif.com', '435942', 'Springfield')
INTO Customers (CUSTOMER_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NO, ADDRESS) VALUES (7, 'Steve', 'Rogers', 'winter@reddif.com', '354855', 'Los Angeles')
INTO Customers (CUSTOMER_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NO, ADDRESS) VALUES (8, 'Andrew', 'Garfield', 'orangecat@reddif.com', '468765', 'New Jersey')
INTO Customers (CUSTOMER_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NO, ADDRESS) VALUES (9, 'Scarlett', 'Johanson', 'johnanson.scarlett@hotmail.com', '564685', 'England')
INTO Customers (CUSTOMER_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NO, ADDRESS) VALUES (10, 'Nick', 'Fury', 'shieldbase@shield.com', '486898', 'Yavatmal')

select * from dual;

 INSERT ALL
 INTO Products (PRODUCT_ID, PRODUCT_NAME, CATEGORY_, PRICE, STOCK_QUANTITY) VALUES (1, 'Laptop', 'Electronics', 500000, 50)
 INTO Products (PRODUCT_ID, PRODUCT_NAME, CATEGORY_, PRICE, STOCK_QUANTITY) VALUES (2, 'MobilePhone', 'Electronics', 20000, 2000)
 INTO Products (PRODUCT_ID, PRODUCT_NAME, CATEGORY_, PRICE, STOCK_QUANTITY) VALUES (3, 'Football', 'Sports Equipment', 1000, 746)
 INTO Products (PRODUCT_ID, PRODUCT_NAME, CATEGORY_, PRICE, STOCK_QUANTITY) VALUES (4, 'Matress', 'Home Decor', 3000, 447)
 INTO Products (PRODUCT_ID, PRODUCT_NAME, CATEGORY_, PRICE, STOCK_QUANTITY) VALUES (5, 'Trolley', 'Luggage', 6000, 76)
 
 select * from dual;
 


INSERT ALL 
INTO Orders (ORDER_ID, CUSTOMER_ID, ORDER_DATE, TOTAL_AMOUNT, ORDER_STATUS) VALUES (1, 1, TO_DATE('29-08-2024', 'DD-MM-YYYY'), 56000, 'Shipped')
INTO Orders (ORDER_ID, CUSTOMER_ID, ORDER_DATE, TOTAL_AMOUNT, ORDER_STATUS) VALUES (2, 9, TO_DATE('24-10-2023', 'DD-MM-YYYY'), 1000, 'Delivered')
INTO Orders (ORDER_ID, CUSTOMER_ID, ORDER_DATE, TOTAL_AMOUNT, ORDER_STATUS) VALUES (3, 5, TO_DATE('05-09-2022', 'DD-MM-YYYY'), 500000, 'Canceled')
INTO Orders (ORDER_ID, CUSTOMER_ID, ORDER_DATE, TOTAL_AMOUNT, ORDER_STATUS) VALUES (4, 2, TO_DATE('01-09-2024', 'DD-MM-YYYY'), 3000, 'Processing')
INTO Orders (ORDER_ID, CUSTOMER_ID, ORDER_DATE, TOTAL_AMOUNT, ORDER_STATUS) VALUES (5, 7, TO_DATE('22-01-2024', 'DD-MM-YYYY'), 20000, 'Shipped')

select * from dual;

select * from Orders;