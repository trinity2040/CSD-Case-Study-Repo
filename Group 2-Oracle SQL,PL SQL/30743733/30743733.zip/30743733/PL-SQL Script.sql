CREATE PROCEDURE Create_Order (
    p_order_id IN NUMBER,
    p_customer_id IN NUMBER,
    p_order_date IN DATE,
    p_total_amount IN NUMBER,
    p_order_status IN VARCHAR2
) AS
BEGIN
    INSERT INTO Orders (ORDER_ID, CUSTOMER_ID, ORDER_DATE, TOTAL_AMOUNT, ORDER_STATUS)
    VALUES (p_order_id, p_customer_id, p_order_date, p_total_amount, p_order_status);
    
    COMMIT;
END;

BEGIN
    Create_Order(
        p_order_id => 6,
        p_customer_id => 6,
        p_order_date => TO_DATE('02-09-2024', 'DD-MM-YYYY'),
        p_total_amount => 350.00,
        p_order_status => 'Processing'
    );
END;


CREATE PROCEDURE Update_Order (
    p_order_id IN NUMBER,
    p_total_amount IN NUMBER,
    p_order_status IN VARCHAR2
) AS
BEGIN
    UPDATE Orders
    SET TOTAL_AMOUNT = p_total_amount,
        ORDER_STATUS = p_order_status
    WHERE ORDER_ID = p_order_id;
    
    COMMIT;
END;

BEGIN
    Update_Order(
        p_order_id => 6,
        p_total_amount => 550.00,
        p_order_status => 'Shipped'
    );
END;


CREATE OR REPLACE PROCEDURE Cancel_Order (
    p_order_id IN NUMBER
) AS
BEGIN
    UPDATE Orders
    SET ORDER_STATUS = 'Cancelled'
    WHERE ORDER_ID = p_order_id;
    
    COMMIT;
END;

BEGIN
    Cancel_Order(
        p_order_id => 4
    );
END;

