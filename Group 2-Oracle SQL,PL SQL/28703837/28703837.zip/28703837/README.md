# Employee Management System

## Project Overview

Employee Management System - implementation is done using using Oracle SQL and PL/SQL.
It manages employee information, departments, and employee-department assignments.

## Setup Instructions

1. Execute 28703837.sql script.
2. All the create table queries, Inserting on sample data, procedure queries are written in this file.

## Running Instructions

- To transfer an employee to another department, execute the TRANSFER_EMPLOYEE procedure:
- TRANSFER_EMPLOYEE(p_employee_id , p_new_department_id );

- To promote an employee, execute the PROMOTE_EMPLOYEE procedure:
- PROMOTE_EMPLOYEE(p_employee_id , p_new_job_id, p_new_salary );

## 28703837.sql Contents:

- Task1: Create 2 tables [Employees, Departments, Employee_Assignments]
- Task2: Insert sample data in all the tables
- Task3: Create 2 Procedures for Employee Transfer and Employee Promotion
- Task4: Test the procedures by Transfering employees & promoting employees
