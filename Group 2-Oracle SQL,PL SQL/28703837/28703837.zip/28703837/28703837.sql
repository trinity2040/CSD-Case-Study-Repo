--TASK1
-- Creating table employees with required columns
CREATE TABLE Employees (
    EMPLOYEE_ID    NUMBER PRIMARY KEY,
    FIRST_NAME     VARCHAR2(50),
    LAST_NAME      VARCHAR2(50),
    EMAIL          VARCHAR2(100),
    PHONE_NUMBER   VARCHAR2(15),
    HIRE_DATE      DATE,
    JOB_ID         VARCHAR2(10),
    SALARY         NUMBER,
    DEPARTMENT_ID  NUMBER
);

-- Creating table departments with required columns
CREATE TABLE Departments (
    DEPARTMENT_ID   NUMBER PRIMARY KEY,
    DEPARTMENT_NAME VARCHAR2(100),
    LOCATION        VARCHAR2(100)
);

-- Creating table Employee-Assignments with required columns
CREATE TABLE Employee_Assignments (
    ASSIGNMENT_ID  NUMBER PRIMARY KEY,
    EMPLOYEE_ID    NUMBER,
    DEPARTMENT_ID  NUMBER,
    START_DATE     DATE,
    END_DATE       DATE
);

-- Assigning department_id as foreign key
ALTER TABLE Employees
ADD CONSTRAINT FK_Employees_Department FOREIGN KEY (DEPARTMENT_ID)
REFERENCES Departments (DEPARTMENT_ID);

-- Assigning EMPLOYEE_ID as foreign key
ALTER TABLE Employee_Assignments
ADD CONSTRAINT FK_Assignments_Employee FOREIGN KEY (EMPLOYEE_ID)
REFERENCES Employees (EMPLOYEE_ID);

-- Assigning DEPARTMENT_ID as foreign key
ALTER TABLE Employee_Assignments
ADD CONSTRAINT FK_Assignments_Department FOREIGN KEY (DEPARTMENT_ID)
REFERENCES Departments (DEPARTMENT_ID);



--TASK2

--inserting sample data into departments table
INSERT INTO Departments (DEPARTMENT_ID, DEPARTMENT_NAME, LOCATION) VALUES (1, 'HR', 'Chennai');
INSERT INTO Departments (DEPARTMENT_ID, DEPARTMENT_NAME, LOCATION) VALUES (2, 'Finance', 'Bengaluru');
INSERT INTO Departments (DEPARTMENT_ID, DEPARTMENT_NAME, LOCATION) VALUES (3, 'IT', 'Hyderabad');


--inserting sample data into Employees table
INSERT INTO Employees (EMPLOYEE_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NUMBER, HIRE_DATE, JOB_ID, SALARY, DEPARTMENT_ID)
VALUES (101, 'Nitish', 'Nirmal', 'nitish.nirmal@gmail.com', '1234567890', TO_DATE('2024-08-30', 'YYYY-MM-DD'), '60', 50000, 1);
INSERT INTO Employees (EMPLOYEE_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NUMBER, HIRE_DATE, JOB_ID, SALARY, DEPARTMENT_ID)
VALUES (102, 'Rahul', 'Singh', 'rahul.singh@gmail.com', '0987654321', TO_DATE('2023-07-18', 'YYYY-MM-DD'), '61', 60000, 2);
INSERT INTO Employees (EMPLOYEE_ID, FIRST_NAME, LAST_NAME, EMAIL, PHONE_NUMBER, HIRE_DATE, JOB_ID, SALARY, DEPARTMENT_ID)
VALUES (103, 'Sakshi', 'S', 'sakshi.s@example.com', '1122334455', TO_DATE('2020-11-24', 'YYYY-MM-DD'), '62', 70000, 3);



--Creating sequence for Assignment_id
--DROP SEQUENCE SEQ_ASSIGNMENT_ID;
CREATE SEQUENCE SEQ_ASSIGNMENT_ID
START WITH 1
INCREMENT BY 1
NOCACHE;

--inserting sample data into Employee_Assignments table
INSERT INTO Employee_Assignments (ASSIGNMENT_ID, EMPLOYEE_ID, DEPARTMENT_ID, START_DATE, END_DATE)
VALUES (SEQ_ASSIGNMENT_ID.NEXTVAL, 101, 1, TO_DATE('2024-08-30', 'YYYY-MM-DD'), NULL);

INSERT INTO Employee_Assignments (ASSIGNMENT_ID, EMPLOYEE_ID, DEPARTMENT_ID, START_DATE, END_DATE)
VALUES (SEQ_ASSIGNMENT_ID.NEXTVAL, 102, 2, TO_DATE('2023-07-18', 'YYYY-MM-DD'), NULL);

INSERT INTO Employee_Assignments (ASSIGNMENT_ID, EMPLOYEE_ID, DEPARTMENT_ID, START_DATE, END_DATE)
VALUES (SEQ_ASSIGNMENT_ID.NEXTVAL, 103, 3, TO_DATE('2020-11-24', 'YYYY-MM-DD'), NULL);

--TASK3
--creating Procedure for  Employee Transfer
CREATE OR REPLACE PROCEDURE Transfer_Employee(
    p_employee_id    IN NUMBER,
    p_new_department_id IN NUMBER
) AS
BEGIN
    -- Updating end_date of the current assignment of Employee
    UPDATE Employee_Assignments
    SET END_DATE = SYSDATE
    WHERE EMPLOYEE_ID = p_employee_id AND END_DATE IS NULL;

     -- Inserting a new assignment for the new department
    INSERT INTO Employee_Assignments (ASSIGNMENT_ID, EMPLOYEE_ID, DEPARTMENT_ID, START_DATE)
    VALUES (SEQ_ASSIGNMENT_ID.NEXTVAL, p_employee_id, p_new_department_id, SYSDATE);

    -- Updating  the new department ID in the Employees table
    UPDATE Employees
    SET DEPARTMENT_ID = p_new_department_id
    WHERE EMPLOYEE_ID = p_employee_id;
    
    COMMIT;
END Transfer_Employee;

--creating Procedure for  Employee promotion
CREATE OR REPLACE PROCEDURE Promote_Employee(
    p_employee_id    IN NUMBER,
    p_new_job_id     IN VARCHAR2,
    p_new_salary     IN NUMBER
) AS
BEGIN
    -- Updating the employee's job ID and salary
    UPDATE Employees
    SET JOB_ID = p_new_job_id, SALARY = p_new_salary
    WHERE EMPLOYEE_ID = p_employee_id;
    
    COMMIT;
END Promote_Employee;




--TASK4
-- Transfer_Employee(Employee_id,department_id) [Testing]
BEGIN
    Transfer_Employee(101, 3);  
END;
--view EMPLOYEE_ASSIGNMENTS table data
--SELECT * FROM EMPLOYEE_ASSIGNMENTS;

-- Promote_Employee(Employee_id,Job_id,salary) [Testing]
BEGIN
    Promote_Employee(102, 63, 75000); 
END;
--view Employees table data
--SELECT * FROM EMPLOYEES;

