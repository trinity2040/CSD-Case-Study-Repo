package dataaccessobject;

import java.util.List;
import java.util.Scanner;

import Models.Route;
import exceptions.DatabaseException;

public class RouteManagement {
    private static RouteDAO routeDAO = new RouteDAO();
    private static Scanner scanner = new Scanner(System.in);

    public static void routeMenu() throws DatabaseException {
        while (true) {
            System.out.println("\nRoute Management");
            System.out.println("1. Add Route");
            System.out.println("2. View Routes");
            System.out.println("3. Update Route");
            System.out.println("4. Delete Route");
            System.out.println("5. Exit");

            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    addRoute();
                    break;
                case 2:
                    viewRoutes();
                    break;
                case 3:
                    updateRoute();
                    break;
                case 4:
                    deleteRoute();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addRoute() throws DatabaseException {
        System.out.print("Enter origin: ");
        String origin = scanner.nextLine();
        System.out.print("Enter destination: ");
        String destination = scanner.nextLine();
        System.out.print("Enter distance (in km): ");
        double distance = scanner.nextDouble();
        System.out.print("Enter estimated duration (in hours): ");
        double duration = scanner.nextDouble();

        routeDAO.addRoute(origin, destination, distance, duration);
    }

    private static void viewRoutes() throws DatabaseException {
        List<Route> routes = routeDAO.getAllRoutes();
        for (Route route : routes) {
            System.out.println(route);
        }
    }

    private static void updateRoute() throws DatabaseException {
        System.out.print("Enter route ID to update: ");
        int routeId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Enter new origin: ");
        String origin = scanner.nextLine();
        System.out.print("Enter new destination: ");
        String destination = scanner.nextLine();
        System.out.print("Enter new distance (in km): ");
        double distance = scanner.nextDouble();
        System.out.print("Enter new estimated duration (in hours): ");
        double duration = scanner.nextDouble();

        routeDAO.updateRoute(routeId, origin, destination, distance, duration);
    }

    private static void deleteRoute() throws DatabaseException {
        System.out.print("Enter route ID to delete: ");
        int routeId = scanner.nextInt();
        scanner.nextLine();  

        routeDAO.deleteRoute(routeId);
    }
}
