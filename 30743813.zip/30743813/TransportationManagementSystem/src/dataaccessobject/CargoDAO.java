package dataaccessobject;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import DataBase.DatabaseConnection;
import Models.Cargo;
import Models.Vehicle;
import exceptions.DatabaseException;
import exceptions.VehicleException;

public class CargoDAO {
    private Connection connection;
    private VehicleDAO vehicleDAO;

    public CargoDAO() {
        connection = DatabaseConnection.getConnection();
        vehicleDAO = new VehicleDAO();
    }

    public void addCargo(String description, double weight, String status, int assignedVehicleId) throws VehicleException, DatabaseException {
        Vehicle vehicle = vehicleDAO.getVehicleById(assignedVehicleId);

        if (vehicle != null && vehicle.getCapacity() >= weight) {
            String sql = "INSERT INTO Cargo (description, weight, status, assigned_vehicle_id) VALUES (?, ?, ?, ?)";
            try (PreparedStatement stmt = connection.prepareStatement(sql)) {
                stmt.setString(1, description);
                stmt.setDouble(2, weight);
                stmt.setString(3, status);
                stmt.setInt(4, assignedVehicleId);
                stmt.executeUpdate();
                vehicleDAO.updateVehicleCapacity(assignedVehicleId, vehicle.getCapacity() - weight);
                System.out.println("Cargo added and assigned to vehicle successfully!");
            } catch (SQLException e) {
            	throw new DatabaseException("Failed to add cargo", e);
            }
        } else {
        	throw new VehicleException("Error: Vehicle does not have enough capacity or is not available.");
        }
    }

    public List<Cargo> getAllCargo() throws DatabaseException {
        List<Cargo> cargoList = new ArrayList<>();
        String sql = "SELECT * FROM Cargo";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Cargo cargo = new Cargo(rs.getInt("cargo_id"), rs.getString("description"),
                        rs.getDouble("weight"), rs.getString("status"), rs.getInt("assigned_vehicle_id"));
                cargoList.add(cargo);
            }
        } catch (SQLException e) {
        	throw new DatabaseException("Failed to fetch cargo list", e);
        }
        return cargoList;
    }

    public void updateCargoStatus(int cargoId, String status) throws DatabaseException {
        String sql = "UPDATE Cargo SET status = ? WHERE cargo_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, status);
            stmt.setInt(2, cargoId);
            stmt.executeUpdate();
            System.out.println("Cargo status updated successfully!");
        } catch (SQLException e) {
        	throw new DatabaseException("Failed to update cargo status", e);
        }
    }

    public void deleteCargo(int cargoId) throws DatabaseException {
        String sql = "DELETE FROM Cargo WHERE cargo_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, cargoId);
            stmt.executeUpdate();
            System.out.println("Cargo deleted successfully!");
        } catch (SQLException e) {
        	throw new DatabaseException("Failed to delete cargo", e);
        }
    }

    public boolean isVehicleAssignedToCargo(int cargoId) throws DatabaseException {
        String sql = "SELECT assigned_vehicle_id FROM Cargo WHERE cargo_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, cargoId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("assigned_vehicle_id") != 0;
            }
        } catch (SQLException e) {
        	throw new DatabaseException("Failed to check if vehicle is assigned to cargo", e);
        }
        return false;
    }
}
