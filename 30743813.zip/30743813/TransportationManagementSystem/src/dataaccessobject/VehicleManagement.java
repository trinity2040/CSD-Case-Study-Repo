package dataaccessobject;

import java.util.List;
import java.util.Scanner;

import Models.Vehicle;
import exceptions.DatabaseException;

public class VehicleManagement {
    private static VehicleDAO vehicleDAO = new VehicleDAO();
    private static Scanner scanner = new Scanner(System.in);

    public static void vehicleMenu() throws DatabaseException {
        while (true) {
            System.out.println("\nVehicle Management");
            System.out.println("1. Add Vehicle");
            System.out.println("2. View Vehicles");
            System.out.println("3. Update Vehicle");
            System.out.println("4. Delete Vehicle");
            System.out.println("5. Exit");

            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine();  // Consume newline

            switch (choice) {
                case 1:
                    addVehicle();
                    break;
                case 2:
                    viewVehicles();
                    break;
                case 3:
                    updateVehicle();
                    break;
                case 4:
                    deleteVehicle();
                    break;
                case 5:
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addVehicle() throws DatabaseException {
        System.out.print("Enter vehicle number: ");
        String vehicleNumber = scanner.nextLine();
        System.out.print("Enter capacity: ");
        int capacity = scanner.nextInt();
        scanner.nextLine();  // Consume newline
        System.out.print("Enter status (Available, In Use, Under Maintenance): ");
        String status = scanner.nextLine();

        vehicleDAO.addVehicle(vehicleNumber, capacity, status);
    }

    private static void viewVehicles() throws DatabaseException {
        List<Vehicle> vehicleList = vehicleDAO.getAllVehicles();
        if (vehicleList.isEmpty()) {
            System.out.println("No vehicles found.");
        } else {
            for (Vehicle vehicle : vehicleList) {
                System.out.println(vehicle);
            }
        }
    }

    private static void updateVehicle() throws DatabaseException {
        System.out.print("Enter vehicle ID to update: ");
        int vehicleId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        System.out.print("Enter new status (Available, In Use, Under Maintenance): ");
        String newStatus = scanner.nextLine();

        vehicleDAO.updateVehicle(vehicleId, newStatus);
    }

    private static void deleteVehicle() throws DatabaseException {
        System.out.print("Enter vehicle ID to delete: ");
        int vehicleId = scanner.nextInt();
        scanner.nextLine();  // Consume newline

        vehicleDAO.deleteVehicle(vehicleId);
    }
}
