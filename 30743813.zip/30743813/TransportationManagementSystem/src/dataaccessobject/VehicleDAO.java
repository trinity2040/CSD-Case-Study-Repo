package dataaccessobject;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import DataBase.DatabaseConnection;
import Models.Vehicle;
import exceptions.DatabaseException;

public class VehicleDAO {
    private Connection connection;

    public VehicleDAO() {
        connection = DatabaseConnection.getConnection();
    }
    public void addVehicle(String vehicleNumber, int capacity, String status) throws DatabaseException {
        String sql = "INSERT INTO Vehicle (vehicle_number, capacity, status) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, vehicleNumber);
            stmt.setInt(2, capacity);
            stmt.setString(3, status);
            stmt.executeUpdate();
            System.out.println("Vehicle added successfully!");
        } catch (SQLException e) {
        	throw new DatabaseException("Failed to add vehicle", e);
        }
    }

    public List<Vehicle> getAllVehicles() throws DatabaseException {
        List<Vehicle> vehicleList = new ArrayList<>();
        String sql = "SELECT * FROM Vehicle";
        try (Statement stmt = connection.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Vehicle vehicle = new Vehicle(rs.getInt("vehicle_id"), rs.getString("vehicle_number"),
                        rs.getInt("capacity"), rs.getString("status"));
                vehicleList.add(vehicle);
            }
        } catch (SQLException e) {
        	throw new DatabaseException("Failed to fetch vehicle list", e);
        }
        return vehicleList;
    }

    

    public void deleteVehicle(int vehicleId) throws DatabaseException {
        String sql = "DELETE FROM Vehicle WHERE vehicle_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, vehicleId);
            stmt.executeUpdate();
            System.out.println("Vehicle deleted successfully!");
        } catch (SQLException e) {
        	throw new DatabaseException("Failed to fetch vehicle by ID", e);
        }
    }


    public Vehicle getVehicleById(int vehicleId) throws DatabaseException {
        String sql = "SELECT * FROM Vehicle WHERE vehicle_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, vehicleId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Vehicle(rs.getInt("vehicle_id"), rs.getString("vehicle_number"),
                        rs.getInt("capacity"), rs.getString("status"));
            }
        } catch (SQLException e) {
        	throw new DatabaseException("Failed to fetch vehicle by ID", e);
        }
        return null;
    }

    public void updateVehicle(int vehicleId, String newStatus) throws DatabaseException {
        String sql = "UPDATE Vehicle SET status = ? WHERE vehicle_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, newStatus);
            stmt.setInt(2, vehicleId);
            stmt.executeUpdate();
            System.out.println("Vehicle status updated successfully!");
        } catch (SQLException e) {
        	throw new DatabaseException("Failed to fetch vehicle by ID", e);
        }
    }
    public void updateVehicleCapacity(int vehicleId, double newCapacity) throws DatabaseException {
        String sql = "UPDATE Vehicle SET capacity = ? WHERE vehicle_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setDouble(1, newCapacity);
            stmt.setInt(2, vehicleId);
            stmt.executeUpdate();
            System.out.println("Vehicle capacity updated successfully!");
        } catch (SQLException e) {
        	throw new DatabaseException("Failed to fetch vehicle by ID", e);
        }
    }
}
