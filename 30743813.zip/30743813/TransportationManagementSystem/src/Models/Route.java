package Models;

public class Route {
    private int routeId;
    private String origin;
    private String destination;
    private double distance;
    private double estimatedDuration;

    public Route(int routeId, String origin, String destination, double distance, double estimatedDuration) {
        this.routeId = routeId;
        this.origin = origin;
        this.destination = destination;
        this.distance = distance;
        this.estimatedDuration = estimatedDuration;
    }

    // Getters and Setters

    @Override
    public String toString() {
        return "Route ID: " + routeId + ", Origin: " + origin + ", Destination: " + destination + ", Distance: " + distance + " km, Duration: " + estimatedDuration + " hours";
    }
}
