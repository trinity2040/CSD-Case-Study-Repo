package Models;

public class Cargo {
    private int cargoId;
    private String description;
    private double weight;
    private String status;
    private int assignedVehicleId;

    public Cargo(int cargoId, String description, double weight, String status, int assignedVehicleId) {
        this.cargoId = cargoId;
        this.description = description;
        this.weight = weight;
        this.status = status;
        this.assignedVehicleId = assignedVehicleId;
    }

    // Getters and Setters

    @Override
    public String toString() {
        return "Cargo ID: " + cargoId + ", Description: " + description + ", Weight: " + weight + " kg, Status: " + status + ", Assigned Vehicle ID: " + assignedVehicleId;
    }
}

